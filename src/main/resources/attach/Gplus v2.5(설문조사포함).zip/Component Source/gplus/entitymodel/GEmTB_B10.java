package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_B10.java
 * Class    : GEmTB_B10
 * Function : Data model of representing parameter data for TB_COMCODE_B10 Table
 * Comment  : table : TB_COMCODE_B10 
 * History  : 
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_B10 {

    private String m_strFldNo = null;
    private String m_strFldName = null;
    private String m_strBoxNo = null;
    private String m_strDocNo = null;
    private String m_strParentNo = null;
    private String m_strRegUser = null;
    private String m_strRegDate = null;
    private String m_strTrashFlag = null;
    private String m_strComments = null;
    private String m_strRefNo = null;

    public String getStrFldNo() { return m_strFldNo; }
    public String getStrFldName() { return m_strFldName; }
    public String getStrBoxNo() { return m_strBoxNo; }
    public String getStrDocNo() { return m_strDocNo; }
    public String getStrParentNo() { return m_strParentNo; }
    public String getStrRegUser() { return m_strRegUser; }
    public String getStrRegDate() { return m_strRegDate; }
    public String getStrTrashFlag() { return m_strTrashFlag; }
    public String getStrComments() { return m_strComments; }
    public String getStrRefNo() { return m_strRefNo; }

    public void setStrFldNo(String s) { m_strFldNo = s; }
    public void setStrFldName(String s) { m_strFldName = s; }
    public void setStrBoxNo(String s) { m_strBoxNo = s; }
    public void setStrDocNo(String s) { m_strDocNo = s; }
    public void setStrParentNo(String s) { m_strParentNo = s; }
    public void setStrRegUser(String s) { m_strRegUser = s; }
    public void setStrRegDate(String s) { m_strRegDate = s; }
    public void setStrTrashFlag(String s) { m_strTrashFlag = s; }
    public void setStrComments(String s) { m_strComments = s; }
    public void setStrRefNo(String s) { m_strRefNo = s; }
}
