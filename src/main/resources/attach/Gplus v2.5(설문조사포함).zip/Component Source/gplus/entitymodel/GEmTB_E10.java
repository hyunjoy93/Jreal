package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_E10.java
 * Class    : GEmTB_E10
 * Function : Data model of representing parameter data for TB_COMCODE_E10 Table
 * Comment  : table : TB_COMCODE_E10 
 * History  : 
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_E10 {

    private String m_strUserId = null;
    private String m_strWriterId = null;
    private String m_strSchdlNo = null;
    private String m_strTitle = null;
    private String m_strGrpNo = null;
    private String m_strStime = null;
    private String m_strLtime = null;
    private String m_strComments = null;
    private String m_strSdate = null;
    private String m_strLdate = null;
    private String m_strRelatMan = null;
    private String m_strRelatId = null;
    private String m_strRelatArea = null;
    private String m_strRepeatFlag = null;
    private String m_strParentNo = null;
    private String m_strAlarmFlag = null;

    public String getStrUserId() { return m_strUserId; }
    public String getStrWriterId() { return m_strWriterId; }
    public String getStrSchdlNo() { return m_strSchdlNo; }
    public String getStrTitle() { return m_strTitle; }
    public String getStrGrpNo() { return m_strGrpNo; }
    public String getStrStime() { return m_strStime; }
    public String getStrLtime() { return m_strLtime; }
    public String getStrComments() { return m_strComments; }
    public String getStrSdate() { return m_strSdate; }
    public String getStrLdate() { return m_strLdate; }
    public String getStrRelatMan() { return m_strRelatMan; }
    public String getStrRelatId() { return m_strRelatId; }
    public String getStrRelatArea() { return m_strRelatArea; }
    public String getStrRepeatFlag() { return m_strRepeatFlag; }
    public String getStrParentNo() { return m_strParentNo; }
    public String getStrAlarmFlag() { return m_strAlarmFlag; }

    public void setStrUserId(String s) { m_strUserId = s; }
    public void setStrWriterId(String s) { m_strWriterId = s; }
    public void setStrSchdlNo(String s) { m_strSchdlNo = s; }
    public void setStrTitle(String s) { m_strTitle = s; }
    public void setStrGrpNo(String s) { m_strGrpNo = s; }
    public void setStrStime(String s) { m_strStime = s; }
    public void setStrLtime(String s) { m_strLtime = s; }
    public void setStrComments(String s) { m_strComments = s; }
    public void setStrSdate(String s) { m_strSdate = s; }
    public void setStrLdate(String s) { m_strLdate = s; }
    public void setStrRelatMan(String s) { m_strRelatMan = s; }
    public void setStrRelatId(String s) { m_strRelatId = s; }
    public void setStrRelatArea(String s) { m_strRelatArea = s; }
    public void setStrRepeatFlag(String s) { m_strRepeatFlag = s; }
    public void setStrParentNo(String s) { m_strParentNo = s; }
    public void setStrAlarmFlag(String s) { m_strAlarmFlag = s; }
}