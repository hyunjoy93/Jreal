package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_D11.java
 * Class    : GEmTB_D11
 * Function : Data model of representing parameter data for TB_COMCODE_D11 Table
 * Comment  : table : TB_COMCODE_D11 
 * History  : 
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_D11 {

    private String m_strDrftNo = null;
    private String m_strSeq = null;
    private String m_strRefType = null;
    private String m_strApprId = null;
    private String m_strApprName = null;
    private String m_strApprDeptCode = null;
    private String m_strApprDeptName = null;
    private String m_strApprPosName = null;
    private String m_strReadFlag = null;
    private String m_strReadDate = null;
    private String m_strApprDate = null;
    private String m_strApprType = null;
    private String m_strDocNo = null;
    private String m_strComments = null;
    private String m_strRealViewDate = null;

    public String getStrDrftNo() { return m_strDrftNo; }
    public String getStrSeq() { return m_strSeq; }
    public String getStrRefType() { return m_strRefType; }
    public String getStrApprId() { return m_strApprId; }
    public String getStrApprName() { return m_strApprName; }
    public String getStrApprDeptCode() { return m_strApprDeptCode; }
    public String getStrApprDeptName() { return m_strApprDeptName; }
    public String getStrApprPosName() { return m_strApprPosName; }
    public String getStrReadFlag() { return m_strReadFlag; }
    public String getStrReadDate() { return m_strReadDate; }
    public String getStrApprDate() { return m_strApprDate; }
    public String getStrApprType() { return m_strApprType; }
    public String getStrDocNo() { return m_strDocNo; }
    public String getStrComments() { return m_strComments; }
    public String getStrRealViewDate() { return m_strRealViewDate; }

    public void setStrDrftNo(String s) { m_strDrftNo = s; }
    public void setStrSeq(String s) { m_strSeq = s; }
    public void setStrRefType(String s) { m_strRefType = s; }
    public void setStrApprId(String s) { m_strApprId = s; }
    public void setStrApprName(String s) { m_strApprName = s; }
    public void setStrApprDeptCode(String s) { m_strApprDeptCode = s; }
    public void setStrApprDeptName(String s) { m_strApprDeptName = s; }
    public void setStrApprPosName(String s) { m_strApprPosName = s; }
    public void setStrReadFlag(String s) { m_strReadFlag = s; }
    public void setStrReadDate(String s) { m_strReadDate = s; }
    public void setStrApprDate(String s) { m_strApprDate = s; }
    public void setStrApprType(String s) { m_strApprType = s; }
    public void setStrDocNo(String s) { m_strDocNo = s; }
    public void setStrComments(String s) { m_strComments = s; }
    public void setStrRealViewDate(String s) { m_strRealViewDate = s; }
}