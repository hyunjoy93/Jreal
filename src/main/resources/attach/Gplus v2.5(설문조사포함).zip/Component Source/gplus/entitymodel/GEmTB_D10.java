package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_D10.java
 * Class    : GEmTB_D10
 * Function : Data model of representing parameter data for TB_COMCODE_D10 Table
 * Comment  : table : TB_COMCODE_D10 
 * History  : 
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_D10 {

    private String m_strDrftNo = null;
    private String m_strTitle = null;
    private String m_strDocNo = null;
    private String m_strDlvrType = null;
    private String m_strRegDate = null;
    private String m_strMaintTerm = null;
    private String m_strApprType = null;
    private String m_strDrftId = null;
    private String m_strDrftName = null;
    private String m_strDrftDept = null;
    private String m_strDrftPos = null;
    private String m_strAttNum = null;
    private String m_strStepNum = null;
    private String m_strRefName = null;
    private String m_strRefDept = null;
    private String m_strMaintDate = null;
    private String m_strKeepTerm = null;
    private String m_strKeepDate = null;
    private String m_strDrftType = null;
    private String m_strSecLvl = null;
    private String m_strCreDate = null;

    public String getStrDrftNo() { return m_strDrftNo; }
    public String getStrTitle() { return m_strTitle; }
    public String getStrDocNo() { return m_strDocNo; }
    public String getStrDlvrType() { return m_strDlvrType; }
    public String getStrRegDate() { return m_strRegDate; }
    public String getStrMaintTerm() { return m_strMaintTerm; }
    public String getStrApprType() { return m_strApprType; }
    public String getStrDrftId() { return m_strDrftId; }
    public String getStrDrftName() { return m_strDrftName; }
    public String getStrDrftDept() { return m_strDrftDept; }
    public String getStrDrftPos() { return m_strDrftPos; }
    public String getStrAttNum() { return m_strAttNum; }
    public String getStrStepNum() { return m_strStepNum; }
    public String getStrRefName() { return m_strRefName; }
    public String getStrRefDept() { return m_strRefDept; }
    public String getStrMaintDate() { return m_strMaintDate; }
    public String getStrKeepTerm() { return m_strKeepTerm; }
    public String getStrKeepDate() { return m_strKeepDate; }
    public String getStrDrftType() { return m_strDrftType; }
    public String getStrSecLvl() { return m_strSecLvl; }
    public String getStrCreDate() { return m_strCreDate; }

    public void setStrDrftNo(String s) { m_strDrftNo = s; }
    public void setStrTitle(String s) { m_strTitle = s; }
    public void setStrDocNo(String s) { m_strDocNo = s; }
    public void setStrDlvrType(String s) { m_strDlvrType = s; }
    public void setStrRegDate(String s) { m_strRegDate = s; }
    public void setStrMaintTerm(String s) { m_strMaintTerm = s; }
    public void setStrApprType(String s) { m_strApprType = s; }
    public void setStrDrftId(String s) { m_strDrftId = s; }
    public void setStrDrftName(String s) { m_strDrftName = s; }
    public void setStrDrftDept(String s) { m_strDrftDept = s; }
    public void setStrDrftPos(String s) { m_strDrftPos = s; }
    public void setStrAttNum(String s) { m_strAttNum = s; }
    public void setStrStepNum(String s) { m_strStepNum = s; }
    public void setStrRefName(String s) { m_strRefName = s; }
    public void setStrRefDept(String s) { m_strRefDept = s; }
    public void setStrMaintDate(String s) { m_strMaintDate = s; }
    public void setStrKeepTerm(String s) { m_strKeepTerm = s; }
    public void setStrKeepDate(String s) { m_strKeepDate = s; }
    public void setStrDrftType(String s) { m_strDrftType = s; }
    public void setStrSecLvl(String s) { m_strSecLvl = s; }
    public void setStrCreDate(String s) { m_strCreDate = s; }
}



