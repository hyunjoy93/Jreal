package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_ZIPCODE.java
 * Class    : GEmTB_ZIPCODE
 * Function : Data model of representing parameter data for TB_COMM_ZIPCODE Table
 * Comment  : table : TB_COMM_ZIPCODE
 * History  : 
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_ZIPCODE {

    private String m_strIdx = null;
    private String m_strZipCode = null;
    private String m_strSiDo = null;
    private String m_strGuGun = null;
    private String m_strDong = null;
    private String m_strBunji = null;

    public String getStrIdx() { return m_strIdx; }
    public String getStrZipCode() { return m_strZipCode; }
    public String getStrSiDo() { return m_strSiDo; }
    public String getStrGuGun() { return m_strGuGun; }
    public String getStrDong() { return m_strDong; }
    public String getStrBunji() { return m_strBunji; }

    public void setStrIdx(String s) { m_strIdx = s; }
    public void setStrZipCode(String s) { m_strZipCode = s; }
    public void setStrSiDo(String s) { m_strSiDo = s; }
    public void setStrGuGun(String s) { m_strGuGun = s; }
    public void setStrDong(String s) { m_strDong = s; }
    public void setStrBunji(String s) { m_strBunji = s; }
}