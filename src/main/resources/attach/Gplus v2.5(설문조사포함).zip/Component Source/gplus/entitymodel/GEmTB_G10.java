package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_G10.java
 * Class    : GEmTB_G10
 * Function : Data model of representing parameter data for TB_COMCODE_E20 Table
 * Comment  : table : TB_COMCODE_G10 
 * History  : 
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_G10 {

    private String m_strGrpNo = null;
    private String m_strGrpName = null;
    private String m_strUserId = null;
    private String m_strGrpColor = null;
    private String m_strGrpType = null;

    public String getStrGrpNo() { return m_strGrpNo; }
    public String getStrGrpName() { return m_strGrpName; }
    public String getStrUserId() { return m_strUserId; }
    public String getStrGrpColor() { return m_strGrpColor; }
    public String getStrGrpType() { return m_strGrpType; }

    public void setStrGrpNo(String s) { m_strGrpNo = s; }
    public void setStrGrpName(String s) { m_strGrpName = s; }
    public void setStrUserId(String s) { m_strUserId = s; }
    public void setStrGrpColor(String s) { m_strGrpColor = s; }
    public void setStrGrpType(String s) { m_strGrpType = s; }
}