package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_A01.java
 * Class    : GEmTB_A01
 * Function : Data model of representing parameter data for TB_COMCODE_A01 Table
 * Comment  : table : TB_COMCODE_A01 
 * History  : 
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_A01 {

    private String m_strNotiNo = null;
    private String m_strBoxNo = null;
    private String m_strDocNo = null;
    private String m_strParentNo = null;
    private String m_strTitle = null;
    private String m_strAttNum = null;
    private String m_strRefNum = null;
    private String m_strNomNum = null;
    private String m_strChildNum = null;
    private String m_strRegUser = null;
    private String m_strRegDate = null;
    private String m_strRegName = null;
    private String m_strRef = null;
    private String m_strSortStep = null;
    private String m_strReLevel = null;

    public String getStrNotiNo() { return m_strNotiNo; }
    public String getStrBoxNo() { return m_strBoxNo; }
    public String getStrDocNo() { return m_strDocNo; }
    public String getStrParentNo() { return m_strParentNo; }
    public String getStrTitle() { return m_strTitle; }
    public String getStrAttNum() { return m_strAttNum; }
    public String getStrRefNum() { return m_strRefNum; }
    public String getStrNomNum() { return m_strNomNum; }
    public String getStrChildNum() { return m_strChildNum; }
    public String getStrRegUser() { return m_strRegUser; }
    public String getStrRegDate() { return m_strRegDate; }
    public String getStrRegName() { return m_strRegName; }
    public String getStrRef() { return m_strRef; }
    public String getStrSortStep() { return m_strSortStep; }
    public String getStrReLevel() { return m_strReLevel; }

    public void setStrNotiNo(String s) { m_strNotiNo = s; }
    public void setStrBoxNo(String s) { m_strBoxNo = s; }
    public void setStrDocNo(String s) { m_strDocNo = s; }
    public void setStrParentNo(String s) { m_strParentNo = s; }
    public void setStrTitle(String s) { m_strTitle = s; }
    public void setStrAttNum(String s) { m_strAttNum = s; }
    public void setStrRefNum(String s) { m_strRefNum = s; }
    public void setStrNomNum(String s) { m_strNomNum = s; }
    public void setStrChildNum(String s) { m_strChildNum = s; }
    public void setStrRegUser(String s) { m_strRegUser = s; }
    public void setStrRegDate(String s) { m_strRegDate = s; }
    public void setStrRegName(String s) { m_strRegName = s; }
    public void setStrRef(String s) { m_strRef = s; }
    public void setStrSortStep(String s) { m_strSortStep = s; }
    public void setStrReLevel(String s) { m_strReLevel = s; }
}
