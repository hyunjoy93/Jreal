package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_N20.java
 * Class    : GEmTB_N20
 * Function : Data model of representing parameter data for TB_COMCODE_N20 Table
 * Comment  : table : TB_COMCODE_N20
 * History  : 
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_N20 {

    private String m_strPosCode = null;
    private String m_strPosName = null;
    private String m_strPosRank = null;

    public String getStrPosCode() { return m_strPosCode; }
    public String getStrPosName() { return m_strPosName; }
    public String getStrPosRank() { return m_strPosRank; }

    public void setStrPosCode(String s) { m_strPosCode = s; }
    public void setStrPosName(String s) { m_strPosName = s; }
    public void setStrPosRank(String s) { m_strPosRank = s; }
}