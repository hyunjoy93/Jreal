package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_N11.java
 * Class    : GEmTB_N11
 * Function : Data model of representing parameter data for TB_COMCODE_N11 Table
 * Comment  : table : TB_COMCODE_N11
 * History  : 
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_N11 {

    private String m_strOrgNo = null;
    private String m_strUserId = null;
    private String m_strDeflt = null;

    public String getStrOrgNo() { return m_strOrgNo; }
    public String getStrUserId() { return m_strUserId; }
    public String getStrDeflt() { return m_strDeflt; }

    public void setStrOrgNo(String s) { m_strOrgNo = s; }
    public void setStrUserId(String s) { m_strUserId = s; }
    public void setStrDeflt(String s) { m_strDeflt = s; }
}