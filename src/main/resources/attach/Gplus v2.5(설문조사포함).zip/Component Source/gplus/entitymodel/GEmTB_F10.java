package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_F10.java
 * Class    : GEmTB_F10
 * Function : Data model of representing parameter data for TB_COMCODE_F10 Table
 * Comment  : table : TB_COMCODE_F10
 * History  :
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_F10 {

    private String m_strUserId = null;
    private String m_strCardNo = null;
    private String m_strGrpNo = null;
    private String m_strNameK = null;
    private String m_strNameE = null;
    private String m_strNameC = null;
    private String m_strSex = null;
    private String m_strComName = null;
    private String m_strDeptName = null;
    private String m_strBirthDay = null;
    private String m_strZipCode = null;
    private String m_strAddr = null;
    private String m_strPosName = null;
    private String m_strLunarFlag = null;
    private String m_strTelHome = null;
    private String m_strTelOffice = null;
    private String m_strTelWork = null;
    private String m_strMobile = null;
    private String m_strPager = null;
    private String m_strHomePage = null;
    private String m_strTelFax = null;
    private String m_strEmail = null;
    private String m_strComments = null;
    private String m_strEmail1 = null;
    private String m_strEmail2 = null;
    private String m_strPubFlag = null;
    private String m_strRegDate = null;
    private String m_strCopierId = null;
    private String m_strCopyDate = null;

    public String getStrUserId() { return m_strUserId; }
    public String getStrCardNo() { return m_strCardNo; }
    public String getStrGrpNo() { return m_strGrpNo; }
    public String getStrNameK() { return m_strNameK; }
    public String getStrNameE() { return m_strNameE; }
    public String getStrNameC() { return m_strNameC; }
    public String getStrSex() { return m_strSex; }
    public String getStrComName() { return m_strComName; }
    public String getStrDeptName() { return m_strDeptName; }
    public String getStrBirthDay() { return m_strBirthDay; }
    public String getStrZipCode() { return m_strZipCode; }
    public String getStrAddr() { return m_strAddr; }
    public String getStrPosName() { return m_strPosName; }
    public String getStrLunarFlag() { return m_strLunarFlag; }
    public String getStrTelHome() { return m_strTelHome; }
    public String getStrTelOffice() { return m_strTelOffice; }
    public String getStrTelWork() { return m_strTelWork; }
    public String getStrMobile() { return m_strMobile; }
    public String getStrPager() { return m_strPager; }
    public String getStrHomePage() { return m_strHomePage; }
    public String getStrTelFax() { return m_strTelFax; }
    public String getStrEmail() { return m_strEmail; }
    public String getStrComments() { return m_strComments; }
    public String getStrEmail1() { return m_strEmail1; }
    public String getStrEmail2() { return m_strEmail2; }
    public String getStrPubFlag() { return m_strPubFlag; }
    public String getStrRegDate() { return m_strRegDate; }
    public String getStrCopierId() { return m_strCopierId; }
    public String getStrCopyDate() { return m_strCopyDate; }

    public void setStrUserId(String s) { m_strUserId = s; }
    public void setStrCardNo(String s) { m_strCardNo = s; }
    public void setStrGrpNo(String s) { m_strGrpNo = s; }
    public void setStrNameK(String s) { m_strNameK = s; }
    public void setStrNameE(String s) { m_strNameE = s; }
    public void setStrNameC(String s) { m_strNameC = s; }
    public void setStrSex(String s) { m_strSex = s; }
    public void setStrComName(String s) { m_strComName = s; }
    public void setStrDeptName(String s) { m_strDeptName = s; }
    public void setStrBirthDay(String s) { m_strBirthDay = s; }
    public void setStrZipCode(String s) { m_strZipCode = s; }
    public void setStrAddr(String s) { m_strAddr = s; }
    public void setStrPosName(String s) { m_strPosName = s; }
    public void setStrLunarFlag(String s) { m_strLunarFlag = s; }
    public void setStrTelHome(String s) { m_strTelHome = s; }
    public void setStrTelOffice(String s) { m_strTelOffice = s; }
    public void setStrTelWork(String s) { m_strTelWork = s; }
    public void setStrMobile(String s) { m_strMobile = s; }
    public void setStrPager(String s) { m_strPager = s; }
    public void setStrHomePage(String s) { m_strHomePage = s; }
    public void setStrTelFax(String s) { m_strTelFax = s; }
    public void setStrEmail(String s) { m_strEmail = s; }
    public void setStrComments(String s) { m_strComments = s; }
    public void setStrEmail1(String s) { m_strEmail1 = s; }
    public void setStrEmail2(String s) { m_strEmail2 = s; }
    public void setStrPubFlag(String s) { m_strPubFlag = s; }
    public void setStrRegDate(String s) { m_strRegDate = s; }
    public void setStrCopierId(String s) { m_strCopierId = s; }
    public void setStrCopyDate(String s) { m_strCopyDate = s; }
}
