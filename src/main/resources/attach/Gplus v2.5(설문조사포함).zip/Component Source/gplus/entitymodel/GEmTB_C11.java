package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_C11.java
 * Class    : GEmTB_C11
 * Function : Data model of representing parameter data for TB_COMCODE_C11 Table
 * Comment  : table : TB_COMCODE_C11 
 * History  : 
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_C11 {

    private String m_strMailNo = null;
    private String m_strRcvrId = null;
    private String m_strRcvrName = null;
    private String m_strReadFlag = null;
    private String m_strReadDate = null;

    public String getStrMailNo() { return m_strMailNo; }
    public String getStrRcvrId() { return m_strRcvrId; }
    public String getStrRcvrName() { return m_strRcvrName; }
    public String getStrReadFlag() { return m_strReadFlag; }
    public String getStrReadDate() { return m_strReadDate; }

    public void setStrMailNo(String s) { m_strMailNo = s; }
    public void setStrRcvrId(String s) { m_strRcvrId = s; }
    public void setStrRcvrName(String s) { m_strRcvrName = s; }
    public void setStrReadFlag(String s) { m_strReadFlag = s; }
    public void setStrReadDate(String s) { m_strReadDate = s; }
}
