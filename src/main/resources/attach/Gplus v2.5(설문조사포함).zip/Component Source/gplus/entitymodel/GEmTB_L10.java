package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_L10.java
 * Class    : GEmTB_L10
 * Function : Data model of representing parameter data for TB_COMCODE_L10 Table
 * Comment  : table : TB_COMCODE_L10
 * History  : 
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_L10 {

    private String m_strDocNo = null;
    private String m_strTitle = null;
    private String m_strDocType = null;
    private String m_strFileNum = null;
    private String m_strRegUser = null;
    private String m_strModUser = null;
    private String m_strRegDate = null;
    private String m_strModDate = null;

    public String getStrDocNo() { return m_strDocNo; }
    public String getStrTitle() { return m_strTitle; }
    public String getStrDocType() { return m_strDocType; }
    public String getStrFileNum() { return m_strFileNum; }
    public String getStrRegUser() { return m_strRegUser; }
    public String getStrModUser() { return m_strModUser; }
    public String getStrRegDate() { return m_strRegDate; }
    public String getStrModDate() { return m_strModDate; }

    public void setStrDocNo(String s) { m_strDocNo = s; }
    public void setStrTitle(String s) { m_strTitle = s; }
    public void setStrDocType(String s) { m_strDocType = s; }
    public void setStrFileNum(String s) { m_strFileNum = s; }
    public void setStrRegUser(String s) { m_strRegUser = s; }
    public void setStrModUser(String s) { m_strModUser = s; }
    public void setStrRegDate(String s) { m_strRegDate = s; }
    public void setStrModDate(String s) { m_strModDate = s; }
}