package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_D31.java
 * Class    : GEmTB_D31
 * Function : Data model of representing parameter data for TB_COMCODE_D31 Table
 * Comment  : table : TB_COMCODE_D31 
 * History  : 
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_D31 {

    private String m_strLineNum = null;
    private String m_strSeq = null;
    private String m_strSubType = null;
    private String m_strSubApprId = null;
    private String m_strStepNum = null;
    private String m_strSubApprName = null;

    public String getStrLineNum() { return m_strLineNum; }
    public String getStrSeq() { return m_strSeq; }
    public String getStrSubType() { return m_strSubType; }
    public String getStrSubApprId() { return m_strSubApprId; }
    public String getStrStepNum() { return m_strStepNum; }
    public String getStrSubApprName() { return m_strSubApprName; }

    public void setStrLineNum(String s) { m_strLineNum = s; }
    public void setStrSeq(String s) { m_strSeq = s; }
    public void setStrSubType(String s) { m_strSubType = s; }
    public void setStrSubApprId(String s) { m_strSubApprId = s; }
    public void setStrStepNum(String s) { m_strStepNum = s; }
    public void setStrSubApprName(String s) { m_strSubApprName = s; }
}