package gplus.commlib;

import java.io.*;
import java.util.*;
import com.objectspace.jgl.util.*;

import gplus.commlib.comm.*;
import gplus.commlib.lib.*;
import gplus.commlib.db.*;
import gplus.commlib.log.GCmDebugLog;

/**
 * <PRE>
 * Filename : GCmInitializer.java
 * Class    : GCmInitializer
 * Function : initialize GPlus GroupWare system
 * Comment  : GPlus �׷���� �ý��� ��ɺ� �ʱ�ȭ Ŭ����
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GCmInitializer
{
    // cannot have instance
    protected GCmInitializer()
    {
    }

    /**
     * @param gplusDir�� �ݵ�� ���� �Ǿ�� ��
     * @exception Exception GCmInitializer failed
     * @pre (commerce21Dir!=null)
     */
    public static void executeAll(String gplusDir) throws Exception
    {
    	GCmDebugLog log = null;

	try
	{
        	log = new GCmDebugLog(gplusDir + File.separator + "log" + File.separator + "gplus.log");
        }
        catch (Exception e)
        {
        	log = new GCmDebugLog(new PrintWriter(System.err));
        }

        initPropertyManager(gplusDir);
        log.println("GCmInitializer : PropertyManger inited");
        System.out.println("GCmInitializer : PropertyManger inited");

     	initDbManager();
    	log.println("GCmInitializer : DbManager inited");
        System.out.println("GCmInitializer : DbManager inited");

        initUtil();
        log.println("GCmInitializer : Util inited");
        System.out.println("GCmInitializer : Util inited");

        initMsgManager();
        log.println("GCmInitializer : MsgManager inited");
        System.out.println("GCmInitializer : MsgManager inited");

//        initConstManager();
//        log.println("GCmInitializer : CodeManager inited");

 //       initCodeManager();
 //       log.println("GCmInitializer : CodeManager inited");
    }

    /**
     * GCmPropertyManager �ʱ�ȭ
     * @param gplusDir GPlus System root directory
     * @exception Exception
     */
    public static void initPropertyManager(String gplusDir) throws Exception
    {
        GCmPropertyManager.init(gplusDir);
    }

    /**
     * GCmUtil �ʱ�ȭ
     * @exception Exception
     */
    public static void initUtil() throws Exception
    {
        GCmUtil.init();
    }


    /**
     * GCmMsgManager �ʱ�ȭ
     * @exception Exception
     */
    public static void initMsgManager() throws Exception
    {
        GCmMsgManager.init();
    }

    /**
     * GCmConstManager �ʱ�ȭ
     * @exception Exception
     */
    public static void initConstManager() throws Exception
    {
        GCmConstManager.init();
    }


    /**
     * GCmDbManager �ʱ�ȭ
     * @exception Exception
     */
    public static void initDbManager() throws Exception
    {
    	GCmDbManager.init();
    }


    /**
     * GCmCodeManager �ʱ�ȭ
     * @exception Exception
     */
    public static void initCodeManager() throws Exception
    {
    	GCmCodeManager.init();
    }

    /**
     * clear all preloaded services's resources
     * @exception Exception
     */
    public static void terminateAll() throws Exception
    {
        System.runFinalization();
        System.gc();
    }
}
