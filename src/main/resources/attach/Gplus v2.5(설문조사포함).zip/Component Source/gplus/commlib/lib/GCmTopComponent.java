package gplus.commlib.lib;

import java.sql.*;
import java.util.*;
import java.io.Serializable;
import gplus.commlib.comm.GCmConstDef;
import gplus.commlib.exception.GCmParameterErrorException;
import gplus.commlib.lib.*;
import gplus.commlib.log.GCmDebugLog;


/**
 * <PRE>
 * Filename	: GCmTopComponent.java <BR>
 * Class	: GCmTopComponent <BR>
 * Function	: <BR>
 * Comment  :
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GCmTopComponent
{
  	public static boolean VERBOSE = false;			// ������ϴµ� ����ϵ��� ��...

  	/*
  	 * DEBUGGING �� �����
  	 */
  	public static boolean DEBUG_1 = false;
  	public static boolean DEBUG_2 = false;
  	public static boolean DEBUG_3 = false;

	public	GCmDebugLog	m_log = null;


	/*
	 * generate sql quotation
	 * @param sqlString - sql string to quotation generate
	 * @return quotation genrated String object
	 */
	public String genQuote(String sqlString)
	{
		if ((sqlString == null) || (sqlString.equals("")))
		{
			return ("''");		// blank string
		}
		else
		{
			String resultString = "";
			StringTokenizer st = new StringTokenizer(sqlString, "'");

			resultString += st.nextToken();

			while (st.hasMoreTokens())
			{
				resultString += "''";
				resultString += st.nextToken();
			}

			return ("'" + GCmUtil.toDB(resultString) + "'");
		}
	}

}

