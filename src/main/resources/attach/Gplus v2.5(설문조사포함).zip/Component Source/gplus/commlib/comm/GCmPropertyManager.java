package gplus.commlib.comm;

import java.util.*;
import java.io.*;
import java.sql.*;
import gplus.commlib.log.GCmDebugLog;

/**
 * 	<PRE>
 * 	Filename : GCmPropertyManager.java
 * 	Class    : gplus.commlib.comm.GCmPropertyManager
 * 	Function : handling fo Property object
 * 	Comment  :
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GCmPropertyManager extends Hashtable
{
    private static GCmPropertyManager m_instance;
    private static final String CONFILE = File.separator + "gplus.properties";
    private static final String	GROUPWARE_ID = GCmConstDef.GROUPWARE_ID;
    private static final boolean	verbose = false;
    private static GCmDebugLog log = null;

 	protected GCmPropertyManager()
 	{
 		m_instance = null;
 	}


	/**
	 * get singleton object<br>
	 * Must be called after init
	 *
	 * @return singleton GCmPropertyManager object
	 * @pre (m_instance != null), "GCmPropertyManager not yet initialized"
	 */
	public static GCmPropertyManager getInstance() throws Exception
	{
		if (m_instance == null)
		{
			throw new Exception("System is not initialized properly: " +
				            "GCmPropertyManager instance is null");
       		}
		return m_instance;
	}

	/**
	 * GPLUS �ý��� �ʱ�ȭ
	 *
	 * @param	: gplus.properties file path
	 */
	public static void init(String gplusDir) throws Exception
	{
		if (m_instance == null)
		{
			if (verbose)
				System.out.println("GCmPropertyManager init ....");

			m_instance = new GCmPropertyManager();
			GCmProperties mallProp = new GCmProperties();

			try
			{
				try
				{
					log = new GCmDebugLog(gplusDir + File.separator + "log" + File.separator + "gplus.log");
				}
				catch (Exception e)
				{
					log = new GCmDebugLog(new PrintWriter(System.err));
				}


				mallProp.loadFromFile(gplusDir + CONFILE);
				mallProp.setProperty("gplusDir.system.home", gplusDir);

				Enumeration enum = mallProp.propertyNames();

				log.println("GPLUS SYSTEM PROPERTIES...");

				while (enum.hasMoreElements())
				{
					String strKey = (String) enum.nextElement();
					String strVal = mallProp.getProperty(strKey);

					log.println(strKey + "=" + strVal);
				}


				String groupWareKey = new String(GROUPWARE_ID);

				if (! m_instance.validate(groupWareKey))
				{
					/*
					 * gplus.properties�� ����Ѵ�.
					 */
					m_instance.put(groupWareKey, mallProp);

				}
				else
				{
					log.println("The groupWareKey is already exists.");
				}
			}
			catch (Exception e)
			{
				log.println(e);
				throw new Exception("GCmPropertyManager : init() error..");
			}


		}
	}

	/**
	 * Parameter Key�� �ش��ϴ� GCmProperties object reference ȹ��
	 *
	 * @param	key Long type key value
	 * @return	GCmProperties������ ���� �ִ� GCmProperties��ü ��ȯ
	 */
	public GCmProperties getPropertyInstance(String key)
	{
		if (validate(key))
		{
			return 	((GCmProperties)get(key));
		}
		else
		{
			return 	((GCmProperties)get(key));
		}
	}

	/*
	 * key validataion check
	 *
	 * @param	������ ����id
	 * @return	���� key�� �����ϸ� true
	 */
	private boolean validate(String key)
	{
		return containsKey(key);
	}

} // end class


