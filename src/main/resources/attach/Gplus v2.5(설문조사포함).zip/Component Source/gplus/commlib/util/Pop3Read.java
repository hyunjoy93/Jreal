package gplus.commlib.util;

import java.sql.*;
import java.io.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.servlet.jsp.JspWriter;
import gplus.commlib.comm.*;
import gplus.commlib.lib.*;
import gplus.commlib.util.*;
import gplus.commlib.db.*;
import gplus.component.menu.*;
import gplus.component.wmail.*;
import gplus.component.doc.*;
import gplus.template.*;
import gplus.entitymodel.*;


/**
 * <PRE>
 * Filename : Pop3Read.java
 * Class    : Pop3Read
 * Function : utility
 * Comment  :
 * History  : 2/16/2002, ������, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class Pop3Read {

	private static int nCnt = 0;
    private static java.util.Vector vError = null;

    public Pop3Read() { }


	/**
	 * <PRE>
	 *  POP3 Mail Read
	 * </PRE>
	 *
	 * @param prop	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String REQUEST     : REQUEST��ü <BR>
	 *				<LI> String COMCODE   : ȸ���ڵ�  <BR>
	 *				<LI> String USERID        : �����ID  <BR>
	 *				<LI> String ROOTPATH   :  ��������Ʈ��� <BR>
	 *				<LI> String TBC30          :  �̸��ϰ������� <BR>
	 *				<LI> String OUT             : OUT��ü <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  String  ������ ���� �Ǽ�ǥ��
	 */
	public synchronized String getPop3Mail(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
		throws Exception
	{

        GTpBoxs Box  = new GTpBoxs();
		GTpMail Mail = new GTpMail();
        EmailRead Email = new EmailRead();
        GTpDoc Doc = new GTpDoc();
		GCmMsgManager msgMgr = GCmMsgManager.getInstance();

		javax.servlet.http.HttpServletRequest request = (javax.servlet.http.HttpServletRequest)dmProp.getObject("REQUEST");
		String comcode = dmProp.getString("COMCODE");
		String userid  = dmProp.getString("USERID");
		String rootpath = dmProp.getString("ROOTPATH");
		String seq = dmProp.getString("seq");
		GEmTB_C30 tbc30 = (GEmTB_C30)dmProp.getObject("TBC30");
		JspWriter out = (JspWriter)dmProp.getObject("OUT");
        String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

        vError = new java.util.Vector();
        int nErrCnt = 0;
        String errmsg = "";

        String retMsg = "";

        final String mailtype = gplus.commlib.comm.GCmConstDef.MAILTYPE_EMAIL;    // �������� : 1(���ڸ���)
        final String sendtype = "1";    // �������� : 1(����)
        final String dlvrtype = "3";    // �߼ۻ��� : 3(�Ϸ�)

        String boxno = "";
        String mailno = "";     // ���Ϲ�ȣ
        String docno = "";      // ������ȣ
        String title = "";      // ����
        String regdate = GCmFcts.dateToStr(new java.util.Date(),2);    // �����Ͻ�
        String sndrid = "";     // �����ھƵ�
        String sndrname = "";   // �������̸�
        String toid = "";       // �޴»���Ƶ�
        String toname = "";     // �޴»���̸�
        String ccid = "";       // �����ھƵ�
        String ccname = "";     // �������̸�
        String bccid = "";      // ��������ھƵ�
        String bccname = "";    // ����������̸�
        int attnum = 0;         // ÷�μ�
        int rcvrnum = 0;        // �޴»����
        int readnum = 0;        // ������

        int count = 0;          // Mail Count
        int nRcvMail = 0;

        String[] emailaddrname = new String[2];

		Folder inbox = null;

        java.util.Date sentdate;
        java.util.Date rcvddate;


        String charset = "";
        String vpath = "/DATA/" + comcode + "/MAIL/" + regdate.substring(0,6) + "/";
        String ppath = rootpath + vpath;

		String acctname = tbc30.getStrAcctName();
        String host = tbc30.getStrPop3Svr();
        String logid = tbc30.getStrPop3Id();
        String passwd = tbc30.getStrPop3Pwd();
        String delflag = GCmFcts.nvl(tbc30.getStrDelFlag(),"1");
        String sysflag = GCmFcts.nvl(tbc30.getStrSysFlag(),"1");
        String deflt = GCmFcts.nvl(tbc30.getStrDeflt(),"1");


        java.io.File oFile = new java.io.File(ppath);

		if (!oFile.isDirectory()) oFile.mkdir();                                    // ��������

        vpath += regdate.substring(6,8) + "/";
        ppath = rootpath + vpath;

        oFile = new java.io.File(ppath);

		if (!oFile.isDirectory()) oFile.mkdir();                                    // ��������


        try
		{

            out.println( host + " �� ������..."); 

            inbox = Email.getInbox(request, host,logid,passwd);

            out.println("<input type=text name=message" + seq + " value='�޽����� Ȯ���մϴ�.'" + " readonly=true" 
			                 + " style='cursor:hand;border-style:none;border-width:0px ;background='transparent';height=13px size=30>"); 
	        
			out.flush(); 

        }
        catch (Exception e)
		{


            throw new Exception(msgMgr.getMessage("C10002"));

        }

        if(inbox == null) throw new Exception(msgMgr.getMessage("C10002"));

        
		
		count = inbox.getMessageCount();
		int nNewMsg = inbox.getNewMessageCount();
        int nUnRead = inbox.getUnreadMessageCount();


		if (count > 0)
		{

			out.print("<script language=javascript>frmList.message" + seq + ".value='�޽����� " +  count + "�� �ֽ��ϴ�.';</script>");
			out.flush(); 

		}
		else
		{
			out.println("<script language=javascript>frmList.message" + seq + ".value='�޽����� �����ϴ�.';</script>");
			out.flush();
		}


        try
		{

			nRcvMail = 0;


			for(int i = 1; i <= count; i++)
			{
                
				Message msg = inbox.getMessage(i);


                if(!msg.isSet(Flags.Flag.DELETED))
				{


                    try
					{
						errmsg = "";
                        /* ���������� eml ���Ϸ� ����
                            String emlfile = docno + "_00.eml";
                            FileOutputStream fout = new FileOutputStream(ppath + emlfile);
                            DataOutputStream dout = new DataOutputStream(fout);
                            msg.writeTo(dout);
						*/

						try
						{
	                        title = msg.getSubject();
						}
						catch (MessagingException ex)
						{

							title = "�������";

						}

                        javax.mail.internet.MimeMessage mMsg = (javax.mail.internet.MimeMessage)msg;


						if (title != null && title.length() > 0)

							title = Email.getHeader(mMsg,"Subject");

						else

							title = "�������";


                        errmsg += " ���� : " + GCmFcts.replace(title,"\\n","");


                        try
						{

							sentdate = msg.getSentDate();

                        }
						catch (Exception ex)
						{

							errmsg += " ������¥ : " + ex.getMessage();

						}

						try
						{

                            rcvddate = msg.getReceivedDate();

                        }
						catch (Exception ex)
						{

							errmsg += " ������¥ : " + ex.getMessage();

						}



                        Address[] from = null;
                        Address[] to = null;
                        Address[] cc = null;
                        Address[] bcc = null;

                        String[] msgFrom = null;
                        String[] msgTo = null;
                        String[] msgCc = null;
                        String[] msgBcc = null;


                        try
						{
							from = msg.getFrom();
                            emailaddrname = Email.getEmailAddr(from);
                            sndrid = emailaddrname[0];
                            sndrname = Email.getEmailName(mMsg,"From");
                        }
						catch (Exception ex)
						{

							try
							{

								msgFrom = Email.getEmail(mMsg,"From");

								if (msgFrom != null)
								{

									sndrid = (sndrid==null || sndrid.equals(""))?GCmFcts.nvl(msgFrom[0],""):"";
                                    sndrname = GCmFcts.nvl(msgFrom[1],"");

									if (sndrname == null || sndrname.equals("")) sndrname = sndrid;

                                }
                            }
							catch (Exception ex1)
							{

								errmsg += " ������� : " + ex1.getMessage();

							}

                        }


                        try
						{

							msgTo = Email.getEmail(mMsg,"To");

							if (msgTo != null)
							{

								toid = GCmFcts.nvl(msgTo[0],"");
                                toname = GCmFcts.nvl(msgTo[1],"");

								if (toname == null || toname.equals("")) toname = toid;

                            }
                        } catch (Exception ex)
						{

							errmsg += " �޴»�� : " + ex.getMessage();

                        }

                        try
						{

							msgCc = Email.getEmail(mMsg,"Cc");

                            if (msgCc != null)
							{

								ccid = GCmFcts.nvl(msgCc[0],"");
								ccname = GCmFcts.nvl(msgCc[1],"");

                                if (ccname == null || ccname.equals("")) ccname = ccid;

                            }
                        } catch (Exception ex)
						{

							errmsg += " ���� : " + ex.getMessage();

                        }


                        try
						{

                            msgBcc = Email.getEmail(mMsg,"Bcc");

                            if (msgBcc != null)
							{

                                bccid = GCmFcts.nvl(msgBcc[0],"");
                                bccname = GCmFcts.nvl(msgBcc[1],"");

								if (bccname == null || bccname.equals("")) bccname = bccid;

							}
                        } catch (Exception ex)
						{
                            errmsg += " �������� : " + ex.getMessage();
                        }

				/*   ���� CLOB Ÿ������ ������ �κ�(����� �Բ�)   */

						if (ccid.length() > 2000)
						{
							ccid = ccid.substring(0, 2000);
						}

						if (ccname.length() > 2000)
						{
							ccname = ccname.substring(0,2000);
						}

						if (bccid.length() > 2000)
						{
							bccid = bccid.substring(0,2000);
						}

						if (bccid.length() > 2000 || bccname.length() > 2000)
						{
							bccname = bccname.substring(0,2000);
						}

                        attnum = 0;         // ÷�μ�
                        rcvrnum = 0;        // �޴»����
                        readnum = 0;        // ������
                        String mime = "";

                        mailno = getMaxMailNo(comcode, strDbType);                    // ���Ϲ�ȣ
						docno = getMaxDocNo(comcode, strDbType);                   // ������ȣ



						dmProp.put("MSG", mMsg);
						dmProp.setProperty("COMCODE", comcode);
						dmProp.setProperty("MAILNO", mailno);
						dmProp.setProperty("DOCNO", docno);
						dmProp.setProperty("TITLE", title);
						dmProp.setProperty("VPATH", vpath);
						dmProp.setProperty("PPATH", ppath);
						dmProp.setProperty("REGUSER", userid);
						dmProp.setProperty("REGDATE", regdate);

						//������ �о�´�.
						Email.getMsgMime(cp, dmProp, msgInfo);



						charset = Email.getCharset();

						dmProp.setProperty("PARENTNO", "000000000000");
						dmProp.setProperty("BOXCLASS", GCmConstDef.BOXCLASS_MAIL);
						dmProp.setProperty("EXECCLASS", GCmConstDef.EXECCLASS_MAIL_INBOX);
						dmProp.setProperty("USERID", userid);

						GCmResultSet rsbox = Box.getBoxNo(cp, dmProp, msgInfo);
						rsbox.next();

						boxno = rsbox.getString("BOXNO");

						dmProp.setProperty("BOXNO", boxno);
						dmProp.setProperty("MAILNO", mailno);
						dmProp.setProperty("SRTYPE", "1");
						dmProp.setProperty("READFLAG", "1");
						dmProp.setProperty("TRASHFLAG", "1");

                        // �����Ժ����ϸ���Է�(TB_COMCODE_C20) ����������
						boolean result =  Mail.insertRegMail(cp, dmProp, msgInfo);
						if (!result) throw new Exception(msgMgr.getMessage("C90002"));



						dmProp.setProperty("MAILNO", mailno);
						dmProp.setProperty("DOCNO", docno);
						dmProp.setProperty("MAILTYPE", "1");
						dmProp.setProperty("SENDTYPE", "1");
						dmProp.setProperty("DLVRTYPE", "3");
						dmProp.setProperty("TITLE", title);
						dmProp.setProperty("REGDATE", regdate);
						dmProp.setProperty("SNDRID", sndrid);
						dmProp.setProperty("SNDRNAME", sndrname);
						dmProp.setProperty("TOID", toid);
						dmProp.setProperty("TONAME", toname);
						dmProp.setProperty("CCID", ccid);
						dmProp.setProperty("CCNAME", ccname);
						dmProp.setProperty("BCCID", bccid);
						dmProp.setProperty("BCCNAME", bccname);
						dmProp.setProperty("ATTNUM", String.valueOf(Email.getAttnum()));
						dmProp.setProperty("RCVRNUM", "0");
						dmProp.setProperty("READNUM", "0");
						dmProp.setProperty("ACCTNAME", acctname);

                        // ���ϸ������(TB_COMCODE_C10)
                        boolean result2 =  Mail.insertMail(cp, dmProp, msgInfo);

						if (!result2) throw new Exception(msgMgr.getMessage("C90003"));


                        if (result && result2)
						{

//   ��Ű�� ��ȭ�� ���� ����� �ش� ������Ʈ������ Ʈ������� ó���ϰ�, jsp���� ����Ͻ� �÷ο츦 ������Ʈ�� �Űܾ߸� Ʈ������� �ϰ��� ����
//   �̷� ���� Ʈ����� �κ��� ���� 2001.02.18 ������
			

	                         if (deflt.equals("0") || delflag.equals("0"))
								msg.setFlag(Flags.Flag.DELETED,true); // Deleted Flag Setting

						}
                        nRcvMail++;
                    }
					catch (Exception e)
					{
						e.printStackTrace();
                        nErrCnt++;
                        vError.add(i + " Mail : " + errmsg + "  Etc Exception : " + e.getMessage() );
                    }
                } // IF END ������� �ƴ� ��� ��...

				out.println("<script language=javascript>frmList.message" + seq + ".value='�޽����� �޴���... " + i + "/" + count + "';</script>");
				out.flush();

            } // FOR END


        }
        catch (javax.mail.MessagingException ex)
		{
			System.out.println("Pop3Read  ::  getPop3Mail error" + ex.getMessage());
			return null;
		}
        finally {
            Email.setInboxClose();
        }

	    retMsg += msgMgr.getMessage("C10001");

        return retMsg;
    }


	
	
	
	
	
	private String getMaxMailNo(String comcode,String strDbType)
    {
		    GCmConnection conn = null;
	    try
	    {
		       conn = GCmDbManager.getInstance().getConnection();
			   StringBuffer sqlQuery = new StringBuffer();

					   if ("oracle".equals(strDbType))
                        {
                             sqlQuery
                                .append(" SELECT DECODE(SUBSTR(MAX(MAILNO),1,8),TO_CHAR(sysdate,'YYYYMMDD'),TO_CHAR(TO_NUMBER(MAX(MAILNO))+1),null,TO_CHAR(sysdate,'YYYYMMDD')||'0001') as NO ")
                             	.append(" FROM TB_").append(comcode).append("_C10 ")
                           	    .append(" WHERE MAILNO LIKE TO_CHAR(sysdate,'YYYYMMDD')||'%'");
                        }
                        else if ("mssql".equals(strDbType))
                             {
                                     sqlQuery
                                        .append(" SELECT (CASE SUBSTRING(MAX(MAILNO),1,8) WHEN convert(char(08),getdate(),112) THEN CAST(SUBSTRING(MAX(MAILNO),1,8) AS varchar(8)) + RIGHT('0000'+CAST(SUBSTRING(MAX(MAILNO),9,4)+1 AS varchar(4)),4) ELSE convert(char(08),getdate(),112)+'0001' END) as NO ")
                                        .append(" FROM TB_").append(comcode).append("_C10 ")
                                        .append(" WHERE MAILNO LIKE convert(char(08),getdate(),112)+'%' ");
                             }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
           	rs.next();
			return rs.getString("NO");
   		}
   		catch (Exception e)
   		{
 			System.out.println(" Pop3Read  :: getMaxMailNo " + e.getMessage());
	 		return null;
   		}
   		finally
   		{
			conn.close();
   		}
    }

    private String getMaxDocNo(String comcode,String strDbType)
    {
		GCmConnection conn = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

			if ("oracle".equals(strDbType))
            {
				sqlQuery
					.append(" SELECT DECODE(SUBSTR(MAX(DOCNO),1,8),TO_CHAR(sysdate,'YYYYMMDD'),TO_CHAR(TO_NUMBER(MAX(DOCNO))+1),null,TO_CHAR(sysdate,'YYYYMMDD')||'0001') as NO ")
                    .append(" FROM TB_").append(comcode).append("_L10 ")
                    .append(" WHERE DOCNO LIKE TO_CHAR(sysdate,'YYYYMMDD')||'%'");
            }
            else if ("mssql".equals(strDbType))
            {
                sqlQuery
                     .append(" SELECT (CASE SUBSTRING(MAX(DOCNO),1,8) WHEN convert(char(08),getdate(),112) THEN CAST(SUBSTRING(MAX(DOCNO),1,8) AS varchar(8)) + RIGHT('0000'+CAST(SUBSTRING(MAX(DOCNO),9,4)+1 AS varchar(4)),4) ELSE convert(char(08),getdate(),112)+'0001' END) as NO ")
                     .append(" FROM TB_").append(comcode).append("_L10 ")
                     .append(" WHERE DOCNO LIKE convert(char(08),getdate(),112)+'%' ");
            }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			rs.next();

			return rs.getString("NO");

      	}
      	catch (Exception e)
      	{

 			System.out.println(" Pop3Rea :: getMaxDocNo " + e.getMessage());
	 		return null;

   		}
      		finally
      	{
			conn.close();
      	}
    }

	/**
     * ���������
     * @retrun �������
     */
	public int getRetCnt()
	{

        return nCnt;

    }

	/**
     * ����������
     * @retrun ������
     */
	public java.util.Vector getErrorList()
	{

		return vError;

    }

}