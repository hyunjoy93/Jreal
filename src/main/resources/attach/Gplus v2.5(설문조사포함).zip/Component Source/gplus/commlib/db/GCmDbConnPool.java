package gplus.commlib.db;

import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.Date;
import gplus.commlib.*;
import gplus.commlib.comm.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.GCmDebugLog;

/**
 * <PRE>
 * Filename	: GCmDbConnPool.java
 * Class	: GCmDbConnPool
 * Function	:
 * Comment      :
 * History      : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

class GCmDbConnPool
{
	private int 	m_checkedOut;
	private Vector 	m_freeConnections	= new Vector();
	private Vector 	m_usingConnections = new Vector();

	private int 	m_maxConn;
	private String 	m_name;
	private String 	m_password;
	private String 	m_URL;
	private String 	m_user;

	private GCmDebugLog log = null;

	private final long 	 A_SEC			= 1000;
	private final long 	 A_MIN			= 60;
	private final long 	 A_HOUR			= 60;
	private final long 	 A_DAY			= 24;

	private final boolean verbose = false;

	/**
	 * Checks connections in usingConnection vector is close or not,
	 * if connection is closed, free it.
	 */
	Thread m_closeChecker = new Thread()
	{
		public void run()
		{
			Enumeration allUsingConnections;
			Enumeration allFreeConnections;

			while (true)
			{
				allUsingConnections = m_usingConnections.elements();
				allFreeConnections = m_freeConnections.elements();

				try
				{
					sleep(A_SEC * 3);			// 30 seconds
				}
				catch (InterruptedException e)
				{
					log.println("InterruptedException : m_closeChecker");
				}

				while (allUsingConnections.hasMoreElements())
				{
					Hashtable hashConn = (Hashtable) allUsingConnections.
					nextElement();
					Date dtNow = Calendar.getInstance().getTime();

					long lCurTime = Calendar.getInstance().getTime().getTime();
					long lUseTime = ((Date) hashConn.get("USE")).getTime();


					if ((lCurTime - lUseTime) > (A_SEC * 300))
					{
						freeConnection((Connection) hashConn.get("CONN"));

						if (verbose)
						{
							System.err.println("COLLECTOR >>> FREE : " + getFreeSize() + "     " + "USED : " + getUsingSize());
						}
					}
				}	// while

				while (allFreeConnections.hasMoreElements())
				{
					Hashtable hashConn = (Hashtable) allFreeConnections.
															nextElement();
					Date dtNow = Calendar.getInstance().getTime();

					long lCurTime = Calendar.getInstance().getTime().getTime();
					long lCreateTime = ((Date) hashConn.get("CREATE")).getTime();

					if ((lCurTime - lCreateTime) > (A_SEC * A_MIN * A_HOUR * A_DAY * 30))
					{
						m_freeConnections.removeElement(hashConn);
						m_freeConnections.addElement(newConnection());
					}
				}	// while

			}	// while
		}	// run
	};


	/**
	 * Creates new connection pool.
	 *
	 * @param name The pool name
	 * @param URL The JDBC URL for the database
	 * @param user The database user, or null
	 * @param password The database user password, or null
	 * @param m_maxConn The maximal number of connections, or 0
	 *   for no limit
	 */
	public GCmDbConnPool(String name, String URL, String user,
		String password, int maxConn)
	{
		this.m_name 	= name;
		this.m_URL 		= URL;
		this.m_user 	= user;
		this.m_password	= password;
		this.m_maxConn 	= maxConn;

		GCmPropertyManager propMgr = null;
		try
		{
			propMgr = GCmPropertyManager.getInstance();
		}
		catch (Exception e)
		{
			log.println("GCmDbConnPool: Can't get property instance");
		}

		try
		{
			String strLogPath = GCmPropertyManager.getInstance()
						.getPropertyInstance(GCmConstDef.GROUPWARE_ID)
						.getProperty("gplus.log.path");

			log = new GCmDebugLog(strLogPath + File.separator + "gplus.log");
		}
		catch (Exception e)
		{
			log = new GCmDebugLog(new PrintWriter(System.err));
		}

		for (int i = 0; i < (maxConn / 5); i++)
		{
			m_freeConnections.addElement(newConnection());
		}

		m_closeChecker.start();
	}


	/**
	 * Checks in a connection to the pool. Notify other Threads that
	 * may be waiting for a connection.
	 *
	 * @param con The connection to check in
	 */
	public synchronized void freeConnection(Connection con)
	{
		Hashtable hashConn = null;

		if (m_usingConnections.size() > 0)
		{

			Enumeration enum = m_usingConnections.elements();

			try
			{
				while (enum.hasMoreElements())
				{
					hashConn = (Hashtable) enum.nextElement();

					if (hashConn.containsValue(con))
					{
						break;
					}
				}
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}

			if (verbose)
			{
				System.err.println("BEFORE >>> FREE : " + getFreeSize() + "     " + "USED : " + getUsingSize());
			}

			m_usingConnections.removeElement(hashConn);
			m_freeConnections.addElement(hashConn);
			m_checkedOut--;

			if (verbose)
			{
				System.err.println("AFTER  >>> FREE : " + getFreeSize() + "     " + "USED : " + getUsingSize());
			}

			notifyAll();
		}

	}


	/**
	 * Checks out a connection from the pool. If no free connection
	 * is available, a new connection is created unless the max
	 * number of connections has been reached. If a free connection
	 * has been closed by the database, it's removed from the pool
	 * and this method is called again recursively.
	 */
	public synchronized Connection getConnection()
	{
		Connection con = null;
		Hashtable hashConn = null;

		if (m_freeConnections.size() > 0)
		{
			hashConn = (Hashtable) m_freeConnections.firstElement();
			con = (Connection) hashConn.get("CONN");
			m_freeConnections.removeElementAt(0);

			try
			{
				if (con.isClosed())
				{
					log.println("Removed bad connection from " + m_name);
					con = getConnection();
				}
			}
			catch (SQLException e)
			{
				log.println("Removed bad connection from " + m_name);
				con = getConnection();
			}
		}
		else if (m_maxConn == 0 || m_checkedOut < m_maxConn)
		{
			hashConn = newConnection();
			con = (Connection) hashConn.get("CONN");
			((Date) hashConn.get("USE")).setTime(Calendar.getInstance().getTime().getTime());
		}

		if ((con != null) && (hashConn != null))
		{
			m_checkedOut++;
			m_usingConnections.addElement(hashConn);
		}

		return con;
	}


	/**
	 * Checks out a connection from the pool. If no free connection
	 * is available, a new connection is created unless the max
	 * number of connections has been reached. If a free connection
	 * has been closed by the database, it's removed from the pool
	 * and this method is called again recursively.
	 * <P>
	 * If no connection is available and the max number has been
	 * reached, this method waits the specified time for one to be
	 * checked in.
	 *
	 * @param timeout The timeout value in milliseconds
	 */
	public synchronized Connection getConnection(long timeout)
	{
		long startTime = new Date().getTime();
		Connection con;

		while ((con = getConnection()) == null)
		{
			try
			{
				wait(timeout);
			}
			catch (InterruptedException e) {}

			if ((new Date().getTime() - startTime) >= timeout)
			{
				// Timeout has expired
				return null;
			}
		}
		return con;
	}


	/**
	 * Closes all available connections.
	 */
	public synchronized void release()
	{
		Enumeration allFreeConnections = m_freeConnections.elements();
		Enumeration allUsingConnections = m_usingConnections.elements();

		while (allFreeConnections.hasMoreElements())
		{
			Connection con = (Connection) ((Hashtable) allFreeConnections.nextElement()).get("CONN");
			try
			{
				con.close();
				log.println("Closed connection for pool " + m_name);
			}
			catch (SQLException e)
			{
				log.println(e + " Can't close connection for pool " + m_name);
			}
		}

		while (allUsingConnections.hasMoreElements())
		{
			Connection con = (Connection) ((Hashtable) allUsingConnections.nextElement()).get("CONN");
			try
			{
				con.close();
				log.println("Closed connection for pool " + m_name);
			}
			catch (SQLException e)
			{
				log.println(e + " Can't close connection for pool " + m_name);
			}
		}

		m_freeConnections.removeAllElements();
		m_usingConnections.removeAllElements();
	}


	/**
	 * Creates a new connection, using a userid and password
	 * if specified.
	 */
	private Hashtable newConnection()
	{
		Connection con = null;
		try
		{
			if (m_user == null)
			{
				con = DriverManager.getConnection(m_URL);
			}
			else
			{
				con = DriverManager.getConnection(m_URL, m_user, m_password);
			}
			log.println("Created a new connection in pool " + m_name);
		}
		catch (SQLException e)
		{
			log.println(e + " Can't create a new connection for " + m_URL);
			return null;
		}

		Hashtable hashConn = new Hashtable();

		hashConn.put("CONN", con);
		hashConn.put("CREATE", Calendar.getInstance().getTime());
		hashConn.put("USE", Calendar.getInstance().getTime());

		return hashConn;
	}


	/**
	 * Get number of available connections in connection pool
	 *
	 * @return numberOfAvailableConnections
	 */
	public int getFreeSize()
	{
		return m_freeConnections.size();
	}


	/**
	 * Get number of connections which are used by someone now in connection pool
	 *
	 * @return numberOfUsingConnections
	 */
	public int getUsingSize()
	{
		return m_usingConnections.size();
	}
}
