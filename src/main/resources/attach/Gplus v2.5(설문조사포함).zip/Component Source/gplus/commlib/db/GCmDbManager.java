package gplus.commlib.db;

import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.Date;
import gplus.commlib.*;
import gplus.commlib.comm.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.GCmDebugLog;

/**
 * <PRE>
 * Filename	: GCmDbManager.java
 * Class	: GCmDbManager
 * Function	: Wrapper class of GCmDbConnPool
 * Comment      :
 * History      : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GCmDbManager
{
    protected String 	m_sysCharSet = null;	// System CharSet
    protected boolean	m_dbReadOnly = false; // Connection ReadOnly flag

    private static GCmDbManager m_instance;       // The single instance
    private static int m_clients;
    private static boolean	verbose = false;

    private Vector 		m_drivers	= new Vector();
    private Hashtable 	m_pools 	= new Hashtable();

    private static GCmDebugLog log = null;

    /**
     * GCmDbManager constructor<br>
     * A private constructor since this is a Singleton
     */
    protected GCmDbManager()
    {
		m_instance = null;
    }


    /**
     * This class is singleton, so Returns the single instance,
     * creating one if it's the first time this method is called.
     *
     * @return GCmDbManager The single instance.
     */
    public static synchronized GCmDbManager getInstance()
    {
        if (m_instance == null)
        {
            m_instance = new GCmDbManager();
        }
        m_clients++;
        return m_instance;
    }


    /**
     * Loads properties and initializes the instance with its values.
     */
    public static void init() throws Exception
	{
		if (m_instance == null)
		{
			if (verbose)
			{
				System.out.println("GCmDbManager Initialized ...");
			}

			m_instance = new GCmDbManager();

			GCmPropertyManager propMgr = GCmPropertyManager.getInstance();

			m_instance.m_sysCharSet = propMgr.getPropertyInstance(GCmConstDef.GROUPWARE_ID).
									getProperty("gplus.system.charset");

			try
			{
				String strLogPath = GCmPropertyManager.getInstance()
							.getPropertyInstance(GCmConstDef.GROUPWARE_ID)
							.getProperty("gplus.log.path");

				log = new GCmDebugLog(strLogPath + File.separator + "gplus.log");
			}
			catch (Exception e)
			{
				log = new GCmDebugLog(new PrintWriter(System.err));
			}

			m_instance.loadDrivers();		// load JDBC Drivers
			m_instance.createGroupWarePools();	// create ConnectionPool of Mall
		}
    }


    /**
     * Loads and registers all JDBC drivers. This is done by the
     * DBConnectionManager, as opposed to the GCmDbConnPool,
     * since many pools may share the same driver.
     *
     * @param props The connection pool properties
     */
    private void loadDrivers()
    {
	GCmPropertyManager propMgr = null;
	try
	{
		propMgr = GCmPropertyManager.getInstance();
	}
	catch (Exception e)
	{
		log.println("GCmDbManager: Can't get property instance");
	}

        String driverClasses = propMgr.getPropertyInstance(GCmConstDef.GROUPWARE_ID).
								  getProperty("gplus.db.jdbcDriver");

        StringTokenizer st = new StringTokenizer(driverClasses);

        while (st.hasMoreElements())
	{
            String driverClassName = st.nextToken().trim();

            try
	    {
                Driver driver = (Driver)Class.forName(driverClassName).newInstance();
                DriverManager.registerDriver(driver);
                m_drivers.addElement(driver);
                log.println("Registered JDBC driver " + driverClassName);
            }
            catch (Exception e)
			{
                log.println("Can't register JDBC driver: " +
                    driverClassName + ", Exception: " + e);
            }
        }
    }


    /**
     * Loads and registers all JDBC drivers. This is done by the
     * DBConnectionManager, as opposed to the GCmDbConnPool,
     * since many pools may share the same driver.
     *
     * @param driverName
     */
    private void loadDrivers(String driverName)
    {

        String driverClasses = driverName;

        StringTokenizer st = new StringTokenizer(driverClasses);

        while (st.hasMoreElements())
	{
            String driverClassName = st.nextToken().trim();

            try
	    {
                Driver driver = (Driver)Class.forName(driverClassName).newInstance();
                DriverManager.registerDriver(driver);
                m_drivers.addElement(driver);
                log.println("Registered JDBC driver " + driverClassName);
            }
            catch (Exception e)
			{
                log.println("Can't register JDBC driver: " +
                    driverClassName + ", Exception: " + e);
            }
        }
    }


    /**
     * Creates instances of GCmDbConnPool based on the Properties.
	 *
	 * @param props Properties object contains url,.etc.
	 */
    private void createGroupWarePools()
    {
	GCmPropertyManager propMgr = null;
	try
	{
		propMgr = GCmPropertyManager.getInstance();
	}
	catch (Exception e)
	{
		log.println("GCmDbManager: Can't get property instance");
	}

        String poolName = GCmConstDef.GROUPWARE_ID;
        String url      = propMgr.getPropertyInstance(GCmConstDef.GROUPWARE_ID).
							getProperty("gplus.db.jdbcUrl");
        String user     = propMgr.getPropertyInstance(GCmConstDef.GROUPWARE_ID).
							getProperty("gplus.db.user");
        String password = propMgr.getPropertyInstance(GCmConstDef.GROUPWARE_ID).
							getProperty("gplus.db.password");
        String maxconn  = propMgr.getPropertyInstance(GCmConstDef.GROUPWARE_ID).
							getProperty("gplus.db.maxconn", "0");
        String m_dbCharSet = propMgr.getPropertyInstance(GCmConstDef.GROUPWARE_ID).
							   getProperty("gplus.db.charset");
        String s = propMgr.getPropertyInstance(GCmConstDef.GROUPWARE_ID).
						getProperty("gplus.db.readOnly");

        if (s != null && (s.equals("yes") || s.equals("true")))
        {
            m_dbReadOnly = true;
        }

        int max;

        try
        {
            max = Integer.parseInt(maxconn);
        }
        catch (NumberFormatException e)
        {
            log.println("Invalid maxconn value " + maxconn + " for " + poolName);
            max = 0;
        }

        GCmDbConnPool pool = new GCmDbConnPool(poolName, url, user, password, max);
        m_pools.put(poolName, pool);

        log.println("Initialized pool " + poolName);
    }

    /**
     * Returns a connection to the named pool.
     *
     * @param shopId The key of shop identifies connection
     * @param con GCmConnection
     */
    public void freeConnection(GCmConnection con)
    {
	String name = GCmConstDef.GROUPWARE_ID; // �ټ����� ��ȣ�� �����ؼ� connection pool�� ����� �ִ�..

        GCmDbConnPool pool = (GCmDbConnPool) m_pools.get(name);
        if (pool != null)
        {
        	if (con.m_depth == 0)
	    	{
        		pool.freeConnection(con.getConnection());
        	}
		else
        	{
        		con.m_depth--;
        	}
        }
    }



    /**
     * Get an open connection. If no one is available, and the max
     * number of connections has not been reached, a new connection is
     * created.
     *
	 * @param shopId The key of shop identifies connection
     * @return Connection The connection or null
     */
    public GCmConnection getConnection()
    {
	String name = GCmConstDef.GROUPWARE_ID;

    	GCmDbConnPool pool = (GCmDbConnPool) m_pools.get(name);

    	if (pool != null)
    	{
    		Connection conn = pool.getConnection();

		try
		{
			if (m_instance.m_dbReadOnly)
			{
				conn.setReadOnly(true);
			}
		}
		catch (Exception e)
		{
			System.out.println("GCmDbManager : setReadOnly Failed");
			e.printStackTrace();
		}

    		return new GCmConnection(conn, pool);
    	}
    	return null;
    }

    /**
     * Closes all open connections and deregisters all drivers.
     */
    public synchronized void release()
    {
        // Wait until called by the last client
        if (--m_clients != 0)
        {
            return;
        }

        Enumeration allPools = m_pools.elements();
        while (allPools.hasMoreElements())
        {
            GCmDbConnPool pool = (GCmDbConnPool) allPools.nextElement();
            pool.release();
        }

        Enumeration allDrivers = m_drivers.elements();

        while (allDrivers.hasMoreElements())
        {
            Driver driver = (Driver) allDrivers.nextElement();
            try
            {
                DriverManager.deregisterDriver(driver);
                log.println("Deregistered JDBC driver " + driver.getClass().getName());
            }
            catch (SQLException e)
            {
                log.println(e + " Can't deregister JDBC driver: "
					+ driver.getClass().getName());
            }
        }
    }


}


