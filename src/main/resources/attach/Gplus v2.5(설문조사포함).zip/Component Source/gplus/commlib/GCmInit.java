package gplus.commlib;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import gplus.commlib.exception.GCmGplusException;
import gplus.commlib.log.GCmDebugLog;

/**
 * <PRE>
 * Filename : GCmInit.java
 * Class    : gplus.commlib.GCmInit
 * Function : GPlus �׷���� �ý��� �ʱ�ȭ Servelt
 * Comment  :
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GCmInit extends HttpServlet
{
    public void init(ServletConfig config) throws ServletException
    {
	System.gc();
        super.init(config);

        ServletContext context = getServletContext();
        String gplusDir	= getInitParameter("GPLUSDIR");

	GCmDebugLog log = null;

	try
	{
        	log = new GCmDebugLog(gplusDir + File.separator + "log" + File.separator + "gplus.log");
        }
        catch (Exception e)
        {
        	context.log("Can't initialize log");
                System.out.println("Can't initialize log");
        	log = new GCmDebugLog(new PrintWriter(System.err));
        }

        Properties prop = System.getProperties();

        Enumeration enum = prop.propertyNames();

        while (enum.hasMoreElements())
        {
            String key = (String) enum.nextElement();
            String val = System.getProperty(key);

            log.println(key + "=" + val);
        }

        try
        {
        	GCmLicenseManager.init(gplusDir);
        }
        catch (GCmGplusException e)
        {
        	context.log("Your license is expired...");
                System.out.println("Your license is expired...");
        	log.println("Your license is expired...");
        	System.runFinalization();
        	System.exit(0);
        }

        try
	{
            if (gplusDir == null)
	    {
                context.log("gplusDir parameter is null, " + " GPlus Initialization failed");
                System.out.println("gplusDir parameter is null, " + " GPlus Initialization failed");
	        log.println("gplusDir parameter is null, " + " GPlus Initialization failed");
                return;
            }

		context.log("Load GCmInit servlet");
                System.out.println("Load GCmInit servlet");
        	log.println("Load GCmInit servlet");
		GCmInitializer.executeAll(gplusDir);
        }
        catch (Exception e)
	{
            context.log(e, " in GCmInit. GPlus Initialization failed");
            System.out.println(e+" in GCmInit. GPlus Initialization failed");
            log.println(e + " in GCmInit. GPlus Initialization failed");
        }
    }

    public void service(HttpServletRequest req,
                        HttpServletResponse res) throws IOException
    {
    }
}
