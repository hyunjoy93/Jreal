package gplus.commlib.db;

import java.io.*;
import java.sql.*;
import java.io.UnsupportedEncodingException;



/**
 * <PRE>
 * Filename	: GCmConnection.java
 * Class	: GCmConnection
 * Function	: Wrap a pure connection and serve several services like 'execute'
 * Comment	:
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 * @see		GCmDbManager
 */
public class GCmConnection
{
	protected Connection 	m_conn 		= null;			// database conneciton object
	protected Statement globalstmt = null;
	protected GCmDbConnPool m_connPool	= null;
	public int m_depth = 0;

	private final boolean verbose = false;

    /**
     * GCmConnection constructor<br>
     */
    protected GCmConnection()
    {
    }

    /**
     * GCmConnection constructor<br>
     *
     * @param conn Database Connection object
     */
    public GCmConnection(Connection conn)
    {
    	if (verbose)
		System.err.println("GCmConnection : constructor2 start.........");

	if (conn == null)
	{
		System.err.println("GCmConnection : Connection parameter is null.. Error occured..");
	}
	else
	{
		m_conn = conn;
		m_depth = 0;
	}
    }


    /**
     * GCmConnection constructor<br>
     *
     * @param conn Database Connection object
     * @param connPool Database Connection Pool object
     */
    public GCmConnection(Connection conn, GCmDbConnPool connPool)
    {
    	if (verbose)
		System.err.println("GCmConnection : constructor3 start.........");

	if (conn == null)
	{
	    	System.err.println("GCmConnection : Connection parameter is null.. Error occured..");
	}
	else if (connPool == null)
	{
		System.err.println("GCmConnection : Connection Pool Parameter is null.. Error occured..");
	}
	else
	{
		m_conn = conn;
		m_connPool = connPool;
		m_depth = 0;

		if (verbose)
		{
			System.err.println("FREE : " + m_connPool.getFreeSize());
			System.err.println("USED : " + m_connPool.getUsingSize());
		}
	}
    }


	/**
	 * Releases a Connection, Satement, PreparedStatement's database <br>
	 * and JDBC resources immediately <br>
	 * instead of waiting for them to be automatically released. <br>
	 */
	public void close()
	{
		if (verbose)
			System.err.println("GCmConnection : close() called ..........");

		if (m_conn == null)
		{
			return;
		}

		if (m_connPool != null)
		{
			if (m_depth == 0)
			{
				m_connPool.freeConnection(m_conn);
				m_conn = null;
			}
			else
			{
				m_depth--;
			}

			if (verbose)
			{
				System.err.println("FREE : " + m_connPool.getFreeSize());
				System.err.println("USED : " + m_connPool.getUsingSize());
			}

		}
	}

	public void closeGlobalStmt()
	{
		if (verbose)
			System.err.println("GCmConnection : close() called ..........");

		if (m_conn == null)
		{
			return;
		}

		if (m_connPool != null)
		{
			if (m_depth == 0)
			{
				m_connPool.freeConnection(m_conn);
				m_conn = null;
			}
			else
			{
				m_depth--;
			}

			if (verbose)
			{
				System.err.println("FREE : " + m_connPool.getFreeSize());
				System.err.println("USED : " + m_connPool.getUsingSize());
			}
		}

		try
		{
			globalstmt.close();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}

	}



    /**
     * Gets current database connection member instance
     *
     * @return Conneciton Database Connection instance
     * @exception NullPointerException If connection member variable is null
     */
    public Connection getConnection() throws NullPointerException
    {
	if (verbose)
		System.err.println("GCmConnection : getConnection() called ..........");

    	if (m_conn == null)
    		throw new NullPointerException();
    	else
    		return m_conn;
    }


    /**
     * Tests to see if a Connection is closed.
     *
     * @return boolean true if the connection is closed; false if it's still open
     * @exception SQLException If database access error occurs
     * @exception NullPointerException If connection member variable is null
     */
    public boolean isClosed() throws SQLException, NullPointerException
    {
    	if (verbose)
		System.err.println("GCmConnection : isClosed() called ..........");

	if (m_conn == null)
		throw new NullPointerException();
	else
		return m_conn.isClosed();

    }


    /**
     * Sets this connection's auto-commit mode. If a connection is in auto-commit mode, <br>
     * then all its SQL statements will be executed and committed as individual transactions. <br>
     * Otherwise, its SQL statements are grouped into transactions that are terminated <br>
     * by a call to either the method commit or the method rollback. <br>
     * By default, new connections are in auto-commit mode. <br>
     * The commit occurs when the statement completes or the next execute occurs, <br>
     * whichever comes first. In the case of statements returning a ResultSet, <br>
     * the statement completes when the last row of the ResultSet has been retrieved <br>
     * or the ResultSet has been closed. In advanced cases, a single statement may <br>
     * return multiple results as well as output parameter values. <br>
     * In these cases the commit occurs when all results and <br>
     * output parameter values have been retrieved. <br>
     *
     * @param autoCommit true enables auto-commit; false disables auto-commit.
     * @exception SQLException If database access error occurs
     * @exception NullPointerException If connection member variable is null
     */
    public void setAutoCommit(boolean autoCommit) throws SQLException, NullPointerException
    {
    	if (verbose)
		System.err.println("GCmConnection : setAutoCommit() called ..........");

	if (m_conn == null)
		throw new NullPointerException();
	else
		m_conn.setAutoCommit(autoCommit);

    }

    /**
     * Gets the current auto-commit state
     *
     * @return boolean The current auto-commit state
     * @exception SQLException If database access error occurs
     * @exception NullPointerException If connection member variable is null
     */
    public boolean getAutoCommit() throws SQLException, NullPointerException
    {
    	if (verbose)
		System.err.println("GCmConnection : getAutoCommit() called ..........");

	if (m_conn == null)
		throw new NullPointerException();
	else
		return m_conn.getAutoCommit();
    }

    /**
     * Puts this connection in read-only mode as a hint to enable database optimizations.
     *
     * @param readOnly true enables read-only mode; false disables read-only mode.
     * @exception SQLException If database access error occurs
     * @exception NullPointerException If connection member variable is null
     */
    public void setReadOnly(boolean readOnly) throws SQLException, NullPointerException
    {
    	if (verbose)
		System.err.println("GCmConnection : setReadOnly() called ..........");

	if (m_conn == null)
		throw new NullPointerException();
	else
		m_conn.setReadOnly(readOnly);
    }

    /**
     * Tests to see if the connection is in read-only mode.
     *
     * @return boolean true if connection is read-only and false otherwise
     * @exception SQLException If database access error occurs
     * @exception NullPointerException If connection member variable is null
     */
    public boolean isReadOnly() throws SQLException, NullPointerException
    {
    	if (verbose)
		System.err.println("GCmConnection : isReadOnly() called ..........");

	if (m_conn == null)
		throw new NullPointerException();
	else
		return m_conn.isReadOnly();

    }

    /**
	 * Gets the metadata regarding this connection's database. <br>
	 * A Connection's database is able to provide information describing its tables, <br>
	 * its supported SQL grammar, its stored procedures, the capabilities of <br>
	 * this connection, and so on. <br>
	 * This information is made available through a DatabaseMetaData object. <br>
	 *
	 * @return DatabaseMetaData a DatabaseMetaData object for this Connection
     * @exception SQLException If database access error occurs
     * @exception NullPointerException If connection member variable is null
     */
    public DatabaseMetaData getMetaData() throws SQLException, NullPointerException
    {
    	if (verbose)
		System.err.println("GCmConnection : getMetaData() called ..........");

	if (m_conn == null)
		throw new NullPointerException();
	else
		return m_conn.getMetaData();
    }

	/**
	 * Makes all changes made since the previous commit/rollback permanent and <br>
	 * releases any database locks currently held by the Connection. <br>
	 * This method should be used only when auto-commit mode has been disabled. <br>
	 *
     * @exception SQLException If database access error occurs
     * @exception NullPointerException If connection member variable is null
     * @see setAutoCommit(boolean autoCommit)
	 */
	public void commit() throws SQLException, NullPointerException
	{
		if (verbose)
			System.err.println("GCmConnection : commit() called ..........");

		if (m_conn == null)
			throw new NullPointerException();
		else if (m_depth == 0)
			m_conn.commit();
	}


	/**
	 * Drops all changes made since the previous commit/rollback and <br>
	 * releases any database locks currently held by this Connection. <br>
	 * This method should be used only when auto- commit has been disabled. <br>
	 *
     * @exception SQLException If database access error occurs
     * @exception NullPointerException If connection member variable is null
     * @see setAutoCommit(boolean autoCommit)
	 */
	public void rollback() throws SQLException, NullPointerException
	{
		if (verbose)
			System.err.println("GCmConnection : rollback() called ..........");

		if (m_conn == null)
			throw new NullPointerException();
		else if (m_depth == 0)
			m_conn.rollback();
	}


	/**
	 * Creates a Statement object for sending SQL statements to the database. <br>
	 * SQL statements without parameters are normally executed using Statement objects. <br>
	 * If the same SQL statement is executed many times, it is more efficient <rb>
	 * to use a PreparedStatement JDBC 2.0 Result sets created using the returned Statement <br>
	 * will have forward-only type, and read-only concurrency, by default. <br>
	 *
	 * @return Statement a new Statement object
     * @exception SQLException If database access error occurs
     * @exception NullPointerException If connection member variable is null
     * @see prepareStatement()
	 */
	public Statement createStatement() throws SQLException, NullPointerException
	{
		if (verbose)
			System.err.println("GCmConnection : createStatement() called ..........");

		if (m_conn == null)
			throw new NullPointerException();
		else
			return m_conn.createStatement();
	}


	/**
	 * Creates a PreparedStatement object for sending parameterized SQL statements <br>
	 * to the database. A SQL statement with or without IN parameters can be pre-compiled <br>
	 * and stored in a PreparedStatement object. This object can then be used to efficiently <br>
	 * execute this statement multiple times. <br>
	 *
	 * @param sql a SQL statement that may contain one or more '?' IN parameter placeholders
	 * @return PreparedStatement a new PreparedStatement object containing the pre-compiled statement
     * @exception SQLException If database access error occurs
     * @exception NullPointerException If connection member variable is null
	 */
	public PreparedStatement prepareStatement(String sql)
		throws SQLException, NullPointerException
	{
		if (verbose)
			System.err.println("GCmConnection : prepareStatement() called ..........");

		if (m_conn == null)
			throw new NullPointerException();
		else
			return m_conn.prepareStatement(sql);
	}

	/**
	 * Execute a SQL query which is given by a method calling this. <br>
	 * At first, it creates statement object of connection object named m_conn, and <br>
	 * execute the query and wrap it into GCmResultSet object, then...Return it. <br>
	 *
	 * @param strSql A SQL string
	 * @return ResultSet A wrapper object of result set
     * @exception SQLException If database access error occurs
     * @exception NullPointerException If SQL string is null
	 */
/*	public ResultSet executeNonGpsQuery(String strSql)
		throws SQLException, NullPointerException
	{
		Statement stmt = null;

		if (strSql == null)
		{
			throw new NullPointerException();
		}

		try
		{
			stmt = m_conn.createStatement();

			if (verbose)
			{
				System.err.println("CONN : " + m_conn.toString());
				System.err.println("CONN_DEPTH : " + Integer.toString(m_depth));
			}

			return stmt.executeQuery(strSql);

		}
		catch (SQLException e)
		{
			e.printStackTrace();
			throw new SQLException();
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
				e.printStackTrace();
			}
		}
	} */

	/**
	 * Execute a SQL query which is given by a method calling this. <br>
	 * At first, it creates statement object of connection object named m_conn, and <br>
	 * execute the query and wrap it into GCmResultSet object, then...Return it. <br>
	 *
	 * @param strSql A SQL string
	 * @return GCmResultSet A wrapper object of result set
     * @exception SQLException If database access error occurs
     * @exception NullPointerException If SQL string is null
	 */
	public GCmResultSet executeQuery(String strSql)
		throws SQLException, NullPointerException
	{
		Statement stmt = null;

		if (strSql == null)
		{
			throw new NullPointerException();
		}

		try
		{
			stmt = m_conn.createStatement();

			if (verbose)
			{
				System.err.println("CONN : " + m_conn.toString());
				System.err.println("CONN_DEPTH : " + Integer.toString(m_depth));
			}

			return new GCmResultSet(stmt.executeQuery(strSql));

		}
		catch (SQLException e)
		{
			e.printStackTrace();

			throw new SQLException();
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
				e.printStackTrace();
			}
		}
	}

	public ResultSet executeSqlQuery(String strSql)
		throws SQLException, NullPointerException
	{

		if (strSql == null)
		{
			throw new NullPointerException();
		}

		try
		{
			globalstmt = m_conn.createStatement();

			if (verbose)
			{
				System.err.println("CONN : " + m_conn.toString());
				System.err.println("CONN_DEPTH : " + Integer.toString(m_depth));
			}

			return globalstmt.executeQuery(strSql);

		}
		catch (SQLException e)
		{
			e.printStackTrace();

			throw new SQLException();
		}
	}

	/**
	 * Execute a SQL query which is given by a method calling this. <br>
	 * At first, it creates statement object of connection object named m_conn. <br>
	 *
	 * @param strSql A SQL string
     * @exception SQLException If database access error occurs
     * @exception NullPointerException If SQL string is null
	 */
	public void execute(String strSql)
		throws SQLException, NullPointerException
	{
		Statement stmt = null;

		if (strSql == null)
		{
			throw new NullPointerException();
		}

		try
		{
			stmt = m_conn.createStatement();

			stmt.execute(strSql);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			throw new SQLException();
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
				e.printStackTrace();
			}
		}
	}


	/**
	 * Execute a SQL query which is given by a method calling this. <br>
	 * At first, it creates statement object of connection object named m_conn. <br>
	 *
	 * @param strSql A SQL string
     * @exception SQLException If database access error occurs
     * @exception NullPointerException If SQL string is null
	 */
	public void executeUpdate(String strSql)
		throws SQLException, NullPointerException
	{
		Statement stmt = null;

		if (strSql == null)
		{
			throw new NullPointerException();
		}

		try
		{
			stmt = m_conn.createStatement();

			stmt.executeUpdate(strSql);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			throw new SQLException();
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
				e.printStackTrace();
			}
		}
	}


}



