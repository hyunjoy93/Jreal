package gplus.commlib.util;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;
import gplus.commlib.comm.*;
import gplus.commlib.lib.*;
import gplus.commlib.util.*;

/**
 * <PRE>
 * Filename : EmailRead.java
 * Class    : EmailRead
 * Function : utility
 * Comment  :
 * History  : 2/16/2002, ������, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class EmailRead {

    public EmailRead() {
    }

    private static String conttype = "1";
    private static String contMimeType = "";
    private static int nAttnum = 0;
    private static InboxManager inboxManager;
    private static String charset = "";
    private static java.io.InputStream isp = null;

    public static int getAttnum() { return nAttnum; }
    /**
     * Charset �� ��� �´�.
     * @return charset
     */
    public static String getCharset() {
        return charset;
    }






    /**
	 * <PRE>
	 * multipart/alternative ���� HTML ���� ����..
     * Html �� Text �� �����ϸ� HTML ������ ����
	 * <PRE>
     * @param multipart
     * @return Html or Text
     */
    public static String getMsgAlternative(Multipart multipart) throws Exception
	{

		String sRet = "";
		String sHtml = "";
		String sTxt = "";
		String sTxt1 = "";


        for(int i = 0;i < multipart.getCount();i++)
		{

			Part p = multipart.getBodyPart(i);
            String mime = p.getContentType();
            contMimeType = mime;


            if(p.isMimeType("text/html"))
			{


                sHtml += getTextMsgBody(p);
                conttype = "2";

            }
            else if (p.isMimeType("text/plain")) sTxt += getTextMsgBody(p);

            else if (mime.startsWith("text")) sTxt1 += getTextMsgBody(p);

            else
			{
                String filename = p.getFileName();

				if (filename != null && !filename.equals(""))
				{

					//��������..

				} else
				{

                    sTxt1 += getTextMsgBody(p);

                }
            }
        }

        sRet = "<pre>" + sTxt + "</pre>";

        if (sHtml != null && !sHtml.equals("")) sRet = sHtml;

        return sRet;
    }




    /**
	 * <PRE>
     * �޼������� �ؽ�Ʈ ������ �����Ѵ�.
     * ĳ���ͼ��� �ִ��� �˻��Ͽ� ������ �� ĳ���ͼ����� ������ EUC_KR�� ��ȯ
	 * <PRE>
     * @param message
     * @return Text
     */
    public static String getTextMsgBody(Object obj) throws Exception
	{


		String sRet = "";
        String tmpStrChk = "";
        javax.mail.Part p = null;
        p = (javax.mail.internet.MimePart)obj;
		InputStream in = null;


		try
		{
			
	
			String[] encoding = p.getHeader("Content-Transfer-Encoding");

			in = p.getInputStream();


			if (encoding !=null && encoding.length > 0)
			{

				encoding[0] = encoding[0].toLowerCase();


				//quoted�� �ѹ� �� decoding
				if (encoding !=null && encoding.length > 0 && encoding[0].equals("quoted-printable"))
				{
					in = MimeUtility.decode(in, encoding[0]);

				}

			}


			String mime = p.getContentType();

			int index = mime.toLowerCase().indexOf("charset=");

		    charset = "";

			if (index >0)
			{

				// ; -> ���� ���� charset= �� �ִ��� Ȯ�� -> ���� �и� -> ' �Ǵ� " ��ȣ ����
				int nSemiPos = mime.indexOf(";");

				// charset �� ������... ���ڼ� �и���
	            if (nSemiPos>-1)
				{

					String sTmp = mime.substring(nSemiPos+1);

					int nEqualPos = sTmp.indexOf("=");  // charset= ������ ���ڼ� �и�...

					if (nEqualPos>0)
					{

						sTmp = sTmp.substring(nEqualPos+1);

			        }

				    int nEndSemicolon = sTmp.indexOf(";");

					if (nEndSemicolon > -1)
					{

		                sTmp = sTmp.substring(0,nEndSemicolon);

			        }

					// ' or " ����
					if (sTmp != null && sTmp.trim().length() > 1)
					{

		                sTmp = GCmFcts.replace(sTmp,"'","");
			            sTmp = GCmFcts.replace(sTmp,"\"","");

				    }

					charset = sTmp.trim();
	            }
		    }



			java.io.BufferedReader bufFile = new java.io.BufferedReader(new java.io.InputStreamReader(in));


	        while ((tmpStrChk = bufFile.readLine()) != null)
			{

			    sRet += tmpStrChk + "\n";
			
				//sRet += new String(tmpStrChk.getBytes()) + "\n";

	        }

	
	        return sRet;

		}
		catch(Exception e)
		{

				e.printStackTrace();
				return null;

		}


    }



	/**
	 * <PRE>
	 *  �޽��� �и�
	 * </PRE>
	 *
	 * @param prop	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�	<BR>
	 *				<LI> String MAILNO        : ���Ϲ�ȣ  <BR>
	 *				<LI> String DOCNO         : ������ȣ  <BR>
	 *				<LI> String TITLE           :  ����        <BR>
	 *				<LI> String VPATH         : ������    <BR>
	 *				<LI> String PPATH         : ��������� <BR>
	 *				<LI> String REGUSER     : �����       <BR>
	 *				<LI> String REGUSER     : �����       <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  String �������ϳ���
	 */
	public static String getMsgMime(GCmProperties prop, GCmProperties dmProp, GCmMsgInfo msgInfo)
    throws IOException, MessagingException, Exception
	{




        String sRet = "";
        String sfile = "";
        String inFileName = "";
        String mime = "";
        String charset = "";
        int nAttCnt = 1;
        int seq;  //�������� �Ϸù�ȣ



		//Message msg= (Message)dmProp.getObject("MSG");
		Part msg = (Part)dmProp.getObject("MSG");
		String comcode = dmProp.getString("COMCODE");
		String mailno = dmProp.getString("MAILNO");
		String docno = dmProp.getString("DOCNO");
		String title = dmProp.getString("TITLE");
		String vpath = dmProp.getString("VPATH");
		String ppath = dmProp.getString("PPATH");
		String reguser = dmProp.getString("REGUSER");
		String regdate = dmProp.getString("REGDATE");


		try
		{


	        //int msgNo = msg.getMessageNumber();

			gplus.template.GTpDoc Doc = new gplus.template.GTpDoc();


		    if(msg.isMimeType("multipart/*"))
			{


				Multipart multipart = (Multipart)msg.getContent();

				for(int i = 0;i < multipart.getCount();i++)
				{

					Part p = multipart.getBodyPart(i);
					mime = p.getContentType();

	                if (p.isMimeType("multipart/alternative"))
					{


						Multipart mp = (Multipart)p.getContent();
				        sRet = getMsgAlternative(mp); //����


	                }
		            else if(p.isMimeType("text/plain") || p.isMimeType("text/html"))
					{


						inFileName = p.getFileName();

						//÷������
						if (inFileName != null && !inFileName.equals(""))
						{

	
							nAttCnt++;

			                sfile += dumpPart(msg,i,nAttCnt,Doc,comcode,docno,title,vpath,ppath,reguser,regdate);

						}

						else
						{

							sRet = getTextMsgBody(p); // ����..
					        sRet = !p.isMimeType("text/html")?"<pre>"+sRet+"</pre>":sRet;
						    contMimeType = mime;


	                    }
		            }
					else if(p.isMimeType("message/rfc822")) 
					{
						
						nAttCnt++;
						sfile += emlSave((Part)p,i, nAttCnt,Doc,comcode,docno,title,vpath,ppath,reguser,regdate);

					}
			        else
					{

					    inFileName = p.getFileName();

						//÷������
						if (inFileName != null && !inFileName.equals(""))
						{

							nAttCnt++;
				            sfile += dumpPart(msg,i,nAttCnt,Doc,comcode,docno,title,vpath,ppath,reguser,regdate);

					    }
						else
						{

		                    sRet = getTextMsgBody(p); // ����..
			                sRet = "<pre>"+sRet+"</pre>";
				            contMimeType = mime;

					    }

	                }
		        }
			}
	        else if(msg.isMimeType("text/plain") || msg.isMimeType("text/html"))
			{


				mime = msg.getContentType();

		        inFileName = msg.getFileName();


				//÷������
				if (inFileName != null && !inFileName.equals(""))
				{

					nAttCnt++;
			        sfile += dumpPart(msg,-1,nAttCnt,Doc,comcode,docno,title,vpath,ppath,reguser,regdate);

				}
	            else
				{

			        sRet += getTextMsgBody(msg);
				    contMimeType = mime;

	            }

		    }
			else
			{


		        mime = msg.getContentType();

			    inFileName = msg.getFileName();

				//÷������
	            if (inFileName != null && !inFileName.equals(""))
				{

					nAttCnt++;
		            sfile += dumpPart(msg,-1,nAttCnt,Doc,comcode,docno,title,vpath,ppath,reguser,regdate);

			    }
				else if(mime.startsWith("text")) {

	                sRet += getTextMsgBody(msg);

				}
				else if (mime.startsWith("multipart/alternative"))
				{

					sRet += getTextMsgBody(msg);

				}
				else if (mime.startsWith("multipart/mixed"))
				{

					Multipart multipart = (Multipart)msg.getContent();


					for(int i=0;i < multipart.getCount();i++)
					{

						Part p = multipart.getBodyPart(i);

						Multipart mp = (Multipart)p.getContent();
						sRet = getMsgAlternative(mp);
					}

				}				
		        else
				{

				    nAttCnt++;
					sfile += dumpPart(msg,-1,nAttCnt,Doc,comcode,docno,title,vpath,ppath,reguser,regdate);

	            }

				contMimeType = mime;

			}





			String fileext = "";
		    String retMimeType = "";
			int nPos = 0;

			contMimeType = contMimeType.trim().toLowerCase();

	        nPos = contMimeType.indexOf(";");

		    if (nPos != -1)
			    retMimeType =  contMimeType.substring(0,nPos);
	        else
		        retMimeType = contMimeType;

			fileext = retMimeType.equals("text/html")?"htm":"txt";


			String  contSize = "0"; 




	        if (nAttCnt >= 2) nAttCnt = nAttCnt - 1;
		    else nAttCnt = 0;


			String attCnt = String.valueOf(nAttCnt);


	        nAttnum = nAttCnt; //÷�θ�ϼ��� �������� ���ؼ�..


			GCmProperties dmDoc = new GCmProperties();


			dmDoc.put("COMCODE", comcode);
			dmDoc.put("Docno", docno);
			dmDoc.put("Seq", "01");
			dmDoc.put("Conttype", "1");
			dmDoc.put("Title", title);
			dmDoc.put("Fileext", "." + fileext);
			dmDoc.put("Filename", docno + "_01." + fileext);
			dmDoc.put("Vpath", vpath);
			dmDoc.put("Mimetype", contMimeType);
			dmDoc.put("Filesize", contSize);
			dmDoc.put("Orgname", docno + "_01." + fileext);
			dmDoc.put("Orgpath", "");
			dmDoc.put("Reguser", reguser);
			dmDoc.put("Regdate", regdate);
			dmDoc.put("Moduser", reguser);
			dmDoc.put("Moddate", regdate);

			//���ϸ������
			Doc.insertAttDoc(prop, dmDoc, msgInfo);

			dmDoc.put("Doctype", "1");
			dmDoc.put("Attnum", attCnt);
			dmDoc.put("fromEmail", "Y");
            dmDoc.put("Conts", sRet);


			Doc.insertDoc(prop, dmDoc, msgInfo);

			return sRet ;


		}
		catch(Exception e)
		{

	 		System.out.println(" EmailRead::getMsgMime : " + e.getMessage());

			return null;

		}


    }



	/**
     * eml ÷������
     * @param   Message         Part
     * @param   sequence No     �Ϸù�ȣ
     * @param   attched count   ÷�μ�
     * @param   Doc                 GTpDoc
     * @param   comcode         ȸ���ڵ�
     * @param   docno           ������ȣ
     * @param   title           ����
     * @param   vpath           ������
     * @param   ppath           ��Ʈ�� ������ ���
     * @param   reguser         �����
     * @param   regdate         �����
     * @retrun  ���
     */
    public static String emlSave(Part msg, int seq, int nAttCnt, gplus.template.GTpDoc Doc, String comcode, String docno, String title,
                    String vpath, String ppath, String reguser, String regdate)
        throws IOException, MessagingException, Exception {
        
		String sRet = "";
        String fileext = "";
        String filename = "";
        String orgname = "";
        String orgpath = "";
        String mime = "";
        int idx = 0;

		
		try
		{

			orgname = "Attached.eml";

			filename = docno + "_" + GCmFcts.numToStr(String.valueOf(nAttCnt+1),2) + ".eml";



			File f = new File(ppath,filename);

	        InputStream in = msg.getInputStream();
		    FileOutputStream fos = new FileOutputStream(f);
			BufferedOutputStream out = new BufferedOutputStream(fos, 8 * 1024); // 8K

	        byte[] bbuf = new byte[100 * 1024];  // 100K
		    int result;

			while ((result = in.read(bbuf, 0, bbuf.length)) != -1)
				out.write(bbuf, 0, result);

	        out.flush();
		    out.close();
			fos.close();

	        int filesize = (int)f.length();
			String strFileSize = String.valueOf(filesize);




			GCmPropertyManager 	propMgr = GCmPropertyManager.getInstance();

			GCmMsgInfo 		msgInfo = new GCmMsgInfo();

			GCmProperties prop = propMgr.getPropertyInstance(GCmConstDef.GROUPWARE_ID);


			GCmProperties dmIns = new GCmProperties();

			dmIns.setProperty("COMCODE", comcode);
			dmIns.setProperty("Docno", docno);
			dmIns.setProperty("Seq", GCmFcts.numToStr(String.valueOf(nAttCnt+1),2));
			dmIns.setProperty("Conttype", "3");
			dmIns.setProperty("Title", title);
			dmIns.setProperty("Filext", ".eml");
			dmIns.setProperty("Filename", filename);
			dmIns.setProperty("Vpath", vpath);
			dmIns.setProperty("MimeType", mime);
			dmIns.setProperty("Filesize", strFileSize);
			dmIns.setProperty("Orgname", orgname);
			dmIns.setProperty("Orgpath", orgpath);
			dmIns.setProperty("Reguser", reguser);
			dmIns.setProperty("Regdate", regdate);
			dmIns.setProperty("Moduser", reguser);
			dmIns.setProperty("Moddate", regdate);

			Doc.insertAttDoc(prop, dmIns, msgInfo);


			return sRet;

		}
		catch(Exception e)
		{

	 		System.out.println(" EmailRead  ::  emlSave : " + e.getMessage());

			return null;

		}

    }




	/**
	 * <PRE>
     * ÷������ ����
	 * </PRE>
     * @param   Message   Part
     * @param   seq          �Ϸù�ȣ
     * @param   nAttCnt     ÷�μ�
     * @param   Doc          �������ø�
     * @param   comcode   ȸ���ڵ�
     * @param   docno       ������ȣ
     * @param   title           ����
     * @param   vpath        ������
     * @param   ppath        ������ ���
     * @param   reguser     �����
     * @param   regdate     �����
     * @retrun  String  ���������
     */
    public static String dumpPart(Part msg, int seq, int nAttCnt, gplus.template.GTpDoc Doc,
                    String comcode, String docno, String title, String vpath, String ppath, String reguser, String regdate)
    throws IOException, MessagingException, Exception
	{

		String sRet = "";
        String fileext = "";
        String filename = "";
        String orgname = "";
        String orgpath = "";
        String mime = "";
        int idx = 0;
        Part p;



		try
		{
			if (seq < 0)

				p = msg;

			else
			{

				Multipart mp = (Multipart)msg.getContent();
			    p = mp.getBodyPart(seq);

	        }


		    mime = p.getContentType();

			idx = mime.toLowerCase().indexOf("charset=");

	        orgname = p.getFileName();


			// ���ڼ� ������ ���� ���
			if( orgname.indexOf("=?")==-1 )

				try
				{

					orgname = MimeUtility.decodeText(orgname);
			        orgname = new String(orgname.getBytes("ISO-8859-1"),"EUC-KR");

				} catch(UnsupportedEncodingException e)
				{

                orgname = orgname;
		        }

			// ���ڼ� ������ �ִ� ���
	        else {

				String charset;

		        int startOfCharset;
			    int endOfCharset;

	            startOfCharset = orgname.indexOf("=?") + 2;
		        endOfCharset = orgname.indexOf("?", startOfCharset) -1;

			    charset = orgname.substring(startOfCharset,endOfCharset+1);

	            try
				{

			        orgname = MimeUtility.decodeText(orgname);
				    orgname = new String(orgname.getBytes(charset),"EUC-KR");

	            } catch (UnsupportedEncodingException e)
				{

			        orgname = orgname;

				}
	        }


		    int nPos = orgname.lastIndexOf("\\");

			if (nPos >0)

				orgname = orgname.substring(nPos+1);

		    nPos = orgname.lastIndexOf(".");

			if (nPos >0)

				fileext = orgname.substring(nPos);

			sRet = ppath ;

			filename = docno + "_" + GCmFcts.numToStr(String.valueOf(nAttCnt),2) + fileext;

			File f = new File(ppath,filename);




			String[] encoding = p.getHeader("Content-Transfer-Encoding");


	        InputStream in = p.getInputStream();

			if (encoding !=null && encoding.length > 0 && encoding[0].equals("quoted-printable"))
			{
				in = MimeUtility.decode(in, encoding[0]);			
			}

			FileOutputStream fos = new FileOutputStream(f);
		    BufferedOutputStream out = new BufferedOutputStream(fos, 8 * 1024); // 8K

	        byte[] bbuf = new byte[100 * 1024];  // 100K

			int result;


	        while ((result = in.read(bbuf, 0, bbuf.length)) != -1)
			{

		        out.write(bbuf, 0, result);
			}


			out.flush();
	        out.close();
		    fos.close();

			int filesize = (int)f.length();

			String strFileSize = String.valueOf(filesize);




		    //÷����������.

			GCmPropertyManager 	propMgr = GCmPropertyManager.getInstance();

			GCmMsgInfo 		msgInfo = new GCmMsgInfo();

			GCmProperties prop = propMgr.getPropertyInstance(GCmConstDef.GROUPWARE_ID);


			GCmProperties dmIns = new GCmProperties();

			dmIns.setProperty("COMCODE", comcode);
			dmIns.setProperty("Docno", docno);
			dmIns.setProperty("Seq", GCmFcts.numToStr(String.valueOf(nAttCnt),2));
			dmIns.setProperty("Conttype", "3");
			dmIns.setProperty("Title", title);
			dmIns.setProperty("Filext", fileext);
			dmIns.setProperty("Filename", filename);
			dmIns.setProperty("Vpath", vpath);
			dmIns.setProperty("MimeType", mime);
			dmIns.setProperty("Filesize", strFileSize);
			dmIns.setProperty("Orgname", orgname);
			dmIns.setProperty("Orgpath", orgpath);
			dmIns.setProperty("Reguser", reguser);
			dmIns.setProperty("Regdate", regdate);
			dmIns.setProperty("Moduser", reguser);
			dmIns.setProperty("Moddate", regdate);

			Doc.insertAttDoc(prop, dmIns, msgInfo);


	        return sRet;
		}
		catch(Exception e)
		{

	 		System.out.println(" EmailRead  ::  dumpPart : " + e.getMessage());

			return null;

		}


    }



	/**
	 * <PRE>
     *  Email Address �� NAME �и�
	 * </PRE>
     * @param Address
     * @retrun String  �����ּҿ� �̸�
     */

	public static String[] getEmailAddr(Address[] addresses) throws Exception
	{

		String[] sRet = new String[2];
        String sAddr = "";
        String sName = "";
        String sTmpAddr = "";
        String sTmpName = "";

        if (addresses != null)
		{

            for(int i = 0; i < addresses.length; i++)
			{

                sTmpAddr = ((InternetAddress) addresses[i]).getAddress();
                sTmpName = ((InternetAddress) addresses[i]).getPersonal();

                if (sTmpAddr == null) sTmpAddr = "\"\"";

	                sAddr += sTmpAddr.trim() + ",";

                if (sTmpName == null)

					sTmpName = sTmpAddr;

                else

					sTmpName = GCmFcts.replace(sTmpName,"\\","");

				sName += sTmpName.trim() + ",";
            }

            if (sAddr.length() > 1 && sAddr.substring(sAddr.length()-1,sAddr.length()).equals(","))

                sAddr = sAddr.substring(0,sAddr.length()-1);

            if (sName.length() > 1 && sName.substring(sName.length()-1,sName.length()).equals(","))

                sName = sName.substring(0,sName.length()-1);

            sRet[0] = sAddr;
            sRet[1] = sName;
        }

        if (sRet[0] == null) sRet[0] = "";
        if (sRet[1] == null) sRet[1] = "";

        return sRet;

    }


	/**
	 * <PRE>
     * �̸�<�����ּ�> ���� �����ּ� ����
	 * </PRE>
     * @param	addr		�ּ�
     * @return  Stirng  �����ּ�
     */
    public static String getMailAddr(String addr) throws Exception
	{

		String sRet = "";
        int nLtPos = 0;
        int nGtPos = 0;
        sRet = addr;

        nLtPos = sRet.indexOf("<");

        if (nLtPos > 0)
		{

            sRet = sRet.substring(nLtPos+1);
            nGtPos = sRet.indexOf(">");

            if (nGtPos>0)

                sRet = sRet.substring(0,nGtPos);

        }

        return sRet;

    }


	/**
	 * <PRE>
     * ��������� ����
	 * </PRE>
     * @param   msg					�޽���
     * @param   header				�����
     * @return						��� ���ڰ�
     */

    public static String getHeader(javax.mail.internet.MimeMessage msg, String header) throws Exception {

		String rawvalue = null;
        String value = null;

        try {

            if ((rawvalue=msg.getHeader(header)[0]) != null) // header�� "Subject"

                value = javax.mail.internet.MimeUtility.decodeText(rawvalue); // �ϴ� decodeText

            else

				return null;

        } catch (java.io.UnsupportedEncodingException e) {


            value =   rawvalue;

        } catch (javax.mail.MessagingException me) { }


        // =?......? ���̿� �ִ� ���ڼ��� �����´�.
        if( rawvalue.indexOf("=?")==-1 ) // ���ڼ� ������ ���� ���

            try
			{

                value = javax.mail.internet.MimeUtility.decodeText(rawvalue);
                value = new String(value.getBytes("ISO-8859-1"),"EUC-KR");

            } catch(java.io.UnsupportedEncodingException e)
			{

                value = value;

            }
		// ���ڼ� ������ �ִ� ���
        else
		{

            String charset;

            int startOfCharset;
            int endOfCharset;

            startOfCharset = rawvalue.indexOf("=?") + 2;
            endOfCharset = rawvalue.indexOf("?", startOfCharset) -1;

            charset = rawvalue.substring(startOfCharset,endOfCharset+1);

            try
			{

                rawvalue = GCmFcts.replace(rawvalue,"\\\"","\"");
                rawvalue = GCmFcts.replace(rawvalue,"\"","");
                value = javax.mail.internet.MimeUtility.decodeText(rawvalue);
                value = new String(value.getBytes(charset),"EUC-KR");

			} catch (java.io.UnsupportedEncodingException e)
			{

                value = value;

            }
        }

        return value;

    }


	/**
	 * <PRE>
     * �̸��� �̸�/�̸��� �и�
	 * </PRE>
     * @param   msg					�޽���
     * @param   header				�����
     * @return	 String[]  �̸��ϰ� �̸��� ������ �ִ� �迭
     */

    public String[] getEmail(javax.mail.internet.MimeMessage msg, String header) throws Exception
	{

		if (msg == null || header == null) return null;

		String value = null;
        String[] sRet = new String[2];
        String sRetName = "";
        String sRetEmail = "";

		// �̸����� <xxxx@xxx.com> �и�
        value = getHeader(msg,header);


		int nLpos;
        int nRpos;
		int nSize = 0;

		String tmp = "";
        String tmpName = "";
        String tmpEmail = "";

        java.util.StringTokenizer st = new java.util.StringTokenizer(value,",");


        nSize = st.countTokens();

        for (int i=0;i<nSize;i++)
		{

			tmp = st.nextToken();
            nLpos = tmp.indexOf("<");
            nRpos = tmp.indexOf(">");

			// �̸�
            if (nLpos>-1)
			{


                tmpName = tmp.substring(0,nLpos);

				//�̸���
                if (nRpos>-1)

                    tmpEmail = tmp.substring(nLpos+1,nRpos);

            }
            else
			{

                tmpEmail = tmp;

            }

			tmpEmail = GCmFcts.nvl(tmpEmail," ");
            tmpName = GCmFcts.replace(tmpName,"\\\"","\"");

            if (GCmFcts.nvl(tmpName,"").equals("")) tmpName = tmpEmail;

            if (sRetName.equals("")) sRetName = tmpName;
            else sRetName += "," + tmpName;

            if (sRetEmail.equals("")) sRetEmail = tmpEmail;
            else sRetEmail += "," + tmpEmail;

        }

        sRet[0] = sRetName;
        sRet[1] = sRetEmail;

        return sRet;

    }







    /**
     * <PRE>
     * �̸��� �̸����� �̸��� �и�
     * </PRE>
     * @param   msg					�޽���
     * @param   header				�����
     * @return    String 	��� ���ڰ�
     */
    public String getEmailName(javax.mail.internet.MimeMessage msg, String header) throws Exception
	{

		String value = null;
        String sRet = "";

        value = getHeader(msg,header);
        // �̸����� <xxxx@xxx.com> �и�

		int nLpos;
        int nRpos;
	    int nSize = 0;
        String tmp = "";
        String tmpName = "";
        String tmpEmail = "";

        java.util.StringTokenizer st = new java.util.StringTokenizer(value,",");

        nSize = st.countTokens();

        for (int i=0;i<nSize;i++)
		{

            tmp = st.nextToken();
            nLpos = tmp.indexOf("<");
            nRpos = tmp.indexOf(">");

            if (nLpos>0)
			{
                // Name
                tmpName = tmp.substring(0,nLpos).trim();
                // Email ã��...
                tmpEmail = tmp.substring(nLpos+1,nRpos).trim();;

            }

			tmpName = GCmFcts.replace(tmpName,"\\\"","\"");

			if (tmpName == null || tmpName.equals("")) tmpName = tmpEmail;

			if (sRet.equals("")) sRet = tmpName;
            else sRet += "," + tmpName;
        }

		return sRet.trim();

	}





	/**
	 * <PRE>
     * ���������Կ� ���ǻ���
	 * </PRE>
     * @param   Reqt     Request Object
     * @param   host          �����ּ�
     * @param   user          POP ID
     * @param   password  POP3 Password
     * @retrun  Folder        ���������� ����
     */

	public static Folder getInbox(javax.servlet.http.HttpServletRequest req, String host, String user, String password)
    throws IOException, ServletException, MessagingException
	{

            if(host == null || user == null || password == null) return null;
				URLName url = new URLName("pop3", host, -1, "", user, password);

			inboxManager = new InboxManager(url);

	        return inboxManager.getInbox();
    }




	/**
	 * <PRE>
     * ���������� ��������
	 * </PRE>
     */

    public static void setInboxClose() throws Exception
	{

		inboxManager.setClose();

	}
}