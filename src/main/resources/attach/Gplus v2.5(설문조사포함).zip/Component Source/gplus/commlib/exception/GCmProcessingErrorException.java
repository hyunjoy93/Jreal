package gplus.commlib.exception;

import gplus.commlib.lib.GCmMsgInfo;

/**
 * <PRE>
 * Filename	: GCmProcessingErrorException.java <BR>
 * Class	: GCmProcessingErrorException <BR>
 * Function	: <BR>
 * Comment	: 
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCmProcessingErrorException extends GCmGplusException 
{
	/**
	 * Catches exceptions without a specified string
	 */
	public GCmProcessingErrorException() {}

	/**
	 * Constructs the appropriate exception with the specified string
	 *
	 * @param message	Exception message
	 */
	public GCmProcessingErrorException(String message) {super(message);}

}
