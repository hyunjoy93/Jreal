package gplus.commlib.util;

/**
 * <PRE>
 * Filename : GCmDateFcts.java
 * Class    : GCmDateFcts
 * Function : GPlus ��¥���� UTIL
 * Comment  :
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GCmDateFcts {

    /**
     * ��¥ ��� -> VB -> DateAdd �Ա�
     * @param  interval -> ��(y), ��(m), ��(d)
     * @param  number -> ���ϰų� �� �Ⱓ
     * @param  date -> ������
     * @return Date
     */
    public static java.util.Date dateAdd(String interval, int number, java.util.Date date)
        throws Exception {
        java.util.Date dtRet = new java.util.Date();

        if (interval.toLowerCase().equals("d")) // ��(d)�ϰ��
            dtRet.setTime(date.getTime() + ((long)number * 1000 * 60 * 60 * 24));
        else if (interval.toLowerCase().equals("m")) {//��(m)�ϰ��
            java.text.SimpleDateFormat yearFormat = new java.text.SimpleDateFormat("yyyy", java.util.Locale.KOREA);
            java.text.SimpleDateFormat monthFormat = new java.text.SimpleDateFormat("MM", java.util.Locale.KOREA);
            java.text.SimpleDateFormat dayFormat = new java.text.SimpleDateFormat("dd", java.util.Locale.KOREA);
            java.text.SimpleDateFormat hourFormat = new java.text.SimpleDateFormat("HH", java.util.Locale.KOREA);
            java.text.SimpleDateFormat minuteFormat = new java.text.SimpleDateFormat("mm", java.util.Locale.KOREA);
            java.text.SimpleDateFormat secondFormat = new java.text.SimpleDateFormat("ss", java.util.Locale.KOREA);

            int year = Integer.parseInt(yearFormat.format(date));
            int month = Integer.parseInt(monthFormat.format(date));
            int day = Integer.parseInt(dayFormat.format(date));
            int hour = Integer.parseInt(hourFormat.format(date));
            int minute = Integer.parseInt(minuteFormat.format(date));
            int second = Integer.parseInt(secondFormat.format(date));

            month += number;
            if (number > 0) {
                while (month > 12) {
                    month -= 12;
                    year += 1;
                }
            } else {
                while (month <= 0) {
                    month += 12;
                    year -= 1;
                }
            }

            String s = String.valueOf(year) + String.valueOf(month) + String.valueOf(day)
                     + String.valueOf(hour) + String.valueOf(minute) + String.valueOf(second);
            java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat ("yyyyMMddHHmmss", java.util.Locale.KOREA);

            dtRet = formatter.parse(s);
        }
        else if (interval.toLowerCase().equals("y"))  //��(y)�� ���
            dtRet.setTime(date.getTime() + ((long)number * 1000 * 60 * 60 * 24 * (365 + 1)));

        return dtRet;
    }

    /**
     * ��¥ ���� ��� -> VB -> DateDiff �Լ�
     * @param  interval -> ��(y), ��(m), ��(d)
     * @param  date1 -> ù��° ������
     * @param  date2 -> �ι�° ������
     * @return ����
     */
    public static int dateDiff(String interval, java.util.Date date1, java.util.Date date2)
        throws Exception {
        int nRet = 0;
        long duration = date2.getTime() - date1.getTime();
        if (interval.toLowerCase().equals("d"))
            nRet =  (int)(duration/(1000 * 60 * 60 * 24));
        else if (interval.toLowerCase().equals("y"))
            nRet =  (int)(duration/(1000 * 60 * 60 * 24) / 365);
        else if (interval.toLowerCase().equals("m")) {
            java.util.Calendar cal1 = new java.util.GregorianCalendar();
            java.util.Calendar cal2 = new java.util.GregorianCalendar();
            cal1.setTime(date1);
            cal2.setTime(date2);

            int month1 = cal1.get(java.util.Calendar.MONTH);
            int month2 = cal2.get(java.util.Calendar.MONTH);

            nRet = month2 - month1;
        }
        return nRet;
    }

    /**
     * ��ȿ�� ��¥���� �ľ�...
     * @param  interval -> ��(y), ��(m), ��(d)
     * @param  s -> ��¥ ���ڿ�
     * @param  format -> yyyyMMdd yyyyMMddHHmmss....
     * @return ��/����
     */
    public static boolean isDate(String s, String format) {
        java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat (format, java.util.Locale.KOREA);
        java.util.Date date = null;
        try { date = formatter.parse(s); }
        catch(java.text.ParseException e) { return false; }
        if (!formatter.format(date).equals(s)) return false;
        return true;
    }

    /**
     * ��¥ ���ڿ��� ��¥Ÿ������ ��ȯ
     * @param  interval -> ��(y), ��(m), ��(d)
     * @param  s -> ��¥ ���ڿ�
     * @param  format -> yyyyMMdd yyyyMMddHHmmss....
     * @return ��¥
     */
    public static java.util.Date getToDate(String s, String format) throws Exception {
        java.util.Date dtRet = new java.util.Date();
        java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat (format, java.util.Locale.KOREA);
        dtRet = formatter.parse(s);
        return dtRet;
    }

    /**
     * VB -> WeekDay
     * @param  date -> ù��° ������
     * @return 1 - 7 -> �� - ��
     */
    public static int weekDay(java.util.Date date)
        throws Exception {
        int nRet = 0;
        java.util.Calendar cal = new java.util.GregorianCalendar();
        cal.setTime(date);
        nRet = cal.get(java.util.Calendar.DAY_OF_WEEK);
        return nRet;
    }

    /**
     * �ش����� ���ϸ� ���
     * @param  ���� ���� : 1 - 7 : �� - ��
     * @param  ��� ��� : 0->"��" 1->"�Ͽ���" 2->"Sun" 3->"Sunday"
     * @return ���ϸ�
     */
    public static String getWeekName(int n, int mode)
        throws Exception {
        String sRet = "";
        if (mode>3) mode=0;

        String[] sun = {"��","�Ͽ���","Sun","Sunday"};
        String[] mon = {"��","������","Mon","Monday"};
        String[] tue = {"ȭ","ȭ����","Tue","Tuesday"};
        String[] wed = {"��","������","Wed","Wednesday"};
        String[] thu = {"��","�����","Thu","Thursday"};
        String[] fri = {"��","�ݿ���","Fri","Friday"};
        String[] sat = {"��","�����","Sat","Saturday"};

        switch(n) {
        case 1 :
            sRet = sun[mode]; break;
        case 2 :
            sRet = mon[mode]; break;
        case 3 :
            sRet = tue[mode]; break;
        case 4 :
            sRet = wed[mode]; break;
        case 5 :
            sRet = thu[mode]; break;
        case 6 :
            sRet = fri[mode]; break;
        case 7 :
            sRet = sat[mode]; break;
        }
        return sRet;
    }

    // ���� �����Լ�... Overloading
    public static String getWeekName(java.util.Date date, int mode)
        throws Exception {

        int n = weekDay(date);
        String sRet = getWeekName(n,mode);

        return sRet;
    }

    public static String getWeekName(java.util.Date date) throws Exception {
        return getWeekName(date,0);
    }

    public static String getWeekName(int n) throws Exception {
        return getWeekName(n,0);
    }



    //parameter�� String���� �޾Ƽ� ���������� ��¥ ���ڿ��� ����...
    /**
     * ���������� ��¥ ���ڿ��� ����
     * @param  ��¥����
     * @param  ��¸��
     * @return ��¥
     */
    public static String formatDate(String dt, int mode)
        throws Exception {
        if (dt == null || dt.equals("")) return "";
        return formatStrToDate(dt, mode);
    }

    //parameter�� Date �� �޾Ƽ� ���������� ��¥ ���ڿ��� ����...
    public static String formatDate(java.util.Date dt, int mode)
        throws Exception {
            if (dt == null || dt.equals("") ) return "";
        String strDT = dateToStr(dt, 2);
        return formatStrToDate(strDT, mode);
    }

    /**
     * ���� ������ ���� ���ϱ�
     * @param  year ��
     * @param  month ��
     * @return ��¥
     */
    public static int lastDay(int year, int month) throws java.text.ParseException {
        int day = 0;
        switch(month) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                day = 31;
                break;
            case 2:
                if ((year % 4) == 0) {
                    if ((year % 100) == 0 && (year % 400) != 0) { day = 28; }
                    else { day = 29; }
                }
                else { day = 28; }
                break;
            default:
                day = 30;
        }
        return day;
    }

    /**
     * ��¥�� ���ӵ� ���ڿ��� �ٲ۴�
     * @param  java.util.Date
     * @param  mode -> 1 : yyyymmdd 2 : yyyymmddhhmiss
     * @return ��¥(��)2001-02-13 --> 20010213
     */
    public static String dateToStr(java.util.Date dt, int mode)
        throws Exception {
        String strRet = "";

        if (dt == null) dt = new java.util.Date();

        java.util.Calendar cal = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("Asia/Seoul"));
        cal.setTime(dt);
        int intAMPM = cal.get(9);
        String strYear = String.valueOf(cal.get(1));
        String strMonth = String.valueOf(cal.get(2) + 1);
        String strDay = String.valueOf(cal.get(5));
        int intHour = cal.get(10);
        if(intAMPM == 1) intHour += 12;
        String strHour = String.valueOf(intHour);
        String strMin = String.valueOf(cal.get(12));
        String strSec = String.valueOf(cal.get(13));

        switch(mode) {
        case 1:
            strRet = gplus.commlib.util.GCmFcts.numToStr(strYear, 4) + gplus.commlib.util.GCmFcts.numToStr(strMonth, 2) + gplus.commlib.util.GCmFcts.numToStr(strDay, 2);
            break;
        case 2:
            strRet = gplus.commlib.util.GCmFcts.numToStr(strYear, 4) + gplus.commlib.util.GCmFcts.numToStr(strMonth, 2) + gplus.commlib.util.GCmFcts.numToStr(strDay, 2)
                + gplus.commlib.util.GCmFcts.numToStr(strHour, 2) + gplus.commlib.util.GCmFcts.numToStr(strMin, 2) + gplus.commlib.util.GCmFcts.numToStr(strSec, 2);
            break;
        default:
            strRet = String.valueOf(dt);
            break;
        }
        return strRet;
    }

    /**
     * ��¥�� ���ӵ� ���ڿ��� �ٲ۴�
     * @param  java.util.Date
     * @param  format (ex:yyyyMMdd,yyyyMMddHHmmss)
     * @return ��¥(��)2001-02-13 --> 20010213
     */
    public static String dateToStr(java.util.Date date, String format) throws Exception {
        java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat (format, java.util.Locale.KOREA);
        String sRet = formatter.format(date);
        return sRet;;
    }

    /**
     * ���������� ��¥ ���ڿ��� ����
     * @param  java.util.Date
     * @param  mode 1-> 0000/00/00   2-> 0000��00��00��   3-> 0000/00/00 00:00:00   4-> 00/00   5-> 00��00��
     * @return ��¥(��)2001-02-13 --> 20010213
     */
    private static String formatStrToDate(String dt, int mode)
        throws Exception {
        String strRet = "";
        switch(mode) {
        case 1:
            strRet = dt.substring(0, 4) + "/" + dt.substring(4, 6) + "/"+ dt.substring(6, 8);
            break;
        case 2:
            strRet = dt.substring(0, 4) + "��" + dt.substring(4, 6) + "��" + dt.substring(6, 8) + "��";
            break;
        case 3:
            strRet = dt.substring(0, 4) + "/" + dt.substring(4, 6) + "/" + dt.substring(6, 8)
                    + " " + dt.substring(8, 10) + ":" + dt.substring(10, 12) + ":" + dt.substring(12, 14);
            break;
        case 4:
            strRet = dt.substring(0, 4) + "��" + dt.substring(4, 6) + "��" + dt.substring(6, 8) + "��"
                    + " " + dt.substring(8, 10) + "��" + dt.substring(10, 12) + "��" + dt.substring(12, 14) + "��";
            break;
        case 5:
            strRet = dt.substring(4, 6) + "/"+ dt.substring(6, 8);
            break;
        case 6:
            strRet = dt.substring(4, 6) + "��" + dt.substring(6, 8) + "��";
            break;
        default:
            strRet = dt;
            break;
        }
        return strRet;
    }

    /**  rjman create 2002.02.07.
     * ��¥ ���ڿ��� ��¥Ÿ������ ��ȯ
     * @param  interval -> ��(y), ��(m), ��(d)
     * @param  s -> ��¥ ���ڿ�
     * @param  format -> yyyyMMdd yyyyMMddHHmmss....
     * @return ��¥
     */

    public static String getToDatecur(String format) throws Exception {
        java.util.Date dtRet = new java.util.Date();
        java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat (format, java.util.Locale.KOREA);
        String dtRet1 = formatter.format(new java.util.Date());
        return dtRet1;
    }

}