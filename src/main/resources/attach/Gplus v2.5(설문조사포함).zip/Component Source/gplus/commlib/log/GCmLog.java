package gplus.commlib.log;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import com.objectspace.jgl.Array;
import javax.servlet.http.*;
import javax.servlet.*;
import gplus.commlib.lib.GCmUtil;
import gplus.commlib.comm.*;
import gplus.commlib.lib.*;


/**
 * <PRE>
 * Filename : GCm.java
 * Class    : GCmLog
 * Function :
 * Comment  :
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GCmLog
{
    protected static GCmLog m_instance = null; 	// Instance of GCmLog
    protected String m_logFilePath = null;		// Log file path
    protected static final boolean verbose =  true;

    /**
     * Default Constructor
     */
    public GCmLog()
    {
		try
		{
			GCmProperties cp = GCmPropertyManager.getInstance().getPropertyInstance(GCmConstDef.GROUPWARE_ID);
			m_logFilePath = cp.getString("gplus.log.path");
		}
		catch (Exception e) {}
    }

    /**
     *  LOG ȭ���� �̸��� ���� �α׵��丮�� ����
     *
     * @param logDir  �α� ���丮
     */
    public GCmLog(String logDir)
    {
        try
        {
 	      GCmProperties cp = GCmPropertyManager.getInstance().getPropertyInstance(GCmConstDef.GROUPWARE_ID);
	      m_logFilePath = cp.getString("gplus.log.path");
        }
        catch(Exception e) {}
    }


    /**
     * �����α� ���� ��ȸ, ��� ���� Array�� �־� ����
     * @param dir       ��ȸ�� �α������� ���丮
     * @param dateTime  ��ȸ�� ������ �ð�(util.getLocalDateTime("yyyyMMddHHmmss") �̿�)
     * @return Array
     */
    public synchronized Array readLog(String dir, String dateTime)
    {
        if(dir != null)
        {
            m_logFilePath = dir;
        }

        Array outputArray = new Array();                              //�Ľ̵� ����� ���� Array
        Array resultArray = new Array();                              //��� ���� ������ Array
        BufferedReader buff = null;

        try
        {
            // �������� �̿�, �α� ������ ã������ ���ϸ��� ����
            StringBuffer nameBuffer = new StringBuffer()
                .append(m_logFilePath)
                .append(File.separator)
                .append(dateTime.substring(0, 8))
                .append(".log");

            // System.out.println(nameBuffer.toString());

            // ���� ������ �б� ����, BufferedReader�� ����
            buff = new BufferedReader(new FileReader(nameBuffer.toString()));

            String lineStr = null;

            while((lineStr = buff.readLine()) != null)
            {
                // ���Ͽ��� �� ������ �о� ','�� �Ľ��Ѵ�
                outputArray = parseArray(lineStr);

                for (int i = 0; i < outputArray.size(); i++)
                {
                    Array oneRow = new Array(outputArray.size());

                    for (int j = 0; j < outputArray.size(); j++)
                    {
                        oneRow.put(j, ((String)outputArray.at(j)));
                    }

                	resultArray.add(oneRow);
                }
            }
        }
        catch(IOException ie)
        {
            System.out.println(ie.getMessage());
            ie.printStackTrace();
        }
        catch(Exception e)
		{}
        finally
        {
            try
            {
                buff.close();
            }
            catch(IOException ie)
            {
                System.out.println("IOException : "+ ie.getMessage());
                ie.printStackTrace();
            }
        }

        return resultArray;
    } // end readLog method

    /**
     * ���ڿ��� ',' �� �Ľ��Ͽ�, Array�� ��� ����
     * @param strData    �Ľ��� ���ڿ�
     * @return Array
     */
    public Array parseArray(String strData)
    {
        Array outputArray = new Array();
        int start=0;
        int seek;

        for (int i=0 ; i < strData.length() ; i++)
        {
            seek = strData.indexOf(",",start);

            if (seek < 0 )
            {
                break;
            }
            else
            {
                outputArray.add(strData.substring(start,seek));
                start = seek+1;
            }
        }

        if (start != strData.length())
        {
            outputArray.add(strData.substring(start, strData.length()));
        }

        return outputArray;
    } // end parseArray method


    /**
     * GCmLog�� Instance�� ����
     * exception  Exception
     * @return GCmLog
     */
    public static GCmLog getInstance() throws Exception
    {
        if(m_instance == null)
        {
            throw new Exception("GCmLog is Not Initialized");
        }
        return m_instance;
    }

    /**
     * GCmLog�� �ʱ�ȭ
     * exception Exception
     */
    public static void init() throws Exception
    {
        m_instance = new GCmLog();
    }


    /**
     * ������ component�� ��뿩�θ� �˼� �ִ� �α׸� ����
     * @param   class      Ŭ������
     * @param   method     �޼ҵ��
     * @param   msg        �޼���
     */
    public void writeLog(String className, String methodName, String msg)
    {
        PrintWriter out = null;

        try
        {
            String currentDate = GCmUtil.getLocalDateTime("yyyyMMddHHmmss");

            StringBuffer logBuff = new StringBuffer()
                .append(m_logFilePath)
                .append(File.separator)
                .append(currentDate.substring(0, 8))
                .append(".log");

            // System message(1999.08.03 05:49:54 Open Log File : ~~/log/19990803.log)
            System.out.println(new StringBuffer()
                               .append(new SimpleDateFormat("yyyy.MM.dd hh:mm:ss").format(new Date()))
                               .append(" Open Log File : ")
                               .append(logBuff.toString()));

            // create instance of File
            File openFile = new File(logBuff.toString());

            // if exist or not
            if(openFile.exists())
            {
                // ������ �����ϸ� append mode, autoflush �� PrintWriter�� ����
                out = new PrintWriter(new FileOutputStream(logBuff.toString(), true), true);
            }
            else
            {
				// �������� ������, ���ο� ����(~~/log/19990803.log) ����
                out = new PrintWriter(new FileOutputStream(logBuff.toString()), true);
            }

            // ���Ͽ� ������ write �ϱ� ���� buffer�� �߰�
            StringBuffer toWriteBuff = new StringBuffer()
                .append(new SimpleDateFormat("yyyy.MM.dd hh:mm:ss").format(new Date()))
                .append(", ")
                .append(className)
                .append(", ")
                .append(methodName)
                .append(", ")
                .append(msg);

            // ���� �α׸� ���δ����� write
            out.println(toWriteBuff.toString());
        }
        catch(IOException ioe)
        {
            System.out.println("IOException : "+ ioe.getMessage());
            ioe.printStackTrace();
        }
        catch(Exception e)
        {
            System.out.println("Exception : "+ e.getMessage());
            e.printStackTrace();
        }
        finally
        {
            // PrintWriter close
            out.close();
        }
    } // end writeLog
}
