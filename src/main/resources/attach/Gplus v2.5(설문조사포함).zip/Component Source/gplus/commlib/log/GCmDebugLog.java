package gplus.commlib.log;

import java.io.*;
import java.util.*;
import java.text.*;

/**
 *<PRE>
 * FileName : GCmDebugLog.java
 * Class      : GCmDebugLog
 * Function   : GCmDebugLog class 
 * Comment  : 
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0 
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GCmDebugLog extends PrintWriter
{
	/**
	 * create Log with filename
	 *
	 * @param fileName log filename
	 * @exception Exception IOException
	 * @pre (fileName!=null)
	 */
	public GCmDebugLog(String fileName) throws Exception
	{
		super(new FileOutputStream(fileName, true), true);
		
	}


	/**
	 * create Log with OutputStream
	 *
	 * @param ostream OutputStream
	 * @pre (ostream!=null)
	 */
	public GCmDebugLog(OutputStream ostream)
	{
	 	// enable autoflushing
		super(ostream, true);
	}


	/**
	 * create Log with PrintWriter
	 *
	 * @param writer PrintWriter
	 * @pre (writer!=null)
	 */
	public GCmDebugLog(PrintWriter writer)
	{
		super(writer, true);
	}


	/**
	 * println override
	 * log�� �߻��� time �߰�
	 */
	public synchronized void println(String className, String methodName, String msg)
	{
		super.println(new SimpleDateFormat("yyyy.MM.dd HH:mm:ss")
					  .format(new Date()) + " " + className + " "+ methodName +" " +msg);
	}


	/**
	 * println override
	 * log�� �߻��� time �߰�
	 */
	public synchronized void println(String msg)
	{
		super.println(new SimpleDateFormat("yyyy.MM.dd HH:mm:ss")
					  .format(new Date()) + " " +msg);
	}
}
