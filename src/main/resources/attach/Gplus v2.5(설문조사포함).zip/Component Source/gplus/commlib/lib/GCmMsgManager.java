package gplus.commlib.lib;

import java.util.*;
import java.io.*;
import gplus.commlib.lib.GCmUtil;
import gplus.commlib.comm.*;
import gplus.commlib.log.GCmDebugLog;


/**
 * 	<PRE>
 * 	Filename : GCmMsgManager.java
 * 	Class    : gplus.commlib.lib.GCmMsgManager
 * 	Function : get GPLUS message string from message code
 * 	Comment  :
 *      History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 *      </PRE>
 *      @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GCmMsgManager extends GCmProperties
{
	private static	GCmMsgManager m_instance;
	private static  final String	GROUPWARE_ID = GCmConstDef.GROUPWARE_ID;
	private static  final boolean verbose = false;
	private static  GCmDebugLog log = null;

 	protected GCmMsgManager()
 	{
 		super();
 		m_instance = null;
 	}


        /**
	 * get singleton object<br>
	 * Must be called after init
	 *
         * @return 	m_instance object reference
         */
 	public static GCmMsgManager getInstance() throws Exception
 	{
		if (m_instance == null)
		{
			throw new Exception("System is not initialized properly: " +
								"GCmMsgManager instance is null");
		}
		return m_instance;
 	}

    /**
     * <PRE>
     * �ʱ� GCmMsgManager�� ���� ������ �ʱ�ȭ �����ִ� �Լ�
	 * singleton design pattern ����
     * </PRE>
     */
    public static void init() throws Exception
    {
	if (verbose)
		System.out.println("GCmMsgManager : Massage Manager init start");

    	if(m_instance == null)
    	{
	    	try
	    	{
	    			try
				{
					String strLogPath = GCmPropertyManager.getInstance()
								.getPropertyInstance(GCmConstDef.GROUPWARE_ID)
								.getProperty("gplus.log.path");

					log = new GCmDebugLog(strLogPath + File.separator + "gplus.log");
				}
				catch (Exception e)
				{
					log = new GCmDebugLog(new PrintWriter(System.err));
				}

	    		    m_instance = new GCmMsgManager();

			    FileInputStream fin = null;

			    GCmProperties	gplusProp = GCmPropertyManager.getInstance().getPropertyInstance(GROUPWARE_ID);

			    Enumeration enum = gplusProp.propertyNames();

			    for ( ;enum.hasMoreElements(); )
			    {
					boolean	validateToken = true;
					String keyToken = (String)enum.nextElement();

					StringTokenizer st = new StringTokenizer(keyToken, ".");

				   	while (st.hasMoreTokens() && validateToken)
				   	{
				   		String token = (String)st.nextToken();

				   		if ("gplus".compareToIgnoreCase( token ) == 0)
				   		{
				   			while(st.hasMoreTokens())
							{
								token = (String)st.nextToken();

						   		if ("message".compareToIgnoreCase( token ) == 0)
						   		{
									m_instance.loadFromFile(gplusProp.getProperty(keyToken));
						   			validateToken = false;
						   		}
						   	}
				   		}
						else
						{
						   	validateToken = false;
						}
				   	}
				}
			}
			catch (Exception e)
			{
				log.println(e);
			}

			if (verbose)
			{
				System.err.println("Message Property ====>" + m_instance);
				System.err.println("Message Property ====>" + m_instance.getMessage("I0022"));
			}
		}
	}


   /**
    * �޼��� �ڵ忡 �ش�Ǵ� �޼��� ��Ʈ�����
    *
    * @param 	msgCode message code
    * @return  	message string for the message code
    * @pre (msgCode!=null), "msgCode cannot be null"
    */
    public String getMessage(String msgCode) throws Exception
    {
	   	String returnMsg = null;

 		return new String(getProperty(msgCode).getBytes("8859_1"),"KSC5601");
    }


    /**
     * regist new message code and string which using temporarily
     *
     * @param 	msgCode message code
     * @param 	msgString message string
     * @return 	true or false
     * @pre (in_msg!=null), "filename cannot be null"
     */
    public synchronized boolean  setMessage(String msgCode, String msgString)
    {
		if (containsKey(msgCode) == false)
		{
			setProperty(msgCode, msgString);
			return true;
		}
		return false;
	}

	public void saveToFile(String filePath)
	{
		super.saveToFile(filePath);
	}

}