package gplus.commlib.util;

/**
 * <PRE>
 * Filename : GCmHtmlPageSaver.java
 * Class    : GCmHtmlPageSaver
 * Function : GPlus���� Html�� �����ϱ� ���� class
 * Comment  : 
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
 
import java.net.*;
import java.io.*;


public class GCmHtmlPageSaver {

    public static String getHtmlPage(String domainUrl, String pageUrl, String qryStr) throws Exception {
        return getHtmlPage(domainUrl, 80, pageUrl,qryStr);
    }

    public static String getHtmlPage(String domainUrl, int httpPort, String pageUrl,String qryStr) throws Exception {
        if (domainUrl == null || pageUrl == null || domainUrl.equals("") || pageUrl.equals("")) return "����";
        //URLStreamHandler oU = new URLStreamHandler();
        StringBuffer sRet = new StringBuffer();
        String line = "";
        URL url = new URL("http",domainUrl,httpPort,pageUrl + "?" + qryStr);

        BufferedReader buf = null;
        DataInputStream dis = new DataInputStream(url.openStream());
        buf = new BufferedReader(new InputStreamReader(dis));

        while ((line = buf.readLine()) != null) {
          sRet.append(line).append("\n");
        }
		System.out.println("sRet.toString();"+sRet.toString());
        return sRet.toString();
    }
}