package gplus.commlib.exception;

import gplus.commlib.lib.GCmMsgInfo;

/**
 * <PRE>
 * Filename	: GCmGplusException.java <BR>
 * Class	: GCmGplusException <BR>
 * Function	: <BR>
 * Comment	: GPLUS parent exception class <BR>
 * Comment	: 
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCmGplusException extends Exception 
{
	protected GCmMsgInfo msgInfo = null;	
	
	/**
	 * Catches exceptions without a specified string
	 */
	public GCmGplusException() {}

	/**
	 * Constructs the appropriate exception with the specified string
	 *
	 * @param message	Exception message
	 */
	public GCmGplusException(String message) {super(message);}

	/**
	 * Catches exceptions with specified message info object
	 *
	 * @param msgInfo GPLUS message info class
	 */
	public GCmGplusException(GCmMsgInfo msgInfo) {this.msgInfo = msgInfo;}

	/**
	 * Get message code
	 *
	 * @return  msgInfo GPLUS message info class
	 */
	public GCmMsgInfo getGPlusMsgInfo() {return msgInfo;} 

}
