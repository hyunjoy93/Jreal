package gplus.template;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;
import com.jspsmart.upload.*;

import gplus.component.board.*;
import gplus.component.userinfo.*;
import gplus.component.org.*;
import gplus.component.doc.*;

/**
 * <PRE>
 * Filename		: GTpUserInfo.java
 * Class		:
 * Function		:
 * Comment		:
 * History      : 03/19/2002, ������, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GTpBoard
{
   /**
    * <PRE>
    *    ȸ���ڵ�, ����, ÷�μ�, �Խù� ��ȣ�� ���޹޾� �Խù��� ������ �����Ѵ�.
    * </PRE>
    *
	* @author          03/19/2002, ������
	*
    * @param cp        a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at seeeion
    *                      <LI> String Title   : �Խù� ����
    *                      <LI> String Attnum  : ÷�μ�
    *                      <LI> String Notino  : �Խù� ��ȣ
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return N/A
    */
	public int updateNoti(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoBoBoardTran boardtran = new GCoBoBoardTran();

	 	try
	 	{
	 		return boardtran.updateNoti(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpBoard::updateNoti: " + e.getMessage());
	 		return -1;
	 	}

	}

    /**
	 *
	 * ȸ�� �����Կ� �ֱ� ��ϵ� �ڷ� ����Ʈ ���
	 * rjman 2002.01.09
	 * @param cp		GCmProperties
	 * @param msgInfo	GCmMsgInfo
	 * @return GCmResultSet
	 */
	 public int updateNom(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoBoBoardTran boardTran = new GCoBoBoardTran();

	 	try
	 	{
	 		return boardTran.updateNom(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println("GTpBoard::updateNom:: " + e.getMessage());
	 		return -1;
	 	}

	}

   /**
    * <PRE>
     *  ���޵� ����ڿ� ����  ���õ� �������� ����Ʈ �Ѵ�.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String USERID : ����� ���̵�
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : A.BOXNO,A.BOXNAME,A.BOXTYPE,B.DOCREAD,B.DOCWRITE,C.FLDNAME,C.FLDNO
    *
    */
    public GCmResultSet getFldBoxList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoDoDocFolder docFolder = new GCoDoDocFolder();
	 	try
	 	{
                    return docFolder.getFldBoxList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpBoard::getFldBoxList : " + e.getMessage());
	 		return null;
	 	}
	}

   /**
    * <PRE>
    *  ���޵� �Թ�ȣ�� ���� �������� ����� �����Ѵ�.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String BOXNO : �� ��ȣ
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : FLDNO,BOXNO,DOCNO,PARENTNO,FLDNAME,REGUSER,REGDATE,
    *                                 TRASHFLAG,COMMENTS,REFNO
    */
    public GCmResultSet getFldInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoDoDocFolder docFolder = new GCoDoDocFolder();
	 	try
	 	{
                    return docFolder.getFldInfo(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpBoard::getFldInfo : " + e.getMessage());
	 		return null;
	 	}
	}

   /**
    * <PRE>
    *    ȸ���ڵ�, ������ȣ�� ���޹޾� ������ �� ������ �����ش�.
    * </PRE>
    *
	* @author          03/19/2002, ������
	*
    * @param cp        a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *						<UL>relevant fields.
    *							<LI> String COMCODE   : ȸ���ڵ�
    *							<LI> String DOCNO     : ������ȣ
	*		                </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : ���������� ( DOCNO,SEQ,CONTTYPE,TITLE,FILEEXT,FILENAME,VPATH,MIMETYPE,FILESIZE,
	*                                                ORGNAME,ORGPATH,REGUSER,REGDATE,MODUSER,MODDATE )
    */
    public GCmResultSet getDocDtlList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoBoBoard board = new GCoBoBoard();


	 	try
	 	{
	 		return board.getDocDtlList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpBoard::getDocDtlList : " + e.getMessage());
	 		return null;
	 	}
	}

   /**
    * <PRE>
    *    ȸ���ڵ�, ������ȣ�� ���޹޾� ������ �� ������ �����ش�.
    * </PRE>
    *
	* @author          03/19/2002, ������
	*
    * @param cp        a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *						<UL>relevant fields.
    *							<LI> String COMCODE   : ȸ���ڵ�
    *							<LI> String DOCNO     : ������ȣ
	*		                </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : ���������� ( DOCNO,SEQ,CONTTYPE,TITLE,FILEEXT,FILENAME,VPATH,MIMETYPE,FILESIZE,
	*                                                ORGNAME,ORGPATH,REGUSER,REGDATE,MODUSER,MODDATE )
    */
    public GCmResultSet getDocDtlInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoBoBoard board = new GCoBoBoard();

	 	try
	 	{
	 		return board.getDocDtlInfo(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpBoard::getDocDtlInfo : " + e.getMessage());
	 		return null;
	 	}
	}

   /**
    * <PRE>
    * �Թ�ȣ�� ������ ��ȣ�� ���޹޾� ���� ������ ������ȣ�� �����̸��� ������.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String BOXNO :  �� ��ȣ
    *                      <LI> String ROOTNO : ������ ��ȣ
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : FLDNO,FLDNAME
    */
    public GCmResultSet getFindFldno(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoDoDocFolder docFolder = new GCoDoDocFolder();
	 	try
	 	{
                    return docFolder.getFindFldno(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpBoard::getFindFldno : " + e.getMessage());
	 		return null;
	 	}
	}

    /**
     * <PRE>
     *  ���޵� �������� ���� �Թ�ȣ�� �����Ѵ�.
     * </PRE>
     *
     * @param cp      a GCmProperties holding gplus groupware properties.
     * @param dmProp    GCmProperties
     *                  <UL>relevant fields.
     *                      <LI> String COMCODE   : current user companycode at session
     *                      <LI> String ROOTNO    : �����Թ�ȣ
     *                      <LI> String BOXCLASS  : �� ����
     *                      <LI> String BOXTYPE   : �� ����
     *                      <LI> String USERID    : ����� ���̵�
     *                  </UL>
     * @param msgInfo   a GCmMsgInfo holding error codes.
     * @return          GCmResultSet : BOXNO
     */
	public GCmResultSet getFindUserBoxno(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoDoDocFolder docFolder = new GCoDoDocFolder();
	 	try
	 	{
                    return docFolder.getFindUserBoxno(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpBoard::getFindUserBoxno : " + e.getMessage());
	 		return null;
	 	}
	}

        /**
	 *
	 * ȸ�� �����Կ� �ֱ� ��ϵ� �ڷ� ����Ʈ ���
	 * rjman 2002.01.09
	 * @param cp		GCmProperties
	 * @param msgInfo	GCmMsgInfo
	 * @return GCmResultSet
	 */
	 public int deleteNoti(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoBoBoardTran boardTran = new GCoBoBoardTran();

	 	try
	 	{
                       return boardTran.deleteNoti(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println("GTpBoard::deleteNoti " + e.getMessage());
	 		return -1;
	 	}

	}

   /**
    * <PRE>
    *    �Խù� ��Ͽ��� ���� �Խù� ��ȣ�� �ش��ϴ� ������ ������ �˻��Ͽ� CNT �� �˻��Ͽ� �����ش�.
    * </PRE>
	*
	* @author          03/19/2002, ������
	*
    * @param cp        a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *						<UL>relevant fields.
    *							<LI> String COMCODE  : ȸ���ڵ�
    *							<LI> String PARENTNO : ���� �Խù� ��ȣ
	*		                </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : COUNT(*) info ( CNT )
    */
    public GCmResultSet getCntChild(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoBoBoard board = new GCoBoBoard();
	 	try
	 	{
                    return board.getCntChild(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpBoard::getCntChild : " + e.getMessage());
	 		return null;
	 	}
	}

	/**
	 * ��������
	 * ������  2002.01.09
	 * @param cp		GCmProperties
	 * @param msgInfo	GCmMsgInfo
	 * @return GCmResultSet
	 */
	  public int processNewBoardMake(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
                SmartUpload oUpload = (SmartUpload)dmProp.getObject("smtUpload");
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
      		String USERNAME = dmProp.getString("USERNAME");
                String FILELMT = dmProp.getString("FILELMT");

	 	GCoBoBoard board = new GCoBoBoard();
	 	GCoBoBoardTran boardtran = new GCoBoBoardTran();
                GCoDoDocTran doctran = new GCoDoDocTran();

                int rv = 0;
	 	try
	 	{
                       String pBoxtype = oUpload.getRequest().getParameter("boxtype");

                       String pActtype = oUpload.getRequest().getParameter("acttype");
                       String pBoxno = oUpload.getRequest().getParameter("boxno");
                       String pNotino = oUpload.getRequest().getParameter("notino");
                       String pRef = oUpload.getRequest().getParameter("ref");
                       String pSortstep = oUpload.getRequest().getParameter("sortstep");
                       String pRelevel = oUpload.getRequest().getParameter("relevel");
                       String pPage = oUpload.getRequest().getParameter("page");
                       String pPageSize = oUpload.getRequest().getParameter("pagesize");
                       String pTitle = oUpload.getRequest().getParameter("title");
                       String pConts = oUpload.getRequest().getParameter("Conts");
                       String pTag = oUpload.getRequest().getParameter("Tag");
                       String pAttachednum = oUpload.getRequest().getParameter("attachednum");
                       String pOldfile = oUpload.getRequest().getParameter("oldfile");
                       String pOldfilenum = oUpload.getRequest().getParameter("oldfilenum");
                       String pVpath = oUpload.getRequest().getParameter("vpath");
                       String pUpfiles = oUpload.getRequest().getParameter("upfiles");
                       String Totfilesize = oUpload.getRequest().getParameter("totfilesize");

        // ���� �뷮 üũ�� �ϰ� ���ѿ� �ɸ��� �������·� �ǵ����� ���� �ʿ��� Parameter
                 dmProp.setProperty("boxtype",pBoxtype);
                 dmProp.setProperty("boxno",pBoxno);
        //////////////////////////// Parameter ��  //////////////////////////////

                       if (pNotino == null) pNotino = "";
                       if (pBoxno == null) pBoxno = "";
                       if (pPage == null) pPage = "";
                       if (pPageSize == null) pPageSize = "";
                       if (pRef == null) pRef = "";
                       if (pSortstep == null) pSortstep = "0";
                       if (pRelevel == null) pRelevel = "0";
                       if (pActtype == null) pActtype = "";

                       String notino = "";
                       String parentno = "";

                       if (pNotino == null || pNotino.equals(""))
                            parentno = "000000000000";
                       else
                            parentno = pNotino;

                       int sortstep = 0;
                       int relevel = 0;
                       String stepnum = "";

                      String filename = "";
                      String fileext = "";
                      String orgname = "";
                      String orgpath = "";
                      String conttype = "";
                      String mimetype = "";
                      int filesize = 0;
                      String regdate = gplus.commlib.util.GCmFcts.dateToStr(new java.util.Date(),2);
                      String docno = "";
                      String seq = "";

                      int count = 0;
                      int fileCnt = oUpload.getFiles().getCount();    // ���ε�� ���� ����



          ///////////////////////////���Ͽ뷮üũ///////////////////////////////
                   //  if(fileCnt != 0){
                   //     for (int i=0;i<fileCnt;i++)
                   //     {
                   //        com.jspsmart.upload.File upFile = oUpload.getFiles().getFile(i);

                   //        if (!upFile.isMissing())
                   //           filesize = upFile.getSize();
                   //     }
                   //   }
          ///////////////////////////���Ͽ뷮üũ ��///////////////////////////


                // if(filesize < Integer.parseInt(FILELMT)){  //�뷮�� �����ڰ� ������ �������� �����ȴ�

                      gplus.commlib.util.GCmFcts.folderMake(cp.getProperty("gplus.system.docroot"),"/DATA/" + COMCODE + "/TEMP/" + USERID + "/");
                      //gplus.commlib.util.GCmFcts.folderMake(cp.getProperty("gplus.system.docroot"),"/DATA/" + COMCODE + "/BOARD/" + pBoxno + "/"+ regdate.substring(0,6) + "/");
                      gplus.commlib.util.GCmFcts.folderMake(cp.getProperty("gplus.system.docroot"),"/DATA/" + COMCODE + "/BOARD/" + regdate.substring(0,6) + "/"+ regdate.substring(6,8) + "/");

                     if (pNotino != null && !pNotino.equals(""))  //�亯����
                      {

                          dmProp.setProperty("REF",pRef);
                          dmProp.setProperty("SORTSTEP",pSortstep);
                          dmProp.setProperty("RELEVEL",pRelevel);

                          stepnum = board.getSortStep(cp, dmProp, msgInfo);


                      	  dmProp.setProperty("STEPNUM",stepnum);

                      	  boardtran.updateNotiOrder(cp, dmProp, msgInfo);
                          sortstep = Integer.parseInt(stepnum) + 1;;
                          relevel = Integer.parseInt(pRelevel) + 1;

                 notino = board.getMaxNotiNo(COMCODE,cp.getProperty("gplus.db.type"));
                          parentno = pNotino;
                      }
                      else
                      {
                          relevel = 0;
                          sortstep = 0;
                          notino = board.getMaxNotiNo(COMCODE,cp.getProperty("gplus.db.type"));
                          parentno = "000000000000";
                          pRef = notino;
                      }

                      dmProp.setProperty("Title",pTitle);
                      dmProp.setProperty("Doctype","2");
                      dmProp.setProperty("Attnum",String.valueOf(fileCnt));
                      dmProp.setProperty("Reguser",USERID);
                      dmProp.setProperty("Regdate",regdate);
                      dmProp.setProperty("Moduser",USERID);
                      dmProp.setProperty("Moddate",regdate);
                      dmProp.setProperty("Totfilesize",Totfilesize);
                      //  --------------
 	              dmProp.setProperty("Conts", pConts);
                      //  --------------

                      doctran.insertDoc(cp, dmProp, msgInfo);

                      docno = dmProp.getString("Docno");

                      count = 2;

                      for (int i=0;i<fileCnt;i++)
                      {
                         com.jspsmart.upload.File upFile = oUpload.getFiles().getFile(i);

                         if (!upFile.isMissing())
                         {
                              seq = gplus.commlib.util.GCmFcts.numToStr(String.valueOf(count),2);
                              fileext = "." + upFile.getFileExt();  // ����Ȯ����
                              filename = docno + "_" + seq + fileext;         // ���ϸ�
                              orgname = upFile.getFileName(); // ���̸�
                              orgpath = upFile.getFilePathName(); // �����
                              orgpath = orgpath.substring(0,orgpath.lastIndexOf("\\")+1);
                              mimetype = upFile.getContentType();
                              filesize = upFile.getSize();

                              conttype = "3";

                              //upFile.saveAs("/DATA/"+COMCODE+"/BOARD/"+pBoxno+"/"+ regdate.substring(0,6)+"/"+filename,upFile.SAVEAS_VIRTUAL);
                              upFile.saveAs("/DATA/"+COMCODE+"/BOARD/"+regdate.substring(0,6)+"/"+ regdate.substring(6,8)+"/"+filename,upFile.SAVEAS_VIRTUAL);

                              dmProp.setProperty("Seq",seq);
                              dmProp.setProperty("Conttype",conttype);
                              dmProp.setProperty("Title",pTitle);
                              dmProp.setProperty("Fileext",fileext);
                              dmProp.setProperty("Filename",filename);
                              //dmProp.setProperty("Vpath","/DATA/"+COMCODE+"/BOARD/"+pBoxno+"/"+ regdate.substring(0,6)+"/");
                              dmProp.setProperty("Vpath","/DATA/"+COMCODE+"/BOARD/"+regdate.substring(0,6)+"/"+ regdate.substring(6,8)+"/");
                              dmProp.setProperty("Mimetype",mimetype);
                              dmProp.setProperty("Filesize",String.valueOf(filesize));
                              dmProp.setProperty("Orgname",orgname);
                              dmProp.setProperty("Orgpath",orgpath);

                              doctran.insertAttDoc(cp, dmProp, msgInfo);
                              count ++;
                         }

                      }
                     //gplus.commlib.util.GCmFcts.setWriteFile(cp.getProperty("gplus.system.docroot")+"/DATA/"+COMCODE+"/BOARD/"+pBoxno+"/"+
                                               // regdate.substring(0,6)+"/",docno + "_01.htm",pConts);




                      //java.io.File contFile = new java.io.File(cp.getProperty("gplus.system.docroot")+"/DATA/"+COMCODE+"/BOARD/"+pBoxno+"/"
                                                                            //  +regdate.substring(0,6)+"/",docno + "_01.htm");
                      int contSize = 0;  //(int)contFile.length();

                      dmProp.setProperty("Seq","01");
                      dmProp.setProperty("Conttype","2");
                      dmProp.setProperty("Fileext",".htm");
                      dmProp.setProperty("Filename",docno + "_01.htm");
                      //dmProp.setProperty("Vpath","/DATA/"+COMCODE+"/BOARD/"+pBoxno+"/"+ regdate.substring(0,6)+"/";
                      dmProp.setProperty("Vpath","/DATA/"+COMCODE+"/BOARD/"+ regdate.substring(0,6)+"/"+regdate.substring(6,8)+"/");
                      dmProp.setProperty("Mimetype","text/html");
                      dmProp.setProperty("Filesize",String.valueOf(contSize));
                      dmProp.setProperty("Orgname","����.HTM");
                      dmProp.setProperty("Orgpath","");

                      doctran.insertAttDoc(cp, dmProp, msgInfo);

                      dmProp.setProperty("Notino",notino);
                      dmProp.setProperty("Boxno",pBoxno);
                      dmProp.setProperty("Docno",docno);
                      dmProp.setProperty("Parentno",parentno);
                      dmProp.setProperty("Title",pTitle);
                      dmProp.setProperty("Attnum",String.valueOf(count-2));
                      dmProp.setProperty("Refnum","0");
                      dmProp.setProperty("Nomnum","0");
                      dmProp.setProperty("Childnum","0");
                      dmProp.setProperty("Reguser",USERID);
                      dmProp.setProperty("Regdate",regdate);
                      dmProp.setProperty("Regname",USERNAME);
                      dmProp.setProperty("STEPNUM",String.valueOf(sortstep));
                      dmProp.setProperty("REF",pRef);
                      dmProp.setProperty("RELEVEL",String.valueOf(relevel));

                      boardtran.insertNotify(cp, dmProp, msgInfo);
                    //return rv;
         	//}else{
                //    return 1;
                //}
                return rv;
              }
	 	catch (Exception e)
	 	{
	 		System.err.println(" processNewBoardMake : " + e.getMessage());
	 		return -1;
	 	}

	}

        /**
	 * ��������
	 * ������ 2002.04.02
	 * @param cp		GCmProperties
	 * @param msgInfo	GCmMsgInfo
	 * @return GCmResultSet
	 */

       public int processUpdateBoardMake(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
       {
                SmartUpload oUpload = (SmartUpload)dmProp.getObject("smtUpload");
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
      		//String USERNAME = dmProp.getString("USERNAME");
                String FILELMT = dmProp.getString("FILELMT");

	 	GCoBoBoard board = new GCoBoBoard();
	 	GCoBoBoardTran boardtran = new GCoBoBoardTran();
                GCoDoDocTran doctran = new GCoDoDocTran();

                int rv = 0;
	 	try
	 	{
                        String pBoxtype = oUpload.getRequest().getParameter("boxtype");
                        String pDocno = oUpload.getRequest().getParameter("docno");
                        String pActtype = oUpload.getRequest().getParameter("acttype");

                        String pMode = oUpload.getRequest().getParameter("mode");           // �ű�/����
                        String pBoxno = oUpload.getRequest().getParameter("boxno");         // �ڽ���ȣ
                        String pNotino = oUpload.getRequest().getParameter("notino");           //
                        String pRef = oUpload.getRequest().getParameter("ref");           //
                        String pSortstep = oUpload.getRequest().getParameter("sortstep");
                        String pRelevel = oUpload.getRequest().getParameter("relevel");
                        String pPage = oUpload.getRequest().getParameter("page");
                        String pPageSize = oUpload.getRequest().getParameter("pagesize");

                        String pTitle = oUpload.getRequest().getParameter("title");         // ����
                        String pConts = oUpload.getRequest().getParameter("Conts");         // ����
                        String pTag = oUpload.getRequest().getParameter("tag");             // HTML/TEXT


                        String pAttachednum = oUpload.getRequest().getParameter("attachednum"); // ÷�μ�
                        String pOldfile = oUpload.getRequest().getParameter("Oldfile");         // ����÷������
                        String pOldfilenum = oUpload.getRequest().getParameter("Oldfilenum");   // ����÷�����ϼ�
                        String pVpath = oUpload.getRequest().getParameter("vpath");             // �������ϰ�����
                        String pUpfiles = oUpload.getRequest().getParameter("upfiles");         // ����÷�������� �ű��

                        String Totfilesize = oUpload.getRequest().getParameter("totfilesize");


                        if (pNotino == null) pNotino = "";
                        if (pBoxno == null) pBoxno = "";
                        if (pPage == null) pPage = "";
                        if (pPageSize == null) pPageSize = "";
                        if (pRef == null) pRef = "";
                        if (pSortstep == null) pSortstep = "0";
                        if (pRelevel == null) pRelevel = "0";


      // ���� �뷮 üũ�� �ϰ� ���ѿ� �ɸ��� �������·� �ǵ����� ���� �ʿ��� Parameter
                 dmProp.setProperty("boxtype",pBoxtype);
                 dmProp.setProperty("boxno",pBoxno);
                 dmProp.setProperty("notino",pNotino);
                 dmProp.setProperty("docno",pDocno);
                 dmProp.setProperty("acttype",pActtype);
      //////////////////////////// Parameter ��  //////////////////////////////

                      int nRet = 0;   // ����۾����

                      String filename = "";   // ���ε����ϸ�
                      String fileext = "";    // ����Ȯ����
                      String filepath = "/DATA/"; // ������
                      String orgname = "";    // �������ϸ�
                      String orgpath = "";    // Ŭ���̾�Ʈ ���Ͼ��ε� ���
                      String conttype = "";   //
                      String mimetype = "";
                      int filesize = 0;

                      String regdate = gplus.commlib.util.GCmFcts.dateToStr(new java.util.Date(),2);   // �����
                      String docno = "";
                      String seq = "";    // ����

                      String oldseq = "";

                      String ppath = cp.getProperty("gplus.system.docroot"); //getServletContext().getRealPath("/");
                      String vpath = "";
                      String tmppath = "/DATA/" + COMCODE + "/TEMP/" + USERID + "/";

                      java.io.File srcFile = null;
                      java.io.File desFile = null;

                      int count = 0;  // ���ε� ī��Ʈ
                      int fileCnt = oUpload.getFiles().getCount();    // ���ε�� ���� ����


          ///////////////////////////���Ͽ뷮üũ/////////////////////////////////
                     if(fileCnt != 0){
                        for (int i=0;i<fileCnt;i++)
                        {
                           com.jspsmart.upload.File upFile = oUpload.getFiles().getFile(i);

                           if (!upFile.isMissing())
                                 filesize = upFile.getSize();
                        }
                     }
          //////////////////////////���Ͽ뷮üũ ��///////////////////////////////////


                 if(filesize < Integer.parseInt(FILELMT)){  //�뷮�� �����ڰ� ������ �������� �����ȴ�

                      java.util.Vector vList = new java.util.Vector(); // �������� ó��

                      vList = gplus.commlib.util.GCmFcts.getSplit(pOldfile,",");

	              GTpDoc doc = new GTpDoc();


	              dmProp.setProperty("COMCODE",COMCODE);
	              dmProp.setProperty("NOTINO",pNotino);

	              GCmResultSet rsNotiDtlInfo = doc.getNotiDtlInfo(cp, dmProp, msgInfo);

	              for (int j=1;j<=rsNotiDtlInfo.getRowCount() && rsNotiDtlInfo.next();j++)
                      {
                		docno = rsNotiDtlInfo.getString("DOCNO");
		                vpath = rsNotiDtlInfo.getString("VPATH");

                      }

                      // temp folder check create
                      gplus.commlib.util.GCmFcts.folderMake(ppath,tmppath);
                      // vpath folder check create
                      gplus.commlib.util.GCmFcts.folderMake(ppath,vpath);




    // ��������ó��
    for (int i=0;i<vList.size();i++) {
        oldseq = (String) vList.elementAt(i);
        // ��������
		dmProp.setProperty("COMCODE",COMCODE);
		dmProp.setProperty("Docno",docno);
		dmProp.setProperty("Seq",oldseq);

		GCmResultSet rsDocDtlInfo = doc.getDocDtlInfo(cp, dmProp, msgInfo);

		for (int j=1;j<=rsDocDtlInfo.getRowCount() && rsDocDtlInfo.next();j++)
		{

        // ���� �̵�...
			srcFile = new java.io.File(rsDocDtlInfo.getString("Vpath"),rsDocDtlInfo.getString("Filename"));
			desFile = new java.io.File(tmppath,rsDocDtlInfo.getString("Filename"));

			if (srcFile.isFile()) {
				gplus.commlib.util.GCmFcts.copyFile(srcFile,desFile);
	            srcFile.delete();
		    }

			doc.deleteFile(cp, dmProp, msgInfo);

	    }
	}


	dmProp.setProperty("COMCODE",COMCODE);
	dmProp.setProperty("Docno",docno);
	dmProp.setProperty("Seq","00");

	GCmResultSet rsDocDtlList = doc.getDocDtlList(cp, dmProp, msgInfo);

	doc.deleteFileAll(cp, dmProp, msgInfo);
    // ���Է�

    count=1;
    for (int i=0;i<rsDocDtlList.getRowCount() && rsDocDtlList.next();i++) {
        //oDoc = (com.win.Doc) vList.elementAt(i);
        seq = gplus.commlib.util.GCmFcts.numToStr(count,2);


		dmProp.setProperty("COMCODE",COMCODE);
		dmProp.setProperty("Docno",docno);
		dmProp.setProperty("Seq",seq);
		dmProp.setProperty("Conttype",rsDocDtlList.getString("Conttype"));
		dmProp.setProperty("Title",rsDocDtlList.getString("Title"));
		dmProp.setProperty("Fileext",rsDocDtlList.getString("Fileext"));
		dmProp.setProperty("Filename",rsDocDtlList.getString("Filename"));
		dmProp.setProperty("Vpath",rsDocDtlList.getString("Vpath"));
		dmProp.setProperty("Mimetype",rsDocDtlList.getString("Mimetype"));
		dmProp.setProperty("Filesize",rsDocDtlList.getString("Filesize"));
		dmProp.setProperty("Orgname",rsDocDtlList.getString("Orgname"));
		dmProp.setProperty("Orgpath",rsDocDtlList.getString("Orgpath"));
		dmProp.setProperty("Reguser",rsDocDtlList.getString("Reguser"));
		dmProp.setProperty("Regdate",rsDocDtlList.getString("Regdate"));
		dmProp.setProperty("Moduser",rsDocDtlList.getString("Moduser"));
		dmProp.setProperty("Moddate",rsDocDtlList.getString("Moddate"));



		doc.insertAttDoc(cp, dmProp, msgInfo);

        count++;
    }





    // �����󼼸�� INSERT
    for (int i=0;i<fileCnt ;i++){
        // Retreive the current file
        com.jspsmart.upload.File upFile = oUpload.getFiles().getFile(i);

        // Save it only if this file exists
        if (!upFile.isMissing()) {
            //�Ϸù�ȣ
            seq = gplus.commlib.util.GCmFcts.numToStr(String.valueOf(count),2);
            fileext = "." + upFile.getFileExt();  // ����Ȯ����
            filename = docno + "_" + seq + fileext;         // ���ϸ�
            orgname = upFile.getFileName(); // ���̸�
            orgpath = upFile.getFilePathName(); // �����
            orgpath = orgpath.substring(0,orgpath.lastIndexOf("\\")+1);
            mimetype = upFile.getContentType();
            filesize = upFile.getSize();
            conttype = "3";

            // ÷����������
            //upFile.saveAs(vpath + filename,upFile.SAVEAS_VIRTUAL);
           // upFile.saveAs("/DATA/"+COMCODE+"/BOARD/"+pBoxno+"/"+ regdate.substring(0,6)+"/"+filename,upFile.SAVEAS_VIRTUAL);
            upFile.saveAs("/DATA/"+COMCODE+"/BOARD/"+regdate.substring(0,6)+"/"+ regdate.substring(6,8)+"/"+filename,upFile.SAVEAS_VIRTUAL);
            // �������


			dmProp.setProperty("COMCODE",COMCODE);
			dmProp.setProperty("Docno",docno);
			dmProp.setProperty("Seq",seq);
			dmProp.setProperty("Conttype",conttype);
			dmProp.setProperty("Title",pTitle);
			dmProp.setProperty("Fileext",fileext);
			dmProp.setProperty("Filename",filename);
			dmProp.setProperty("Vpath",vpath);
			dmProp.setProperty("Mimetype",mimetype);
			dmProp.setProperty("Filesize",String.valueOf(filesize));
			dmProp.setProperty("Orgname",orgname);
			dmProp.setProperty("Orgpath",orgpath);
			dmProp.setProperty("Reguser",USERID);
			dmProp.setProperty("Regdate",regdate);
			dmProp.setProperty("Moduser",USERID);
			dmProp.setProperty("Moddate",regdate);

			doc.insertAttDoc(cp, dmProp, msgInfo);


            count ++;
        }
    }


    // ��������...
    //gplus.commlib.util.GCmFcts.setWriteFile(getServletContext().getRealPath(vpath),docno + "_01.htm",pConts);
//gplus.commlib.util.GCmFcts.setWriteFile(cp.getProperty("gplus.system.docroot")+"/DATA/"+COMCODE+"/BOARD/"+pBoxno+"/"+
                                                //regdate.substring(0,6)+"/",docno + "_01.htm",pConts);

    // ���� ������� ����(����,���ϼ�)

	dmProp.setProperty("COMCODE",COMCODE);
	dmProp.setProperty("Title",pTitle);
	dmProp.setProperty("Filenum",String.valueOf(count-2));
	dmProp.setProperty("Docno",docno);
        dmProp.setProperty("DOCTYPE","2");
        dmProp.setProperty("REGUSER",USERID);
	dmProp.setProperty("REGDATE",regdate);
	dmProp.setProperty("MODUSER",USERID);
	dmProp.setProperty("MODDATE",regdate);
        dmProp.setProperty("Totfilesize",Totfilesize);

//  --------------
     dmProp.setProperty("Conts", pConts);
//  --------------

	doc.updateDocEdit(cp, dmProp, msgInfo);


    // �Խù� ����
	dmProp.setProperty("COMCODE",COMCODE);
	dmProp.setProperty("Title",pTitle);
	dmProp.setProperty("Attnum",String.valueOf(count-2));
	dmProp.setProperty("Notino",pNotino);

	boardtran.updateNoti(cp, dmProp, msgInfo);

    nRet = rsNotiDtlInfo.getRowCount();

                    return rv;
         	}else{
                    return 1;
                }
               // return rv;
              }
	 	catch (Exception e)
	 	{
	 		System.err.println(" processNewBoardMake : " + e.getMessage());
	 		return -1;
	 	}

	}

   /**
    * <PRE>
    *    ȸ���ڵ�� �Խù� ��ȣ�� ���޹޾� �Խù���ȣ�� �´� ����Ʈ�� ������ �����ش�.
    * </PRE>
	*
	* @author          03/19/2002, ������
	*
    * @param cp        a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *						<UL>relevant fields.
    *							<LI> String COMCODE   : ȸ���ڵ�
    *							<LI> String NOTINO    : �Խù� ��ȣ
	*		                </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : �Խù� ���� ( NOTINO,BOXNO,DOCNO,PARENTNO,TITLE,ATTNUM,REFNUM,NOMNUM,CHILDNUM,
    *                                               REGUSER,REGDATE,REGNAME,REF,SORTSTEP,RELEVEL)
    */
	public GCmResultSet getNotiInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoBoBoard board = new GCoBoBoard();

	 	try
	 	{
	 		return board.getNotiInfo(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpBoard::getNotiInfo : " + e.getMessage());
	 		return null;
	 	}
	}

       /**
    * <PRE>
    *    ȸ���ڵ�� �Խù� ��ȣ�� ���޹޾� �Խù���ȣ�� �´� ����Ʈ�� ������ �����ش�.
    * </PRE>
	*
	* @author          03/19/2002, ������
	*
    * @param cp        a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *						<UL>relevant fields.
    *							<LI> String COMCODE   : ȸ���ڵ�
    *							<LI> String NOTINO    : �Խù� ��ȣ
	*		                </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : �Խù� ���� ( NOTINO,BOXNO,DOCNO,PARENTNO,TITLE,ATTNUM,REFNUM,NOMNUM,CHILDNUM,
    *                                               REGUSER,REGDATE,REGNAME,REF,SORTSTEP,RELEVEL)
    */
	public GCmResultSet getNotiDtlInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoBoBoard board = new GCoBoBoard();

	 	try
	 	{
	 		return board.getNotiDtlInfo(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpBoard::getNotiDtlInfo : " + e.getMessage());
	 		return null;
	 	}
	}


    /**
	 *
	 * ȸ�� �����Կ� �ֱ� ��ϵ� �ڷ� ����Ʈ ���
	 * rjman 2002.01.09
	 * @param cp		GCmProperties
	 * @param msgInfo	GCmMsgInfo
	 * @return GCmResultSet
	 */
	 public int updateRefCnt(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoBoBoardTran boardTran = new GCoBoBoardTran();

	 	try
	 	{
	 		return boardTran.updateRefCnt(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println("GTpBoardTran::updateRefCnt:: " + e.getMessage());
	 		return -1;
	 	}

	}

   /**
    * <PRE>
    *    ȸ���ڵ�, ���� �Խù� ��ȣ, �˻�����, �˻���, ���۳�¥, ������ ��¥�� ���޹޾� �� �˻����ǰ� ��ġ�ϴ�
	*    ����Ʈ�� ������ �� ����Ʈ�� ������ �����ش�.
    * </PRE>
    *
	* @author          03/19/2002, ������
	*
    * @param cp        a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *						<UL>relevant fields.
    *							<LI> String COMCODE   : ȸ���ڵ�
    *							<LI> String PARENTNO  : ���� �Խù� ��ȣ
	*							<LI> String OPT       : �˻�����
    *							<LI> String Q         : �˻���
    *							<LI> String SDATE     : ���� ��¥
    *							<LI> String LDATE     : ������ ��¥
	*		                </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : COUNT(*) info ( CNT )
    */
  	public GCmResultSet getRecordCount(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
                GCoBoBoard board = new GCoBoBoard();
 	 	try
	 	{
                        return board.getRecordCount(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpUserInfo::getRecordCount : " + e.getMessage());
	 		return null;
	 	}
	}

    /**
     * <PRE>
     *    ȸ���ȣ, �����Թ�ȣ, ����� ID�� ���޹޾� ����ں� ������ ��뿡 ���� ������ �����ش�.
     * </PRE>
     *
	 * @author          03/19/2002, ������
	 *
     * @param cp        a GCmProperties holding gplus groupware properties.
     * @param dmProp    GCmProperties
     *                  <UL>relevant fields.
     *                      <LI> String COMCODE : current user companycode at session
     *                      <LI> String Boxno   : �Թ�ȣ
	 *                      <LI> String USERID  : current user ID at session
     *                  </UL>
     * @param msgInfo   a GCmMsgInfo holding error codes.
     * @return          GCmResultSet : �����Ա������� list (BOXNO,USERID,DOCREAD,DOCWRITE,DOCDEL,DOCDELADM,FLDMAKE,FLDDEL)
     */
	public GCmResultSet getBoxRight(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoBoBoardRight board = new GCoBoBoardRight();

	 	try
	 	{
	 		return board.getBoxRight(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpBoard::getBoxRight : " + e.getMessage());
	 		return null;
	 	}
	}

   /**
    * <PRE>
    *    ȸ���ڵ�, ���� �Խù� ��ȣ, ���ع�ȣ, �˻�����, �˻���, ���۳�¥, ������ ��¥, ���� ������, �������� ����Ʈ ������ ���޹޾�
	*    �� �˻����ǰ� ��ġ�ϴ� ����Ʈ�� ������ �����ش�
    * </PRE>
    *
	* @author          03/19/2002, ������
	*
    * @param cp        a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *						<UL>relevant fields.
    *							<LI> String COMCODE   : ȸ���ڵ�
    *							<LI> String PARENTNO  : ���� �Խù� ��ȣ
	*							<LI> String SORTID    : ���ع�ȣ
	*							<LI> String OPT       : �˻�����
    *							<LI> String Q         : �˻���
    *							<LI> String SDATE     : ���� ��¥
    *							<LI> String LDATE     : ������ ��¥
	*							<LI> String CURPAGE   : ���� ������ ��ȣ
    *							<LI> String PAGESIZE  : �������� ����Ʈ ��
	*		                </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : �Խù� ���� ( NOTINO,BOXNO,DOCNO,PARENTNO,TITLE,ATTNUM,REFNUM,NOMNUM
    *												 CHILDNUM,REGUSER,REGDATE,REGNAME,REF,SORTSTEP,RELEVEL, ROWNUM )
    */
    public GCmResultSet getBoardList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoBoBoard board = new GCoBoBoard();

	 	try
	 	{
	 		return board.getBoardList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpBoard::getBoardList : " + e.getMessage());
	 		return null;
	 	}
	}

   /**
    * <PRE>
    *    ȸ���ڵ�, ������ ��ȣ�� ���޹޾� �������� �̸��� �����ش�.
    * </PRE>
    *
	* @author          03/19/2002, ������
	*
    * @param cp        a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *						<UL>relevant fields.
    *							<LI> String COMCODE   : ȸ���ڵ�
    *							<LI> String boxno     : �����Թ�ȣ
	*		                </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : ������ �̸� ( BOXNAME )
    */
	public GCmResultSet getBoardTitle(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoBoBoard board = new GCoBoBoard();

	 	try
	 	{
	 		return board.getBoardTitle(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpBoard::getBoardTitle: " + e.getMessage());
	 		return null;
	 	}
	}

   /**
    * <PRE>
    *    ȸ���ڵ�, ������ ��ȣ�� ���޹޾� ������ �����ϴ� ������ ������ �����ش�. ( �Խ����� ���� �׸��� )
    * </PRE>
    *
	* @author          03/19/2002, ������
	*
    * @param cp        a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *						<UL>relevant fields.
    *							<LI> String COMCODE   : ȸ���ڵ�
    *							<LI> String boxno     : �����Թ�ȣ
	*		                </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : �Խ��� �� �̸� ( BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,BOXTYPE,BOXNAME,
	*                                                  BASEFLAG, PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE )
    */
    public String getDrawTab(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoBoBoard board = new GCoBoBoard();
                String retTab = "";

	 	try
	 	{
	 		GCmResultSet rsTab = board.getDrawTab(cp, dmProp, msgInfo);
	 		int count = 0;

                        for (int i=0; i < rsTab.getRowCount() && rsTab.next();i++) {

                              if( count == 0)
                              {
                                      dmProp.setProperty("firstBoxNo",rsTab.getString("boxno"));
                                      dmProp.setProperty("firstBoxName",rsTab.getString("boxname"));
                                      dmProp.setProperty("boxtype",rsTab.getString("boxtype"));
                              }

                	      retTab += "<td class=clsTab id=tabs onclick=\"fnTabClick('";
                              retTab += count;
                              retTab += "','" + rsTab.getString("boxno") + "','" + rsTab.getString("boxtype") + "');\" height=20 >";
                              retTab += "<A class=clsTabLink  href=\"javascript: void();\" onclick=\"this.blur(); return fnTabClick('";
                              retTab += count;
                              retTab += "','" + rsTab.getString("boxno") + "','" + rsTab.getString("boxtype") + "');\"><nobr>&nbsp;";
                              retTab += rsTab.getString("boxname") + "&nbsp;</nobr></A></td>";

	                      count++;
                        }
                        dmProp.setProperty("rstabcount",String.valueOf(rsTab.getRowCount()));
                        return retTab;
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpUserInfo::getUserList : " + e.getMessage());
	 		return null;
	 	}

        }

	/**
	 *  ���� ȭ�鿡�� �������� ����Ʈ ���
	 * rjman 2002.02.07
	 * @param cp		GCmProperties
	 * @param msgInfo	GCmMsgInfo
	 * @return GCmResultSet
	 */
	 public GCmResultSet getGongjiBoardList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoBoBoard board = new GCoBoBoard();

	 	try
	 	{
	 		return board.getGongjiBoardList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println("GTpBoard::getGongjiBoardList:: " + e.getMessage());
	 		return null;
	 	}

	}	// end component call



	/**
	 *
	 * ���� ȭ�鿡�� ����Խ��� ����Ʈ ���.
	 * rjman 2002.01. 09
	 * @param cp		GCmProperties
	 * @param msgInfo	GCmMsgInfo
	 * @return GCmResultSet
	 */
	 public GCmResultSet getSaunBoardList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoBoBoard board = new GCoBoBoard();

	 	try
	 	{
	 		return board.getSaunBoardList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println("GTpBoard::getSaunBoardList:: " + e.getMessage());
	 		return null;
	 	}

	}

   /**
    * <PRE>
    *    ȸ���ڵ�, ���ع�ȣ, ����, �亯������ ���� ���޹޾� ���� ������ �亯�� �������� �������� �����Ͽ�
	*    ���� �ٸ� ���̿� ������ �����Ͽ� �亯(Re) ����Ʈ�� �����ش�
    * </PRE>
	*
	* @author          03/19/2002, ������
	*
    * @param cp        a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *						<UL>relevant fields.
    *							<LI> String COMCODE   : ȸ���ڵ�
    *							<LI> String REF       : ���ع�ȣ
	*                          <LI> String SORTSTEP  : ����
    *							<LI> String RELEVEL   : �亯����
	*		                </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : ���ع�ȣ�� ����, �亯�� ���� ( REF,SORTSTEP,RELEVEL )
    */
    public String getSortStep(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoBoBoard board = new GCoBoBoard();
	 	try
	 	{
                    return board.getSortStep(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpBoard::getSortStep : " + e.getMessage());
	 		return null;
	 	}
	}



	/**
	 *
	 * ȸ�� �����Կ� �ֱ� ��ϵ� �ڷ� ����Ʈ ���
	 * rjman 2002.01.09
	 * @param cp		GCmProperties
	 * @param msgInfo	GCmMsgInfo
	 * @return GCmResultSet
	 */
	 public GCmResultSet getJaryoBoardList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoBoBoard board = new GCoBoBoard();

	 	try
	 	{
	 		return board.getJaryoBoardList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println("GTpBoard::getJaryoBoardList:: " + e.getMessage());
	 		return null;
	 	}

	}

   /**
    * <PRE>
    *    �Խù��� �ڷ��Կ� �����Ѵ�
    * </PRE>
	*
	* @author          03/19/2002, ������
	*
    * @param cp        a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *						<UL>relevant fields.
    *							<LI> String COMCODE   : ȸ���ڵ�
    *							<LI> String BOXNO     : �����Թ�ȣ
	*                          <LI> Strin NOTINO    : �Խù���ȣ
    *							<LI> String FLDBOXNO  : �ӽ� ������ ��ȣ
	*							<LI> String FLDNO     : ������ȣ
    *							<LI> String USERID    : ����� ID
	*                          <LI> String USERNAME  : ����� �̸�
    *							<LI> String PPATH     : ���
	*							<LI> String DOMAIN    : ������
    *							<LI> String READPAGE  : ���� ������
	*                          <LI> String HTTPPORT  : ��Ʈ
	*		                </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : ���ع�ȣ�� ����, �亯�� ���� ( REF,SORTSTEP,RELEVEL )
    */
    public int setCopyFld(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

		String COMCODE  = dmProp.getString("COMCODE");
		String BOXNO    = dmProp.getString("BOXNO");
		String NOTINO   = dmProp.getString("NOTINO");
                String FLDBOXNO = dmProp.getString("FLDBOXNO");
                String pFLDNO   = dmProp.getString("FLDNO");
                String USERID   = dmProp.getString("USERID");
                String USERNAME = dmProp.getString("USERNAME");
		String PPATH    = cp.getProperty("gplus.system.docroot");
                String DOMAIN   = dmProp.getString("DOMAIN");
                String READPAGE = dmProp.getString("READPAGE");
		int HTTPPORT    = dmProp.getInt("HTTPPORT");



	 	GCoBoBoard board = new GCoBoBoard();
	 	GCoBoBoardTran boardTran = new GCoBoBoardTran();
                GCoDoDoc doc = new GCoDoDoc();
                GCoDoDocTran docTran = new GCoDoDocTran();
                GCoDoDocFolder docFolder = new GCoDoDocFolder();
                GCoDoDocFolderTran docFolderTran = new GCoDoDocFolderTran();

                int rv = 0;

                String DOCNO = "";
                String TITLE = "";
                String tTITLE = "";
                String DOCTYPE = "";
                String FILENUM = "";
                String REGUSER = "";
                String REGDATE = "";
                String Conts = "";


	 	try
	 	{

                        dmProp.setProperty("COMCODE",COMCODE);
                        dmProp.setProperty("NOTINO",NOTINO);

                        GCmResultSet rsNotiInfo = board.getNotiInfo(cp, dmProp, msgInfo);

	                for (int j=1;j<=rsNotiInfo.getRowCount() && rsNotiInfo.next();j++)
                        {
                               DOCNO = rsNotiInfo.getString("Docno");
                               TITLE = rsNotiInfo.getString("Title");
                        }

                        dmProp.setProperty("Docno",DOCNO);

                        GCmResultSet rsDocInfo = doc.getDocInfo(cp, dmProp, msgInfo);



                        for (int j=0;j<=rsDocInfo.getRowCount() && rsDocInfo.next();j++)
                        {
                              tTITLE = rsDocInfo.getString("TITLE");
                              DOCTYPE = rsDocInfo.getString("DOCTYPE");
                              FILENUM = rsDocInfo.getString("FILENUM");
                              REGUSER = rsDocInfo.getString("REGUSER");
                              REGDATE = rsDocInfo.getString("REGDATE");
                              Conts = rsDocInfo.getString("MSTDOC");

                         }

                        dmProp.setProperty("Title",tTITLE);
                        dmProp.setProperty("Doctype",DOCTYPE);
                        dmProp.setProperty("Attnum",FILENUM);
                        dmProp.setProperty("Reguser",REGUSER);
                        dmProp.setProperty("Regdate",REGDATE);
                        dmProp.setProperty("Moduser",USERID);
                        dmProp.setProperty("Conts",Conts);
                        dmProp.setProperty("Moddate",gplus.commlib.util.GCmDateFcts.dateToStr(new java.util.Date(), 2));

                        rv = docTran.insertDoc(cp, dmProp, msgInfo);

                        String sRet = dmProp.getString("Docno");

                        dmProp.setProperty("COMCODE",COMCODE);
                        dmProp.setProperty("Boxno",FLDBOXNO);
                        dmProp.setProperty("Docno",sRet);
                        dmProp.setProperty("Parentno",pFLDNO);
                        dmProp.setProperty("Boxname",TITLE);
                        dmProp.setProperty("Userno",USERID);
                        dmProp.setProperty("Regdate",GCmDateFcts.dateToStr(new java.util.Date(), 2));
                        dmProp.setProperty("Trashflag","1");
                        dmProp.setProperty("Comments","");
                        dmProp.setProperty("Refno","A"+NOTINO+BOXNO);


                        rv = docFolderTran.insertFolder(cp, dmProp, msgInfo);

                        dmProp.setProperty("COMCODE",COMCODE);
                        dmProp.setProperty("Boxno",FLDBOXNO);
                        dmProp.setProperty("Fldno",pFLDNO);
                        dmProp.setProperty("USERID",USERID);
                        dmProp.setProperty("Boxname","");


                        String fldNoPath = docFolder.getFldnoPath(cp, dmProp, msgInfo);
              //System.out.println("fldNoPath--------"+fldNoPath);

                        //String sPath = "/DATA/"+COMCODE+"/BOX/"+FLDBOXNO+"/"+fldNoPath;
                        String sPath = "/DATA/"+COMCODE+"/BOX/"+GCmDateFcts.dateToStr(new java.util.Date(), 2).substring(0,6)+"/"+GCmDateFcts.dateToStr(new java.util.Date(), 2).substring(6,8)+"/";

                        java.io.File oFile = null;
                        java.util.Vector vec= new java.util.Vector();
                        String fld = "";
                        String tmp = "";
                        String tPath = "";

                        tmp = sPath.substring(0,1);
                        if (tmp.equals("/"))
                            tPath = sPath.substring(1,sPath.length());
                            vec = GCmFcts.getSplit(tPath,"/");

                        for (int i=0;i<vec.size();i++)
                        {
                            fld += (String)vec.elementAt(i) + "/";
                            oFile = new java.io.File(PPATH + "/" +fld);

                            if (!oFile.isDirectory()) {
                                oFile.mkdir();
                            }
                        }


                        dmProp.setProperty("COMCODE",COMCODE);
                        dmProp.setProperty("Docno",DOCNO);
                        dmProp.setProperty("Seq","00");

                        GCmResultSet rsDocDtlList = doc.getDocDtlList(cp, dmProp, msgInfo);
              //System.out.println("rsDocDtlList.getRowCount()->"+rsDocDtlList.getRowCount());


                        for (int j=0;j<=rsDocDtlList.getRowCount() && rsDocDtlList.next();j++)
                        {

                              String SEQ      = rsDocDtlList.getString("SEQ");
                              String CONTTYPE = rsDocDtlList.getString("Conttype");
                                     TITLE    = rsDocDtlList.getString("Title");
                              String FILEEXT  = rsDocDtlList.getString("Fileext");
                              String FILENAME = rsDocDtlList.getString("Filename");
                              String VPATH    = rsDocDtlList.getString("Vpath");
                              String MIMETYPE = rsDocDtlList.getString("Mimetype");
                              int    FILESIZE = rsDocDtlList.getInt("Filesize");
                              String ORGNAME  = rsDocDtlList.getString("Orgname");
                              String ORGPATH  = rsDocDtlList.getString("Orgpath");
                                     REGUSER  = rsDocDtlList.getString("Reguser");
                                     REGDATE  = rsDocDtlList.getString("Regdate");
                              String MODUSER  = rsDocDtlList.getString("Moduser");
                              String MODDATE  = rsDocDtlList.getString("Moddate");

                              String newFILENAME = sRet+"_"+SEQ+FILEEXT;

                              dmProp.setProperty("COMCODE",COMCODE);
                              dmProp.setProperty("Docno",sRet);
                              dmProp.setProperty("Seq",SEQ);
                              dmProp.setProperty("Conttype",CONTTYPE);
                              dmProp.setProperty("Title",TITLE);
                              dmProp.setProperty("Fileext",FILEEXT);
                              dmProp.setProperty("Filename",newFILENAME);
                              dmProp.setProperty("Vpath",sPath);
                              dmProp.setProperty("Mimetype",MIMETYPE);
                              dmProp.setProperty("Filesize",String.valueOf(FILESIZE));
                              dmProp.setProperty("Orgname",ORGNAME);
                              dmProp.setProperty("Orgpath",ORGPATH);
                              dmProp.setProperty("Reguser",REGUSER);
                              dmProp.setProperty("Regdate",REGDATE);
                              dmProp.setProperty("Moduser",MODUSER);
                              dmProp.setProperty("Moddate",MODDATE);

                              rv = docTran.insertAttDoc(cp, dmProp, msgInfo);

                             // java.io.File file = new java.io.File(PPATH + VPATH, FILENAME);
                             // java.io.File file1 = new java.io.File(PPATH +sPath, newFILENAME);
                              java.io.File file = new java.io.File(PPATH + VPATH, FILENAME);
                              java.io.File file1 = new java.io.File(PPATH +sPath, newFILENAME);
/*
                              if(!file.isFile()){
                                  continue;
                              }
*/
                           // if(file.isFile()){
                              // if(SEQ.equals("01"))
                                 //{

                                      StringBuffer stringbuffer = new StringBuffer();
                                      stringbuffer.append("COMCODE=")
                                      .append(COMCODE).append("&USERID=")
                                      .append(USERID).append("&boxno=")
                                      .append(BOXNO).append("&notino=")
                                      .append(NOTINO).append("&from=copyfld");


                                       GCmHtmlPageSaver htmlpagesaver = new GCmHtmlPageSaver();
                                       String s45 = htmlpagesaver.getHtmlPage(DOMAIN,HTTPPORT,READPAGE,stringbuffer.toString());


                                       dmProp.setProperty("Conts",s45);
                                       dmProp.setProperty("Docno",sRet);

                                       rv = docTran.updateContsDoc(cp, dmProp, msgInfo);
                                       //GCmFcts.setWriteFile(PPATH + sPath, newFILENAME, s45);


                                        if(Integer.parseInt(SEQ)>01){
                                            GCmFcts.copyFile(file, file1);
                                        }

                                  //} else {
                                  //     GCmFcts.copyFile(file, file1);
                                  //}

                              //dmProp.setProperty("Conts",s45);
                              //rv = docTran.updateDoc(cp, dmProp, msgInfo);
                            // }

                        }

                return rv;
           }
           catch (Exception e)
	   {
	        System.err.println(" setCopyFld :: " + e.getMessage());
	 	return -1;
	   }

	}

}