package gplus.template;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;
import gplus.component.wmail.*;

/**
 * <PRE>
 * Filename		: GTpMail.java
 * Class		:
 * Function		:
 * Comment		:
 * History  : 2/15/2002, ������ �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GTpMail
{



	 public GCmResultSet getMailCount(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoWmMail mail = new GCoWmMail();

	 	try
	 	{
	 		return mail.getMailCount(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
			System.out.println("GTpMail :: getMailCount::"+e.getMessage());

	 		return null;
	 	}

	}	// end component call




	 public GCmResultSet getMailAlarmCount(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoWmMail mail = new GCoWmMail();

	 	try
	 	{
	 		return mail.getMailAlarmCount(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println("GTpMail :: getMailAlarmCount::"+e.getMessage());
	 		return null;
	 	}

	}	// end component call




	 public GCmResultSet getMailScreenList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoWmMail mail = new GCoWmMail();

	 	try
	 	{
	 		return mail.getMailScreenList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println("GtpMail::getMailScreenList:"+ e.getMessage());
	 		return null;
	 	}

	}	// end component call



	public GCmResultSet getMailList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoWmMail Mail = new GCoWmMail();

	 	try
	 	{
	 		return Mail.getMailList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}

	}	// end component call



	public GCmResultSet getRecordCount(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoWmMail Mail = new GCoWmMail();

	 	try
	 	{
	 		return Mail.getRecordCount(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}

	}	// end component call



	public String getMaxMailNo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoWmMail Mail = new GCoWmMail();

	 	try
	 	{
	 		return Mail.getMaxMailNo(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}

	}	// end component call



	public String getMaxRegMailNo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoWmMail Mail = new GCoWmMail();

	 	try
	 	{
	 		return Mail.getMaxRegMailNo(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}

	}	// end component call



	public GCmResultSet getNotiDtlInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoWmMail Mail = new GCoWmMail();

	 	try
	 	{
	 		return Mail.getNotiDtlInfo(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}

	}	// end component call



	public GCmResultSet getUserList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoWmMail Mail = new GCoWmMail();

	 	try
	 	{
	 		return Mail.getUserList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}

	}	// end component call





// #################################################################################################### //
//																																													//
//              (GCoWmMailTran) Transaction Template Start >>>>      									//
//																																													//
// #################################################################################################### //



	public boolean  insertMail(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoWmMailTran Mail = new GCoWmMailTran();

	 	try
	 	{
	 		return Mail.insertMail(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
			return false;
	 	}

	}	// end component call




	public boolean  insertRegMail(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoWmMailTran Mail = new GCoWmMailTran();

	 	try
	 	{
	 		return Mail.insertRegMail(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
			return false;
	 	}

	}	// end component call



	public boolean  insertRcvMail(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoWmMailTran Mail = new GCoWmMailTran();

	 	try
	 	{
	 		return Mail.insertRcvMail(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
			return false;
	 	}

	}	// end component call


	public boolean  deleteRegMail(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoWmMailTran Mail = new GCoWmMailTran();

	 	try
	 	{
	 		return Mail.deleteRegMail(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
			return false;
	 	}

	}	// end component call


	public boolean  deleteMailAll(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoWmMailTran Mail = new GCoWmMailTran();

	 	try
	 	{
	 		return Mail.deleteMailAll(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
			return false;
	 	}

	}	// end component call




	public boolean  deleteMail(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoWmMailTran Mail = new GCoWmMailTran();

	 	try
	 	{
	 		return Mail.deleteMail(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
			return false;
	 	}

	}	// end component call




	public boolean  moveBox(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoWmMailTran Mail = new GCoWmMailTran();

	 	try
	 	{
	 		return Mail.moveBox(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
			return false;
	 	}

	}	// end component call


	public boolean  emptyBox(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoWmMailTran Mail = new GCoWmMailTran();

	 	try
	 	{
	 		return Mail.emptyBox(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
			return false;
	 	}

	}	// end component call


	public boolean  updateMoveMail(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoWmMailTran Mail = new GCoWmMailTran();

	 	try
	 	{
	 		return Mail.updateMoveMail(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
			return false;
	 	}

	}	// end component call



	public boolean  setCopyFld(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoWmMailTran Mail = new GCoWmMailTran();

	 	try
	 	{
	 		return Mail.setCopyFld(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
			return false;
	 	}

	}	// end component call



// #################################################################################################### //
//																																													//
//                   (GCoWmMailAccount) Template Start >>>>												//
//																																													//
// #################################################################################################### //


	public GCmResultSet getMailDefaultAcct(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoWmMailAccount Mail = new GCoWmMailAccount();

	 	try
	 	{
	 		return Mail.getMailDefaultAcct(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}

	}	// end component call



	public GCmResultSet getMailAcctList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoWmMailAccount Mail = new GCoWmMailAccount();

	 	try
	 	{
	 		return Mail.getMailAcctList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}

	}	// end component call


	public GCmResultSet getMailAcctInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoWmMailAccount Mail = new GCoWmMailAccount();

	 	try
	 	{
	 		return Mail.getMailAcctInfo(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}

	}	// end component call


	public GCmResultSet isMailAcctDup(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoWmMailAccount Mail = new GCoWmMailAccount();

	 	try
	 	{
	 		return Mail.isMailAcctDup(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}

	}	// end component call


	public GCmResultSet getSysMailAcct(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoWmMailAccount Mail = new GCoWmMailAccount();

	 	try
	 	{
	 		return Mail.getSysMailAcct(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}

	}	// end component call


	public GCmResultSet getMailPop3List(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoWmMailAccount Mail = new GCoWmMailAccount();

	 	try
	 	{
	 		return Mail.getMailPop3List(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}

	}	// end component call


	public GCmResultSet getBoxNoApplyCnt(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoWmMailAccount Mail = new GCoWmMailAccount();

	 	try
	 	{
	 		return Mail.getBoxNoApplyCnt(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}

	}	// end component call


	public GCmResultSet getMailInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoWmMailAccount Mail = new GCoWmMailAccount();

	 	try
	 	{
	 		return Mail.getMailInfo(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}

	}	// end component call



	public GCmResultSet getReadInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoWmMailAccount Mail = new GCoWmMailAccount();

	 	try
	 	{
	 		return Mail.getReadInfo(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}

	}	// end component call




// #################################################################################################### //
//																																													//
//                           	                       (GCoWmMailAccountTran) Transaction Template Start >>>>											//
//																																													//
// #################################################################################################### //



	public boolean  deleteMailAcct(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoWmMailAccountTran Mail = new GCoWmMailAccountTran();

	 	try
	 	{
	 		return Mail.deleteMailAcct(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
			return false;
	 	}

	}	// end component call


	public boolean  insertMailAcct(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoWmMailAccountTran Mail = new GCoWmMailAccountTran();

	 	try
	 	{
	 		return Mail.insertMailAcct(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
			return false;
	 	}

	}	// end component call


	public boolean  updateMailDeflt(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoWmMailAccountTran Mail = new GCoWmMailAccountTran();

	 	try
	 	{
	 		return Mail.updateMailDeflt(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
			return false;
	 	}

	}	// end component call



	public boolean  readMail(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoWmMailAccountTran Mail = new GCoWmMailAccountTran();

	 	try
	 	{
	 		return Mail.readMail(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
			return false;
	 	}

	}	// end component call


   	public int MailAccInfoToDb(GCmProperties prop, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoWmMailAccountTran mailacctran = new GCoWmMailAccountTran();

		String Mode = dmProp.getString("Mode");

                int rv = 0;

	 	try
	 	{
                      rv = mailacctran.deleteEmailAcct(prop, dmProp, msgInfo);

                      if (!Mode.equals("d"))
                      {
                          rv = mailacctran.insertEmailAcct(prop, dmProp, msgInfo);
                      }

                      return rv;
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpMailAccount::MailAccInfoToDb : " + e.getMessage());
	 		return -1;
	 	}
	}	// end component call

//--------------------------------------------------------
// �������Ϸ� �ϰ�ó�� 2002.04.24 ���߱�
//---------------------------------------------------
public boolean setReadFlag(GCmProperties prop, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCoWmMailAccountTran Mail = new GCoWmMailAccountTran();
			 	try
	 	{
	 		return Mail.setReadFlag(prop, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
			return false;
	 	}

	}	// end component call

}
