package gplus.template;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;
import gplus.component.draft.*;

/**
 * <PRE>
 * Filename		: GTpDraft.java
 * Class		:
 * Function		:
 * Comment		:
 * History  : 1/8/2002, ������ �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GTpDraft
{



	/**
	 *
	 * �� �� �� 2002.02.07
	 * @param cp		GCmProperties
	 * @param msgInfo	GCmMsgInfo
	 * @return GCmResultSet
	 */

	 public GCmResultSet getDraftAlarmCountApprtypeNo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoDfDraft draft = new GCoDfDraft();

	 	try
	 	{
	 		return draft.getDraftAlarmCountApprtypeNo(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(" GTpDraft :: getDraftAlarmCountApprtypeNo :: " + e.getMessage());
	 		return null;
	 	}

	}	// getDraftCount1 component call



	/**
	 * ȸ�� ������ ����Ʈ�� �˻��Ѵ�.
	 * �� �� �� 2002.02.07
	 * @param cp		GCmProperties
	 * @param msgInfo	GCmMsgInfo
	 * @return GCmResultSet
	 */

	 public GCmResultSet getDraftAlarmCountApprtypeYes(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoDfDraft draft = new GCoDfDraft();

	 	try
	 	{
	 		return draft.getDraftAlarmCountApprtypeYes(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(" GTpDraft :: getDraftAlarmCountApprtypeYes :: " + e.getMessage());
	 		return null;
	 	}

	}	// getDraftCount1 component call


	public GCmResultSet getDraftStatus(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCoDfDraft Draft = new GCoDfDraft();

	 	try
	 	{
	 		return Draft.getDraftStatus(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println("  AT  getDraftStatus "+e.getMessage());
	 		return null;
	 	}

	}	// end component call

	/**
	 *  ���� ȭ���� ���� ����Ʈ �׸� ���.
	 * �� �� �� 2002.02.07
	 * @param cp		GCmProperties
	 * @param msgInfo	GCmMsgInfo
	 * @return GCmResultSet
	 */

	public GCmResultSet getDraftScreenList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCoDfDraft draft = new GCoDfDraft();

		try
		{
			return draft.getDraftScreenList(cp, dmProp, msgInfo);
		}
		catch (Exception e)
		{
			System.err.println("GTpDraft::getDraftScreenList " + e.getMessage());
			return null;
		}

	}	// getDraftProcList component call

	public GCmProperties getDraftApprStatusList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCoDfDraft Draft = new GCoDfDraft();

	 	try
	 	{
	 		return Draft.getDraftApprStatusList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println("  AT  getDraftApprStatusList "+e.getMessage());
	 		return null;
	 	}

	}	// end component call


	public GCmResultSet getDraftLineInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoDfDraft Draft = new GCoDfDraft();

	 	try
	 	{
	 		return Draft.getDraftLineInfo(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}

	}	// end component call



	// ���� setDraftLineInfo �� �и�( ���߿� �����ؾ���, �ϴ� Business�ϰ� �����ϰ� ���߱� ����...)
	public GCmResultSet getDraftSubLineInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoDfDraft Draft = new GCoDfDraft();

	 	try
	 	{
	 		return Draft.getDraftSubLineInfo(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}

	}	// end component call



	public String getMaxLineNo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoDfDraft Draft = new GCoDfDraft();

	 	try
	 	{
	 		return Draft.getMaxLineNo(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}

	}	// end component call




	public GCmResultSet getDraftLineList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoDfDraft Draft = new GCoDfDraft();

	 	try
	 	{
	 		return Draft.getDraftLineList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}

	}	// end component call




	public GCmResultSet getBoxnoApplyCnt(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoDfDraft Draft = new GCoDfDraft();

	 	try
	 	{
	 		return Draft.getBoxnoApplyCnt(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}

	}	// end component call




	public GCmResultSet getDraftList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoDfDraft Draft = new GCoDfDraft();

	 	try
	 	{
	 		return Draft.getDraftList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}

	}	// end component call



	public int getRecordCount(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoDfDraft Draft = new GCoDfDraft();

	 	try
	 	{
	 		return Draft.getRecordCount(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return -1;
	 	}

	}	// end component call






	public String getMaxDrftNo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoDfDraft Draft = new GCoDfDraft();


        // String regdate = com.win.Fcts.dateToStr(new java.util.Date(),1);                ���κ��� ���� Business�� �־����� JSP�ܿ��� �����ֵ��� �����ؾ� ��.

	 	try
	 	{


			String strRet = Draft.getMaxDrftNo(cp, dmProp, msgInfo);

	 		return strRet;
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}

	}	// end component call




	public String getMaxRegDrftNo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoDfDraft Draft = new GCoDfDraft();


        // String regdate = com.win.Fcts.dateToStr(new java.util.Date(),1);                ���κ��� ���� Business�� �־����� JSP�ܿ��� �����ֵ��� �����ؾ� ��.

	 	try
	 	{


			String strRet = Draft.getMaxRegDrftNo(cp, dmProp, msgInfo);

	 		return strRet;
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}

	}	// end component call



	public boolean isCheckRead(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

		String strTmp = "";
		boolean bRead = false;

		GCoDfDraft Draft = new GCoDfDraft();

	 	try
	 	{
	 		GCmResultSet rs = Draft.isCheckRead(cp, dmProp, msgInfo);


			if (rs.next()) {

	            strTmp = rs.getString("APPRTYPE");

				if (strTmp.equals("2"))

					bRead = true;

	            else bRead = false;

			}

			else bRead = true;

			return bRead;

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return false;
	 	}

	}	// end component call



	public GCmResultSet getDraftInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{



		GCoDfDraft Draft = new GCoDfDraft();

	 	try
	 	{
	 		return Draft.getDraftInfo(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}

	}	// end component call


	public GCmResultSet getDraftProcList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{



		GCoDfDraft Draft = new GCoDfDraft();

	 	try
	 	{
	 		return Draft.getDraftProcList(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}

	}	// end component call

	public GCmResultSet getPApprUserList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCoDfDraft Draft = new GCoDfDraft();
	 	try
	 	{
	 		return Draft.getPApprUserList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}
	}	// end component call



	public GCmResultSet getOrgUserList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{



		GCoDfDraft Draft = new GCoDfDraft();

	 	try
	 	{
	 		return Draft.getOrgUserList(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}

	}	// end component call


	public GCmResultSet getDraftHelpComment(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{



		GCoDfDraft Draft = new GCoDfDraft();

	 	try
	 	{
	 		return Draft.getDraftHelpComment(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
	 		return null;
	 	}

	}	// end component call


// #################################################################################################### //
//																																													//
//                               	                       (GCoDfDraftTran) Transaction Template Start >>>>													//
//																																													//
// #################################################################################################### //


	public boolean  updateReadFlag(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoDfDraftTran Draft = new GCoDfDraftTran();

	 	try
	 	{
	 		return Draft.updateReadFlag(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
			return false;
	 	}

	}	// end component call



	public void  deleteDraftLine(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoDfDraftTran Draft = new GCoDfDraftTran();

	 	try
	 	{
	 		 Draft.deleteDraftLine(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());

	 	}

	}	// end component call


	public void  insertDraftLine(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoDfDraftTran Draft = new GCoDfDraftTran();

	 	try
	 	{
	 		 Draft.insertDraftLine(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());

	 	}

	}	// end component call




	public void  insertSubDraftLine(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoDfDraftTran Draft = new GCoDfDraftTran();

	 	try
	 	{
	 		 Draft.insertSubDraftLine(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());

	 	}

	}	// end component call



	public int  insertDraft(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoDfDraftTran DraftTran = new GCoDfDraftTran();

	 	try
	 	{
	 		 return DraftTran.insertDraft(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
			return -1;
	 	}

	}	// end component call


	public boolean  insertAppr(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoDfDraftTran DraftTran = new GCoDfDraftTran();

	 	try
	 	{
	 		 return DraftTran.insertAppr(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
			return false;
	 	}

	}	// end component call






	public boolean  insertRegDraft(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoDfDraftTran DraftTran = new GCoDfDraftTran();

	 	try
	 	{
	 		 return DraftTran.insertRegDraft(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
			return false;

	 	}

	}	// end component call



	public int reSaveDeleteCount(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoDfDraftTran DraftTran = new GCoDfDraftTran();

	 	try
	 	{
	 		 return DraftTran.reSaveDeleteCount(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
			return -1;

	 	}

	}	// end component call



	public boolean draftFinish(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoDfDraftTran DraftTran = new GCoDfDraftTran();

	 	try
	 	{
	 		 return DraftTran.draftFinish(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
			return false;

	 	}

	}	// end component call


	public boolean setCopyFld(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoDfDraftTran DraftTran = new GCoDfDraftTran();

	 	try
	 	{
	 		 return DraftTran.setCopyFld(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
			return false;
	 	}

	}	// end component call

	/*public boolean deleteRealFile(String realfile)
        {
              GCoDfDraftTran DraftTran = new GCoDfDraftTran();
             try
              {
                return DraftTran.deleteRealFile(realfile);
              }
              catch(Exception e)
              {
              System.err.println(e.getMessage());
			return false;
              }
        }
*/
        public String setDraftTemp(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

                String conts = "";
		GCoDfDraftTran DraftTran = new GCoDfDraftTran();

	 	try
	 	{
	 		  conts = DraftTran.setDraftTemp(cp, dmProp, msgInfo);
                          return conts;
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
			return conts;

	 	}

	}	// end component call
// #################################################################################################### //
//																																													//
//                               	                       (GCoDfApproval) Template Start >>>>																		//
//																																													//
// #################################################################################################### //


	public GCmResultSet  getInfoStep(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

		GCoDfApproval Draft = new GCoDfApproval();

	 	try
	 	{
	 		return Draft.getInfoStep(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(e.getMessage());
			return null;
	 	}

	}	// end component call

	public GCmResultSet  getInfoBoxNo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoDfApproval Draft = new GCoDfApproval();

	 	try
	 	{
	 		return Draft.getInfoBoxNo(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{

	 		System.err.println(e.getMessage());
			return null;

	 	}

	}	// end component call



	public GCmResultSet  getLastId(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoDfApproval Draft = new GCoDfApproval();

	 	try
	 	{
	 		return Draft.getLastId(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{

	 		System.err.println(e.getMessage());
			return null;

	 	}

	}	// end component call


	public GCmResultSet  getApprovedLastId(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoDfApproval Draft = new GCoDfApproval();

	 	try
	 	{
	 		return Draft.getApprovedLastId(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{

	 		System.err.println(e.getMessage());
			return null;

	 	}

	}	// end component call


	public GCmResultSet  getCountRead(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoDfApproval Draft = new GCoDfApproval();

	 	try
	 	{
	 		return Draft.getCountRead(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{

	 		System.err.println(e.getMessage());
			return null;

	 	}

	}	// end component call



// #################################################################################################### //
//																																													//
//                           	                       (GCoDfApprovalTran) Transaction Template Start >>>>  												//
//																																													//
// #################################################################################################### //


	public boolean  updateApproval(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoDfApprovalTran Draft = new GCoDfApprovalTran();

	 	try
	 	{
	 		return Draft.updateApproval(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{

	 		System.err.println(e.getMessage());
			return false;

	 	}

	}	// end component call



	public boolean  updateBox(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoDfApprovalTran Draft = new GCoDfApprovalTran();

	 	try
	 	{
	 		return Draft.updateBox(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{

	 		System.err.println(e.getMessage());
			return false;

	 	}

	}	// end component call



	public boolean  updateApprovalType(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoDfApprovalTran Draft = new GCoDfApprovalTran();

	 	try
	 	{
	 		return Draft.updateApprovalType(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{

	 		System.err.println(e.getMessage());
			return false;

	 	}

	}	// end component call



	public boolean  draftCancel(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoDfApprovalTran Draft = new GCoDfApprovalTran();

	 	try
	 	{
	 		return Draft.draftCancel(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{

	 		System.err.println(e.getMessage());
			return false;

	 	}

	}	// end component call


	public boolean  upApprDelete(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoDfApprovalTran Draft = new GCoDfApprovalTran();

	 	try
	 	{
	 		return Draft.upApprDelete(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{

	 		System.err.println(e.getMessage());
			return false;

	 	}

	}	// end component call



	public boolean  draftReject(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoDfApprovalTran Draft = new GCoDfApprovalTran();

	 	try
	 	{
	 		return Draft.draftReject(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{

	 		System.err.println(e.getMessage());
			return false;

	 	}

	}	// end component call

	public boolean  deleteRegDrft(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoDfApprovalTran Draft = new GCoDfApprovalTran();

	 	try
	 	{
	 		return Draft.deleteRegDrft(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{

	 		System.err.println(e.getMessage());
			return false;

	 	}

	}	// end component call


	public boolean  updateReadAppr(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoDfApprovalTran Draft = new GCoDfApprovalTran();

	 	try
	 	{
	 		return Draft.updateReadAppr(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{

	 		System.err.println(e.getMessage());
			return false;

	 	}

	}	// end component call


	public boolean  updateHelpAppr(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoDfApprovalTran Draft = new GCoDfApprovalTran();

	 	try
	 	{
	 		return Draft.updateHelpAppr(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{

	 		System.err.println(e.getMessage());
			return false;

	 	}

	}	// end component call



	public boolean  updateHelpApprComments(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCoDfApprovalTran Draft = new GCoDfApprovalTran();

	 	try
	 	{
	 		return Draft.updateHelpApprComments(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{

	 		System.err.println(e.getMessage());
			return false;

	 	}

	}	// end component call

      public boolean deleteBox(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
      {
       GCoDfDraftTran draftTran = new GCoDfDraftTran();
       try
	 	{
	 		return draftTran.deleteBox(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpDraft::deleteBox : " + e.getMessage());
	 		return false;
	 	}
	}


       /**
        * <PRE>
        * ���޵� ��忡 ���� �������� ����Ѵ�. ��尡 d�̸� ���� �������� �����ϰ� ��尡 null�̸� �������� ����Ѵ�.
        * ��������ȣ�� ���Ͽ� ����/������ ����� �����Ѵ�. ��������ȣ�� null�� ��� deleteDraftSubLine,deleteDraftLine����
        * �������� �����ϰ� ��尡 d�� �ƴϸ� insertDraftLine���� �������� ����ϰ� insertSubDraftLine���� ��������
        * �������� ����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Mode : ��� (d:����, null:�Է�)
        *                      <LI> String Linenum : ��������ȣ
        *                      <LI> String Line2 : �������
        *                      <LI> String Line3 : �������
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int DraftLineInfoToDb(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoDfDraftTran draftTran = new GCoDfDraftTran();

	 	try
	 	{
	 		return draftTran.DraftLineInfoToDb(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpDraft::DraftLineInfoToDb : " + e.getMessage());
	 		return -1;
	 	}
	}

}