package gplus.template;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;
import com.jspsmart.upload.*;

import gplus.component.card.*;

/**
 * Title:        GPlus
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      korpa
 * @author
 * @version 1.0
 */

public class GTpCardHistory {

	 public GCmResultSet getCardHistoryDetail(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoCaCardHistory Card = new GCoCaCardHistory();

	 	try
	 	{
	 		return Card.getCardHistoryDetail(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" getCardHistoryDetail : " + e.getMessage());
	 		return null;
	 	}

	}	// end component call

  	/**
	 *
	 * rjman 2002.02.04
	 * @param cp		GCmProperties
	 * @param msgInfo	GCmMsgInfo
	 * @return GCmResultSet
	 */

	 public GCmResultSet getCardHistoryCount(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoCaCardHistory Card = new GCoCaCardHistory();

	 	try
	 	{
	 		return Card.getCardHistoryCount(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" getCardHistoryCount: " + e.getMessage());
	 		return null;
	 	}

	}	// end component call


   	/**
	 *
	 * rjman 2002.02.04
	 * @param cp		GCmProperties
	 * @param msgInfo	GCmMsgInfo
	 * @return GCmResultSet
	 */

	 public GCmResultSet getCardHistoryList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoCaCardHistory Card = new GCoCaCardHistory();

	 	try
	 	{
	 		return Card.getCardHistoryList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" getCardHistoryList: " + e.getMessage());
	 		return null;
	 	}

	}	// end component call

  	/**
	 *
	 * rjman 2002.02.05
	 * @param cp		GCmProperties
	 * @param msgInfo	GCmMsgInfo
	 * @return GCmResultSet
	 */



	public int updateCardHistory(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoCaCardHistoryTran Card = new GCoCaCardHistoryTran();

	 	try
	 	{
	 		return Card.updateCardHistory(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" updateCardHistory: " + e.getMessage());
	 		return -1;
	 	}

	}	// end component call


  	/**
	 *
	 * rjman 2002.02.05
	 * @param cp		GCmProperties
	 * @param msgInfo	GCmMsgInfo
	 * @return GCmResultSet
	 */




       	public int insertCardHistory(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoCaCardHistoryTran Card = new GCoCaCardHistoryTran();

	 	try
	 	{
	 		return Card.insertCardHistory(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" ::insertCardHistory: " + e.getMessage());
	 		return -1;
	 	}

	}	// end component call

       /**
        * <PRE>
        * ���޵� �����ڵ忡 �ش��ϴ� �����ڵ带 �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String PosCode : �����ڵ�
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteCardHistory(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoCaCardHistoryTran Card = new GCoCaCardHistoryTran();

	 	try
	 	{
	 		return Card.deleteCardHistory(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpCardHistory::deleteCardHistory : " + e.getMessage());
	 		return -1;
	 	}

	}	// end component call

       /**
        * <PRE>
        * ���޵� �����ڵ忡 �ش��ϴ� �����ڵ带 �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String PosCode : �����ڵ�
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteCardHistoryAll(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoCaCardHistoryTran cardtran = new GCoCaCardHistoryTran();

	 	try
	 	{
	 		return cardtran.deleteCardHistoryAll(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpCardHistory::deleteCardHistoryAll : " + e.getMessage());
	 		return -1;
	 	}

	}	// end component call

}


