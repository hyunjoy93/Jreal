package gplus.template;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

import gplus.component.pims.*;

/**
 * <PRE>
 * Filename		: GTpLogin.java
 * Class		:
 * Function		:
 * Comment		:
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GTpSchedule
{


       /**
        * <PRE>
        * ����ڿ� ���� ��,��,�Ͽ� ���� �Ϸ� ���� ����� ����Ʈ �Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : ����� ���̵�
        *                      <LI> String Year : ��
        *                      <LI> String Month : ��
        *                      <LI> String Day : ��
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	 public GCmResultSet getSchdlEveryListTotal(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoPiSchedule pims = new GCoPiSchedule();

	 	try
	 	{
	 		return pims.getSchdlEveryListTotal(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpSchdl::getSchdlEveryListTotal: " + e.getMessage());
	 		return null;
	 	}

	}	// end component call


       /**
        * <PRE>
        * ����ڿ� ���� ��,��,�Ͽ� ���� �Ϸ� ���� ����� ����Ʈ �Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : ����� ���̵�
        *                      <LI> String Year : ��
        *                      <LI> String Month : ��
        *                      <LI> String Day : ��
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	 public GCmResultSet getSchdlEveryList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoPiSchedule pims = new GCoPiSchedule();

	 	try
	 	{
	 		return pims.getSchdlEveryList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpSchdl::getSchdlEveryList1: " + e.getMessage());
	 		return null;
	 	}

	}	// end component call

       /**
        * <PRE>
        * ����ڿ� ���� ��,��,�Ͽ� ���� �Ϸ� ���� ����� ����Ʈ �Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : ����� ���̵�
        *                      <LI> String Year : ��
        *                      <LI> String Month : ��
        *                      <LI> String Day : ��
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	 public GCmResultSet getMainSchdlList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoPiSchedule pims = new GCoPiSchedule();

	 	try
	 	{
	 		return pims.getMainSchdlList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpSchdl::getSchdlEveryList: " + e.getMessage());
	 		return null;
	 	}

         }	// end component call

       /**
        * <PRE>
        * ��������Ʈ �ð��� ����Ʈ.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : ����� ���̵�
        *                      <LI> String Year : ��
        *                      <LI> String Month : ��
        *                      <LI> String Day : ��
        *                      <LI> String Time : �ð�
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */

	 public GCmResultSet getSchdlTimeList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoPiSchedule pims = new GCoPiSchedule();

	 	try
	 	{
	 		return pims.getSchdlTimeList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpSchdl::SchdlTimeList: " + e.getMessage());
	 		return null;
	 	}

	}	// end component call

       /**
        * <PRE>
        * ��������Ʈ (�ְ�/����������)
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : ����� ���̵�
        *                      <LI> String Year : ��
        *                      <LI> String Month : ��
        *                      <LI> String Day : ��
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	 public GCmResultSet getSchdlList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoPiSchedule pims = new GCoPiSchedule();

	 	try
	 	{
	 		return pims.getSchdlList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpSchdl::getSchdlList: " + e.getMessage());
	 		return null;
	 	}

	}	// end component call

       /**
        * <PRE>
        * ����ڿ� ���� ���� ����� ����Ʈ �Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : ����� ���̵�
        *                      <LI> String Schdlno : ������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	 public GCmResultSet getSchdlInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoPiSchedule pims = new GCoPiSchedule();

	 	try
	 	{
	 		return pims.getSchdlInfo(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpSchdl::getSchdlInfo: " + e.getMessage());
	 		return null;
	 	}

	}	// end component call


       /**
        * <PRE>
        *  ������� ( ���ο� �������, ����, ����, Ÿ���� ���� ��� )
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	 public int SchdlManager(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	int rv = 0;

	 	GCoPiScheduleTran schdlTran = new GCoPiScheduleTran();

		String Delflag = dmProp.getString("Delflag");
                //System.out.println("Delflag--->"+Delflag);
		//String Grpname = dmProp.getString("Grpname");
		String Sub2 = dmProp.getString("Sub2");

                GEmTB_E10 dm = (GEmTB_E10) dmProp.getObject("TB_E10");

	 	try
	 	{

                    if ( dm == null ) throw new Exception("ENTITY MODEL is null");

                     if (Delflag==null || Delflag.equals("")) {
                          if( dm.getStrSchdlNo() == null || dm.getStrSchdlNo().equals("")) {
                              rv = schdlTran.insertNewSchedule(cp, dmProp, msgInfo);
                              if(Sub2 != null && !Sub2.equals("")) {
                                    rv = schdlTran.insertOtherNewSchedule(cp, dmProp, msgInfo);
                              }
                          }
                          else {
                              rv = schdlTran.updateSchedule(cp, dmProp, msgInfo);
                              if(Sub2 != null && !Sub2.equals("")) {
                                 rv = schdlTran.updateOtherNewSchedule(cp, dmProp, msgInfo);
                              }
                          }
                     }
                     else {//System.out.println("DelFlag------------>"+Delflag);
                              rv = schdlTran.deleteSchedule(cp, dmProp, msgInfo);
                     }

	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpSchdl::SchdlManager " + e.getMessage());
	 		rv = -1;
	 	}

	 	return rv;
	}	// end component call

       /**
        * <PRE>
        * ����ڿ� ���� ���� �뺸�� ����Ʈ.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : ����� ���̵�
        *                      <LI> String Schdlno : ������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public GCmResultSet getDeliverList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoPiSchedule pims = new GCoPiSchedule();

	 	try
	 	{
	 		return pims.getDeliverList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpSchdl::getDeliverList  " + e.getMessage());
	 		return null;
	 	}

	}	// end component call
}	// end GTpLogin