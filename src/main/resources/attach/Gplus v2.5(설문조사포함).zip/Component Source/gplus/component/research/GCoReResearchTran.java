package gplus.component.research;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

/**
 * <PRE>
 * Filename		: GCoBoBoard.java
 * Class		: gplus.component.pos.GCoBoBoard
 * Fuction		:
 * Comment		:
 * History      : 03/19/2002, ������, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GCoReResearchTran extends GCmTopComponent
{
      public int  insertResearchMain(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
      {
		GCmConnection conn = null;
		int rv = 0 ;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			String strComCode  = dmProp.getString("COMCODE");
			String strBoxNo    = dmProp.getString("boxno");
			String strSdate    = dmProp.getString("sdate");
			String strLdate    = dmProp.getString("ldate");
			String strStatus   = dmProp.getString("status");
			String strRegUser  = dmProp.getString("reguser");
			String strTitle    = dmProp.getString("title");
			String strComments = dmProp.getString("comments");
                        String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

			String strQuestionNo = getMaxQuestionNo(strComCode,strDbType);
                        String Sdate    = GCmFcts.replace(strSdate, "/", "");
			String Ldate    = GCmFcts.replace(strLdate, "/", "");


			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
					.append(" INSERT INTO TB_").append(strComCode).append("_Q10 ")
					.append(" (QUESTIONNO,BOXNO,SDATE,LDATE,STATUS,REGUSER,TITLE,COMMENTS)")
					.append(" VALUES (")
					.append(genQuote(strQuestionNo)).append(", ")
					.append(genQuote(strBoxNo)).append(", ")
					.append(genQuote(Sdate)).append(", ")
					.append(genQuote(Ldate)).append(", ")
					.append(genQuote(strStatus)).append(", ")
					.append(genQuote(strRegUser)).append(", ")
					.append(genQuote(strTitle)).append(", ")
					.append(genQuote(strComments))
					.append(" ) ");


			stmt = conn.createStatement();
			rv = stmt.executeUpdate(sqlQuery.toString());
			conn.commit();

			dmProp.setProperty("QUESTIONNO", strQuestionNo);

			return rv;

		}
		catch (Exception e)
		{

			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoReResearchTran :: insertResearchMain()" + e.getMessage());
			}


			System.out.println("GCoReResearchTran :: insertResearchMain()" + e.getMessage());


			return -1;

		}
		finally
		{
			conn.close();
		}
	}


       public int  insertResearchUser(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
       {
		GCmConnection conn = null;
		int rv = 0 ;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			String strComCode  = dmProp.getString("COMCODE");
                        String strQuestionNo    = dmProp.getString("questionno");
			String strUserId    = dmProp.getString("userid");
                        String strReqFlag    = dmProp.getString("reqflag");

			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
					.append(" INSERT INTO TB_").append(strComCode).append("_Q20 ")
					.append(" (QUESTIONNO,USERID,REQFLAG)")
					.append(" VALUES (")
					.append(genQuote(strQuestionNo)).append(", ")
                                        .append(genQuote(strUserId)).append(", ")
					.append(genQuote(strReqFlag))
					.append(" ) ");

			stmt = conn.createStatement();
			rv = stmt.executeUpdate(sqlQuery.toString());
			conn.commit();

			return rv;

		}
		catch (Exception e)
		{

			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoReResearchTran :: insertResearchUser()" + e.getMessage());
			}


			System.out.println("GCoReResearchTran :: insertResearchUser()" + e.getMessage());


			return -1;

		}
		finally
		{
			conn.close();
		}
	}


        public int  insertResearchObject(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
       {
		GCmConnection conn = null;
		int rv = 0 ;
		Statement stmt = null;


		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			String strComCode     = dmProp.getString("COMCODE");
                        String strQuestionNo  = dmProp.getString("questionno");
                        String strItemTitle   = dmProp.getString("itemtitle");
			String strItemType    = dmProp.getString("itemtype");
                        String strSubItemCnt  = dmProp.getString("subitemcnt");

                        if(strItemType.equals("5"))
                        {
                              strSubItemCnt = "1";
                        }

                        int count             = dmProp.getInt("count");
                        String strDbType      = cp.getProperty("gplus.db.type").toLowerCase();

                        String strItemNo = getMaxItemNo(strComCode,strDbType);
                        String strSeq = gplus.commlib.util.GCmFcts.numToStr(String.valueOf(count),3);

			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
					.append(" INSERT INTO TB_").append(strComCode).append("_Q11 ")
					.append(" (ITEMNO,QUESTIONNO,SEQ,ITEMTITLE,ITEMTYPE,SUBITEMCNT)")
					.append(" VALUES (")
					.append(genQuote(strItemNo)).append(", ")
                                        .append(genQuote(strQuestionNo)).append(", ")
                                        .append(genQuote(strSeq)).append(", ")
                                        .append(genQuote(strItemTitle)).append(", ")
                                        .append(genQuote(strItemType)).append(", ")
					.append(genQuote(strSubItemCnt))
					.append(" ) ");

			stmt = conn.createStatement();
			rv = stmt.executeUpdate(sqlQuery.toString());
			conn.commit();

                        dmProp.setProperty("ITEMNO", strItemNo);

			return rv;

		}
		catch (Exception e)
		{

			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoReResearchTran :: insertResearchObject()" + e.getMessage());
			}


			System.out.println("GCoReResearchTran :: insertResearchObject()" + e.getMessage());


			return -1;

		}
		finally
		{
			conn.close();
		}
	}

        public int  insertResearchDetailObject(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
        {
		GCmConnection conn = null;
		int rv = 0 ;
		Statement stmt = null;
		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			String strComCode       = dmProp.getString("COMCODE");
                        String strItemNo        = dmProp.getString("itemno");
                        String strSubItemTitle  = dmProp.getString("subitemtitle");
                        String strDbType        = cp.getProperty("gplus.db.type").toLowerCase();

                        int count               = dmProp.getInt("count");
                        String strSeq = gplus.commlib.util.GCmFcts.numToStr(String.valueOf(count),3);

                        String strSubItemNo = getMaxSubItemNo(strComCode,strDbType);

			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
					.append(" INSERT INTO TB_").append(strComCode).append("_Q12 ")
					.append(" (SUBITEMNO,ITEMNO,SEQ,SUBITEMTITLE)")
					.append(" VALUES (")
					.append(genQuote(strSubItemNo)).append(", ")
                                        .append(genQuote(strItemNo)).append(", ")
                                        .append(genQuote(strSeq)).append(", ")
					.append(genQuote(strSubItemTitle))
					.append(" ) ");

			stmt = conn.createStatement();
			rv = stmt.executeUpdate(sqlQuery.toString());
			conn.commit();

                        dmProp.setProperty("ITEMNO", strItemNo);

			return rv;

		}
		catch (Exception e)
		{

			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoReResearchTran :: insertResearchDetailObject()" + e.getMessage());
			}


			System.out.println("GCoReResearchTran :: insertResearchDetailObject()" + e.getMessage());


			return -1;

		}
		finally
		{
			conn.close();
		}
	}

        public int  insertSuggestion(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
       {
		GCmConnection conn = null;
		int rv = 0 ;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			String strComCode    = dmProp.getString("COMCODE");
                        String strSubItemNo  = dmProp.getString("subitemno");
                        String strQuestionNo = dmProp.getString("questionno");
                        String strUserId     = dmProp.getString("USERID");
                        String strSuggestion = dmProp.getString("suggestion");

                        if(strSuggestion == null || strSuggestion.equals("")) strSuggestion = "";

			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
					.append(" INSERT INTO TB_").append(strComCode).append("_Q30 ")
					.append(" (SUBITEMNO,QUESTIONNO,USERID,SUGGESTION)")
					.append(" VALUES (")
					.append(genQuote(strSubItemNo)).append(", ")
                                        .append(genQuote(strQuestionNo)).append(", ")
                                         .append(genQuote(strUserId)).append(", ")
					.append(genQuote(strSuggestion))
					.append(" ) ");

			stmt = conn.createStatement();
			rv = stmt.executeUpdate(sqlQuery.toString());
			conn.commit();

			return rv;

		}
		catch (Exception e)
		{

			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoReResearchTran :: insertSuggestion()" + e.getMessage());
			}


			System.out.println("GCoReResearchTran :: insertSuggestion()" + e.getMessage());


			return -1;

		}
		finally
		{
			conn.close();
		}
	}

      public int  updateUser(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
       {
		GCmConnection conn = null;
		int rv = 0 ;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			String strComCode  = dmProp.getString("COMCODE");
                        String strQuestionNo    = dmProp.getString("questionno");
			String strUserId    = dmProp.getString("USERID");
                        String strReqFlag    = dmProp.getString("reqflag");

			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
					.append(" UPDATE TB_").append(strComCode).append("_Q20 ")
					.append(" SET REQFLAG = " + genQuote(strReqFlag))
					.append(" WHERE QUESTIONNO = " + genQuote(strQuestionNo))
                                        .append(" AND USERID = " + genQuote(strUserId));


			stmt = conn.createStatement();
			rv = stmt.executeUpdate(sqlQuery.toString());
			conn.commit();

			return rv;

		}
		catch (Exception e)
		{

			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoReResearchTran :: updateUser()" + e.getMessage());
			}


			System.out.println("GCoReResearchTran :: updateUser()" + e.getMessage());


			return -1;

		}
		finally
		{
			conn.close();
		}
	}

        public int  updateBoxNo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
       {
		GCmConnection conn = null;
		int rv = 0 ;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			String strComCode  = dmProp.getString("COMCODE");
                        String strQuestionNo    = dmProp.getString("questionno");
			String strBoxNo   = dmProp.getString("boxno");

			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
					.append(" UPDATE TB_").append(strComCode).append("_Q10 ")
					.append(" SET BOXNO = " + genQuote(strBoxNo))
					.append(" WHERE QUESTIONNO = " + genQuote(strQuestionNo));



			stmt = conn.createStatement();
			rv = stmt.executeUpdate(sqlQuery.toString());
			conn.commit();

			return rv;

		}
		catch (Exception e)
		{

			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoReResearchTran :: updateBoxNo()" + e.getMessage());
			}


			System.out.println("GCoReResearchTran :: updateBoxNo()" + e.getMessage());


			return -1;

		}
		finally
		{
			conn.close();
		}
	}

        public int  updateResearchMain(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
       {
		GCmConnection conn = null;
		int rv = 0 ;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			String strComCode  = dmProp.getString("COMCODE");
                        String strQuestionNo    = dmProp.getString("questionno");
			String strBoxNo    = dmProp.getString("boxno");
			String strSdate    = dmProp.getString("sdate");
			String strLdate    = dmProp.getString("ldate");
			String strStatus   = dmProp.getString("status");
			String strRegUser  = dmProp.getString("reguser");
			String strTitle    = dmProp.getString("title");
			String strComments = dmProp.getString("comments");
                        String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

                        String Sdate    = GCmFcts.replace(strSdate, "/", "");
			String Ldate    = GCmFcts.replace(strLdate, "/", "");

			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
					.append(" UPDATE TB_").append(strComCode).append("_Q10 ")
					.append(" SET SDATE = " + genQuote(Sdate))
                                        .append(" , LDATE = " + genQuote(Ldate))
                                        .append(" , TITLE = " + genQuote(strTitle))
                                        .append(" , COMMENTS = " + genQuote(strComments))
                                  	.append(" WHERE QUESTIONNO = " + genQuote(strQuestionNo));

			stmt = conn.createStatement();
			rv = stmt.executeUpdate(sqlQuery.toString());
			conn.commit();

			return rv;

		}
		catch (Exception e)
		{

			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoReResearchTran :: updateBoxNo()" + e.getMessage());
			}


			System.out.println("GCoReResearchTran :: updateBoxNo()" + e.getMessage());


			return -1;

		}
		finally
		{
			conn.close();
		}
	}

        public int  updateStatus(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
       {
		GCmConnection conn = null;
		int rv = 0 ;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			String strComCode  = dmProp.getString("COMCODE");
                        String strQuestionNo    = dmProp.getString("questionno");
                        String strStatus   = dmProp.getString("status");

			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
					.append(" UPDATE TB_").append(strComCode).append("_Q10 ")
					.append(" SET STATUS = " + genQuote(strStatus))
					.append(" WHERE QUESTIONNO = " + genQuote(strQuestionNo));

			stmt = conn.createStatement();
			rv = stmt.executeUpdate(sqlQuery.toString());
			conn.commit();

			return rv;

		}
		catch (Exception e)
		{

			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoReResearchTran :: updateBoxNo()" + e.getMessage());
			}


			System.out.println("GCoReResearchTran :: updateBoxNo()" + e.getMessage());


			return -1;

		}
		finally
		{
			conn.close();
		}
	}

        public int  updateDate(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
       {
		GCmConnection conn = null;
		int rv = 0 ;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			String strComCode  = dmProp.getString("COMCODE");
                        String strQuestionNo    = dmProp.getString("questionno");
                        String strSdate   = dmProp.getString("sdate");
                        String strLdate   = dmProp.getString("ldate");

                        String Sdate    = GCmFcts.replace(strSdate, "/", "");
			String Ldate    = GCmFcts.replace(strLdate, "/", "");

			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
					.append(" UPDATE TB_").append(strComCode).append("_Q10 ")
					.append(" SET SDATE = " + genQuote(Sdate))
                                        .append(" , Ldate = " + genQuote(Ldate))
					.append(" WHERE QUESTIONNO = " + genQuote(strQuestionNo));

			stmt = conn.createStatement();
			rv = stmt.executeUpdate(sqlQuery.toString());
			conn.commit();

			return rv;

		}
		catch (Exception e)
		{

			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoReResearchTran :: updateDate()" + e.getMessage());
			}


			System.out.println("GCoReResearchTran :: updateDate()" + e.getMessage());


			return -1;

		}
		finally
		{
			conn.close();
		}
	}

        public int deleteQ10(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String strComCode = dmProp.getString("COMCODE");
		String strQuestionNo  = dmProp.getString("questionno");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

             	int rv=0;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
                        StringBuffer SqlQuery = null;

			conn = GCmDbManager.getInstance().getConnection();

			stmt = conn.createStatement();
			conn.setAutoCommit(false);

                        StringBuffer sqlQuery = new StringBuffer()
					.append(" DELETE FROM TB_").append(strComCode).append("_Q10 ")
					.append(" WHERE QUESTIONNO = " + genQuote(strQuestionNo));

			stmt = conn.createStatement();
			rv = stmt.executeUpdate(sqlQuery.toString());
			conn.commit();

                        return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoReResearchTran::deleteQ10 : " + ignored.getMessage());
			}

	 		System.out.println(" GCoReResearchTran::deleteQ10 : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoReResearchTran::deleteQ10 : " + e.getMessage());
			}
			conn.close();
		}
	}

        public int deleteQ20(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String strComCode = dmProp.getString("COMCODE");
		String strQuestionNo  = dmProp.getString("questionno");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

             	int rv=0;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
                        StringBuffer SqlQuery = null;

			conn = GCmDbManager.getInstance().getConnection();

			stmt = conn.createStatement();
			conn.setAutoCommit(false);

                        StringBuffer sqlQuery = new StringBuffer()
					.append(" DELETE FROM TB_").append(strComCode).append("_Q20 ")
					.append(" WHERE QUESTIONNO = " + genQuote(strQuestionNo));

                        stmt = conn.createStatement();
			rv = stmt.executeUpdate(sqlQuery.toString());
			conn.commit();

                        return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoReResearchTran::deleteQ20 : " + ignored.getMessage());
			}

	 		System.out.println(" GCoReResearchTran::deleteQ20 : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoReResearchTran::deleteQ20 : " + e.getMessage());
			}
			conn.close();
		}
	}

        public int deleteQ30(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String strComCode = dmProp.getString("COMCODE");
		String strQuestionNo  = dmProp.getString("questionno");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

             	int rv=0;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
                        StringBuffer SqlQuery = null;

			conn = GCmDbManager.getInstance().getConnection();

			stmt = conn.createStatement();
			conn.setAutoCommit(false);

                        StringBuffer sqlQuery = new StringBuffer()
					.append(" DELETE FROM TB_").append(strComCode).append("_Q30 ")
					.append(" WHERE QUESTIONNO = " + genQuote(strQuestionNo));

			stmt = conn.createStatement();
			rv = stmt.executeUpdate(sqlQuery.toString());
			conn.commit();

                        return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoReResearchTran::deleteQ30 : " + ignored.getMessage());
			}

	 		System.out.println(" GCoReResearchTran::deleteQ30 : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoReResearchTran::deleteQ30 : " + e.getMessage());
			}
			conn.close();
		}
	}

        public int deleteQ11(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String strComCode = dmProp.getString("COMCODE");
		String strQuestionNo  = dmProp.getString("questionno");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

             	int rv=0;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
                        StringBuffer SqlQuery = null;

			conn = GCmDbManager.getInstance().getConnection();

			stmt = conn.createStatement();
			conn.setAutoCommit(false);

                        StringBuffer sqlQuery = new StringBuffer()
					.append(" DELETE FROM TB_").append(strComCode).append("_Q11 ")
					.append(" WHERE QUESTIONNO = " + genQuote(strQuestionNo));

			stmt = conn.createStatement();
			rv = stmt.executeUpdate(sqlQuery.toString());
			conn.commit();

                        return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoReResearchTran::deleteQ11 : " + ignored.getMessage());
			}

	 		System.out.println(" GCoReResearchTran::deleteQ11 : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoReResearchTran::deleteQ11 : " + e.getMessage());
			}
			conn.close();
		}
	}

        public int deleteQ12(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String strComCode = dmProp.getString("COMCODE");
		String strItemNo  = dmProp.getString("itemno");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

             	int rv=0;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
                        StringBuffer SqlQuery = null;

			conn = GCmDbManager.getInstance().getConnection();

			stmt = conn.createStatement();
			conn.setAutoCommit(false);

                        StringBuffer sqlQuery = new StringBuffer()
					.append(" DELETE FROM TB_").append(strComCode).append("_Q12 ")
					.append(" WHERE ITEMNO = " + genQuote(strItemNo));

			stmt = conn.createStatement();
			rv = stmt.executeUpdate(sqlQuery.toString());
			conn.commit();

                        return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoReResearchTran::deleteQ12 : " + ignored.getMessage());
			}

	 		System.out.println(" GCoReResearchTran::deleteQ12 : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoReResearchTran::deleteQ11 : " + e.getMessage());
			}
			conn.close();
		}
	}



        public String getMaxQuestionNo(String comcode,String strDbType)
        {
		GCmConnection conn = null;


		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                             sqlQuery
		        	.append(" SELECT DECODE(SUBSTR(MAX(QUESTIONNO),1,8),TO_CHAR(sysdate,'YYYYMMDD'),TO_CHAR(TO_NUMBER(MAX(QUESTIONNO))+1),null,TO_CHAR(sysdate,'YYYYMMDD')||'0001') as NO ")
                           	.append(" FROM TB_").append(comcode).append("_Q10 ")
                           	.append(" WHERE QUESTIONNO LIKE TO_CHAR(sysdate,'YYYYMMDD')||'%'");
                        }
                        else if ("mssql".equals(strDbType))
                             {
                                     sqlQuery
                                        .append(" SELECT (CASE SUBSTRING(MAX(QUESTIONNO),1,8) WHEN convert(char(08),getdate(),112) THEN CAST(SUBSTRING(MAX(QUESTIONNO),1,8) AS varchar(8)) + RIGHT('0000'+CAST(SUBSTRING(MAX(QUESTIONNO),9,4)+1 AS varchar(4)),4) ELSE convert(char(08),getdate(),112)+'0001' END) as NO ")
                                        .append(" FROM TB_").append(comcode).append("_Q10 ")
                                        .append(" WHERE QUESTIONNO LIKE convert(char(08),getdate(),112)+'%' ");
                             }


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
                	rs.next();

			return rs.getString("NO");

      		}
      		catch (Exception e)
      		{
 			System.out.println(" GCoReResearchTran::getMaxQuestionNo " + e.getMessage());
	 		return null;
      		}
      		finally
      		{
			conn.close();
      		}
    	}

        public String getMaxItemNo(String comcode,String strDbType)
        {
		GCmConnection conn = null;


		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                             sqlQuery
		        	.append(" SELECT DECODE(SUBSTR(MAX(ITEMNO),1,8),TO_CHAR(sysdate,'YYYYMMDD'),TO_CHAR(TO_NUMBER(MAX(ITEMNO))+1),null,TO_CHAR(sysdate,'YYYYMMDD')||'0001') as NO ")
                           	.append(" FROM TB_").append(comcode).append("_Q11 ")
                           	.append(" WHERE ITEMNO LIKE TO_CHAR(sysdate,'YYYYMMDD')||'%'");
                        }
                        else if ("mssql".equals(strDbType))
                             {
                                     sqlQuery
                                        .append(" SELECT (CASE SUBSTRING(MAX(ITEMNO),1,8) WHEN convert(char(08),getdate(),112) THEN CAST(SUBSTRING(MAX(ITEMNO),1,8) AS varchar(8)) + RIGHT('0000'+CAST(SUBSTRING(MAX(ITEMNO),9,4)+1 AS varchar(4)),4) ELSE convert(char(08),getdate(),112)+'0001' END) as NO ")
                                        .append(" FROM TB_").append(comcode).append("_Q11 ")
                                        .append(" WHERE ITEMNO LIKE convert(char(08),getdate(),112)+'%' ");
                             }


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
                	rs.next();

			return rs.getString("NO");

      		}
      		catch (Exception e)
      		{
 			System.out.println(" GCoReResearchTran::getMaxItemNo " + e.getMessage());
	 		return null;
      		}
      		finally
      		{
			conn.close();
      		}
    	}

        public String getMaxSubItemNo(String comcode,String strDbType)
        {
		GCmConnection conn = null;


		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                             sqlQuery
		        	.append(" SELECT DECODE(SUBSTR(MAX(SUBITEMNO),1,8),TO_CHAR(sysdate,'YYYYMMDD'),TO_CHAR(TO_NUMBER(MAX(SUBITEMNO))+1),null,TO_CHAR(sysdate,'YYYYMMDD')||'0001') as NO ")
                           	.append(" FROM TB_").append(comcode).append("_Q12 ")
                           	.append(" WHERE SUBITEMNO LIKE TO_CHAR(sysdate,'YYYYMMDD')||'%'");
                        }
                        else if ("mssql".equals(strDbType))
                             {
                                     sqlQuery
                                        .append(" SELECT (CASE SUBSTRING(MAX(SUBITEMNO),1,8) WHEN convert(char(08),getdate(),112) THEN CAST(SUBSTRING(MAX(SUBITEMNO),1,8) AS varchar(8)) + RIGHT('0000'+CAST(SUBSTRING(MAX(SUBITEMNO),9,4)+1 AS varchar(4)),4) ELSE convert(char(08),getdate(),112)+'0001' END) as NO ")
                                        .append(" FROM TB_").append(comcode).append("_Q12 ")
                                        .append(" WHERE SUBITEMNO LIKE convert(char(08),getdate(),112)+'%' ");
                             }


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
                	rs.next();

			return rs.getString("NO");

      		}
      		catch (Exception e)
      		{
 			System.out.println(" GCoReResearchTran::getMaxSubItemNo " + e.getMessage());
	 		return null;
      		}
      		finally
      		{
			conn.close();
      		}
    	}




}