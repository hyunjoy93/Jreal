package gplus.component.menu;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

/**
 * <PRE>
 * Filename		: GCoMeBoxsTran.java
 * Class		: gplus.component.pos.GCoMeBoxsTran
 * Fuction		: ���������� ������
 * Comment		:
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCoMeBoxsTran extends GCmTopComponent
{
       /**
        * <PRE>
        * �Խ�/����/����/����Ը�Ͽ� ��ϵǴ� �ű����� ����Ѵ�.
        * ��ϵǴ� �ű��Թ�ȣ�� getMaxNo�Լ��� ���Ͽ� �����Ǹ� �ش���+�Ϸù�ȣ������ �����ȴ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : current user id at session : �����
        *                      <LI> String Iconno : �����ܹ�ȣ : null
        *                      <LI> String Parentno : �����Թ�ȣ
        *                      <LI> String Boxclass : ������
        *                      <LI> String Execclass : ����������
        *                      <LI> String Boxtype : ������
        *                      <LI> String Boxname : ���̸�
        *                      <LI> String Baseflag : �⺻�Կ���
        *                      <LI> String Pubflag : �����Կ���
        *                      <LI> String Execflag : �����Կ���
        *                      <LI> String Userno : ������
        *                      <LI> String Regdate : �����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int insertBox(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String Iconno = dmProp.getString("Iconno");
		String Parentno = dmProp.getString("Parentno");
		String Boxclass = dmProp.getString("Boxclass");
		String Execclass = dmProp.getString("Execclass");
		String Boxtype = dmProp.getString("Boxtype");
		String Boxname = dmProp.getString("Boxname");
		String Baseflag = dmProp.getString("Baseflag");
		String Pubflag = dmProp.getString("Pubflag");
		String Execflag = dmProp.getString("Execflag");
		String Userno = dmProp.getString("Userno");
		String Regdate = dmProp.getString("Regdate");

                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();
                        String Boxno = getMaxNo(COMCODE,strDbType);
                        dmProp.setProperty("Boxno",Boxno);

			StringBuffer SqlQuery = new StringBuffer()
					.append(" INSERT INTO TB_"+COMCODE+"_M10 (BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,BOXTYPE,BOXNAME,BASEFLAG,PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE) ")
                                        .append(" VALUES("+genQuote(Boxno)+","+genQuote(Iconno)+","+genQuote(Parentno)+","+genQuote(Boxclass)+",")
                                        .append("        "+genQuote(Execclass)+","+genQuote(Boxtype)+","+genQuote(Boxname)+","+genQuote(Baseflag)+",")
                                        .append("        "+genQuote(Pubflag)+","+genQuote(Execflag)+","+genQuote(Userno)+","+genQuote(USERID)+","+genQuote(Regdate)+") ");
//System.out.println("insertBox = " + SqlQuery.toString());
			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoMeBoxsTran::insertBox : " + ignored.getMessage());
			}

	 		System.out.println(" GCoMeBoxsTran::insertBox : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoMeBoxsTran::insertBox : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * �Խ�/����/����/����Ը�Ͽ� ��ϵǴ� �ű����� ����Ѵ�.
        * ��ϵǴ� �ű��Թ�ȣ�� getMaxNo�Լ��� ���Ͽ� �����Ǹ� �ش���+�Ϸù�ȣ������ �����ȴ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : current user id at session : �����
        *                      <LI> String Iconno : �����ܹ�ȣ : null
        *                      <LI> String Parentno : �����Թ�ȣ
        *                      <LI> String Boxclass : ������
        *                      <LI> String Execclass : ����������
        *                      <LI> String Boxtype : ������
        *                      <LI> String Boxname : ���̸�
        *                      <LI> String Baseflag : �⺻�Կ���
        *                      <LI> String Pubflag : �����Կ���
        *                      <LI> String Execflag : �����Կ���
        *                      <LI> String Userno : ������
        *                      <LI> String Regdate : �����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int insertNewBox(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String Mode = dmProp.getString("Mode");
		String Boardname = dmProp.getString("Boardname");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();
		String Parentno = dmProp.getString("Parentno");
                String ChkBox = dmProp.getString("ChkBox");

                String boxtype = "";


		int rv;

		GCmConnection conn = null;
		Statement stmt = null;
                StringBuffer SqlQuery = null;

		try
		{
                        String Regdate = gplus.commlib.util.GCmDateFcts.dateToStr(new java.util.Date(),2);
			conn = GCmDbManager.getInstance().getConnection();
			stmt = conn.createStatement();
			conn.setAutoCommit(true);

                        if (Mode.equals("newtab"))
                        {
                             Parentno = dmProp.getString("Boxno");

                        }
                    //System.out.println("Mode1 = " + Mode);
                   // System.out.println("Parentno1 = " + Parentno);


                         if(ChkBox == "0"){
                                boxtype = "1";
                         }else{
                             if(Parentno.equals("000000000000")){
                                   boxtype = "1";
                             }else{
                                   boxtype = "3";
                             }
                         }

//System.out.println("boxtype11 = " + boxtype);

                        String Boxno = getMaxNo(COMCODE,strDbType);
                        dmProp.setProperty("Boxno",Boxno);

			SqlQuery = new StringBuffer()
				    .append(" INSERT INTO TB_"+COMCODE+"_M10 (BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,BOXTYPE,BOXNAME,BASEFLAG,PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE) ")
                                    .append(" VALUES("+genQuote(Boxno)+",'',"+genQuote(Parentno)+",'1','1',"+genQuote(boxtype)+","+genQuote(dmProp.getString("Boxname"))+",'1',")
                                    .append("        '0',"+genQuote(Mode.equals("newtab")?"0":"1")+",'',"+genQuote(USERID)+","+genQuote(Regdate)+") ");

		        rv = stmt.executeUpdate(SqlQuery.toString());
                        if( rv <= 0 ) throw new Exception(" During insertNewBox error !!!");


                        if (Mode.equals("newtab"))
                        {
 			       SqlQuery = new StringBuffer()
				           .append(" INSERT INTO TB_"+COMCODE+"_M20 (BOXNO,USERID,DOCREAD,DOCWRITE,DOCDEL,DOCDELADM,FLDMAKE,FLDDEL) ")
				           .append("          SELECT "+genQuote(Boxno)+",USERID,'1','1','1','1','1','1' ")
                           .append("          FROM TB_COMM_Z20 ")
                           .append("          WHERE COMCODE = "+genQuote(COMCODE));

		             rv = stmt.executeUpdate(SqlQuery.toString());
                             if( rv <= 0 ) throw new Exception(" During insertNewBox error !!!");
                        }

                        if (Mode.equals("newbox") && !Boardname.equals(""))
                        {
                             String newBoxno = getMaxNo(COMCODE,strDbType);
                    //System.out.println("Mode = " + Mode);
                    //System.out.println("Parentno = " + Boxno);
                              if(ChkBox == "0"){
                                    boxtype = "1";
                              }else{
                                    if(Boxno.equals("000000000000")){
                                        boxtype = "1";
                                    }else{
                                        boxtype = "3";
                                    }
        	              }
                     // System.out.println("boxtype = " + boxtype);
 			     SqlQuery = new StringBuffer()
				        .append(" INSERT INTO TB_"+COMCODE+"_M10 (BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,BOXTYPE,BOXNAME,BASEFLAG,PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE) ")
                                        .append(" VALUES("+genQuote(newBoxno)+",'',"+genQuote(Boxno)+",'1','1',"+genQuote(boxtype)+","+genQuote(dmProp.getString("Boardname"))+",'1',")
                                        .append("        '0',"+genQuote(Mode.equals("newtab")?"0":"1")+",'',"+genQuote(USERID)+","+genQuote(Regdate)+") ");

		             rv = stmt.executeUpdate(SqlQuery.toString());
                             if( rv <= 0 ) throw new Exception(" During insertNewBox error !!!");

 			      SqlQuery = new StringBuffer()
				           .append(" INSERT INTO TB_"+COMCODE+"_M20 (BOXNO,USERID,DOCREAD,DOCWRITE,DOCDEL,DOCDELADM,FLDMAKE,FLDDEL) ")
				           .append("          SELECT "+genQuote(newBoxno)+",USERID,'1','1','1','1','1','1' ")
                           .append("          FROM TB_COMM_Z20 ")
                           .append("          WHERE COMCODE = "+genQuote(COMCODE));

		             rv = stmt.executeUpdate(SqlQuery.toString());
                             if( rv <= 0 ) throw new Exception(" During insertNewBox error !!!");

                        }

			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoMeBoxsTran::insertNewBox : " + ignored.getMessage());
			}

	 		System.out.println(" GCoMeBoxsTran::insertNewBox : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoMeBoxsTran::insertNewBox : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * �Խ�/����/����/����Ը�Ͽ� ��ϵ� ���̸��� �Թ�ȣ�� ���Ͽ� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Boxno : �Թ�ȣ
        *                      <LI> String Boxname : ���̸�
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int updateBoxName(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Boxno = dmProp.getString("Boxno");
		String Boxname = dmProp.getString("Boxname");
                String ChkBox = dmProp.getString("ChkBox");

                String boxtype = "";

                if(ChkBox == "0"){
                      boxtype = "1";
                }else{
                      if(Boxno.equals("000000000000")){
                             boxtype = "1";
                      }else{
                             boxtype = "3";
                      }
        	 }

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" UPDATE TB_"+COMCODE+"_M10 ")
                                        .append(" SET BOXNAME = "+genQuote(Boxname) + ", BOXTYPE = "+genQuote(boxtype))
                                        .append(" WHERE BOXNO = "+genQuote(Boxno));


			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoMeBoxsTran::updateBoxName : " + ignored.getMessage());
			}

	 		System.out.println(" GCoMeBoxsTran::updateBoxName : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoMeBoxsTran::updateBoxName : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� �Թ�ȣ�� ���Ͽ� �Խù� ��Ͽ� �����ϴ� ��������� �˻��ؼ� �ش��ϴ� ������ȣ�� ���� ������
        * ������Ͽ��� �ϰ� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Boxno : �Թ�ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteMasterDoc(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Boxno = dmProp.getString("Boxno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" DELETE FROM TB_"+COMCODE+"_L10 ")
                                        .append(" WHERE DOCNO IN ( SELECT DOCNO ")
                                        .append("                  FROM TB_"+COMCODE+"_A01 ")
                                        .append("                  WHERE BOXNO = "+genQuote(Boxno)+" )");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoMeBoxsTran::deleteMasterDoc : " + ignored.getMessage());
			}

	 		System.out.println(" GCoMeBoxsTran::deleteMasterDoc : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoMeBoxsTran::deleteMasterDoc : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� �Թ�ȣ�� ���Ͽ� �Խù� ��Ͽ� �����ϴ� ��������� �˻��ؼ� �ش��ϴ� ������ȣ�� ���� ������
        * �����󼼸�Ͽ��� �ϰ� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Boxno : �Թ�ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteDocDetail(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Boxno = dmProp.getString("Boxno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" DELETE FROM TB_"+COMCODE+"_L11 ")
                                        .append(" WHERE DOCNO IN ( SELECT DOCNO ")
                                        .append("                  FROM TB_"+COMCODE+"_A01 ")
                                        .append("                  WHERE BOXNO = "+genQuote(Boxno)+" )");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoMeBoxsTran::deleteDocDetail : " + ignored.getMessage());
			}

	 		System.out.println(" GCoMeBoxsTran::deleteDocDetail : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoMeBoxsTran::deleteDocDetail : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� �Թ�ȣ�� ���Ͽ� �ش��Թ�ȣ�� ������ �Խù� ����� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Boxno : �Թ�ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteBoxNoti(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Boxno = dmProp.getString("Boxno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" DELETE FROM TB_"+COMCODE+"_A01 ")
                                        .append(" WHERE BOXNO = "+genQuote(Boxno));

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoMeBoxsTran::deleteBoxNoti : " + ignored.getMessage());
			}

	 		System.out.println(" GCoMeBoxsTran::deleteBoxNoti : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoMeBoxsTran::deleteBoxNoti : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� �Թ�ȣ�� ���Ͽ� �ش� �Թ�ȣ�� ������ ������ �������� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Boxno : �Թ�ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteBoxRight(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Boxno = dmProp.getString("Boxno");
		String Userid = dmProp.getString("Userid");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" DELETE FROM TB_"+COMCODE+"_M20 ")
                    .append(" WHERE BOXNO = "+genQuote(Boxno)+" AND USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userid,",","','")+"') ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoMeBoxsTran::deleteBoxRight : " + ignored.getMessage());
			}

	 		System.out.println(" GCoMeBoxsTran::deleteBoxRight : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoMeBoxsTran::deleteBoxRight : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� �Թ�ȣ�� ���Ͽ� �ش��Թ�ȣ�� ������ �Խ�/����/����/����� ����� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Boxno : �Թ�ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteBox(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Boxno = dmProp.getString("Boxno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" DELETE FROM TB_"+COMCODE+"_M10 ")
                                        .append(" WHERE BOXNO = "+genQuote(Boxno));

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoMeBoxsTran::deleteBox : " + ignored.getMessage());
			}

	 		System.out.println(" GCoMeBoxsTran::deleteBox : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoMeBoxsTran::deleteBox : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * �Խ�/����/����/����Ը�Ͽ� ��ϵ� ���� �����Ѵ�. ���޵� �Թ�ȣ�� ���� �������� ���θ� getChildBox�� ���Ͽ� ���� �ް�
        * ������ ����� deleteBoardBox�� Boxno�� ������ ���ȣ�� �Ѵ�. ���̻� �������� ������ deleteMasterDoc,deleteDocDetail
        * deleteBoxNoti,deleteBoxRight,deleteBox�� �����Ͽ� DB�� �Կ� ������ ������ �����ϰ�, �������� ���� ȭ�ϵ��� ����������
        * �����ϰ� �������� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Boxno : �Թ�ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteBoardBox(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Boxno = dmProp.getString("Boxno");
                String strDocroot = cp.getProperty("gplus.system.docroot");

		int rv=0;

		GCmConnection conn = null;
		Statement stmt = null;
 	        GCoMeBoxs box = new GCoMeBoxs();
		StringBuffer SqlQuery = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			stmt = conn.createStatement();
			conn.setAutoCommit(false);

                        GCmResultSet rsBox = box.getChildBox(cp, dmProp, msgInfo);

                        while(rsBox.next())
                        {
                              dmProp.setProperty("Boxno",rsBox.getString("BOXNO"));
                              deleteBoardBox(cp, dmProp, msgInfo);
                        }

			SqlQuery = new StringBuffer()
			            .append(" DELETE FROM TB_"+COMCODE+"_L10 ")
                                    .append(" WHERE DOCNO IN ( SELECT DOCNO ")
                                    .append("                  FROM TB_"+COMCODE+"_A01 ")
                                    .append("                  WHERE BOXNO = "+genQuote(Boxno)+" )");

                        rv = stmt.executeUpdate(SqlQuery.toString());
//                        if( rv <= 0 ) throw new Exception(" During deleteBoardBox error !!!");

			SqlQuery = new StringBuffer()
				    .append(" DELETE FROM TB_"+COMCODE+"_L11 ")
                                    .append(" WHERE DOCNO IN ( SELECT DOCNO ")
                                    .append("                  FROM TB_"+COMCODE+"_A01 ")
                                    .append("                  WHERE BOXNO = "+genQuote(Boxno)+" )");

                        rv = stmt.executeUpdate(SqlQuery.toString());
//                        if( rv <= 0 ) throw new Exception(" During deleteBoardBox error !!!");

			SqlQuery = new StringBuffer()
				    .append(" DELETE FROM TB_"+COMCODE+"_A01 ")
                                    .append(" WHERE BOXNO = "+genQuote(Boxno));

                        rv = stmt.executeUpdate(SqlQuery.toString());
//                        if( rv <= 0 ) throw new Exception(" During deleteBoardBox error !!!");

			SqlQuery = new StringBuffer()
				    .append(" DELETE FROM TB_"+COMCODE+"_M20 ")
                                    .append(" WHERE BOXNO = "+genQuote(Boxno));

                        rv = stmt.executeUpdate(SqlQuery.toString());
//                        if( rv <= 0 ) throw new Exception(" During deleteBoardBox error !!!");

			SqlQuery = new StringBuffer()
				    .append(" DELETE FROM TB_"+COMCODE+"_M10 ")
                                    .append(" WHERE BOXNO = "+genQuote(Boxno));

                        rv = stmt.executeUpdate(SqlQuery.toString());
//                        if( rv <= 0 ) throw new Exception(" During deleteBoardBox error !!!");

                        gplus.commlib.util.GCmFcts.setDelete(strDocroot + "/DATA/" + COMCODE + "/BOARD/" + Boxno);

                        java.io.File oFile = new java.io.File(strDocroot + "/DATA/" + COMCODE + "/BOARD/" + Boxno);
                        if (oFile.isDirectory())
                        {
                             oFile.delete();
                        }

		        conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoMeBoxsTran::deleteBoardBox : " + ignored.getMessage());
			}

	 		System.out.println(" GCoMeBoxsTran::deleteBoardBox : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoMeBoxsTran::deleteBoardBox : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * �������� �űԵ���Ѵ�. insertBox�� �����ϰ�, ���޵� Boxno�� ������ insertFolder,�� insertNewDocBoxRight��
        * �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Boxname : ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int processDocBoxMake(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;
                StringBuffer SqlQuery = null;

		try
		{
                        String Regdate = gplus.commlib.util.GCmDateFcts.dateToStr(new java.util.Date(),2);
			conn = GCmDbManager.getInstance().getConnection();

			stmt = conn.createStatement();
			conn.setAutoCommit(false);

                        String Boxno = getMaxNo(COMCODE,strDbType);
                        dmProp.setProperty("Boxno",Boxno);

			SqlQuery = new StringBuffer()
				    .append(" INSERT INTO TB_"+COMCODE+"_M10 (BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,BOXTYPE,BOXNAME,BASEFLAG,PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE) ")
                                    .append(" VALUES("+genQuote(Boxno)+",'','000000000000','2','1','1',"+genQuote(dmProp.getString("Boxname"))+",'1',")
                                    .append("        '0','0','',"+genQuote(USERID)+","+genQuote(Regdate)+") ");

		        rv = stmt.executeUpdate(SqlQuery.toString());
                        if( rv <= 0 ) throw new Exception(" During processDocBoxMake error !!!");


                        String Folderno = getMaxFolderNo(COMCODE,strDbType);
			SqlQuery = new StringBuffer()
				    .append(" INSERT INTO TB_"+COMCODE+"_B10 (FLDNO,BOXNO,DOCNO,PARENTNO,FLDNAME,REGUSER,REGDATE,TRASHFLAG,COMMENTS,REFNO) ")
				    .append(" VALUES ("+genQuote(Folderno)+","+genQuote(Boxno)+",'','000000000000',"+genQuote(dmProp.getString("Boxname"))+",'',")
                                    .append("         "+genQuote(Regdate)+",'','','')");

		        rv = stmt.executeUpdate(SqlQuery.toString());
                        if( rv <= 0 ) throw new Exception(" During processDocBoxMake error !!!");

			SqlQuery = new StringBuffer()
				    .append(" INSERT INTO TB_"+COMCODE+"_M20 (BOXNO,USERID,DOCREAD,DOCWRITE,DOCDEL,DOCDELADM,FLDMAKE,FLDDEL) ")
				    .append("          SELECT "+genQuote(Boxno)+",USERID,'1','1','1','1','1','1' ")
                                    .append("          FROM TB_COMM_Z20 ")
                                    .append("          WHERE COMCODE = "+genQuote(COMCODE));

		        rv = stmt.executeUpdate(SqlQuery.toString());
                        if( rv <= 0 ) throw new Exception(" During processDocBoxMake error !!!");

			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoMeBoxsTran::processDocBoxMake : " + ignored.getMessage());
			}

	 		System.out.println(" GCoMeBoxsTran::processDocBoxMake : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoMeBoxsTran::processDocBoxMake : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * �Խ�/����/����/����Ը�Ͽ� ��ϵǴ� �ű����� ��Ͻ� �ʿ��� �ű��Թ�ȣ�� �����ϴ� �����Լ��̸�,
        * �����Ǵ� �Թ�ȣ�� �ش���+�Ϸù�ȣ������ �����ȴ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String strDbType : gplus db type
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return String : �ű��Թ�ȣ
        */
    	private String getMaxNo(String comcode,String strDbType)
        {
		GCmConnection conn = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                             sqlQuery
		        	.append(" SELECT DECODE(SUBSTR(MAX(BOXNO),1,8),TO_CHAR(sysdate,'YYYYMMDD'),TO_CHAR(TO_NUMBER(MAX(BOXNO))+1),null,TO_CHAR(sysdate,'YYYYMMDD')||'0001') as NO ")
                           	.append(" FROM TB_").append(comcode).append("_M10 ")
                           	.append(" WHERE BOXNO LIKE TO_CHAR(sysdate,'YYYYMMDD')||'%'");
                        }
                        else if ("mssql".equals(strDbType))
                             {
                                     sqlQuery
                                        .append(" SELECT (CASE SUBSTRING(MAX(BOXNO),1,8) WHEN convert(char(08),getdate(),112) THEN CAST(SUBSTRING(MAX(BOXNO),1,8) AS varchar(8)) + RIGHT('0000'+CAST(SUBSTRING(MAX(BOXNO),9,4)+1 AS varchar(4)),4) ELSE convert(char(08),getdate(),112)+'0001' END) as NO ")
                                        .append(" FROM TB_").append(comcode).append("_M10 ")
                                        .append(" WHERE BOXNO LIKE convert(char(08),getdate(),112)+'%' ");
                             }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
                	rs.next();

			return rs.getString("NO");

      		}
      		catch (Exception e)
      		{
 			System.out.println(" GCoMeBoxsTran::getMaxNo " + e.getMessage());
	 		return null;
      		}
      		finally
      		{
			conn.close();
      		}
    	}


       /**
        * <PRE>
        * �����Կ� ��ϵǴ� �ű� �������� ��Ͻ� �ʿ��� �ű� ������ȣ�� �����ϴ� �����Լ��̸�,
        * �����Ǵ� ������ȣ�� �ش���+�Ϸù�ȣ������ �����ȴ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String strDbType : gplus db type
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return String : �ű� �����Թ�ȣ
        */
    	private String getMaxFolderNo(String comcode,String strDbType) {

	    GCmConnection conn = null;

	    try
	    {
		    conn = GCmDbManager.getInstance().getConnection();

		    StringBuffer sqlQuery = new StringBuffer();

                    if ("oracle".equals(strDbType))
                    {
		    	sqlQuery
		           .append(" SELECT DECODE(SUBSTR(MAX(FLDNO),1,8),TO_CHAR(sysdate,'YYYYMMDD'),TO_CHAR(TO_NUMBER(MAX(FLDNO))+1),null,TO_CHAR(sysdate,'YYYYMMDD')||'0001') as NO ")
                           .append(" FROM TB_").append(comcode).append("_B10 ")
                           .append(" WHERE FLDNO LIKE TO_CHAR(sysdate,'YYYYMMDD')||'%'");
                    }
                    else if ("mssql".equals(strDbType))
                         {
                                sqlQuery
                                   .append(" SELECT (CASE SUBSTRING(MAX(FLDNO),1,8) WHEN convert(char(08),getdate(),112) THEN CAST(SUBSTRING(MAX(FLDNO),1,8) AS varchar(8)) + RIGHT('0000'+CAST(SUBSTRING(MAX(FLDNO),9,4)+1 AS varchar(4)),4) ELSE convert(char(08),getdate(),112)+'0001' END) as NO ")
                                   .append(" FROM TB_").append(comcode).append("_B10 ")
                                   .append(" WHERE FLDNO LIKE convert(char(08),getdate(),112)+'%' ");
                         }

    		    GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
                    rs.next();

		    return rs.getString("NO");

            }
            catch (Exception e)
            {
 		  System.out.println(" GCoMeBoxsTran::getMaxFolderNo " + e.getMessage());
	 	  return null;
            }
            finally
            {
		  conn.close();
            }
      }
}