package gplus.component.wmail;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

/**
 * <PRE>
 * Filename	: GCoWmMailAccountTran.java
 * Class	: gplus.component.draft.GCoWmMailAccountTran
 * Fuction	:
 * Comment	:
 * History  : 2/16/2002, ������, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCoWmMailAccountTran extends GCmTopComponent
{


	/**
	 * <PRE>
	 *  ���ϰ��� ����
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE : ȸ���ڵ�	<BR>
	 *				<LI> String USERID      : �����ID  <BR>
	 *				<LI> String EMAIL       : �̸����ּ�  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  boolean
	 */
	public boolean deleteMailAcct(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strUserId   = dmProp.getString("USERID");
		String strEmail   = dmProp.getString("EMAIL");




		try
		{
			conn = GCmDbManager.getInstance().getConnection();


			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
							.append(" DELETE FROM TB_").append(strComCode).append("_C30 ")
							.append(" WHERE USERID = " + genQuote(strUserId))
							.append(" AND EMAIL = " + genQuote(strEmail));


			conn.executeUpdate(sqlQuery.toString());

			conn.commit();

			return true;

		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoWmMailAccountTran :: deleteMailAcct" + ignored.getMessage());
			}


			System.out.println("GCoWmMailAccountTran  :: deleteMailAdcct" + e.getMessage());

			return false;

		}
		finally
		{
			conn.close();
		}
	}



	/**
	 * <PRE>
	 *  ���ϰ��� ����
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE  : ȸ���ڵ�	<BR>
	 *				<LI> String USERID       : �����ID  <BR>
	 *				<LI> String EMAIL        : �̸����ּ�  <BR>
	 *				<LI> String ACCTNAME : �����̸�	<BR>
	 *				<LI> String SMTPSVR    : �����¼����ּ�  <BR>
	 *				<LI> String SMTPTYPE   : �����¼�������  <BR>
	 *				<LI> String SMTPID        : �����¼�������	<BR>
	 *				<LI> String SMTPPWD    : �����¼�����ȣ  <BR>
	 *				<LI> String SNDRNAME  : �����»��  <BR>
	 *				<LI> String POP3SVR     : �޴¼����ּ�	<BR>
	 *				<LI> String POP3TYPE    : �޴¼�������  <BR>
	 *				<LI> String POP3ID        : �޴¼�������  <BR>
	 *				<LI> String POP3PWD    : �޴¼�����ȣ	<BR>
	 *				<LI> String DEFLT         : �⺻��������  <BR>
	 *				<LI> String SYSFLAG     : �ý��۰����������  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  boolean
	 */

	public boolean insertMailAcct(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strUserId   = dmProp.getString("USERID");
		String strEmail   = dmProp.getString("EMAIL");
		String strAcctName = dmProp.getString("ACCTNAME");
		String strSmtpSvr   = dmProp.getString("SMTPSVR");
		String strSmtpType = dmProp.getString("SMTPTYPE");
		String strSmtpId   = dmProp.getString("SMTPID");
		String strSmtpPwd   = dmProp.getString("SMTPPWD");
		String strSndrName  = dmProp.getString("SNDRNAME");
		String strPop3Svr   = dmProp.getString("POP3SVR");
		String strPop3Type  = dmProp.getString("POP3TYPE");
		String strPop3Id   = dmProp.getString("POP3ID");
		String strPop3Pwd   = dmProp.getString("POP3PWD");
		String strDeflt   = dmProp.getString("DEFLT");
		String strSysFlag   = dmProp.getString("SYSFLAG");



		try
		{
			conn = GCmDbManager.getInstance().getConnection();


			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
							.append(" INSERT INTO TB_").append(strComCode).append("_C30 ")
							.append(" USERID, EMAIL, ACCTNAME, SMTPSVR, SMTPTYPE, SMTPID, SMTPPWD, SNDRNAME, ")
							.append(" POP3SVR, POP3TYPE, POP3ID, POP3PWD, DEFLT, SYSFLAG, DELFLAG) VALUES (")
							.append( genQuote(strUserId)).append(" , ")
							.append( genQuote(strEmail)).append(" , ")
							.append( genQuote(strAcctName)).append(" , ")
							.append( genQuote(strSmtpSvr)).append(" , ")
							.append( genQuote(strSmtpType)).append(" , ")
							.append( genQuote(strSmtpId)).append(" , ")
							.append( genQuote(strSmtpPwd)).append(" , ")
							.append( genQuote(strSndrName)).append(" , ")
							.append( genQuote(strPop3Svr)).append(" , ")
							.append( genQuote(strPop3Type)).append(" , ")
							.append( genQuote(strPop3Id)).append(" , ")
							.append( genQuote(strPop3Pwd)).append(" , ")
							.append( genQuote(strDeflt)).append(" , ")
							.append( genQuote(strSysFlag)).append(" ) ");

			conn.executeUpdate(sqlQuery.toString());

			conn.commit();

			return true;

		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoWmMailAccountTran :: insertMailAcct" + ignored.getMessage());
			}


			System.out.println("GCoWmMailAccountTran :: insertMailAcct" + e.getMessage());

			return false;

		}
		finally
		{
			conn.close();
		}
	}







	/**
	 * <PRE>
	 *  �⺻���� ����
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE : ȸ���ڵ�	<BR>
	 *				<LI> String USERID      : �����ID  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  boolean
	 */

	public boolean updateMailDeflt(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strUserId   = dmProp.getString("USERID");



		try
		{
			conn = GCmDbManager.getInstance().getConnection();


			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
							.append(" UPDATE TB_").append(strComCode).append("_C30 ")
							.append(" SET DEFLT = " + genQuote("1"))
							.append(" AND USERID = " + genQuote(strUserId));


			conn.executeUpdate(sqlQuery.toString());

			conn.commit();

			return true;

		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoWmMailAccountTran :: updateMailDeflt" + ignored.getMessage());
			}


			System.out.println("GCoWmMailAccountTran :: updateMailDeflt" +  e.getMessage());

			return false;

		}
		finally
		{
			conn.close();
		}
	}




	/**
	 * <PRE>
	 *  ���� ���� üũ
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE : ȸ���ڵ�	<BR>
	 *				<LI> String EXECCLASS   : ������  <BR>
	 *				<LI> String MAILNO          : ���Ϲ�ȣ	<BR>
	 *				<LI> String REGMAILNO    : ���θ��Ϲ�ȣ  <BR>
	 *				<LI> String MAILTYPE       : ��������	<BR>
	 *				<LI> String RCVRID           : ������  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  boolean
	 */
	public boolean readMail(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strExecClass  = dmProp.getString("EXECCLASS");
		String strMailNo = dmProp.getString("MAILNO");
		String strRegMailNo  = dmProp.getString("REGMAILNO");
		String strMailType = dmProp.getString("MAILTYPE");
		String strRcvrId  = dmProp.getString("RCVRID");



		try
		{
			conn = GCmDbManager.getInstance().getConnection();


			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
							.append(" UPDATE TB_").append(strComCode).append("_C20 ")
							.append(" SET READFLAG = " + genQuote("0"))
							.append(" WHERE REGMAILNO = " + genQuote(strRegMailNo));


			conn.executeUpdate(sqlQuery.toString());


			if (GCmFcts.nvl(strExecClass,"").equals(GCmConstDef.EXECCLASS_MAIL_INBOX))
			{


				String strReadDate = GCmDateFcts.dateToStr(new java.util.Date(),2);

				StringBuffer sqlQuery2 = new StringBuffer()
								.append(" UPDATE TB_").append(strComCode).append("_C11 ")
								.append(" SET READFLAG = " + genQuote("0"))
								.append(" , READDATE = " + genQuote(strReadDate))
								.append(" WHERE MAILNO = " + genQuote(strMailNo))
								.append(" AND RCVRID = " + genQuote(strRcvrId));


				conn.executeUpdate(sqlQuery2.toString());

			}

				conn.commit();

				return true;

		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoWmMailAccountTran :: updateMailDeflt" + ignored.getMessage());
			}


			System.out.println("GCoWmMailAccountTran :: updateMailDeflt" + e.getMessage());

			return false;


		}
		finally
		{
			conn.close();
		}
	}



	/**
	 * <PRE>
	 *  ���ϰ�������
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE : ȸ���ڵ�	<BR>
	 *				<LI> String USERID      : �����ID	<BR>
	 *				<LI> String OldEmail     : ���ϰ��� <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  int
	 */
   	public int deleteEmailAcct(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String OldEmail = dmProp.getString("OldEmail");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" DELETE FROM TB_").append(COMCODE).append("_C30 ")
					.append(" WHERE USERID = "+genQuote(USERID)+" AND EMAIL = "+genQuote(OldEmail));

			stmt = conn.createStatement();
			conn.setAutoCommit(false);

			rv = stmt.executeUpdate(SqlQuery.toString());

			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoWmMailAccountTran::deleteEmailAcct : " + ignored.getMessage());
			}

	 		System.out.println(" GCoWmMailAccountTran::deleteEmailAcct : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoWmMailAccountTran::deleteEmailAcct : " + e.getMessage());
			}
			conn.close();
		}
	}


	/**
	 * <PRE>
	 *  ���ϰ����Է�
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE : ȸ���ڵ�	<BR>
	 *				<LI> String USERID      : �����ID	<BR>
	 *				<LI> String OldEmail     : ���ϰ��� <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  int
	 */
	public int insertEmailAcct(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
                GEmTB_C30 tbc30 = (GEmTB_C30)dmProp.getObject("tbc30");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
			     .append(" INSERT INTO TB_").append(COMCODE).append("_C30 (USERID,EMAIL,ACCTNAME,")
                             .append(" SMTPSVR,SMTPTYPE,SMTPID,SMTPPWD,SNDRNAME,POP3SVR,POP3TYPE,POP3ID,POP3PWD,DEFLT,SYSFLAG,DELFLAG) ")
                             .append(" VALUES ("+genQuote(tbc30.getStrUserId())+","+genQuote(tbc30.getStrEmail())+","+genQuote(tbc30.getStrAcctName())+",")
                             .append("         "+genQuote(tbc30.getStrSmtpSvr())+","+genQuote(tbc30.getStrSmtpType())+","+genQuote(tbc30.getStrSmtpId())+",")
                             .append("         "+genQuote(tbc30.getStrSmtpPwd())+","+genQuote(tbc30.getStrSndrName())+","+genQuote(tbc30.getStrPop3Svr())+",")
                             .append("         "+genQuote(tbc30.getStrPop3Type())+","+genQuote(tbc30.getStrPop3Id())+","+genQuote(tbc30.getStrPop3Pwd())+",")
                             .append("         "+genQuote(tbc30.getStrDeflt())+","+genQuote(tbc30.getStrSysFlag())+","+genQuote(tbc30.getStrDelFlag())+")");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			  rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoWmMailAccountTran::insertEmailAcct : " + ignored.getMessage());
			}

	 		System.out.println(" GCoWmMailAccountTran::insertEmailAcct : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoWmMailAccountTran::insertEmailAcct : " + e.getMessage());
			}
			conn.close();
		}
	}

	/**
	 * <PRE>
	 *  �������Ϸ� �ϰ�ó��
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE : ȸ���ڵ�	<BR>
	 *				<LI> String BOXNO      :�Թ�ȣ 	<BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  boolean
	 */
public boolean setReadFlag(GCmProperties prop, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String BOXNO = dmProp.getString("BOXNO");
				try
				{
			conn = GCmDbManager.getInstance().getConnection();


			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
							.append(" UPDATE TB_").append(COMCODE).append("_C20 ")
							.append(" SET READFLAG = '0'")
							.append(" WHERE BOXNO = "+genQuote(BOXNO));

			conn.executeUpdate(sqlQuery.toString());

			conn.commit();

			return true;

		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoWmMailAccountTran :: setReadFlag" + ignored.getMessage());
			}


			System.out.println("GCoWmMailAccountTran :: setReadFlag" + e.getMessage());

			return false;

		}
		finally
		{
			conn.close();
		}
	}

	}
