package gplus.component.wmail;


import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

/**
 * <PRE>
 * Filename	: GCoWmMail.java
 * Class		    : gplus.component.wmail.GCoWmMail
 * Fuction	    :
 * Comment	:
 * History       : 2/6/2002, ������, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCoWmMail extends GCmTopComponent
{




	/**
	 * <PRE>
	 *  ����ī��Ʈ
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE : ȸ���ڵ�  <BR>
	 *				<LI> String USERID      : �����ID  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return GCmReSultSet		���ϼ�
	 */
	public GCmResultSet getMailCount(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");

		try
		{

			conn = GCmDbManager.getInstance().getConnection();

			//EXECCLASS_MAIL_INBOX = "1" ���� ����
			StringBuffer sqlQuery = new StringBuffer()
			   .append(" select  count( yy.boxno )     ")
               .append(" from tb_").append(COMCODE).append("_c10 xx, (select cc.mailno mailno, cc.boxno boxno, cc.regmailno regmailno, cc.execclass execclass,cc.readflag ")
			   .append("     from (select aa.mailno, aa.boxno, aa.regmailno, bb.execclass, aa.readflag	")
	           .append("           from tb_").append(COMCODE).append("_c20 aa, tb_").append(COMCODE).append("_m10 bb	")
			   .append("           where aa.boxno = bb.boxno and boxclass='3' and execclass="+genQuote(gplus.commlib.comm.GCmConstDef.EXECCLASS_MAIL_INBOX)+" and userid = "+genQuote(USERID)+" and readflag='1' ")
	           .append("                                     ) cc) yy ")
			   .append(" where xx.mailno = yy.mailno ");

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println("GCoWmMail :: getMailCount " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}

	}




	/**
	 * <PRE>
	 *  ���Ͼ˶� ī��Ʈ
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE : ȸ���ڵ�  <BR>
	 *				<LI> String USERID      : �����ID  <BR>
	 *				<LI> String timelogin     : �α��νð�  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return GCmReSultSet		���Ͼ˶���
	 */
	public GCmResultSet getMailAlarmCount(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
        String timelogin = dmProp.getString("timelogin");

		try
		{

			conn = GCmDbManager.getInstance().getConnection();


			//EXECCLASS_MAIL_INBOX = "1" ���� ����
			StringBuffer sqlQuery = new StringBuffer()
                        .append(" select   yy.boxno     ")
                        .append(" from tb_").append(COMCODE).append("_c10 xx, ")
                        .append(" ( select cc.mailno mailno, cc.boxno boxno, cc.regmailno regmailno, cc.execclass execclass,cc.readflag ")
                        .append("   from ( select aa.mailno, aa.boxno, aa.regmailno, bb.execclass, aa.readflag	")
                        .append("          from tb_").append(COMCODE).append("_c20 aa, tb_").append(COMCODE).append("_m10 bb	")
                        .append("          where aa.boxno = bb.boxno ")
                        .append("          and boxclass='3'")
                        .append("          and execclass="+ genQuote(gplus.commlib.comm.GCmConstDef.EXECCLASS_MAIL_INBOX))
                        .append("          and userid = "+genQuote(USERID)+" and readflag='1' ")
                        .append("    ) cc) yy ")
                        .append("    where xx.mailno = yy.mailno ")
                        .append("    and regdate > "+genQuote(timelogin));



			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println("GCoWmMail  :: getMailAlarmCount " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}

	}





	/**
	 * <PRE>
	 *  ���ϸ���Ʈ
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE : ȸ���ڵ�  <BR>
	 *				<LI> String USERID      : �����ID  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return GCmReSultSet		���ϸ���Ʈ
	 */
	public GCmResultSet getMailScreenList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
        String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{

			conn = GCmDbManager.getInstance().getConnection();

  	        StringBuffer sqlQuery = new StringBuffer();

            if ("oracle".equals(strDbType))
            {
                 sqlQuery
		   .append(" select  yy.boxno, yy.execclass, xx.mailno, yy.regmailno,xx.title, xx.attnum, xx.mailtype, xx.sndrname, xx.regdate, yy.readflag, yy.num  ")
		   .append(" from tb_").append(COMCODE).append("_c10 xx, ( select rownum num, cc.mailno mailno, cc.boxno boxno, cc.regmailno regmailno, cc.execclass execclass,cc.readflag ")
        	   .append("     from (select aa.mailno, aa.boxno, aa.regmailno, bb.execclass, aa.readflag	")
                   .append("           from tb_").append(COMCODE).append("_c20 aa, tb_").append(COMCODE).append("_m10 bb	")
                   .append("           where aa.boxno = bb.boxno and boxclass='3' and execclass="+genQuote(gplus.commlib.comm.GCmConstDef.EXECCLASS_MAIL_INBOX)+" and userid = "+genQuote(USERID)+" and readflag='1' ")
                   .append("           order by aa.mailno desc) cc) yy ")
		   .append(" where  xx.mailno = yy.mailno ");
            }
            else if ("mssql".equals(strDbType))
            {
                 sqlQuery
		   .append(" select  yy.boxno, yy.execclass, xx.mailno, yy.regmailno,xx.title, xx.attnum, xx.mailtype, xx.sndrname, xx.regdate, yy.readflag  ")
		   .append(" from tb_").append(COMCODE).append("_c10 xx, ( select cc.mailno mailno, cc.boxno boxno, cc.regmailno regmailno, cc.execclass execclass,cc.readflag ")
        	   .append("     from (select TOP 4 aa.mailno, aa.boxno, aa.regmailno, bb.execclass, aa.readflag	")
                   .append("           from tb_").append(COMCODE).append("_c20 aa, tb_").append(COMCODE).append("_m10 bb	")
                   .append("           where aa.boxno = bb.boxno and boxclass='3' and execclass="+genQuote(gplus.commlib.comm.GCmConstDef.EXECCLASS_MAIL_INBOX)+" and userid = "+genQuote(USERID)+" and readflag='1' ")
                   .append("           order by aa.mailno desc) cc) yy ")
		   .append(" where  xx.mailno = yy.mailno ");
            }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println("GCoWmMail::getMailScreenList::" + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}

	} //  getMailCount method end..




	/**
	 * <PRE>
	 *  �������ã��
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�    <BR>
	 *				<LI> String USERID         : �����ID    <BR>
	 *				<LI> String BOXNO         : �Թ�ȣ       <BR>
	 *				<LI> String TRASH          : ������       <BR>
	 *				<LI> String SORTID         : �����ʵ�    <BR>
	 *				<LI> String SORTOPT      : ��������,��������  <BR>
	 *				<LI> String OPT              : �����ʵ�   <BR>
	 *				<LI> String Q				    :                 <BR>
	 *				<LI> String SDATE          : ��������    <BR>
	 *				<LI> String LDATE          : ��������    <BR>
	 *				<LI> String CURPAGE     : ���������� <BR>
	 *				<LI> String PAGESIZE     : ������ũ�� <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return �˻������ �ش��ϴ� ���ϸ���Ʈ���� ���� GCmResultSet
	 */

	public GCmResultSet getMailList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

        String strOptSql = "";
         String strSortSql = "";
		String strComCode = dmProp.getString("COMCODE");
		String strUserId = dmProp.getString("USERID");
		String strBoxNo = dmProp.getString("BOXNO");
		String strTrash = dmProp.getString("TRASH");
		String strSortId = dmProp.getString("SORTID");
		String strSortOpt = dmProp.getString("SORTOPT");
		String strOpt = dmProp.getString("OPT");
		String strQ = dmProp.getString("Q");
		String strSDate = dmProp.getString("SDATE");
		String strLDate = dmProp.getString("LDATE");
		int       intCurPage = dmProp.getInt("CURPAGE");
		int       intPageSize = dmProp.getInt("PAGESIZE");
        String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
                    conn = GCmDbManager.getInstance().getConnection();

                    if (!strOpt.equals("") && (!strQ.equals("") || !strSDate.equals(""))) {

						strSDate = GCmFcts.replace(strSDate,"/","");
						strLDate = GCmFcts.replace(strLDate,"/","");

						if (strOpt.toUpperCase().equals("REGDATE"))
                        {
						     if (!strLDate.equals(""))
						     {
								strSDate = strSDate + "000000";
								strLDate = strLDate + "240000";
							}
						}
                        else
						{
							strSDate = strSDate + "%";
						}
                   }
                   else
				   {
                        strQ = "%" + strQ.toLowerCase() + "%";
					}


					strOptSql = getOptSQL(strOpt, strQ, strSDate, strLDate);
					strSortSql = getSortSQL(strSortId, strSortOpt);

                   StringBuffer sqlQuery = new StringBuffer();

                   if ("oracle".equals(strDbType))
                   {
	  	         sqlQuery.append(" SELECT D.REGMAILNO, D.BOXNO,  D.SRTYPE,D.READFLAG,D.TRASHFLAG, D.MAILNO,D.DOCNO,D.MAILTYPE,D.SENDTYPE,D.DLVRTYPE, ")
                        .append(" D.TITLE,D.REGDATE,D.SNDRID,D.SNDRNAME,D.TOID,D.TONAME,D.CCID,D.CCNAME,D.BCCID,D.BCCNAME,D.ATTNUM,D.ACCTNAME, D.RN ")
                        .append(" FROM (SELECT C.REGMAILNO,C.BOXNO,C.SRTYPE,C.READFLAG,C.TRASHFLAG, C.MAILNO,C.DOCNO,C.MAILTYPE,C.SENDTYPE, ")
                        .append(" C.DLVRTYPE,C.TITLE,C.REGDATE,C.SNDRID,C.SNDRNAME,C.TOID,C.TONAME,C.CCID,C.CCNAME,C.BCCID,C.BCCNAME,C.ATTNUM,C.ACCTNAME, ROWNUM AS RN ")
                        .append(" FROM (SELECT B.REGMAILNO,B.BOXNO,B.SRTYPE,B.READFLAG,B.TRASHFLAG, A.MAILNO,A.DOCNO,A.MAILTYPE,A.SENDTYPE,A.DLVRTYPE,A.TITLE, ")
                        .append(" A.REGDATE,A.SNDRID,A.SNDRNAME,A.TOID,A.TONAME,A.CCID,A.CCNAME,A.BCCID,A.BCCNAME,A.ATTNUM,A.ACCTNAME ")
                        .append(" FROM TB_").append(strComCode).append("_C10 A, TB_").append(strComCode).append("_C20 B ")
                        .append(" WHERE B.BOXNO = " + genQuote(strBoxNo))
                        .append(" AND A.MAILNO = B.MAILNO ")
                        .append(" AND B.TRASHFLAG = " + genQuote(strTrash))
                        .append(strOptSql)
                        .append(" ORDER BY ")
                        .append(strSortSql)
                        .append("	) C ")
                        .append(" WHERE ROWNUM <=  " ).append(intCurPage * intPageSize).append(") D ")
                        .append(" WHERE D.RN BETWEEN ").append(intCurPage * intPageSize - intPageSize + 1).append(" AND ").append(intCurPage * intPageSize);



                   }
                   else if ("mssql".equals(strDbType))
                   {
	  	      sqlQuery
	  	         .append(" SELECT TOP ").append(intCurPage * intPageSize).append(" B.REGMAILNO,B.BOXNO,B.SRTYPE,B.READFLAG,B.TRASHFLAG, A.MAILNO,A.DOCNO,A.MAILTYPE,A.SENDTYPE,A.DLVRTYPE,A.TITLE, ")
                         .append("        A.REGDATE,A.SNDRID,A.SNDRNAME,A.TOID,A.TONAME,A.CCID,A.CCNAME,A.BCCID,A.BCCNAME,A.ATTNUM,A.ACCTNAME ")
                         .append(" FROM TB_").append(strComCode).append("_C10 A, TB_").append(strComCode).append("_C20 B ")
                         .append("  WHERE B.BOXNO = " + genQuote(strBoxNo)+" AND A.MAILNO = B.MAILNO AND B.TRASHFLAG = " + genQuote(strTrash))
                         .append(strOptSql)
                         .append(" ORDER BY ")
                         .append(strSortSql);
                   }

		  GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

                  if ("mssql".equals(strDbType))
                  {
                     rs.moveRecordPos((intCurPage-1)*intPageSize);
                  }

                  return rs;

		}
		catch (Exception e)
		{

		 	System.out.println("GCoWmMail :: getMailList " + e.getMessage());

		 	return null;
		}
		finally
		{
			conn.close();
		}
	}






	/**
	 * <PRE>
	 *  ������ ī��Ʈ
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE : ȸ���ڵ�  <BR>
	 *				<LI> String BOXNO      : �Թ�ȣ     <BR>
	 *				<LI> String TRASH       : ������     <BR>
	 *				<LI> String OPT           : �����ʵ�  <BR>
	 *				<LI> String Q               : ȸ���ڵ�  <BR>
	 *				<LI> String SDATE       : ��������   <BR>
	 *				<LI> String LADTE        : ��������  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return ī��Ʈ ��
	 */
	public GCmResultSet getRecordCount(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmLog log = new GCmLog(GCmConstDef.GROUPWARE_ID);
		GCmConnection conn = null;


		String strComCode = dmProp.getString("COMCODE");
		String strBoxNo = dmProp.getString("BOXNO");
		String strTrash = dmProp.getString("TRASH");
		String strOpt = dmProp.getString("OPT");
		String strQ = dmProp.getString("Q");
		String strSDate = dmProp.getString("SDATE");
		String strLDate = dmProp.getString("LDATE");
		String strOptSql = "";
		try
		{


			conn = GCmDbManager.getInstance().getConnection();




			if (!strOpt.equals("") && (!strQ.equals("") || !strSDate.equals(""))) {

				strSDate = GCmFcts.replace(strSDate,"/","");
			    strLDate = GCmFcts.replace(strLDate,"/","");


	            if (strOpt.toUpperCase().equals("REGDATE"))
				{
					if (!strLDate.equals(""))
					{
						strSDate = strSDate + "000000";
						strLDate = strLDate + "240000";
					}
				}
                else
				{
					strSDate = strSDate + "%";
				}
            }
            else
			{
                strQ = "%" + strQ.toLowerCase() + "%";

			}


			strOptSql = getOptSQL(strOpt, strQ, strSDate, strLDate);




			StringBuffer sqlQuery = new StringBuffer()
							.append("SELECT COUNT(*) AS CNT ")
							.append(" FROM TB_").append(strComCode).append("_C10 A, TB_").append(strComCode).append("_C20 B ")
							.append(" WHERE B.BOXNO = " + genQuote(strBoxNo) + " AND A.MAILNO = B.MAILNO ")
                            .append(" AND B.TRASHFLAG = " + genQuote(strTrash) +  strOptSql ) ;


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());



		    return rs;


		}
		catch (Exception e)
		{

	 		System.out.println("GCoWmMail :: getRecourdCount " + e.getMessage());

		 	return null;
		}
		finally
		{
			conn.close();
		}
	}






	/**
	 * <PRE>
	 *  ���Ϲ�ȣ����
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE : ȸ���ڵ�  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return ���Ϲ�ȣ
	 */
	public String getMaxMailNo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmLog log = new GCmLog(GCmConstDef.GROUPWARE_ID);
		GCmConnection conn = null;


		String strComCode = dmProp.getString("COMCODE");

        String strRet = "";

		try
		{


			conn = GCmDbManager.getInstance().getConnection();

	        String strRegdate = GCmFcts.dateToStr(new java.util.Date(),1);


			StringBuffer sqlQuery = new StringBuffer()
							.append("SELECT MAX(MAILNO) AS MAXNO FROM TB_").append(strComCode).append("_C10 ")
							.append(" WHERE MAILNO LIKE " + genQuote(strRegdate + "%")) ;



			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());


			while (rs.next()) {


				strRet = rs.getString("MAXNO");


	            if (strRet.equals(null) || strRet.equals("")) {


		            strRet = strRegdate + "0001";

	            }
		        else {

			        strRet = String.valueOf(Integer.parseInt(strRet.substring(8, 12)) + 1);
				    strRet = GCmFcts.numToStr(strRet, 4);
					strRet = strRegdate + strRet;

	            }
		    }


		    return strRet;


		}
		catch (Exception e)
		{

	 		System.out.println("GCoWmMail :: getMaxMailNo " + e.getMessage());

		 	return null;
		}
		finally
		{
			conn.close();
		}
	}





	/**
	 * <PRE>
	 *  ���θ��Ϲ�ȣ����
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE : ȸ���ڵ�  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return ���θ��Ϲ�ȣ
	 */
	public String getMaxRegMailNo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;


		String strComCode = dmProp.getString("COMCODE");

        String strRet = "";

		try
		{


			conn = GCmDbManager.getInstance().getConnection();

	        String strRegdate = GCmFcts.dateToStr(new java.util.Date(),1);


			StringBuffer sqlQuery = new StringBuffer()
							.append("SELECT MAX(REGMAILNO) AS MAXNO FROM TB_").append(strComCode).append("_C20 ")
							.append(" WHERE REGMAILNO LIKE " + genQuote(strRegdate + "%")) ;



			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());


			while (rs.next()) {

				strRet = rs.getString("MAXNO");

	            if (strRet.equals(null) || strRet.equals("")) {

		            strRet = strRegdate + "0001";

	            }
		        else {

			        strRet = String.valueOf(Integer.parseInt(strRet.substring(8, 12)) + 1);
				    strRet = GCmFcts.numToStr(strRet, 4);
					strRet = strRegdate + strRet;

	            }
		    }


		    return strRet;


		}
		catch (Exception e)
		{

	 		System.out.println("GCoWmMail :: getMaxMailNo" + e.getMessage());

		 	return null;
		}
		finally
		{
			conn.close();
		}
	}




	/**
	 * <PRE>
	 *  �Խù�������
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE : ȸ���ڵ�  <BR>
	 *				<LI> String NOTINO      : �Խù���ȣ  <BR>
	 *				<LI> String SEQ           : �����Ϸù�ȣ  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return ���θ��Ϲ�ȣ
	 *  GCoBoBoard�� �޼����̳� ���(�����)
	 */



	public GCmResultSet getNotiDtlInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;


		String strComCode = dmProp.getString("COMCODE");
		String strNotiNo = dmProp.getString("NOTINO");
		String strSeq  = dmProp.getString("SEQ");


		try
		{


			conn = GCmDbManager.getInstance().getConnection();


			StringBuffer sqlQuery = new StringBuffer()
							.append(" SELECT A.NOTINO,A.BOXNO,A.DOCNO,A.PARENTNO,A.TITLE,A.ATTNUM,A.REFNUM,A.NOMNUM, ")
							.append(" A.CHILDNUM,A.REGUSER,A.REGDATE,A.REGNAME,A.REF,A.SORTSTEP,A.RELEVEL,B.DOCNO,B.DOCTYPE,B.FILENUM, ")
							.append(" C.SEQ,C.FILEEXT,C.FILENAME,C.VPATH,C.MIMETYPE,C.FILESIZE FROM TB_").append(strComCode).append("_A01 A, TB_")
							.append(strComCode).append("_L10 B, TB_").append(strComCode).append("_L11 C ")
							.append(" WHERE A.DOCNO = B.DOCNO AND B.DOCNO = C.DOCNO AND A.NOTINO = " + genQuote(strNotiNo))
							.append(" AND C.SEQ = " + genQuote(strSeq));


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;


		}
		catch (Exception e)
		{

	 		System.out.println("GCoWmMail :: getNotiDtlInfo" + e.getMessage());

		 	return null;
		}
		finally
		{
			conn.close();
		}
	}









	/**
	 * <PRE>
	 *  ����ڸ���Ʈ
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE : ȸ���ڵ�  <BR>
	 *				<LI> String OPT           : ����  <BR>
	 *				<LI> String Q               : ���Ǿ�  <BR>
	 *				<LI> String SORTID       : ��������     <BR>
	 *				<LI> String SORTOPT       : ���Ĺ��   <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return GCmResultSet
	 */



	public GCmResultSet getUserList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strOpt = dmProp.getString("OPT");
		String strQ  = dmProp.getString("Q");
		String strSortId = dmProp.getString("SORTID");
		String strSortOpt = dmProp.getString("SORTOPT");
		String strSort = "";
                String strOptSql = "";
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			if (strOpt==null)
			{
				strOpt="";
			}
			else if (strOpt.toUpperCase().equals("USERID"))
			{
				strOptSql = " AND TB_COMM_Z20.USERID LIKE " + genQuote(strQ + "%");
			}
			else if (strOpt.toUpperCase().equals("USERNAME"))
			{
				strOptSql = " AND TB_COMM_Z20.USERNAME LIKE " + genQuote(strQ + "%");
			}

			if (strQ==null) strQ = "";

			if ( strSortId.toUpperCase().equals("USERID"))
			{
				strSortId = " TB_COMM_Z20.USERID ";
			}
			else if (strSortId.toUpperCase().equals("ORGNAME"))
			{
				strSortId = " TB_" + strComCode + "_N10.ORGNAME ";
			}
	                else if (strSortId.toUpperCase().equals("POSCODE"))
			{
				strSortId = " TB_" + strComCode + "_N20.POSRANK ";

			}
	                else strSortId = " TB_COMM_Z20.USERNAME ";


	                if (strSortOpt == null)
			{
				strSortOpt = "";
			}

			strSort = "ORDER BY " + strSortId + strSortOpt;

  	             StringBuffer sqlQuery = new StringBuffer();

                     if ("oracle".equals(strDbType))
                     {
                         sqlQuery
                           .append(" SELECT TB_COMM_Z20.USERID,TB_COMM_Z20.COMCODE,TB_COMM_Z20.PASSWD,TB_COMM_Z20.ORGNO,TB_COMM_Z20.POSCODE, ")
                           .append("        TB_COMM_Z20.USERNAME,TB_COMM_Z20.SECLVL,TB_COMM_Z20.TEL1,TB_COMM_Z20.TEL2,TB_COMM_Z20.TEL3, ")
                           .append("        TB_COMM_Z20.ZIPCODE,TB_COMM_Z20.ADDR,TB_COMM_Z20.ALARMFLAG,TB_COMM_Z20.ALARMTIME,TB_COMM_Z20.ALARMREPEAT, ")
                           .append("        TB_COMM_Z20.ALARMTYPE,TB_COMM_Z20.ALARMMAILON,TB_COMM_Z20.ALARMDRFTON,TB_COMM_Z20.LOGINFLAG,TB_COMM_Z20.LOGINDATE, ")
                           .append("        TB_COMM_Z20.BOXNO,TB_COMM_Z20.SIGNDOCNO,TB_COMM_Z20.INDATE,TB_COMM_Z20.BIRTHDAY,TB_COMM_Z20.LUNARFLAG, ")
                           .append("        TB_").append(strComCode).append("_N10.ORGNAME, TB_").append(strComCode).append("_N20.POSNAME  ")
                           .append(" FROM TB_COMM_Z20 TB_COMM_Z20, TB_").append(strComCode).append("_N10 TB_").append(strComCode).append("_N10, TB_").append(strComCode).append("_N20 TB_").append(strComCode).append("_N20 ")
                           .append(" WHERE TB_COMM_Z20.ORGNO = TB_").append(strComCode).append("_N10.ORGNO (+) AND ")
                           .append("       TB_COMM_Z20.POSCODE = TB_").append(strComCode).append("_N20.POSCODE (+) AND ")
                           .append("       TB_COMM_Z20.COMCODE = "+genQuote(strComCode))
                           .append(strOptSql).append(strSort);
                     }
                     else if ("mssql".equals(strDbType))
                     {
                         sqlQuery
                           .append(" SELECT TB_COMM_Z20.USERID,TB_COMM_Z20.COMCODE,TB_COMM_Z20.PASSWD,TB_COMM_Z20.ORGNO,TB_COMM_Z20.POSCODE, ")
                           .append("        TB_COMM_Z20.USERNAME,TB_COMM_Z20.SECLVL,TB_COMM_Z20.TEL1,TB_COMM_Z20.TEL2,TB_COMM_Z20.TEL3, ")
                           .append("        TB_COMM_Z20.ZIPCODE,TB_COMM_Z20.ADDR,TB_COMM_Z20.ALARMFLAG,TB_COMM_Z20.ALARMTIME,TB_COMM_Z20.ALARMREPEAT, ")
                           .append("        TB_COMM_Z20.ALARMTYPE,TB_COMM_Z20.ALARMMAILON,TB_COMM_Z20.ALARMDRFTON,TB_COMM_Z20.LOGINFLAG,TB_COMM_Z20.LOGINDATE, ")
                           .append("        TB_COMM_Z20.BOXNO,TB_COMM_Z20.SIGNDOCNO,TB_COMM_Z20.INDATE,TB_COMM_Z20.BIRTHDAY,TB_COMM_Z20.LUNARFLAG, ")
                           .append("        TB_").append(strComCode).append("_N10.ORGNAME, TB_").append(strComCode).append("_N20.POSNAME  ")
                           .append(" FROM TB_COMM_Z20 TB_COMM_Z20, TB_").append(strComCode).append("_N10 TB_").append(strComCode).append("_N10, TB_").append(strComCode).append("_N20 TB_").append(strComCode).append("_N20 ")
                           .append(" WHERE TB_COMM_Z20.ORGNO *= TB_").append(strComCode).append("_N10.ORGNO AND ")
                           .append("       TB_COMM_Z20.POSCODE *= TB_").append(strComCode).append("_N20.POSCODE AND ")
                           .append("       TB_COMM_Z20.COMCODE = "+genQuote(strComCode))
                           .append(strOptSql).append(strSort);
                     }

                     GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
                     return rs;
		}
		catch (Exception e)
		{

	 		System.out.println("GCoWmMail  :: getUserList " + e.getMessage());

		 	return null;
		}
		finally
		{
			conn.close();
		}
	}







	/**
	 * <PRE>
	 *  �系���� �ּҷ� ����Ʈ
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE : ȸ���ڵ�  <BR>
	 *				<LI> String USERID        : �����ID  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return GCmResultSet
	 */



	public GCmResultSet getInAddrBookList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;


		String strComCode = dmProp.getString("COMCODE");
		String strUserId = dmProp.getString("USERID");



		try
		{


			conn = GCmDbManager.getInstance().getConnection();


			StringBuffer sqlQuery = new StringBuffer()
							.append(" SELECT ADDRBOOKNO, TITLE  FROM TB_").append(strComCode).append("_F30 ")
							.append(" WHERE USERID = " + genQuote(strUserId));


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());



			return rs;


		}
		catch (Exception e)
		{

	 		System.out.println("GCoWmMail ::  getInAddrBookList " + e.getMessage());

		 	return null;
		}
		finally
		{
			conn.close();
		}
	}




    /**
	 * WHERE �� ����
	 * @param opt	�˻�����
	 * @param q		�˻�����
	 * @param sdate	������
	 * @param ldate	������
	 * @return	��� ���ڰ�
	 */
     private String getOptSQL(String opt, String q, String sdate, String ldate)
        throws Exception
	{

		String sRet = "";

		if (opt == null || opt.equals("")) return "";

		if (opt.toUpperCase().equals("REGDATE") && !ldate.equals(""))

			sRet = " AND A." + opt + " BETWEEN " + genQuote(sdate) + " AND " + genQuote(ldate);

		else
			sRet = " AND LOWER(A." + opt + ") LIKE " + genQuote("%" + q + "%");

        return sRet;
    }

    /**
	 * ����
	 * @param sortid    ��������
	 * @param sortopt   ���Ĺ��
	 * @return	���ڰ�
	 */
    private String getSortSQL(String sortid, String sortopt) throws Exception {

		String sorting = "A.MAILNO DESC";

		if (!sortid.equals("") && !sortopt.equals(""))
            sorting = "A." + sortid + " " + sortopt;

		return sorting;
    }

}