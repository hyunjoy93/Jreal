package gplus.component.system;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

/**
 * <PRE>
 * Filename		: GCoSyComInfo.java
 * Class		: gplus.component.pos.GCoSyComInfo
 * Fuction		: ȸ�� �⺻���� �� �ý��� ������ ������
 * Comment		:
 * History      : 03/19/2002, ������, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCoSyComInfo extends GCmTopComponent
{
   /**
    * <PRE>
    *    ���޵� ȸ���ڵ带 ���Ͽ� ȸ���� ȯ���������� ȸ�� ȯ�������� �˻��Ͽ� �ǵ��� �ش�.
    * </PRE>
    *
    * @param cp        a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : ȸ����ȯ������ (COMNAME,CHKFILEDATE,CHKFILEINT,LMTFILESIZE,curfilesize,docread,
    *                                 docwrite,docdel,fldmake,flddel,brdread,brdwrite,brddel,chkalarmint,maxnotitab,
    *                                 maxnotilvl,MAILSVR,SMTPSVR,DEFLTEMAIL,MAXUSER ,ADDR,TEL,FAX,CEO,MANAGER)
    */
	public GCmResultSet getComInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT COMNAME,CHKFILEDATE,CHKFILEINT,LMTFILESIZE,curfilesize,docread,")
                           .append(" docwrite,docdel,fldmake, flddel,brdread,brdwrite,brddel,chkalarmint,maxnotitab,")
                           .append(" maxnotilvl,MAILSVR,SMTPSVR,DEFLTEMAIL,MAXUSER ,ADDR,TEL,FAX,CEO,MANAGER ")
                           .append(" FROM TB_COMM_Z10 ")
                           .append(" WHERE COMCODE = "+genQuote(COMCODE));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoSyComInfo::getComInfo : " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

   /**
    * <PRE>
    *    ���޵� ȸ���ڵ带 ���Ͽ� ȸ���� ȯ���������� ���ϼ����� �������� �˻��Ͽ� �ǵ��� �ش�.
    * </PRE>
    *
    * @param cp        a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : ȸ���� ���ϼ������� (MAILSVR, SMTPSVR)
    */
	public GCmResultSet getMailSvrInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT MAILSVR, SMTPSVR, BOARDLMT, DRAFTLMT, MAILLMT, DOCLMT ")
                           .append(" FROM TB_COMM_Z10 ")
                           .append(" WHERE COMCODE = "+genQuote(COMCODE));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoSyComInfo::getMailSvrInfo :" + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

   /**
    * <PRE>
    *    ���޵� ȸ���ڵ带 ���Ͽ� ȸ���� ȯ������������ ����ڼ��� �����ȯ���������� ���� ����ڼ���
    *    �˻��Ͽ� �ǵ��� �ش�.
    * </PRE>
    *
    * @param cp       a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : ����ڼ� ���� (MAXUSER, COUNT(MAXUSER) CURUSER)
    */
	public GCmResultSet currentUserCount(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT MAXUSER, COUNT(MAXUSER) CURUSER ")
                           .append(" FROM TB_COMM_Z10 T1, TB_COMM_Z20 T2 ")
                           .append(" WHERE T1.COMCODE = T2.COMCODE AND T1.COMCODE = "+genQuote(COMCODE))
                           .append(" GROUP BY MAXUSER ");

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoSyComInfo::currentUserCount : " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}


   /**
    * <PRE>
    *    �˻� ���ǿ� �´� ����Ʈ�� ���� Count���� �����ش�.
    * </PRE>
    *
    * @param cp        a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String OPT : �˻�����
	*                      <LI> String Q   : �˻���
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : COUNT(*) info ( CNT )
    */
	public int getListCount(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String OPT = dmProp.getString("opt");
        String Q   = dmProp.getString("q");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

            StringBuffer sqlQuery = new StringBuffer();

            if(!OPT.equals("")&&!Q.equals(""))
            {
                 sqlQuery
		            .append("select count(*) AS CNT from tb_comm_z10 ")
		            .append(" where LOWER("+OPT+") like '%"+Q.toLowerCase()+"%'");
	        }
	        else
	        {
                 sqlQuery
                    .append("select count(*) AS CNT from tb_comm_z10 ");
	        }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

            rs.next();
			return rs.getInt("CNT");

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoSyComInfo::getListCount : " + e.getMessage());
		 	return -1;
		}
		finally
		{
			conn.close();
		}
	}



	/**
	 * <PRE>
	 *    ��ϵǾ� �ִ� ȸ������� ����Ʈ�� ������ �����ش�.
	 * </PRE>
	 *
	 * @param cp	    a GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				    <�����׸� ����Ʈ>
	 *					<TT><UL> <BR>
	 *				        <LI> String OPT      : �˻�����
	 *						<LI> String Q        : �˻���
	 *						<LI> String CURPAGE  : ���� ������ ��ȣ
	 *						<LI> String PAGESIZE : �������� ����Ʈ ��
	 *				    </UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return          GCmResultSet : �� ȸ������� ����(COMCODE,COMNAME,MAXUSER,ADDR,TEL,FAX,CEO,MANAGER)
	 */
	public GCmResultSet getComList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;
                String strOptSql = "";
                String strSortSql = "";

		String  OPT   = dmProp.getString("opt");
		String  Q     = dmProp.getString("q");
                String strSortId = dmProp.getString("SORTID");
		String strSortOpt = dmProp.getString("SORTOPT");
		int  CURPAGE  = dmProp.getInt("curPage");
		int  PAGESIZE = dmProp.getInt("pageSize");

                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

            StringBuffer sqlQuery = new StringBuffer();


            if ("oracle".equals(strDbType))
            {



	        strSortSql = getSortSQL(strSortId, strSortOpt);
                sqlQuery
                    .append("SELECT C.* ")
                    .append(" FROM (SELECT B.*, ROWNUM AS RN ")
                    .append(" FROM (SELECT A.COMCODE,A.COMNAME,A.MAXUSER,A.ADDR,A.TEL,A.FAX,A.CEO,A.MANAGER ")
                    .append(" FROM TB_comm_z10 A ");

                    if(!OPT.equals("")&&!Q.equals(""))
                    {
                        sqlQuery
                            .append(" WHERE LOWER(A.").append(OPT).append(") LIKE '%").append(Q.toLowerCase()).append("%'");
                    }

                    sqlQuery
                         .append(" ORDER BY ")
                         .append(strSortSql)
                         .append(" ) B WHERE rownum <=  " )
                         .append(CURPAGE * PAGESIZE).append(") C ")
  			 .append(" WHERE C.RN BETWEEN ")
                         .append(CURPAGE * PAGESIZE - PAGESIZE + 1)
                         .append(" AND ")
                         .append(CURPAGE * PAGESIZE);
           }
           else if ("mssql".equals(strDbType))
           {
	  	         sqlQuery
                    .append(" SELECT TOP ").append(CURPAGE * PAGESIZE).append(" A.COMCODE,A.COMNAME,A.MAXUSER,A.ADDR,A.TEL,A.FAX,A.CEO,A.MANAGER ")
                    .append(" FROM TB_comm_z10 A ");

                 if(!OPT.equals("")&&!Q.equals(""))
                 {
                       sqlQuery
                          .append(" WHERE LOWER(A.").append(OPT).append(") LIKE '%").append(Q.toLowerCase()).append("%'");
                 }

          }
			//System.out.println("�ý��۲�:"+sqlQuery.toString());

		  GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

          if ("mssql".equals(strDbType))
          {
                rs.moveRecordPos((CURPAGE-1)*PAGESIZE);
          }

          return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoSyComInfo::getComList : " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

	/**
	 * ����
	 * @param sortid    ��������
	 * @param sortopt   ���Ĺ��
	 * @return	���ڰ�
	 */
	private String getSortSQL(String sortid, String sortopt) throws Exception {

		String sorting = "A.COMNAME DESC";

		if (!sortid.equals("") && !sortopt.equals(""))
                    sorting = "A." + sortid + " " + sortopt;

		return sorting;
    }





   /**
	* <PRE>
	*    �ߺ��� ID�� �ִ��� Count���� üũ�Ѵ�.( '0', '1' )
	* </PRE>
	*
	* @param cp	        a GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	* @param dmProp	    GCmProperties ��ü
	*				    <�����׸� ����Ʈ>
	*                   <TT><UL>
	*				        <LI> String USERNO   : �����ID
	*				    </UL></TT>
	* @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	* @return           GCmResultSet : COUNT(*) info ( CNT )
	*/
	public int idDualCheck(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String  USERNO  = dmProp.getString("USERNO");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

                        StringBuffer sqlQuery = new StringBuffer()
			    .append("SELECT COUNT(USERID) AS CNT  FROM TB_COMM_Z20 WHERE USERID = ")
			    .append(genQuote(USERNO));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
                        rs.next();

                    return rs.getInt("CNT");

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoSyComInfo::idDualCheck : " + e.getMessage());
		 	return -1;
		}
		finally
		{
			conn.close();
		}
	}

}