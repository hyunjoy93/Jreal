package gplus.component.board;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

/**
 * <PRE>
 * Filename		: GCoBoBoard.java
 * Class		: gplus.component.pos.GCoBoBoard
 * Fuction		:
 * Comment		:
 * History      : 03/19/2002, ������, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GCoBoBoard extends GCmTopComponent
{
	/**
	 * <PRE>
	 *    ȸ���ȣ,�Խù� ��ȣ,������ ���޹޾� �Խù��� ���� �������� �����´�.
	 * </PRE>
	 *
	 * @author          03/19/2002, ������
	 *
	 * @param cp	    a GCmProperties holding gplus groupware properties.
	 * @param dmProp	GCmProperties
	 *					<�����׸� ����Ʈ>						<BR>
	 *						<TT>
	 *							<UL>
	 *							<LI> String COMCODE : ȸ���ڵ�  <BR>
	 *							<LI> String NOTINO  : �Խù���ȣ  <BR>
	 *							<LI> String SEQ     : �����Ϸù�ȣ  <BR>
	 *							</UL>
	 *						</TT>
	 * @param msgInfo 	a GCmMsgInfo holding error codes.
	 * @return          GCmResultSet : �Խù� �� ���� (NOTINO,BOXNO,DOCNO,PARENTNO,TITLE,ATTNUM,REFNUM,NOMNUM
     *										CHILDNUM,REGUSER,REGDATE,REGNAME,REF,SORTSTEP,RELEVEL, DOCNO,DOCTYPE,
     *										FILENUM,SEQ,FILEEXT,FILENAME,VPATH,MIMETYPE,FILESIZE)
	 */

	public GCmResultSet getNotiDtlInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strNotiNo  = dmProp.getString("NOTINO");
		String strSeq     = dmProp.getString("SEQ");
        String strRet     = "";

		try
		{
			conn = GCmDbManager.getInstance().getConnection();
			StringBuffer sqlQuery = new StringBuffer()
							.append(" SELECT A.NOTINO,A.BOXNO,A.DOCNO,A.PARENTNO,A.TITLE,A.ATTNUM,A.REFNUM,A.NOMNUM, ")
							.append(" A.CHILDNUM,A.REGUSER,A.REGDATE,A.REGNAME,A.REF,A.SORTSTEP,A.RELEVEL, ")
							.append(" B.DOCNO,B.DOCTYPE,B.FILENUM,B.TOTFILESIZE,C.SEQ,C.FILEEXT,C.FILENAME,C.VPATH,C.MIMETYPE,C.FILESIZE ")
				            .append(" FROM TB_").append(strComCode).append("_A01 A, TB_")
							.append(strComCode).append("_L10 B, TB_").append(strComCode).append("_L11 C ")
							.append(" WHERE A.DOCNO = B.DOCNO AND B.DOCNO = C.DOCNO AND A.NOTINO = " + genQuote(strNotiNo))
							.append(" AND C.SEQ = " + genQuote(strSeq));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		}
		catch (Exception e)
		{
	 		System.out.println("  GCoBoBoard::getNotiDtlInfo" + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

    /**
     * <PRE>
     *    ȸ���ڵ�� �Խù���ȣ�� ���޹޾� ������ �����ϴ� ����Ʈ�� �����ش�.
     * </PRE>
	 *
	 * @author          03/19/2002, ������
	 *
     * @param cp        a GCmProperties holding gplus groupware properties.
     * @param dmProp    GCmProperties
     *						<UL>relevant fields.
     *							<LI> String COMCODE : ȸ���ڵ�
     *							<LI> String NOTINO  : �Խù� ��ȣ
	 *		                </UL>
     * @param msgInfo   a GCmMsgInfo holding error codes.
     * @return          GCmResultSet : ���� ����Ʈ ��� (DOCNO, SEQ, FILENAME, FILEEXT, VPATH)
     */

	public GCmResultSet getDelList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String NOTINO = dmProp.getString("NOTINO");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT C.DOCNO, C.SEQ, C.FILENAME, C.FILEEXT,C.VPATH ")
                           .append(" FROM TB_").append(COMCODE).append("_A01 A, ")
                           .append(" TB_").append(COMCODE).append("_L10 B, ")
                           .append(" TB_").append(COMCODE).append("_L11 C ")
                           .append(" WHERE A.NOTINO = "+genQuote(NOTINO))
                           .append(" AND A.DOCNO = B.DOCNO AND B.DOCNO = C.DOCNO ");


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;
		}
		catch (Exception e)
		{
	 		System.out.println(" GCoBoBoard::getDelList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

	/**
     * <PRE>
     *    �Խù� ��Ͽ��� ���� �Խù� ��ȣ�� �ش��ϴ� ������ ������ �˻��Ͽ� CNT �� �˻��Ͽ� �����ش�.
     * </PRE>
	 *
	 * @author          03/19/2002, ������
	 *
     * @param cp        a GCmProperties holding gplus groupware properties.
     * @param dmProp    GCmProperties
     *						<UL>relevant fields.
     *							<LI> String COMCODE  : ȸ���ڵ�
     *							<LI> String PARENTNO : ���� �Խù� ��ȣ
	 *		                </UL>
     * @param msgInfo   a GCmMsgInfo holding error codes.
     * @return          GCmResultSet : COUNT(*) info ( CNT )
     */

	public GCmResultSet getCntChild(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String PARENTNO = dmProp.getString("PARENTNO");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT COUNT(*) AS CNT ")
                           .append(" FROM TB_").append(COMCODE).append("_A01 ")
                           .append(" WHERE PARENTNO = "+genQuote(PARENTNO));


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;
		}
		catch (Exception e)
		{
	 		System.out.println(" GCoBoBoard::getCntChild " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

	/**
     * <PRE>
     *    ȸ���ڵ�, ���ع�ȣ, ����, �亯������ ���� ���޹޾� ���� ������ �亯�� �������� �������� �����Ͽ�
	 *    ���� �ٸ� ���̿� ������ �����Ͽ� �亯(Re) ����Ʈ�� �����ش�
     * </PRE>
	 *
	 * @author          03/19/2002, ������
	 *
     * @param cp        a GCmProperties holding gplus groupware properties.
     * @param dmProp    GCmProperties
     *						<UL>relevant fields.
     *							<LI> String COMCODE   : ȸ���ڵ�
     *							<LI> String REF       : ���ع�ȣ
	 *                          <LI> String SORTSTEP  : ����
     *							<LI> String RELEVEL   : �亯����
	 *		                </UL>
     * @param msgInfo   a GCmMsgInfo holding error codes.
     * @return          GCmResultSet : ���ع�ȣ�� ����, �亯�� ���� ( REF,SORTSTEP,RELEVEL )
     */

    public String getSortStep(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
    {
	    GCmConnection conn = null;

            String COMCODE = dmProp.getString("COMCODE");
            String REF = dmProp.getString("REF");
            String SORTSTEP = dmProp.getString("SORTSTEP");
            String RELEVEL = dmProp.getString("RELEVEL");

            GCmResultSet rs = null;
            GCmResultSet rs1 = null;

       	    try
	    {
		conn = GCmDbManager.getInstance().getConnection();

		StringBuffer sqlQuery = new StringBuffer()
                       .append(" SELECT REF,SORTSTEP,RELEVEL ")
                       .append(" FROM TB_"+COMCODE+"_A01 ")
                       .append(" WHERE REF = " + genQuote(REF)+" AND SORTSTEP > " + SORTSTEP)
                       .append("       AND RELEVEL <= "+RELEVEL)
                       .append(" ORDER BY SORTSTEP ");

		 rs = conn.executeQuery(sqlQuery.toString());

                if (rs.next()) {
                      sqlQuery = new StringBuffer()
                              .append(" SELECT REF,SORTSTEP,RELEVEL ")
                              .append(" FROM TB_"+COMCODE+"_A01 ")
                              .append(" WHERE REF = " + genQuote(REF)+" AND SORTSTEP > " + SORTSTEP)
                              .append("       AND SORTSTEP < "+rs.getInt("SORTSTEP")+" AND RELEVEL > "+RELEVEL)
                              .append(" ORDER BY SORTSTEP DESC ");
                       rs1 = conn.executeQuery(sqlQuery.toString());
                 }
                 else {// ���� LEVEL�� �亯�� ������
                       sqlQuery = new StringBuffer()
                               .append(" SELECT REF,SORTSTEP,RELEVEL ")
                               .append(" FROM TB_"+COMCODE+"_A01 ")
                               .append(" WHERE REF = " + genQuote(REF)+" AND SORTSTEP > " + SORTSTEP)
                               .append("       AND RELEVEL > "+RELEVEL)
                               .append(" ORDER BY SORTSTEP DESC ");
                        rs1 = conn.executeQuery(sqlQuery.toString());
                 }

                 if(rs1.next())
                     SORTSTEP = String.valueOf(rs1.getInt("SORTSTEP"));

		 return SORTSTEP;
		}
		catch (Exception e)
		{
	 		System.out.println(" GCoBoBoard::getSortStep " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

	/**
     * <PRE>
     *    ����� ID�� ������, �����Կ� ���� ������ �����ϴ� �������� �ִ����� Ȯ���ϰ� ������ BOXNO�� �����ش�.
     * </PRE>
	 *
	 * @author          03/19/2002, ������
	 *
     * @param cp        a GCmProperties holding gplus groupware properties.
     * @param dmProp    GCmProperties
     *						<UL>relevant fields.
     *							<LI> String COMCODE   : ȸ���ڵ�
     *							<LI> String Userno    : ����� ID
	 *		                </UL>
     * @param msgInfo   a GCmMsgInfo holding error codes.
     * @return          GCmResultSet : �����Թ�ȣ( BOXNO )
     */


	public GCmResultSet getDeleteBoxList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String Userno = dmProp.getString("Userno");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT BOXNO ")
                           .append(" FROM TB_").append(COMCODE).append("_M10 ")
                           .append(" WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') AND BOXCLASS = '2' AND EXECCLASS = '2' " );

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoOrOrgInfo::getDeleteBoxList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

	/**
     * <PRE>
     *    ȸ���ڵ�� �Խù� ��ȣ�� ���޹޾� �Խù���ȣ�� �´� ����Ʈ�� ������ �����ش�.
     * </PRE>
	 *
	 * @author          03/19/2002, ������
	 *
     * @param cp        a GCmProperties holding gplus groupware properties.
     * @param dmProp    GCmProperties
     *						<UL>relevant fields.
     *							<LI> String COMCODE   : ȸ���ڵ�
     *							<LI> String NOTINO    : �Խù� ��ȣ
	 *		                </UL>
     * @param msgInfo   a GCmMsgInfo holding error codes.
     * @return          GCmResultSet : �Խù� ���� ( NOTINO,BOXNO,DOCNO,PARENTNO,TITLE,ATTNUM,REFNUM,NOMNUM,CHILDNUM,
     *                                               REGUSER,REGDATE,REGNAME,REF,SORTSTEP,RELEVEL)
     */

    public GCmResultSet getNotiInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

                String COMCODE = dmProp.getString("COMCODE");
                String NOTINO = dmProp.getString("NOTINO");

               	try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT NOTINO,BOXNO,DOCNO,PARENTNO,TITLE,ATTNUM,REFNUM,NOMNUM,CHILDNUM,")
                           .append(" REGUSER,REGDATE,REGNAME,REF,SORTSTEP,RELEVEL")
                           .append(" FROM TB_").append(COMCODE).append("_A01 ")
                           .append(" WHERE NOTINO = " + genQuote(NOTINO));

                        GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;
		}
		catch (Exception e)
		{
	 		System.out.println(" GCoBoBoard::getNotiInfo " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

	/**
     * <PRE>
     *    ȸ���ڵ�, ���� �Խù� ��ȣ, �˻�����, �˻���, ���۳�¥, ������ ��¥�� ���޹޾� �� �˻����ǰ� ��ġ�ϴ�
	 *    ����Ʈ�� ������ �� ����Ʈ�� ������ �����ش�.
     * </PRE>
     *
	 * @author          03/19/2002, ������
	 *
     * @param cp        a GCmProperties holding gplus groupware properties.
     * @param dmProp    GCmProperties
     *						<UL>relevant fields.
     *							<LI> String COMCODE   : ȸ���ڵ�
     *							<LI> String PARENTNO  : ���� �Խù� ��ȣ
	 *							<LI> String OPT       : �˻�����
     *							<LI> String Q         : �˻���
     *							<LI> String SDATE     : ���� ��¥
     *							<LI> String LDATE     : ������ ��¥
	 *		                </UL>
     * @param msgInfo   a GCmMsgInfo holding error codes.
     * @return          GCmResultSet : COUNT(*) info ( CNT )
     */

    public GCmResultSet getRecordCount(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

                String COMCODE  = dmProp.getString("COMCODE");
                String PARENTNO = dmProp.getString("BOXNO");
                String OPT      = dmProp.getString("OPT");
                String Q	    = dmProp.getString("Q");
				String SDATE    = dmProp.getString("SDATE");
                String LDATE    = dmProp.getString("LDATE");


               	try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT COUNT(*) AS CNT ")
                           .append(" FROM TB_").append(COMCODE).append("_A01 A")
                           .append(" WHERE BOXNO = ")
                           .append(genQuote(PARENTNO));

                       if(!OPT.equals("") && (!Q.equals("") || !SDATE.equals("")))
                       {
                            String s4 = GCmFcts.replace(SDATE, "/", "");
                            String s5 = GCmFcts.replace(LDATE, "/", "");

                            s4 = s4.concat("000000");
                            s5 = s5.concat("240000");

                            if(OPT.toUpperCase().equals("REGDATE"))
                            {
                                if(!s5.equals(""))
                                {
                                          sqlQuery
                                             .append(" AND A.").append(OPT)
                                             .append(" BETWEEN "+genQuote(s4))
                                             .append(" AND "+genQuote(s5));

                                } else {
                                    sqlQuery
                                        .append(" AND A.").append(OPT)
                                        .append(" BETWEEN '%").append(s4).append("%'");
                                }
                            } else {
                               sqlQuery
                                  .append(" AND LOWER(A.").append(OPT).append(") LIKE ")
                                  .append("'%").append(Q.toLowerCase()).append("%'");
                            }
                        }

                        GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;
		}
		catch (Exception e)
		{
	 		System.out.println(" GCoBoBoard::getRecordCount " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

	/**
     * <PRE>
     *    ȸ���ڵ�, ���� �Խù� ��ȣ, ���ع�ȣ, �˻�����, �˻���, ���۳�¥, ������ ��¥, ���� ������, �������� ����Ʈ ������ ���޹޾�
	 *    �� �˻����ǰ� ��ġ�ϴ� ����Ʈ�� ������ �����ش�
     * </PRE>
     *
	 * @author          03/19/2002, ������
	 *
     * @param cp        a GCmProperties holding gplus groupware properties.
     * @param dmProp    GCmProperties
     *						<UL>relevant fields.
     *							<LI> String COMCODE   : ȸ���ڵ�
     *							<LI> String PARENTNO  : ���� �Խù� ��ȣ
	 *							<LI> String SORTID    : ���ع�ȣ
	 *							<LI> String OPT       : �˻�����
     *							<LI> String Q         : �˻���
     *							<LI> String SDATE     : ���� ��¥
     *							<LI> String LDATE     : ������ ��¥
	 *							<LI> String CURPAGE   : ���� ������ ��ȣ
     *							<LI> String PAGESIZE  : �������� ����Ʈ ��
	 *		                </UL>
     * @param msgInfo   a GCmMsgInfo holding error codes.
     * @return          GCmResultSet : �Խù� ���� ( NOTINO,BOXNO,DOCNO,PARENTNO,TITLE,ATTNUM,REFNUM,NOMNUM
     *												 CHILDNUM,REGUSER,REGDATE,REGNAME,REF,SORTSTEP,RELEVEL, ROWNUM )
     */

	public GCmResultSet getBoardList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

        String COMCODE = dmProp.getString("COMCODE");
        String BOXNO   = dmProp.getString("BOXNO");
        String SORTID  = dmProp.getString("SORTID");
        String SORTOPT = dmProp.getString("SORTOPT");
		String OPT     = dmProp.getString("OPT");
		String Q       = dmProp.getString("Q");
        String SDATE   = dmProp.getString("SDATE");
        String LDATE   = dmProp.getString("LDATE");
		int  CURPAGE   = dmProp.getInt("CURPAGE");
		int  PAGESIZE  = dmProp.getInt("PAGESIZE");
        String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

            StringBuffer sqlQuery = new StringBuffer();

            if ("oracle".equals(strDbType))
            {
               sqlQuery
		  .append(" SELECT C.NOTINO,C.BOXNO,C.DOCNO,C.PARENTNO,C.TITLE,C.ATTNUM,C.REFNUM,C.NOMNUM, ")
                  .append("       C.CHILDNUM,C.REGUSER,C.REGDATE,C.REGNAME,C.REF,C.SORTSTEP,C.RELEVEL,C.RN   ")
		  .append(" FROM (SELECT B.NOTINO,B.BOXNO,B.DOCNO,B.PARENTNO,B.TITLE,B.ATTNUM,B.REFNUM,B.NOMNUM, ")
                  .append("              B.CHILDNUM,B.REGUSER,B.REGDATE,B.REGNAME,B.REF,B.SORTSTEP,B.RELEVEL, ROWNUM AS RN ")
                  .append("       FROM (SELECT A.NOTINO,A.BOXNO,A.DOCNO,A.PARENTNO,A.TITLE,A.ATTNUM,A.REFNUM,A.NOMNUM, ")
                  .append("                    A.CHILDNUM, A.REGUSER,A.REGDATE,A.REGNAME,A.REF,A.SORTSTEP,A.RELEVEL ")
		  .append("             FROM TB_").append(COMCODE).append("_A01 A WHERE A.BOXNO = ").append(genQuote(BOXNO));
             }
            else if ("mssql".equals(strDbType))
            {
               sqlQuery
		  .append(" SELECT TOP ").append(CURPAGE * PAGESIZE).append(" A.NOTINO,A.BOXNO,A.DOCNO,A.PARENTNO,A.TITLE,A.ATTNUM,A.REFNUM,A.NOMNUM, ")
                  .append("        A.CHILDNUM, A.REGUSER,A.REGDATE,A.REGNAME,A.REF,A.SORTSTEP,A.RELEVEL ")
		  .append(" FROM TB_").append(COMCODE).append("_A01 A WHERE A.BOXNO = ").append(genQuote(BOXNO));
            }

            if(!OPT.equals("") && (!Q.equals("") || !SDATE.equals("")))
            {
                      String s4 = GCmFcts.replace(SDATE, "/", "");
                      String s5 = GCmFcts.replace(LDATE, "/", "");

                      s4 = s4.concat("000000");
                      s5 = s5.concat("240000");

                      if(OPT.toUpperCase().equals("REGDATE"))
                      {
                            if(!s5.equals(""))
                            {
                               sqlQuery
                                   .append(" AND A.").append(OPT)
                                   .append(" BETWEEN "+genQuote(s4))
                                   .append(" AND "+genQuote(s5));
                            }else {
                               sqlQuery
                                   .append(" AND LOWER(A.").append(OPT).append(") LIKE ")
                                   .append("'").append(s4).append("%'");
                            }
                       } else {
                            sqlQuery
                                .append(" AND LOWER(A.").append(OPT).append(") LIKE ")
                                .append("'%").append(Q.toLowerCase()).append("%'");
                       }
                  }

				  sqlQuery
                      .append(" ORDER BY ");

                  if(!SORTID.equals("") && !SORTOPT.equals("") && !SORTID.equals("REF")){
                        sqlQuery
                            .append(" A.").append(SORTID).append(" ").append(SORTOPT);
                  }else{
                        sqlQuery
                            .append(" A.REF DESC, A.SORTSTEP ASC ");
                  }

           if ("oracle".equals(strDbType))
           {      sqlQuery
                      .append(" ) B WHERE rownum <=  " ).append(CURPAGE * PAGESIZE).append(") C ")
  					  .append(" WHERE C.RN BETWEEN ").append(CURPAGE * PAGESIZE - PAGESIZE + 1)
                      .append(" AND ").append(CURPAGE * PAGESIZE);
           }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

           if ("mssql".equals(strDbType))
           {
                rs.moveRecordPos((CURPAGE-1)*PAGESIZE);
           }

            return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoBoBoard::getBoardList : " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

	/**
     * <PRE>
     *    ȸ���ڵ�, ������ȣ�� ���޹޾� ������ �� ������ �����ش�.
     * </PRE>
     *
	 * @author          03/19/2002, ������
	 *
     * @param cp        a GCmProperties holding gplus groupware properties.
     * @param dmProp    GCmProperties
     *						<UL>relevant fields.
     *							<LI> String COMCODE   : ȸ���ڵ�
     *							<LI> String DOCNO     : ������ȣ
	 *		                </UL>
     * @param msgInfo   a GCmMsgInfo holding error codes.
     * @return          GCmResultSet : ���������� ( DOCNO,SEQ,CONTTYPE,TITLE,FILEEXT,FILENAME,VPATH,MIMETYPE,FILESIZE,
	 *                                                ORGNAME,ORGPATH,REGUSER,REGDATE,MODUSER,MODDATE )
     */

	public GCmResultSet getDocDtlInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

                String COMCODE = dmProp.getString("COMCODE");
                String DOCNO = dmProp.getString("DOCNO");

               	try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT * ")
                           .append(" FROM TB_").append(COMCODE).append("_L11 ")
                           .append(" WHERE DOCNO = " + genQuote(DOCNO))
                           .append(" AND SEQ = '01'");

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;
		}
		catch (Exception e)
		{
	 		System.out.println(" GCoBoBoard::getDocDtlInfo " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

	/**
     * <PRE>
     *    ȸ���ڵ�, ������ȣ�� ���޹޾� ������ �� ������ �����ش�.
     * </PRE>
     *
	 * @author          03/19/2002, ������
	 *
     * @param cp        a GCmProperties holding gplus groupware properties.
     * @param dmProp    GCmProperties
     *						<UL>relevant fields.
     *							<LI> String COMCODE   : ȸ���ڵ�
     *							<LI> String DOCNO     : ������ȣ
	 *		                </UL>
     * @param msgInfo   a GCmMsgInfo holding error codes.
     * @return          GCmResultSet : ���������� ( DOCNO,SEQ,CONTTYPE,TITLE,FILEEXT,FILENAME,VPATH,MIMETYPE,FILESIZE,
	 *                                                ORGNAME,ORGPATH,REGUSER,REGDATE,MODUSER,MODDATE )
     */

	public GCmResultSet getDocDtlList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

        String COMCODE = dmProp.getString("COMCODE");
        String DOCNO = dmProp.getString("DOCNO");

        try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT * ")
                           .append(" FROM TB_").append(COMCODE).append("_L11 ")
                           .append(" WHERE DOCNO = " + genQuote(DOCNO))
                           .append(" AND SEQ > '01' ORDER BY SEQ");


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;
		}
		catch (Exception e)
		{
	 		System.out.println(" GCoBoBoard::getDocDtlList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

	/**
     * <PRE>
     *    ȸ���ڵ�, ������ ��ȣ�� ���޹޾� �������� �̸��� �����ش�.
     * </PRE>
     *
	 * @author          03/19/2002, ������
	 *
     * @param cp        a GCmProperties holding gplus groupware properties.
     * @param dmProp    GCmProperties
     *						<UL>relevant fields.
     *							<LI> String COMCODE   : ȸ���ڵ�
     *							<LI> String boxno     : �����Թ�ȣ
	 *		                </UL>
     * @param msgInfo   a GCmMsgInfo holding error codes.
     * @return          GCmResultSet : ������ �̸� ( BOXNAME )
     */

	public GCmResultSet getBoardTitle(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("comcode");
		String Boxno = dmProp.getString("boxno");

                try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT BOXNAME, BOXTYPE ")
                           .append(" FROM TB_").append(COMCODE).append("_M10 ")
                           .append(" WHERE BOXNO = "+genQuote(Boxno));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;


		}
		catch (Exception e)
		{
	 		System.out.println(" GCoBoBoard::getBoardTitle " + e.getMessage());
		 	return null;
		}
		finally
		{

			conn.close();
		}
	}

	/**
     * <PRE>
     *    ȸ���ڵ�, ������ ��ȣ�� ���޹޾� ������ �����ϴ� ������ ������ �����ش�. ( �Խ����� ���� �׸��� )
     * </PRE>
     *
	 * @author          03/19/2002, ������
	 *
     * @param cp        a GCmProperties holding gplus groupware properties.
     * @param dmProp    GCmProperties
     *						<UL>relevant fields.
     *							<LI> String COMCODE   : ȸ���ڵ�
     *							<LI> String boxno     : �����Թ�ȣ
	 *		                </UL>
     * @param msgInfo   a GCmMsgInfo holding error codes.
     * @return          GCmResultSet : �Խ��� �� �̸� ( BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,BOXTYPE,BOXNAME,
	 *                                                  BASEFLAG, PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE )
     */

    public GCmResultSet getDrawTab(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

                String COMCODE = dmProp.getString("comcode");
                String Parentno = dmProp.getString("boxno");
                String Boxclass = "1";

               	try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,BOXTYPE,BOXNAME,")
                           .append(" BASEFLAG, PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE")
                           .append(" FROM TB_").append(COMCODE).append("_M10 ")
                           .append(" WHERE PARENTNO = " + genQuote(Parentno))
                           .append(" AND BOXCLASS = " + genQuote(Boxclass))
                           .append(" order by BOXNO ");



			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;
		}
		catch (Exception e)
		{
	 		System.out.println(" GCoBoBoard::getDrawTab " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

	/**
     * <PRE>
     *    ���ο��� �������� ���� ����Ʈ ������ �����ش�.
     * </PRE>
     *
	 * @author          03/19/2002, ������
	 *
     * @param cp        a GCmProperties holding gplus groupware properties.
     * @param dmProp    GCmProperties
     *						<UL>relevant fields.
     *							<LI> String COMCODE   : ȸ���ڵ�
	 *		                </UL>
     * @param msgInfo   a GCmMsgInfo holding error codes.
     * @return          GCmResultSet : �Խù� ����Ʈ�� ���� ( boxno, notino, title, regdate, parentno, execclass )
     */

	public GCmResultSet getGongjiBoardList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
        String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                           sqlQuery
                              .append(" select yy.boxno, yy.notino, xx.title, xx.regdate, yy.parentno, yy.execclass ")
                              .append(" from tb_").append(COMCODE).append("_l10 xx, ")
                              .append(" 	(select aa.boxno, aa.notino, aa.docno, bb.parentno,bb.execclass ")
                              .append(" 	 from tb_").append(COMCODE).append("_a01 aa, ")
                              .append(" 		(select * ")
                              .append("		 from tb_").append(COMCODE).append("_m10 ")
                              .append("		 where boxname ='��������' ")
                              .append("		 and boxclass='1') bb ")
                              .append("	where aa.boxno = bb.boxno and   aa.sortstep < 1     ")
                              .append("	order by aa.regdate desc) yy ")
                              .append(" where xx.docno = yy.docno");
                        }
                        else if ("mssql".equals(strDbType))
                             {
                                   sqlQuery
                                      .append(" select yy.boxno, yy.notino, xx.title, xx.regdate, yy.parentno, yy.execclass ")
                                      .append(" from tb_").append(COMCODE).append("_l10 xx, ")
                                      .append(" 	(select TOP 5 aa.boxno, aa.notino, aa.docno, bb.parentno,bb.execclass ")
                                      .append(" 	 from tb_").append(COMCODE).append("_a01 aa, ")
                                      .append(" 	      (select * ")
                                      .append("		       from tb_").append(COMCODE).append("_m10 ")
                                      .append("		       where boxname ='��������' and boxclass='1') bb ")
                                      .append("	         where aa.boxno = bb.boxno and   aa.sortstep < 1     ")
                                      .append("	         order by aa.regdate desc) yy ")
                                      .append(" where xx.docno = yy.docno");
                              }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println("GCoBoBoard::getGongjiBoardList::" + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

	/**
	 *  ���ο��� ��� �Խ��� ����Ʈ.
	 * rjman 2002.02.07
	 * @param cp		GCmProperties
	 * @param msgInfo	GCmMsgInfo
	 * @return GCmResultSet
	 */

	public GCmResultSet getSaunBoardList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                           sqlQuery
	   		      .append("  select yy.boxno, yy.notino, xx.title, xx.regdate, yy.parentno, yy.execclass ")
                              .append(" from tb_").append(COMCODE).append("_l10 xx, ")
                              .append(" 	(select aa.boxno, aa.notino, aa.docno ,bb.parentno, bb.execclass")
                              .append(" 	 from tb_").append(COMCODE).append("_a01 aa, ")
                              .append(" 		(select * ")
                              .append("		 from tb_").append(COMCODE).append("_m10 ")
                              .append("		 where boxname ='����Խ���' ")
                              .append("		 and boxclass='1') bb ")
                              .append("	where aa.boxno = bb.boxno ")
                              .append("   and   aa.sortstep < 1     ")
                              .append("	order by aa.regdate desc) yy ")
                              .append(" where xx.docno = yy.docno");
                        }
                        else if ("mssql".equals(strDbType))
                             {
                                   sqlQuery
                                      .append("  select yy.boxno, yy.notino, xx.title, xx.regdate, yy.parentno, yy.execclass ")
                                      .append(" from tb_").append(COMCODE).append("_l10 xx, ")
                                      .append(" 	(select TOP 5 aa.boxno, aa.notino, aa.docno ,bb.parentno, bb.execclass")
                                      .append(" 	 from tb_").append(COMCODE).append("_a01 aa, ")
                                      .append(" 		( select * ")
                                      .append("		         from tb_").append(COMCODE).append("_m10 ")
                                      .append("		         where boxname ='����Խ���' and boxclass='1') bb ")
                                      .append("          where aa.boxno = bb.boxno and   aa.sortstep < 1 ")
                                      .append("	         order by aa.regdate desc) yy ")
                                      .append(" where xx.docno = yy.docno");
                             }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println("GCoBoBoard::getSaunBoardList::" + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}


	/**
	 *  ���ο��� ȸ�� �����Կ� �ֱ� ��ϵ� �ڷ� ����Ʈ ���
	 * rjman 2002.02.07
	 * @param cp		GCmProperties
	 * @param msgInfo	GCmMsgInfo
	 * @return GCmResultSet
	 */

	public GCmResultSet getJaryoBoardList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();
			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                           sqlQuery
                              .append(" SELECT A.BOXNO, A.FLDNO, A.PARENTNO, A.DOCNO, D.title, A.REGDATE , A.refno, D.reguser")
                              .append(" FROM TB_").append(COMCODE).append("_B10 A, TB_").append(COMCODE).append("_L10 D ")
                              .append(" WHERE A.DOCNO = D.DOCNO  ")
                              .append(" AND A.PARENTNO in (SELECT fldno ")
                              .append("                    FROM TB_").append(COMCODE).append("_B10 ")
                              .append("                    WHERE (DOCNO IS NULL OR DOCNO = '`')  ")
                              .append("                    and BOXNO = (SELECT boxno ")
                              .append("                                 FROM TB_").append(COMCODE).append("_M10 ")
                              .append("                                 WHERE PARENTNO = '000000000000' ")
                              .append("								 AND BOXCLASS = '2' ")
                              .append("								 AND PUBFLAG = '0' ")
                              .append("								 AND BOXTYPE = '1' ")
                              .append("								 and baseflag='0')) ")
                              .append(" order by A.REGDATE desc ");
                        }
                        else if ("mssql".equals(strDbType))
                             {
                                   sqlQuery
                                      .append(" SELECT TOP 5 A.BOXNO, A.FLDNO, A.PARENTNO, A.DOCNO, D.title, A.REGDATE , A.refno, D.reguser")
                                      .append(" FROM TB_").append(COMCODE).append("_B10 A, TB_").append(COMCODE).append("_L10 D ")
                                      .append(" WHERE A.DOCNO = D.DOCNO  ")
                                      .append(" AND A.PARENTNO in (SELECT fldno ")
                                      .append("                    FROM TB_").append(COMCODE).append("_B10 ")
                                      .append("                    WHERE (DOCNO = '' OR DOCNO = '`')  ")
                                      .append("                    and BOXNO = (SELECT boxno ")
                                      .append("                                 FROM TB_").append(COMCODE).append("_M10 ")
                                      .append("                                 WHERE PARENTNO = '000000000000' ")
                                      .append("								 AND BOXCLASS = '2' ")
                                      .append("								 AND PUBFLAG = '0' ")
                                      .append("								 AND BOXTYPE = '1' ")
                                      .append("								 and baseflag='0')) ")
                                      .append(" order by A.REGDATE desc ");
                             }


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println("GCoBoBoard::getJaryoBoardList::" + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

    /**
     * <PRE>
     *    �Խù� ��Ͽ��� �ش� �Թ�ȣ�� �ش��ϴ� ������ ������ �˻��Ͽ� CNT �� �˻��Ͽ� �����ش�.
     * </PRE>
     *
	 * @author          03/19/2002, ������
	 *
     * @param cp      a GCmProperties holding gplus groupware properties.
     * @param dmProp    GCmProperties
     *                  <UL>relevant fields.
     *                      <LI> String COMCODE : current user companycode at session
     *                      <LI> String Boxno : �Թ�ȣ
     *                  </UL>
     * @param msgInfo   a GCmMsgInfo holding error codes.
     * @return          GCmResultSet COUNT(*) info ( CNT )
     */
	public GCmResultSet getBoxApplyCnt(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String Boxno = dmProp.getString("Boxno");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT COUNT(*) AS CNT ")
                           .append(" FROM TB_").append(COMCODE).append("_A01 ")
                           .append(" WHERE BOXNO = "+genQuote(Boxno));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;
		}
		catch (Exception e)
		{
	 		System.out.println(" GCoBoBoard::getBoxApplyCnt " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

        public String getMaxNotiNo(String comcode,String strDbType)
        {
		GCmConnection conn = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                             sqlQuery
		        	.append(" SELECT DECODE(SUBSTR(MAX(NOTINO),1,8),TO_CHAR(sysdate,'YYYYMMDD'),TO_CHAR(TO_NUMBER(MAX(NOTINO))+1),null,TO_CHAR(sysdate,'YYYYMMDD')||'0001') as NO ")
                           	.append(" FROM TB_").append(comcode).append("_A01 ")
                           	.append(" WHERE NOTINO LIKE TO_CHAR(sysdate,'YYYYMMDD')||'%'");
                        }
                        else if ("mssql".equals(strDbType))
                             {
                                     sqlQuery
                                        .append(" SELECT (CASE SUBSTRING(MAX(NOTINO),1,8) WHEN convert(char(08),getdate(),112) THEN CAST(SUBSTRING(MAX(NOTINO),1,8) AS varchar(8)) + RIGHT('0000'+CAST(SUBSTRING(MAX(NOTINO),9,4)+1 AS varchar(4)),4) ELSE convert(char(08),getdate(),112)+'0001' END) as NO ")
                                        .append(" FROM TB_").append(comcode).append("_A01 ")
                                        .append(" WHERE NOTINO LIKE convert(char(08),getdate(),112)+'%' ");
                             }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
                	rs.next();

			return rs.getString("NO");

      		}
      		catch (Exception e)
      		{
 			System.out.println(" GCoMeBoxsTran::getMaxNo " + e.getMessage());
	 		return null;
      		}
      		finally
      		{
			conn.close();
      		}
    	}

}