package gplus.component.card;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;
import gplus.commlib.util.GCmFcts;

/**
 * <PRE>
 * Filename		: GCoCaCardGroupHistory.java
 * Class		: gplus.component.card.GCoCaCardGroup
 * Fuction		:
 * Comment		:
 * History      : 01/10/2002, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GCoCaCardHistory extends GCmTopComponent {

   /**
    * <PRE>
    *  ���� ���� ���� ��ȸ. 
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String USERID : current user id at session
    *                      <LI> String CardNo : �׷��ڵ�
    *                      <LI> String MeetNo : ������ȣ
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : MEETNO, CARDNO, USERID, MEETDATE, COMMENTS 
    */
	public GCmResultSet getCardHistoryDetail(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
 	    String CardNo = dmProp.getString("CardNo");
 	    String MeetNo = dmProp.getString("MeetNo");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();
			StringBuffer sqlQuery = new StringBuffer()
                                .append(" SELECT MEETNO, CARDNO, USERID, MEETDATE, COMMENTS ")
                                .append(" FROM TB_").append(COMCODE).append("_F11 ")
                                .append(" WHERE MEETNO="+genQuote(MeetNo)+" AND CARDNO="+genQuote(CardNo)+" AND USERID="+genQuote(USERID));

        	GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		}
		catch (Exception e)
		{
	 		System.out.println(" GCoCaCardHistory::getCardHistoryDetail " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

   /**
    * <PRE>
    *  ����ڿ� ���� ���� �Ǽ�. 
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String USERID : current user id at session
    *                      <LI> String CardNo : �׷��ڵ�
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : MEETNO, CARDNO, USERID, MEETDATE, COMMENTS 
    */
	public GCmResultSet getCardHistoryCount(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String CardNo = dmProp.getString("CardNo");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();
			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT COUNT(*) AS CNT ")
                           .append(" FROM TB_").append(COMCODE).append("_F11 ")
                           .append(" WHERE CARDNO="+genQuote(CardNo)+" AND USERID="+genQuote(USERID));

       		GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		}
		catch (Exception e)
		{
	 		System.out.println(" GCoCaCardHistory::getCardHistoryCount " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}


   /**
    * <PRE>
    *  ����ڿ����� ���� ���� ����Ʈ.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String USERID : current user id at session
    *                      <LI> String CardNo : �׷��ڵ�
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : MEETNO, CARDNO, USERID, MEETDATE, COMMENTS 
    */


	public GCmResultSet getCardHistoryList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String CardNo = dmProp.getString("CardNo");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();
			StringBuffer sqlQuery = new StringBuffer()
                                .append(" SELECT MEETNO, CARDNO, USERID, MEETDATE, COMMENTS ")
                                .append(" FROM TB_").append(COMCODE).append("_F11 ")
                                .append(" WHERE CARDNO="+genQuote(CardNo)+" AND USERID="+genQuote(USERID))
                                .append(" ORDER BY MEETNO DESC");

        		GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		}
		catch (Exception e)
		{
	 		System.out.println(" GCoCaCardHistory::getCardHistoryList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}


}
