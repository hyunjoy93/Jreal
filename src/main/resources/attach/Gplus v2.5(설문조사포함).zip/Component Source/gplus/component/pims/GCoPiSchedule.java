package gplus.component.pims;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;


/**
 * <PRE>
 * Filename		: CCoPimsSchdl.java
 * Class		: gplus.component.pims.CCoPimsSchdl
 * Fuction		: ����� ������������ ��ȸ�Ѵ�.
 * Comment		:
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCoPiSchedule extends GCmTopComponent
{
       /**
        * <PRE>
        * ����ڿ� ���� ���� ����� ����Ʈ �Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : ����� ���̵�
        *                      <LI> String Schdlno : ������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */

	public GCmResultSet getSchdlInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String Schdlno = dmProp.getString("Schdlno");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                           sqlQuery
                              .append(" SELECT A.*, B.* FROM TB_").append(COMCODE).append("_E10 A, TB_").append(COMCODE).append("_G10 B ")
                              .append(" WHERE A.SCHDLNO = "+genQuote(Schdlno))
                              .append(" AND A.USERID = "+genQuote(USERID))
                              .append(" AND A.GRPNO = B.GRPNO (+) ");
                        }
                        else if ("mssql".equals(strDbType))
                             {
                           sqlQuery
                              .append(" SELECT A.*, B.* FROM TB_").append(COMCODE).append("_E10 A, TB_").append(COMCODE).append("_G10 B ")
                              .append(" WHERE A.SCHDLNO = "+genQuote(Schdlno))
                              .append(" AND A.USERID = "+genQuote(USERID))
                              .append(" AND A.GRPNO *= B.GRPNO ");
                              }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoPiSchedule::getSchdlInfo " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

       /**
        * <PRE>
        * ����ڿ� ���� ��,��,�Ͽ� ���� �Ϸ� ���� ����� ����Ʈ �Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : ����� ���̵�
        *                      <LI> String Year : ��
        *                      <LI> String Month : ��
        *                      <LI> String Day : ��
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */



	public GCmResultSet getSchdlEveryListTotal(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String Year = dmProp.getString("Year");
		String Month = dmProp.getString("Month");
		String Day = dmProp.getString("Day");
        String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

            if ("oracle".equals(strDbType))
            {
                  sqlQuery
                     .append(" SELECT A.*,B.* FROM TB_").append(COMCODE).append("_E10 A, TB_").append(COMCODE).append("_G10 B ")
                     .append(" WHERE "+genQuote(Year+Month+Day)+" BETWEEN A.SDATE AND A.LDATE " )
                     .append("       AND A.USERID = "+genQuote(USERID)+" AND A.GRPNO = B.GRPNO (+) ")
                     .append(" order by schdlno ");
            }
            else if ("mssql".equals(strDbType))
            {
                  sqlQuery
                     .append(" SELECT A.*,B.* FROM TB_").append(COMCODE).append("_E10 A, TB_").append(COMCODE).append("_G10 B ")
                     .append(" WHERE "+genQuote(Year+Month+Day)+" BETWEEN A.SDATE AND A.LDATE " )
                     .append("       AND A.USERID = "+genQuote(USERID)+" AND A.GRPNO *= B.GRPNO ")
                     .append(" order by schdlno ");
            }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
                        System.out.println(" GCoPiSchedule::getSchdlEveryListTotal " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

       /**
        * <PRE>
        * ����ڿ� ���� ��,��,�Ͽ� ���� �Ϸ� ���� ����� ����Ʈ �Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : ����� ���̵�
        *                      <LI> String Year : ��
        *                      <LI> String Month : ��
        *                      <LI> String Day : ��
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */



	public GCmResultSet getSchdlEveryList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String Year = dmProp.getString("Year");
		String Month = dmProp.getString("Month");
		String Day = dmProp.getString("Day");


                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                         sqlQuery
                              .append(" SELECT A.*,B.* FROM TB_").append(COMCODE).append("_E10 A, TB_").append(COMCODE).append("_G10 B ")
                              .append(" WHERE "+genQuote(Year+Month+Day)+" BETWEEN A.SDATE AND A.LDATE AND SDATE != "+genQuote(Year+Month+Day))
                              .append("       AND A.USERID = "+genQuote(USERID)+" AND A.GRPNO = B.GRPNO (+) ")
                              .append(" UNION ")
                              .append(" SELECT A.*,B.* FROM TB_").append(COMCODE).append("_E10 A, TB_").append(COMCODE).append("_G10 B ")
                              .append(" WHERE SDATE = "+genQuote(Year+Month+Day)+" AND  A.USERID = "+genQuote(USERID)+" AND (STIME IS NULL OR STIME = '') ")
                              .append("       AND A.GRPNO = B.GRPNO (+) ");
                        }
                        else if ("mssql".equals(strDbType))
                             {
                          sqlQuery
                              .append(" SELECT A.*,B.* ")
                              .append(" FROM TB_").append(COMCODE).append("_E10 A, TB_").append(COMCODE).append("_G10 B ")
                              .append(" WHERE "+genQuote(Year+Month+Day)+" BETWEEN A.SDATE AND A.LDATE AND SDATE != "+genQuote(Year+Month+Day))
                              .append("       AND A.USERID = "+genQuote(USERID)+" AND A.GRPNO *= B.GRPNO ")
                              .append(" UNION ")
                              .append(" SELECT A.*,B.* ")
                              .append(" FROM TB_").append(COMCODE).append("_E10 A, TB_").append(COMCODE).append("_G10 B ")
                              .append(" WHERE SDATE = "+genQuote(Year+Month+Day)+" AND  A.USERID = "+genQuote(USERID)+" AND (STIME IS NULL OR STIME = '') ")
                              .append("       AND A.GRPNO *= B.GRPNO ");
                             }


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
                        System.out.println(" GCoPiSchedule::getSchdlEveryList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

       /**
        * <PRE>
        * ����ڿ� ���� ��,��,�Ͽ� ���� �Ϸ� ���� ����� ����Ʈ �Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : ����� ���̵�
        *                      <LI> String Year : ��
        *                      <LI> String Month : ��
        *                      <LI> String Day : ��
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */

	public GCmResultSet getMainSchdlList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String Year = dmProp.getString("Year");
		String Month = dmProp.getString("Month");
		String Day = dmProp.getString("Day");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                           sqlQuery
                              .append(" SELECT A.*,B.* FROM TB_").append(COMCODE).append("_E10 A, TB_").append(COMCODE).append("_G10 B ")
	                      .append(" WHERE "+genQuote(Year+Month+Day)+" BETWEEN A.SDATE AND A.LDATE ")
                              .append(" AND A.USERID = "+genQuote(USERID))
                              .append(" AND A.GRPNO = B.GRPNO (+) ")
                              .append(" ORDER BY A.TITLE ");
                        }
                        else if ("mssql".equals(strDbType))
                             {
                           sqlQuery
                              .append(" SELECT A.*,B.* FROM TB_").append(COMCODE).append("_E10 A, TB_").append(COMCODE).append("_G10 B ")
                              .append(" WHERE "+genQuote(Year+Month+Day)+" BETWEEN A.SDATE AND A.LDATE ")
                              .append(" AND A.USERID = "+genQuote(USERID))
                              .append(" AND A.GRPNO *= B.GRPNO  ")
                              .append(" ORDER BY A.TITLE ");
                             }


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
                	System.out.println(" GCoPiSchedule::getMainSchdlList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

       /**
        * <PRE>
        * ��������Ʈ (�ְ�/����������)
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : ����� ���̵�
        *                      <LI> String Year : ��
        *                      <LI> String Month : ��
        *                      <LI> String Day : ��
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */

	public GCmResultSet getSchdlList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String Year = dmProp.getString("Year");
		String Month = dmProp.getString("Month");
		String Day = dmProp.getString("Day");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                           sqlQuery
      			      .append(" SELECT A.*,B.* FROM TB_").append(COMCODE).append("_E10 A, TB_").append(COMCODE).append("_G10 B ")
                              .append(" WHERE "+genQuote(Year+Month+Day)+" between A.SDATE and A.LDATE ")
                              .append(" AND A.USERID ="+genQuote(USERID))
                              .append(" AND A.GRPNO = B.GRPNO(+) ");
                        }
                        else if ("mssql".equals(strDbType))
                        {

                           sqlQuery
                              .append(" SELECT A.*,B.* FROM TB_").append(COMCODE).append("_E10 A, TB_").append(COMCODE).append("_G10 B ")
                              .append(" WHERE "+genQuote(Year+Month+Day)+" between A.SDATE and A.LDATE ")
                              .append(" AND A.USERID ="+genQuote(USERID))
                              .append(" AND A.GRPNO *= B.GRPNO  ");
                             }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoPiSchedule::getSchdlList "+ e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

       /**
        * <PRE>
        * ��������Ʈ �ð��� ����Ʈ.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : ����� ���̵�
        *                      <LI> String Year : ��
        *                      <LI> String Month : ��
        *                      <LI> String Day : ��
        *                      <LI> String Time : �ð�
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
   	public GCmResultSet getSchdlTimeList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String Year = dmProp.getString("Year");
		String Month = dmProp.getString("Month");
		String Day = dmProp.getString("Day");
		String Time = dmProp.getString("Time");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                           sqlQuery
                              .append(" SELECT A.* ,B.* ")
                              .append(" FROM TB_").append(COMCODE).append("_E10 A, TB_").append(COMCODE).append("_G10 B ")
                              .append(" WHERE A.SDATE = "+genQuote(Year+Month+Day))
                              .append("       AND A.STIME LIKE "+genQuote(Time + "%"))
                              .append("       AND A.USERID = "+genQuote(USERID)+" AND A.GRPNO = B.GRPNO (+)  ")
                              .append(" ORDER BY A.TITLE ");
                        }
                        else if ("mssql".equals(strDbType))
                             {
                           sqlQuery
                              .append(" SELECT A.* ,B.* ")
                              .append(" FROM TB_").append(COMCODE).append("_E10 A, TB_").append(COMCODE).append("_G10 B ")
                              .append(" WHERE A.SDATE = "+genQuote(Year+Month+Day))
                              .append("       AND A.STIME LIKE "+genQuote(Time + "%"))
                              .append("       AND A.USERID = "+genQuote(USERID)+" AND A.GRPNO *= B.GRPNO ")
                              .append(" ORDER BY A.TITLE ");
                             }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoPiSchedule::getSchdlTimeList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

       /**
        * <PRE>
        * ����ڿ� ���� ���� �뺸�� ����Ʈ.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : ����� ���̵�
        *                      <LI> String Schdlno : ������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
   	public GCmResultSet getDeliverList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmLog log = new GCmLog(GCmConstDef.GROUPWARE_ID);
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String Schdlno = dmProp.getString("Schdlno");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT distinct t2.username username, t2.userid userid ")
                           .append(" FROM TB_").append(COMCODE).append("_E10 t1, TB_COMM_Z20 t2 ")
                           .append(" WHERE t1.userid = t2.userid AND t1.WRITERID = "+genQuote(USERID)+" AND t1.SCHDLNO = "+genQuote(Schdlno));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoPiSchedule::getDeliverList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}
}