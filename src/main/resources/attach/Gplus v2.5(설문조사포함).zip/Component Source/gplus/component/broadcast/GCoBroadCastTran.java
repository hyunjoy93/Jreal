package gplus.component.broadcast;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

/**
 * <PRE>
 * Filename	: GCoBroadCastTran.java
 * Class	: gplus.component.draft.GCoBroadCastTran
 * Fuction  :
 * Comment	:
 * History  : 26/03/2002, ���߱� �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GCoBroadCastTran extends GCmTopComponent
{
       /**
        * <PRE>
        * ���޵� ��忡 ���� �������� ����Ѵ�. ��尡 d�̸� ���� �������� �����ϰ� ��尡 null�̸� �������� ����Ѵ�.
        * ��������ȣ�� ���Ͽ� ����/������ ����� �����Ѵ�. ��������ȣ�� null�� ��� deleteDraftSubLine,deleteDraftLine����
        * �������� �����ϰ� ��尡 d�� �ƴϸ� insertDraftLine���� �������� ����ϰ� insertSubDraftLine���� ��������
        * �������� ����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Mode : ��� (d:����, null:�Է�)
        *                      <LI> String Linenum : ��������ȣ
        *                      <LI> String Line2 : �������
        *                      <LI> String Line3 : �������
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int broadCastLineToDb(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String Lineno = dmProp.getString("Lineno");
   		String Linename = dmProp.getString("Linename");
		String Linenote = dmProp.getString("Linenote");
		String Mode = dmProp.getString("Mode");
		String Line = dmProp.getString("Acctlist");
        String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		int rv=0;

		GCmConnection conn = null;
		Statement stmt = null;
        StringBuffer SqlQuery = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();
			stmt = conn.createStatement();

            conn.setAutoCommit(true);

            if (!Lineno.equals(""))
            {
  			     SqlQuery = new StringBuffer()
					.append(" DELETE FROM TB_").append(COMCODE).append("_F31 ")
					.append(" WHERE BROADCASTNO = "+genQuote(Lineno));

	             rv = stmt.executeUpdate(SqlQuery.toString());

  			     SqlQuery = new StringBuffer()
					.append(" DELETE FROM TB_").append(COMCODE).append("_F30 ")
					.append(" WHERE BROADCASTNO = "+genQuote(Lineno));

		         rv = stmt.executeUpdate(SqlQuery.toString());
                 if( rv <= 0 ) throw new Exception(" During broadCastLineToDb error !!!");
            }

            if (!Mode.equals("d"))
            {
                 String newLinenum = getMaxNo(COMCODE,strDbType);

			     SqlQuery = new StringBuffer()
					.append(" INSERT INTO TB_").append(COMCODE).append("_F30 ")
                    .append(" (BROADCASTNO,TITLE,USERID,NOTE) ")
                    .append("  VALUES ("+genQuote(newLinenum)+","+genQuote(Linename)+","+genQuote(USERID)+","+genQuote(Linenote)+") ");

	              rv = stmt.executeUpdate(SqlQuery.toString());
                  if( rv <= 0 ) throw new Exception(" During broadCastLineToDb error !!!");


                 java.util.Vector vLine = gplus.commlib.util.GCmFcts.getSplit(Line,",");

                 int i=0;
                 while(i < vLine.size())
                 {
                       java.util.Vector vTmp = gplus.commlib.util.GCmFcts.getSplit((String)vLine.elementAt(i),"#");

                       SqlQuery = new StringBuffer()
					      .append(" INSERT INTO TB_").append(COMCODE).append("_F31 ")
                          .append(" (BROADCASTNO,ACCTINFO,USERNAME,BROADTYPE) ")
                          .append("  VALUES ("+genQuote(newLinenum)+","+genQuote(((String)vTmp.elementAt(0)).substring(1))+","+genQuote((String)vTmp.elementAt(1))+","+genQuote(((String)vTmp.elementAt(0)).substring(0,1))+") ");

                       rv = stmt.executeUpdate(SqlQuery.toString());
                       if( rv <= 0 ) throw new Exception(" During broadCastLineToDb error !!!");
                       i++;
                 }

            }

			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoBroadCastTran::broadCastLineToDb : " + ignored.getMessage());
			}

	 		System.out.println(" GCoBroadCastTran::broadCastLineToDb : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoBroadCastTran::broadCastLineToDb : " + e.getMessage());
			}
			conn.close();
		}
	}


	public int updateBroadList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String oldemail = dmProp.getString("oldemail");
		String Email = dmProp.getString("Email");
		String Mailusername = dmProp.getString("Mailusername");
        String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" UPDATE TB_"+COMCODE+"_F31 ")
                    .append(" SET ACCTINFO = "+genQuote(Email)+", USERNAME = "+genQuote(Mailusername))
					.append(" WHERE ACCTINFO = "+genQuote(oldemail)+" AND ")
                    .append("       BROADCASTNO IN ( SELECT BROADCASTNO ")
                    .append("                        FROM TB_"+COMCODE+"_F30 ")
                    .append("                        WHERE USERID = "+genQuote(USERID)+" )");

			stmt = conn.createStatement();

			conn.setAutoCommit(false);
            stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return 1;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoBroadCastTran::updateBroadList : " + ignored.getMessage());
			}

	 		System.out.println(" GCoBroadCastTran::updateBroadList : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoBroadCastTran::updateBroadList : " + e.getMessage());
			}
			conn.close();
		}
	}

	public int deleteBroadList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String oldemail = dmProp.getString("oldemail");
		String Email = dmProp.getString("Email");
		String Mailusername = dmProp.getString("Mailusername");
        String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" DELETE TB_"+COMCODE+"_F31 ")
					.append(" WHERE ACCTINFO = "+genQuote(oldemail)+" AND ")
                    .append("       BROADCASTNO IN ( SELECT BROADCASTNO ")
                    .append("                        FROM TB_"+COMCODE+"_F30 ")
                    .append("                        WHERE USERID = "+genQuote(USERID)+" )");

			stmt = conn.createStatement();

			conn.setAutoCommit(false);
            stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return 1;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoBroadCastTran::updateBroadList : " + ignored.getMessage());
			}

	 		System.out.println(" GCoBroadCastTran::updateBroadList : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoBroadCastTran::updateBroadList : " + e.getMessage());
			}
			conn.close();
		}
	}

	   /**
        * <PRE>
        * ��������Ͽ� ��ϵǴ� �ű԰�������ȣ�� �����ϴ� �����Լ��̸�,
        * �����Ǵ� �ű԰�������ȣ�� �ش���+�Ϸù�ȣ������ �����ȴ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String strDbType : gplus db type
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return String : �ű԰�������ȣ
        */
    	private String getMaxNo(String comcode,String strDbType)
    	{

		GCmConnection conn = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

            if ("oracle".equals(strDbType))
            {
                   sqlQuery
	          	      .append(" SELECT DECODE(SUBSTR(MAX(BROADCASTNO),1,8),TO_CHAR(sysdate,'YYYYMMDD'),TO_CHAR(TO_NUMBER(MAX(BROADCASTNO))+1),null,TO_CHAR(sysdate,'YYYYMMDD')||'0001') as NO ")
                      .append(" FROM TB_").append(comcode).append("_F30 ")
                      .append(" WHERE BROADCASTNO LIKE TO_CHAR(sysdate,'YYYYMMDD')||'%'");
            }
            else if ("mssql".equals(strDbType))
                 {
                        sqlQuery
                           .append(" SELECT (CASE SUBSTRING(MAX(BROADCASTNO),1,8) WHEN convert(char(08),getdate(),112) THEN CAST(SUBSTRING(MAX(BROADCASTNO),1,8) AS varchar(8)) + RIGHT('0000'+CAST(SUBSTRING(MAX(BROADCASTNO),9,4)+1 AS varchar(4)),4) ELSE convert(char(08),getdate(),112)+'0001' END) as NO ")
                           .append(" FROM TB_").append(comcode).append("_F30 ")
                           .append(" WHERE BROADCASTNO LIKE convert(char(08),getdate(),112)+'%' ");
                 }


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
            rs.next();

			return rs.getString("NO");

      		}
      		catch (Exception e)
      		{
 			System.out.println(" GCoDfDraftTran::getMaxNo " + e.getMessage());
	 		return null;
      		}
      		finally
      		{
			conn.close();
      		}
    	}

}