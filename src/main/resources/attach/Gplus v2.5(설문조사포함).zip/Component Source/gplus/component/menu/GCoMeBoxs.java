package gplus.component.menu;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

/**
 * <PRE>
 * Filename		: GCoMeBoxs.java
 * Class		: gplus.component.pos.GCoMeBoxs
 * Fuction		: �������� ������
 * Comment		:
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCoMeBoxs extends GCmTopComponent
{
      /**
        * <PRE>
        * ������� ���� ã��
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String PARENTNO : �����Թ�ȣ
        *                      <LI> String BOXCLASS : ������
        *                      <LI> String EXECCLASS : ����������
        *                      <LI> String USERID     : ������
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : �Թ�ȣ (BOXNO)
        */
	public GCmResultSet getBoxNo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String Parentno = dmProp.getString("PARENTNO");
		String Boxclass  = dmProp.getString("BOXCLASS");
		String Execclass = dmProp.getString("EXECCLASS");
		String UserId = dmProp.getString("USERID");



		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT BOXNO ")
                           .append(" FROM TB_").append(COMCODE).append("_M10 ")
                           .append(" WHERE PARENTNO = "+genQuote(Parentno))
						   .append(" AND BOXCLASS = " + genQuote(Boxclass))
						   .append(" AND EXECCLASS = " + genQuote(Execclass))
						   .append(" AND USERID = " + genQuote(UserId));



			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoMeBoxs:getBoxNo " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

      /**
        * <PRE>
        * ���ڰ���, ���ڿ��� �Ǳ���
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String PARENTNO : �����Թ�ȣ
        *                      <LI> String BOXCLASS : ������
        *                      <LI> String USERID     : ������
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet
        */
	public GCmResultSet getTabSubmenu(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String Parentno = dmProp.getString("PARENTNO");
		String Boxclass  = dmProp.getString("BOXCLASS");
		String UserId = dmProp.getString("USERID");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                                        .append(" SELECT BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,BOXTYPE,BOXNAME,BASEFLAG,PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE ")
                                        .append(" FROM TB_").append(COMCODE).append("_M10 ")
                                        .append(" WHERE PARENTNO = "+genQuote(Parentno))
				        .append(" AND BOXCLASS = " + genQuote(Boxclass))
					.append(" AND USERID = " + genQuote(UserId))
					.append(" ORDER BY EXECCLASS, BOXNO");

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoMeBoxs:getTabSubmenu " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

   /**
    * <PRE>
    * TOP �޴������� ������ ����Ʈ�� �����ϱ� ���Ͽ� ���޵� �������� ����� ID�� �� ����Ʈ�� �˻��Ͽ� �ǵ����ش�.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String boxclass : ������
    *                      <LI> String pubflag : ������ ����
    *                      <LI> String boxtype : ������
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : ���������� (BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,BOXTYPE,
    *                                            BOXNAME,BASEFLAG,PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE)
    */
	public GCmResultSet getMenuBoxList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String boxclass = dmProp.getString("boxclass");
		String pubflag = dmProp.getString("pubflag");
		String boxtype = dmProp.getString("boxtype");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,BOXTYPE,BOXNAME,BASEFLAG,PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE ")
                           .append(" FROM TB_").append(COMCODE).append("_M10 ")
                           .append(" WHERE PARENTNO = '000000000000' AND BOXCLASS = "+genQuote(boxclass))
                           .append("       AND PUBFLAG = "+genQuote(pubflag)+" AND BOXTYPE = "+genQuote(boxtype))
                           .append(" ORDER BY BOXNO ");

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoMeBoxs::getMenuBoxList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

   /**
    * <PRE>
    * TOP �޴������� ��������� �����ϱ� ���Ͽ� ���޵� �������� ����� ID�� �� ����Ʈ�� �˻��Ͽ� �ǵ����ش�.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String USERID : current user id at session
    *                      <LI> String boxclass : ������
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : ���������� (BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,BOXTYPE,
    *                                            BOXNAME,BASEFLAG,PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE)
    */
	public GCmResultSet setMenuDocBoxList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String boxclass = dmProp.getString("boxclass");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,BOXTYPE,BOXNAME,BASEFLAG,PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE ")
                           .append(" FROM TB_").append(COMCODE).append("_M10 ")
                           .append(" WHERE PARENTNO = '000000000000' AND BOXCLASS = "+genQuote(boxclass))
                           .append("       AND USERID = "+genQuote(USERID))
                           .append(" ORDER BY BOXNO ");

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoMeBoxs::setMenuDocBoxList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

       /**
        * <PRE>
        * �Խ�/����/����/����� ��Ͽ��� ȸ�� ������ ����� �˻��Ͽ� �����ش�.
        * GCmConstDef.BOXTYPE_COM,GCmConstDef.PUBFLAG_ON�� ���� �������� �Ͽ�
        * �ش��ϴ� �Ը���� �˻��Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : �Խ�/����/����/����� ��� (BOXNO,BOXNAME)
        */
	public GCmResultSet getPubBoxList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT BOXNO,BOXNAME ")
                           .append(" FROM TB_"+COMCODE+"_M10 ")
                           .append(" WHERE BOXTYPE = "+genQuote(GCmConstDef.BOXTYPE_COM)+" AND PUBFLAG = "+genQuote(GCmConstDef.PUBFLAG_ON));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoMeBoxs::getPubBoxList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

       /**
        * <PRE>
        * �Խ�/����/����/����� ��� Tree�� �����ϱ� ���ؼ� ���޵� ������ �˻��Ͽ�
        * �ش��ϴ� �Խ�/����/����/����� ����� �ǵ��� �ش�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String rootno : ������ ��ȣ
        *                      <LI> String Boxclass : ������
        *                      <LI> String Boxtype : ������
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : �Խ�/����/����/����� ��� (BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,
        *                                    BOXTYPE,BOXNAME,BASEFLAG,PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE)
        */
	public GCmResultSet getDrawTree(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String rootno = dmProp.getString("rootno");
		String Boxclass = dmProp.getString("Boxclass");
		String Boxtype = dmProp.getString("Boxtype");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT  BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,BOXTYPE,BOXNAME,BASEFLAG,PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE ")
                           .append(" FROM TB_").append(COMCODE).append("_M10 ")
                           .append(" WHERE PARENTNO = "+genQuote(rootno)+" AND BOXCLASS = "+genQuote(Boxclass)+" AND ( BOXTYPE = "+genQuote(Boxtype)+"  OR BOXTYPE ='3') ");

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoMeBoxs::getDrawTree : " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

       /**
        * <PRE>
        * �Խ��� Tree�� �����ϱ� ���ؼ� ���޵� ������ ����������ϰ� �Խ�/����/����/����� �����
        * ���ΰ˻��Ͽ� �ش��ϴ� �Խ��� ������ �ǵ��� �ش�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String rootno : ������ ��ȣ
        *                      <LI> String Boxclass : ������
        *                      <LI> String Boxtype : ������
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : �Խ��� ���� (FLDNO,BOXNO,DOCNO,PARENTNO,FLDNAME,REGUSER,REGDATE,
        *                                              TRASHFLAG,COMMENTS,REFNO,BOXNO, BOXNAME)
        */
	public GCmResultSet getDocTreeList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String rootno = dmProp.getString("rootno");
		String Boxclass = dmProp.getString("Boxclass");
		String Boxtype = dmProp.getString("Boxtype");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                           sqlQuery
                             .append(" SELECT * ")
                             .append(" FROM (SELECT FLDNO,BOXNO,DOCNO,PARENTNO,FLDNAME,REGUSER,REGDATE,TRASHFLAG,COMMENTS,REFNO ")
                             .append("       FROM TB_").append(COMCODE).append("_B10 ")
                             .append("       WHERE PARENTNO = "+genQuote(rootno)+" AND (DOCNO IS NULL OR DOCNO = '`')) T1, ")
                             .append("      (SELECT BOXNO,BOXNAME,BOXCLASS,EXECCLASS ")
                             .append("       FROM TB_").append(COMCODE).append("_M10 ")
                             .append("       WHERE PARENTNO = "+genQuote(rootno)+" AND BOXCLASS = "+genQuote(Boxclass)+" AND BOXTYPE = "+genQuote(Boxtype)+") T2 ")
                             .append(" WHERE T1.BOXNO = T2.BOXNO ");
                        }
                        else if ("mssql".equals(strDbType))
                             {
                                   sqlQuery
                                      .append(" SELECT * ")
                                      .append(" FROM (SELECT FLDNO,BOXNO,DOCNO,PARENTNO,FLDNAME,REGUSER,REGDATE,TRASHFLAG,COMMENTS,REFNO ")
                                      .append("       FROM TB_").append(COMCODE).append("_B10 ")
                                      .append("       WHERE PARENTNO = "+genQuote(rootno)+" AND (DOCNO = '' OR DOCNO = '`')) T1, ")
                                      .append("      (SELECT BOXNO,BOXNAME,BOXCLASS,EXECCLASS ")
                                      .append("       FROM TB_").append(COMCODE).append("_M10 ")
                                      .append("       WHERE PARENTNO = "+genQuote(rootno)+" AND BOXCLASS = "+genQuote(Boxclass)+" AND BOXTYPE = "+genQuote(Boxtype)+") T2 ")
                                      .append(" WHERE T1.BOXNO = T2.BOXNO ");
                             }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoMeBoxs::getDocTreeList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}
       /**
        * <PRE>
        * ������ Tree�� �����ϱ� ���ؼ� ���޵� ������ �������� ����� �˻��Ͽ� �ش��ϴ� ������������ �ǵ��� �ش�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String rootno : �������� ��ȣ
        *                      <LI> String Boxno : �Թ�ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : ���������� (FLDNO,BOXNO,DOCNO,PARENTNO,FLDNAME,REGUSER,REGDATE,
        *                                            TRASHFLAG,COMMENTS,REFNO)
        */
	public GCmResultSet getDrawDocFolderTree(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String rootno = dmProp.getString("rootno");
		String Boxno = dmProp.getString("Boxno");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                           sqlQuery
                             .append(" SELECT FLDNO,BOXNO,DOCNO,PARENTNO,FLDNAME,REGUSER,REGDATE,TRASHFLAG,COMMENTS,REFNO ")
                             .append(" FROM TB_").append(COMCODE).append("_B10 ")
                             .append(" WHERE PARENTNO = "+genQuote(rootno)+" AND BOXNO = "+genQuote(Boxno)+" AND (DOCNO IS NULL OR DOCNO = '`') ");
                        }
                        else if ("mssql".equals(strDbType))
                             {
                                   sqlQuery
                                      .append(" SELECT FLDNO,BOXNO,DOCNO,PARENTNO,FLDNAME,REGUSER,REGDATE,TRASHFLAG,COMMENTS,REFNO ")
                                      .append(" FROM TB_").append(COMCODE).append("_B10 ")
                                      .append(" WHERE PARENTNO = "+genQuote(rootno)+" AND BOXNO = "+genQuote(Boxno)+" AND (DOCNO = '' OR DOCNO = '`') ");
                             }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoMeBoxs::getDrawDocFolderTree " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� �Թ�ȣ�� ������ �Խ�/����/����/����Ը���� �˻��Ͽ� �ش��ϴ�
        * �Խ�/����/����/����������� �ǵ��� �ش�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Boxno : �Թ�ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : �Խ�/����/����/��������� (BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,
        *                              BOXTYPE,BOXNAME,BASEFLAG,PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE)
        */
	public GCmResultSet getBoxInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String Boxno = dmProp.getString("Boxno");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,BOXTYPE,BOXNAME,BASEFLAG,PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE ")
                           .append(" FROM TB_").append(COMCODE).append("_M10 ")
                           .append(" WHERE BOXNO = "+genQuote(Boxno));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoMeBoxs::getBoxInfo " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� �Թ�ȣ�� ������ �ش��ϴ� �Թ�ȣ�� ���������� ������ �Խ�/����/����/����Ը����
        * �˻��Ͽ� �ش��ϴ� �������� �Թ�ȣ ����� �ǵ��� �ش�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Boxno : �Թ�ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : �Թ�ȣ (BOXNO)
        */
	public GCmResultSet getChildBox(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String Boxno = dmProp.getString("Boxno");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT BOXNO ")
                           .append(" FROM TB_").append(COMCODE).append("_M10 ")
                           .append(" WHERE PARENTNO = "+genQuote(Boxno));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoMeBoxs::getChildBoxCnt " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}
}