package gplus.component.draft;


import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

/**
 * <PRE>
 * Filename	: GCoDfApprovalTran.java
 * Class		    : gplus.component.draft.GCoDfApprovalTran
 * Fuction	    :
 * Comment	:
 * History       : 2/5/2002, ������, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCoDfApprovalTran extends GCmTopComponent
{


	/**
	 * <PRE>
	 *  ������º���
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�	<BR>
	 *				<LI> String APPRDATE    : �����ȣ  <BR>
	 *				<LI> String APPRTYPE    : ��������  <BR>
	 *				<LI> String DRFTNO        : ��ȹ�ȣ  <BR>
	 *				<LI> String SEQ             : ����         <BR>
	 *				<LI> String REFTYPE      : ������������  <BR>
	 *				<LI> String APPRID         : ������ID  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  Boolean
	 */
	public boolean updateApproval(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmLog log = new GCmLog(GCmConstDef.GROUPWARE_ID);
		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strApprDate   = dmProp.getString("APPRDATE");
		String strApprType   = dmProp.getString("APPRTYPE");
		String strDraftNo     = dmProp.getString("DRFTNO");
		String strSeq         = dmProp.getString("SEQ");
		String strRefType   = dmProp.getString("REFTYPE");
		String strApprId     = dmProp.getString("APPRID");


		try
		{
			conn = GCmDbManager.getInstance().getConnection();


			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
							.append(" UPDATE TB_").append(strComCode).append("_D11 SET ")
							.append(" APPRDATE = " + genQuote(strApprDate))
							.append(" , APPRTYPE = " + genQuote(strApprType))
							.append(" WHERE DRFTNO = " + genQuote(strDraftNo))
							.append(" AND SEQ = " + genQuote(strSeq))
							.append(" AND REFTYPE = " + genQuote(strRefType))
							.append(" AND APPRID = " + genQuote(strApprId));


			conn.executeUpdate(sqlQuery.toString());

			conn.commit();

			return true;

		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoDfApprovalTran :: updateApproval" + ignored.getMessage());
			}


			System.out.println("GCoDfApprovalTran :: updateApproval " + e.getMessage());

			return false;


		}
		finally
		{
			conn.close();
		}
	}





	/**
	 * <PRE>
	 *  ������ �ٲٱ�
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�	<BR>
	 *				<LI> String BOXNO         : �Թ�ȣ  <BR>
	 *				<LI> String REGDRFTNO : ���α�ȹ�ȣ  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  Boolean
	 */

	public boolean updateBox(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmLog log = new GCmLog(GCmConstDef.GROUPWARE_ID);
		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strBoxNo      = dmProp.getString("BOXNO");
		String strRegDraftNo = dmProp.getString("REGDRFTNO");



		try
		{
			conn = GCmDbManager.getInstance().getConnection();


			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
							.append(" UPDATE TB_").append(strComCode).append("_D20 SET ")
							.append(" BOXNO = " + genQuote(strBoxNo))
							.append(" WHERE REGDRFTNO = " + genQuote(strRegDraftNo));



			conn.executeUpdate(sqlQuery.toString());

			conn.commit();

			return true;

		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoDfApprovalTran :: updateBox"  + ignored.getMessage());
			}


			System.out.println("GCoDfApprovalTran :: updateBox"  + e.getMessage());

			return false;


		}
		finally
		{
			conn.close();
		}
	}





	/**
	 * <PRE>
	 *  ��ȸ�� ������º���
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�	<BR>
	 *				<LI> String APPRTYPE    : �������  <BR>
	 *				<LI> String DRFTNO        : ��ȹ�ȣ  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  Boolean
	 */

	public boolean updateApprovalType(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmLog log = new GCmLog(GCmConstDef.GROUPWARE_ID);
		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strApprType  = dmProp.getString("APPRTYPE");
		String strDraftNo     = dmProp.getString("DRFTNO");



		try
		{
			conn = GCmDbManager.getInstance().getConnection();


			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
							.append(" UPDATE TB_").append(strComCode).append("_D10 SET ")
							.append(" APPRTYPE = " + genQuote(strApprType))
							.append(" WHERE DRFTNO = " + genQuote(strDraftNo));



			conn.executeUpdate(sqlQuery.toString());

			conn.commit();

			return true;

		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoDfApproval :: updateApprovalType" + ignored.getMessage());
			}

			System.out.println("GCoDfApproval :: updateApprovalType" + e.getMessage());

			return false;


		}
		finally
		{
			conn.close();
		}
	}







	/**
	 * <PRE>
	 *  ������
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�	<BR>
	 *				<LI> String DRFTNO        : ��ȹ�ȣ  <BR>
	 *				<LI> String TARGET        : ��������������  <BR>
	 *				<LI> String SRC             : ����������  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  Boolean
	 */

	public boolean draftCancel(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmLog log = new GCmLog(GCmConstDef.GROUPWARE_ID);
		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strDraftNo     = dmProp.getString("DRFTNO");
		String strTarget      = dmProp.getString("TARGET");
		String strSrc          = dmProp.getString("SRC");
		String strApprId = "";

		try
		{
			conn = GCmDbManager.getInstance().getConnection();


			conn.setAutoCommit(false);

			//����� ã��
			StringBuffer sqlQuery = new StringBuffer()
							.append(" SELECT DRFTID FROM TB_").append(strComCode).append("_D10 ")
							.append(" WHERE DRFTNO = " + genQuote(strDraftNo));


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());


			while(rs.next()) {

				strApprId = rs.getString("DRFTID");
			}


	        if (strApprId != null && !strApprId.equals("")) {


				//���������Կ��� �ӽú���������
				StringBuffer sqlQuery2 = new StringBuffer()
							.append(" UPDATE TB_").append(strComCode).append("_D20 ")
							.append(" SET BOXNO = ")
							.append(" (SELECT BOXNO FROM TB_").append(strComCode).append("_M10 ")
							.append(" WHERE BOXCLASS = " + genQuote(GCmConstDef.BOXCLASS_DRAFT))
							.append(" AND EXECCLASS = " + genQuote(strTarget))
							.append(" AND BOXTYPE = " + genQuote(GCmConstDef.BOXTYPE_PRIVATE))
							.append(" AND USERID = " + genQuote(strApprId)).append(" ) ")
							.append(" WHERE BOXNO = ( SELECT BOXNO FROM TB_").append(strComCode).append("_M10 ")
							.append(" WHERE BOXCLASS = " + genQuote(GCmConstDef.BOXCLASS_DRAFT))
							.append(" AND EXECCLASS = " + genQuote(strSrc))
							.append(" AND BOXTYPE = " + genQuote(GCmConstDef.BOXTYPE_PRIVATE))
							.append(" AND USERID = " + genQuote(strApprId)).append(" ) ")
							.append(" AND DRFTNO = " + genQuote(strDraftNo));


				conn.executeUpdate(sqlQuery2.toString());

			}



			//���缱�� ������ ã��
			StringBuffer sqlQuery3 = new StringBuffer()
						.append(" SELECT APPRID FROM TB_").append(strComCode).append("_D11 ")
						.append(" WHERE DRFTNO = " + genQuote(strDraftNo));


			GCmResultSet rs2 = conn.executeQuery(sqlQuery3.toString());



			while(rs2.next()) {

				//���缱�� �����ڵ� ��ȸ�� ����
				StringBuffer sqlQuery4 = new StringBuffer()
						.append(" DELETE FROM TB_").append(strComCode).append("_D20 ")
						.append(" WHERE BOXNO = ( SELECT BOXNO FROM TB_").append(strComCode).append("_M10 ")
						.append(" WHERE USERID = " + genQuote(rs2.getString("APPRID")))
						.append(" AND BOXCLASS = " + genQuote(GCmConstDef.BOXCLASS_DRAFT))
						.append(" AND EXECCLASS = " + genQuote(GCmConstDef.EXECCLASS_DRAFT_INBOX))
						.append(" AND BOXTYPE = " + genQuote(GCmConstDef.BOXTYPE_PRIVATE)).append(" ) ")
						.append(" AND DRFTNO = " + genQuote(strDraftNo));


				conn.executeUpdate(sqlQuery4.toString());

			}


			conn.commit();

			return true;

		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoDfApprovalTran :: draftCancel" + ignored.getMessage());
			}


			System.out.println("GCoDfApprovalTran :: draftCancel" + e.getMessage());

			return false;


		}
		finally
		{
			conn.close();
		}
	}






/**
	 * <PRE>
	 *  ���������� ����(�����Ժ� ��ȸ�Ͽ��� ����)
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�	<BR>
	 *				<LI> String DRFTNO        : ��ȹ�ȣ  <BR>
	 *				<LI> String SEQ              : ����  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  Boolean
	 */

	public boolean upApprDelete(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmLog log = new GCmLog(GCmConstDef.GROUPWARE_ID);
		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strDraftNo  = dmProp.getString("DRFTNO");
		String strSeq           = dmProp.getString("SEQ");



		try
		{
			conn = GCmDbManager.getInstance().getConnection();


			conn.setAutoCommit(false);



			StringBuffer sqlQuery = new StringBuffer()
							.append(" SELECT APPRID, SEQ FROM TB_").append(strComCode).append("_D11 ")
							.append(" WHERE DRFTNO = " + genQuote(strDraftNo))
							.append(" AND SEQ > " + genQuote(strSeq));
//							.append(" AND SEQ BETWEEN " + genQuote(strSeq)).append(" AND '07' ")
//							.append(" AND REFTYPE = '1' ");


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());



			while (rs.next())
			{
				// ������������ �����Ժ���ȸ�Ͽ��� ��Ȼ���
				StringBuffer sqlQuery2 = new StringBuffer()
							.append(" DELETE FROM TB_").append(strComCode).append("_D20 ")
							.append(" WHERE REGDRFTNO = (SELECT REGDRFTNO FROM TB_").append(strComCode).append("_D20 ")
							.append(" WHERE BOXNO = (SELECT BOXNO FROM TB_").append(strComCode).append("_M10 ")
							.append(" WHERE BOXCLASS = " + genQuote(GCmConstDef.BOXCLASS_DRAFT))
							.append(" AND EXECCLASS = " + genQuote(GCmConstDef.EXECCLASS_DRAFT_INBOX))
							.append(" AND BOXTYPE = " + genQuote(GCmConstDef.BOXTYPE_PRIVATE))
							.append(" AND USERID = " + genQuote(rs.getString("APPRID"))).append(" ) ")
							.append(" AND DRFTNO = " + genQuote(strDraftNo)).append(" ) ");


				conn.executeUpdate(sqlQuery2.toString());


			}


			conn.commit();

			return true;

		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoDfApprovalTran :: upApprDelete" + ignored.getMessage());
			}

			System.out.println("GCoDfApprovalTran :: upApprDelete" + e.getMessage());

			return false;


		}
		finally
		{
			conn.close();
		}
	}






	/**
	 * <PRE>
	 *  �ݷ�
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�	<BR>
	 *				<LI> String	DRFTNO        : ��ȹ�ȣ  <BR>
	 *				<LI> String SEQ             : ����  <BR>
	 *				<LI> String DRFTID         :  �����ID  <BR>
	 *				<LI> String CURAPPRID   : ���������ID      <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  Boolean
	 */

	public boolean draftReject(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmLog log = new GCmLog(GCmConstDef.GROUPWARE_ID);
		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strDraftNo    = dmProp.getString("DRFTNO");
		String strSeq          = dmProp.getString("SEQ");
		String strDraftId       = dmProp.getString("DRFTID");
		String strCurApprId = dmProp.getString("CURAPPRID");



		try
		{
			conn = GCmDbManager.getInstance().getConnection();


			conn.setAutoCommit(false);



			 // �����ܰ� ������ ����Ʈ
			StringBuffer sqlQuery = new StringBuffer()
							.append("SELECT APPRID, SEQ FROM TB_").append(strComCode).append("_D11 ")
							.append(" WHERE DRFTNO = " + genQuote(strDraftNo))
							.append(" AND SEQ < " + genQuote(strSeq))
							.append(" AND REFTYPE = '1' ");


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());


			//�����ܰ� �������� ���縦  �ݷ������� �̵�(������ Parameter 1 -> ����)
			while (rs.next())
			{

					updateDraftReject(conn, strComCode, rs.getString("APPRID"), GCmConstDef.EXECCLASS_DRAFT_SENDBOX, strDraftNo, "1");

			}


			//������� ���縦 �ݷ������� �̵�(������ Parameter 0 -> ���)
			updateDraftReject(conn, strComCode, strDraftId, GCmConstDef.EXECCLASS_DRAFT_SENDBOX, strDraftNo, "0");


			// ����������� ���縦 �ݷ�������(������ Parameter 1 -> ����)
			updateDraftReject(conn, strComCode, strCurApprId, GCmConstDef.EXECCLASS_DRAFT_INBOX, strDraftNo, "1");


			conn.commit();

			return true;

		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoDfApprovalTran :: draftReject" + ignored.getMessage());
			}


			System.out.println("GCoDfApprovalTran :: draftReject" + e.getMessage());

			return false;


		}
		finally
		{
			conn.close();
		}
	}




	/**
	 * <PRE>
	 *  ��ȹ����� �ݷ������� �̵�
	 * </PRE>
	 *
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						    <BR>
	 *				<TT><UL>
     *				<LI> String COMCODE       : ȸ���ڵ�  <BR>
	 *				<LI> String APPRID            : ������ID	<BR>
	 *				<LI> String BOX                 : ������(�Ϸ������ : EXECCLASS_DRAFT_ENDBOX , ���������� : EXECCLASS_DRAFT_INBOX)	<BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @
	 */

	public void  updateDraftReject(GCmConnection conn, String comCode, String userId, String box , String draftNo, String refType)
		throws GCmProcessingErrorException, GCmParameterErrorException
	{


		GCmLog log = new GCmLog(GCmConstDef.GROUPWARE_ID);
		int intCount = 0;

		try
		{


			// parameter check
			if (conn == null)
			{
				throw new GCmParameterErrorException("updateDraftReject() connection object is null...");
			}
			else if ((comCode == null) || (comCode.equals("")))
			{
				throw new GCmParameterErrorException("updateDraftReject() comCode parameter is null...");
			}
			else if ((userId == null) || (userId.equals("")))
			{
				throw new GCmParameterErrorException("updateDraftReject() userId parameter is null...");
			}
			else if ((box == null) || (box.equals("")))
			{
				throw new GCmParameterErrorException("updateDraftReject() box parameter is null...");
			}
			else if ((draftNo == null) || (draftNo.equals("")))
			{
				throw new GCmParameterErrorException("updateDraftReject() draftNo parameter is null...");
			}
			else if ((refType == null) || (refType.equals("")))
			{
				throw new GCmParameterErrorException("updateDraftReject() refType parameter is null...");
			}

			StringBuffer sqlQuery = new StringBuffer()
							.append(" UPDATE  TB_").append(comCode).append("_D20 ")
							.append(" SET BOXNO = (SELECT BOXNO FROM TB_").append(comCode).append("_M10")
							.append(" WHERE USERID = " + genQuote(userId))
							.append(" AND BOXCLASS = " + genQuote(GCmConstDef.BOXCLASS_DRAFT))
							.append(" AND EXECCLASS = " + genQuote(GCmConstDef.EXECCLASS_DRAFT_REJECTBOX))
							.append(" AND BOXTYPE = " + genQuote(GCmConstDef.BOXTYPE_PRIVATE) + " ) " )
							.append(" WHERE BOXNO = ( SELECT BOXNO FROM TB_").append(comCode).append("_M10")
							.append(" WHERE USERID = " + genQuote(userId))
							.append(" AND BOXCLASS = " + genQuote(GCmConstDef.BOXCLASS_DRAFT))
							.append(" AND EXECCLASS = " + genQuote(box))
							.append(" AND BOXTYPE = " + genQuote(GCmConstDef.BOXTYPE_PRIVATE) + ")" )
							.append(" AND DRFTNO = " + genQuote(draftNo))
							.append(" AND REFTYPE = " + genQuote(refType));



			conn.executeUpdate(sqlQuery.toString());



		}
		catch (Exception e)
		{


			System.err.println("GCoDfApprovalTran :: updateDraftReject"  + e.getMessage());

			throw new GCmProcessingErrorException("GCoDfApprovalTran :: updateDraftReject" + e.getMessage());


		}

	}




	/**
	 * <PRE>
	 *  �����Ժ���ȸ�ϻ���
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�	<BR>
	 *				<LI> String REGDRFTNO  : ���α�ȹ�ȣ  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  Boolean
	 */

	public boolean deleteRegDrft(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmLog log = new GCmLog(GCmConstDef.GROUPWARE_ID);
		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strRegDraftNo     = dmProp.getString("REGDRFTNO");



		try
		{
			conn = GCmDbManager.getInstance().getConnection();


			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
							.append(" DELETE FROM TB_").append(strComCode).append("_D20 ")
							.append(" WHERE REGDRFTNO = " + genQuote(strRegDraftNo));


			conn.executeUpdate(sqlQuery.toString());

			conn.commit();

			return true;

		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoDfApprovalTran :: deleteRegDrft " + ignored.getMessage());
			}


			System.out.println("GCoDfApprovalTran :: deleteRegDrft " + e.getMessage());

			return false;


		}
		finally
		{
			conn.close();
		}
	}




	/**
	 * <PRE>
	 *  ������ ��ȸ�Ͻ� �Է�
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�	<BR>
	 *				<LI> String RVIEW          : ��ȸ�Ͻ�  <BR>
	 *				<LI> String DRFTNO        : ȸ���ڵ�	<BR>
	 *				<LI> String APPRID         : ������ID  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  Boolean
	 */

	public boolean updateReadAppr(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmLog log = new GCmLog(GCmConstDef.GROUPWARE_ID);
		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strRview = dmProp.getString("RVIEW");
		String strDraftNo     = dmProp.getString("DRFTNO");
		String strApprId = dmProp.getString("APPRID");


		try
		{
			conn = GCmDbManager.getInstance().getConnection();


			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
							.append(" UPDATE TB_").append(strComCode).append("_D11 ")
							.append(" SET REALVIEWDATE = " + genQuote(strRview)+",")
							.append(" READFLAG = '0'")
				                        .append(" WHERE DRFTNO = " + genQuote(strDraftNo))
							.append(" AND REFTYPE = " + genQuote("1"))
							.append(" AND APPRID = " + genQuote(strApprId));


			conn.executeUpdate(sqlQuery.toString());

			conn.commit();

			return true;

		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoDfApprovalTran :: updateReadAppr" + ignored.getMessage());
			}


			System.out.println("GCoDfApprovalTran  ::  updateReadAppr() " + e.getMessage());

			return false;


		}
		finally
		{
			conn.close();
		}
	}






	/**
	 * <PRE>
	 *  ����,������ ��ȸ�Ͻ� �Է�
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�	<BR>
	 *				<LI> String RVIEW          : ��ȸ�Ͻ�  <BR>
	 *				<LI> String DRFTNO        : ȸ���ڵ�	<BR>
	 *				<LI> String REFTYPE      : ������������	<BR>
	 *				<LI> String APPRID         : ������ID  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  Boolean
	 */

	public boolean updateHelpAppr(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmLog log = new GCmLog(GCmConstDef.GROUPWARE_ID);
		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strRview = dmProp.getString("RVIEW");
		String strDraftNo     = dmProp.getString("DRFTNO");
		String strRefType = dmProp.getString("REFTYPE");
		String strApprId = dmProp.getString("APPRID");


		try
		{
			conn = GCmDbManager.getInstance().getConnection();


			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
							.append(" UPDATE TB_").append(strComCode).append("_D11 ")
							.append(" SET REALVIEWDATE = " + genQuote(strRview)+",")
                                                        .append(" READFLAG = '0' ")
				                        .append(" WHERE DRFTNO = " + genQuote(strDraftNo))
							.append(" AND REFTYPE = " + genQuote(strRefType))
							.append(" AND APPRID = " + genQuote(strApprId));


			conn.executeUpdate(sqlQuery.toString());

			conn.commit();

			return true;

		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoDfApprovalTran :: updateHelpAppr"+ ignored.getMessage());
			}


			System.out.println("GCoDfApprovalTran  ::  updateHelpAppr() " + e.getMessage());

			return false;


		}
		finally
		{
			conn.close();
		}
	}




	/**
	 * <PRE>
	 *  �ǰ� �Է�
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�	<BR>
	 *				<LI> String COMMENTS  : �ǰ�  <BR>
	 *				<LI> String DRFTNO        : ȸ���ڵ�	<BR>
	 *				<LI> String REFTYPE      : ������������	<BR>
	 *				<LI> String APPRID         : ������ID  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  Boolean
	 */

	public boolean updateHelpApprComments(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmLog log = new GCmLog(GCmConstDef.GROUPWARE_ID);
		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strComments = dmProp.getString("COMMENTS");
		String strDraftNo     = dmProp.getString("DRFTNO");
		String strRefType = dmProp.getString("REFTYPE");
		String strApprId = dmProp.getString("APPRID");


		try
		{
			conn = GCmDbManager.getInstance().getConnection();


			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
							.append(" UPDATE TB_").append(strComCode).append("_D11 ")
							.append(" SET COMMENTS = " + genQuote(strComments))
				            .append(" WHERE DRFTNO = " + genQuote(strDraftNo))
							.append(" AND REFTYPE = " + genQuote(strRefType))
							.append(" AND APPRID = " + genQuote(strApprId));


			conn.executeUpdate(sqlQuery.toString());

			conn.commit();

			return true;

		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoDfApprovalTran :: updateHelpApprComments"+ ignored.getMessage());
			}


			System.out.println("GCoDfApprovalTran  ::  updateHelpApprComments" + e.getMessage());


			e.printStackTrace();

			return false;


		}
		finally
		{
			conn.close();
		}
	}

}