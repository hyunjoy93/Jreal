package gplus.component.pos;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

/**
 * <PRE>
 * Filename		: GCoPoPositionTran.java
 * Class		: gplus.component.draft.GCoPoPositionTran
 * Fuction		: ȸ���� �����ڵ带 ���� �Ѵ�.
 * Comment		:
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCoPoPositionTran extends GCmTopComponent
{
       /**
        * <PRE>
        * ȸ���纰�����ڵ忡 ��ϵǴ� �ű������ڵ带 ����Ѵ�.
        * ��ϵǴ� �ű������ڵ�� getMaxNo�Լ��� ���Ͽ� �����Ǹ� �Ϸù�ȣ������ �����ȴ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String PosName : �����̸�
        *                      <LI> String PosRank : ���޼���
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int insertPosCode(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String PosName = dmProp.getString("PosName");
		String PosRank = dmProp.getString("PosRank");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();
            String Posno = getMaxNo(COMCODE,strDbType);
            
            if(Posno == null || Posno.equals(""))
            {
                Posno = "01";
            }

			StringBuffer SqlQuery = new StringBuffer()
					.append(" INSERT INTO TB_").append(COMCODE).append("_N20 ")
                                        .append(" (POSCODE,POSNAME,POSRANK) ")
                                        .append("  VALUES ("+genQuote(GCmFcts.numToStr(Posno,2))+","+genQuote(PosName)+","+genQuote(GCmFcts.numToStr(PosRank,2))+")");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			  rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoPoPositionTran::insertPosCode : " + ignored.getMessage());
			}

	 		System.out.println(" GCoPoPositionTran::insertPosCode : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoPoPositionTran::insertPosCode : " + e.getMessage());
			}
			conn.close();
		}
    	}

       /**
        * <PRE>
        * ���޵� �����ڵ忡 �ش��ϴ� �����ڵ��� �����̸�,���޼��������� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String PosCode : �����ڵ�
        *                      <LI> String PosName : �����̸�
        *                      <LI> String PosRank : ���޼���
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int updatePosCode(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String PosCode = dmProp.getString("PosCode");
		String PosName = dmProp.getString("PosName");
		String PosRank = dmProp.getString("PosRank");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" UPDATE TB_").append(COMCODE).append("_N20 ")
                                        .append(" SET POSNAME = "+genQuote(PosName)+", POSRANK = "+genQuote(PosRank))
                                        .append(" WHERE POSCODE = "+genQuote(PosCode));

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			  rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoPoPositionTran::updatePosCode : " + ignored.getMessage());
			}

	 		System.out.println(" GCoPoPositionTran::updatePosCode : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoPoPositionTran::updatePosCode : " + e.getMessage());
			}
			conn.close();
		}
    	}

       /**
        * <PRE>
        * ���޵� �����ڵ忡 �ش��ϴ� �����ڵ带 �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String PosCode : �����ڵ�
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deletePosCode(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String PosCode = dmProp.getString("PosCode");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" DELETE FROM TB_").append(COMCODE).append("_N20 ")
                                        .append(" WHERE POSCODE IN ("+PosCode+")");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			  rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoPoPositionTran::deletePosCode : " + ignored.getMessage());
			}

	 		System.out.println(" GCoPoPositionTran::deletePosCode : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoPoPositionTran::deletePosCode : " + e.getMessage());
			}
			conn.close();
		}
    	}

       /**
        * <PRE>
        * ȸ���������ڵ忡 ��ϵǴ� �����ڵ� ��Ͻ� �ʿ��� �����ڵ带 �����ϴ� �����Լ��̸�,
        * �����Ǵ� �����ڵ�� �����ڵ� �Ϸù�ȣ������ �����ȴ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String strDbType : gplus db type
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return String : �ű��Թ�ȣ
        */
    	private String getMaxNo(String comcode,String strDbType)
    	{

		GCmConnection conn = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();
			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                             sqlQuery
		        	.append(" SELECT DECODE(MAX(POSCODE),MAX(POSCODE),TO_CHAR(TO_NUMBER(MAX(POSCODE))+1),null,'01') as NO ")
                           	.append(" FROM TB_").append(comcode).append("_N20 ");
                        }
                        else if ("mssql".equals(strDbType))
                             {
                                     sqlQuery
                                        .append(" SELECT (CASE MAX(POSCODE) WHEN MAX(POSCODE) THEN RIGHT('00'+CAST(MAX(POSCODE)+1 AS varchar(2)),2) ELSE '01' END) as NO ")
                                        .append(" FROM TB_").append(comcode).append("_N20 ");
                             }


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
                	rs.next();

			return rs.getString("NO");

      		}
      		catch (Exception e)
      		{
 			System.out.println(" GCoPoPositionTran::getMaxNo " + e.getMessage());
	 		return null;
      		}
      		finally
      		{
			conn.close();
      		}
    	}
}