
package gplus.component.login;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;


/**
 * <PRE>
 * Filename		: GCoLogin.java
 * Class		: gplus.component.common.GCoLogin
 * Fuction		: ����� LOGIN ������ �����Ѵ�.
 * Comment		:
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCoLogin extends GCmTopComponent
{
   /**
    * <PRE>
    * ���޵� �����ID�� ����� PASSWORD�� ���Ͽ� ����ڸ� �˻��ϰ� �˻��� ����ڸ� �ǵ��� �ش�.
    * ������� ID �Ǵ� PASSWORD�� null�ΰ�� Exception�� �߻��Ѵ�.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String USER_ID : ����� ID
    *                      <LI> String USER_PWD : ����� PASSWORD
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : ���������(USERID, USERNAME, PASSWD, COMCODE)
    */
	public GCmResultSet getLoginUser(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmLog log = new GCmLog(GCmConstDef.GROUPWARE_ID);
		GCmConnection conn = null;

		String UserId = dmProp.getString("USER_ID");
		String UserPwd = dmProp.getString("USER_PWD");
        //String strDbType = cp.getProperty("gplus.db.type").toLowerCase();
                GCmResultSet rs2 = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			if ( UserId == null || UserId.length() == 0 ) throw new Exception("USER_ID is null");
			if ( UserPwd == null || UserPwd.length() == 0 ) throw new Exception("USER_PWD is null");

			StringBuffer sqlQuery = new StringBuffer();
                        sqlQuery.append(" SELECT USERID, USERNAME, PASSWD, COMCODE , PAGESIZE")
                                   .append(" FROM TB_COMM_Z20 ")
                                   .append(" WHERE USERID = "+genQuote(UserId));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

                        if(rs.next())
                        {
                              sqlQuery = new StringBuffer();
                              sqlQuery.append(" SELECT USERID, USERNAME, PASSWD, COMCODE , PAGESIZE")
                                       .append(" FROM TB_COMM_Z20 ")
                                       .append(" WHERE USERID = "+genQuote(UserId))
                                       .append(" AND PASSWD = "+genQuote(UserPwd));

                              GCmResultSet rs1 = conn.executeQuery(sqlQuery.toString());
                              if(rs1.next())
                              {
                                    sqlQuery = new StringBuffer();
                                    sqlQuery.append(" SELECT USERID, USERNAME, PASSWD, COMCODE , PAGESIZE")
                                         .append(" FROM TB_COMM_Z20 ")
                                         .append(" WHERE USERID = "+genQuote(UserId))
                                         .append(" AND PASSWD = "+genQuote(UserPwd));

                                    rs2 = conn.executeQuery(sqlQuery.toString());


                              }else{
                                     dmProp.setProperty("ERR_MSG","PASSWORD�� ��Ȯ���� �ʽ��ϴ�!");

                              }
                        }else{
                               dmProp.setProperty("ERR_MSG","ID�� ��Ȯ���� �ʽ��ϴ�!");

                        }

                    return rs2;

                }
		catch (Exception e)
		{
	 		System.out.println(" GCoLogin::getLoginUser " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

   /**
    * <PRE>
    * ���޵� �����ID�� ���Ͽ� ����ڸ� �˻��ϰ� �˻��� ���������, ��������, ����������
    * �˻��Ͽ� �ǵ��� �ش�.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String USER_ID : ����� ID
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : ���������(TB_COMM_Z20.*, N10.*, N20.*)
    */
	public GCmResultSet getUserInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmLog log = new GCmLog(GCmConstDef.GROUPWARE_ID);
		GCmConnection conn = null;

		String ComCode = dmProp.getString("COMCODE");
		String UserId = dmProp.getString("USER_ID");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

	 		if ( UserId == null || UserId.length() == 0 ) throw new Exception("USER_ID is null");

			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                           sqlQuery.append(" SELECT A.*, B.*, C.* ")
                                   .append(" FROM TB_COMM_Z20 A, TB_").append(ComCode).append("_N10 B, TB_").append(ComCode).append("_N20 C ")
                                   .append(" WHERE A.POSCODE = C.POSCODE(+) AND A.ORGNO = B.ORGNO(+) AND ")
                                   .append("       A.USERID = "+genQuote(UserId));
                        }
                        else if ("mssql".equals(strDbType))
                             {
                                  sqlQuery.append(" SELECT A.*, B.*, C.* ")
                                          .append(" FROM TB_COMM_Z20 A, TB_").append(ComCode).append("_N10 B, TB_").append(ComCode).append("_N20 C ")
                                          .append(" WHERE A.POSCODE *= C.POSCODE AND A.ORGNO *= B.ORGNO AND ")
                                          .append("       A.USERID = "+genQuote(UserId));
                             }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoLogin::getUserInfo " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

   /**
    * <PRE>
    * ���� �α����� ������� address, login �ð�,������ Ÿ���� �����Ѵ�
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String USERID : current user id at session
    *                      <LI> String LoginDT : �α��� �ð�
    *                      <LI> String Remoteaddr : ����� address
    *                      <LI> String Remotehost : no use
    *                      <LI> String Remoteuser : no use
    *                      <LI> String Useragent : ������ Type
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : ���������(TB_COMM_Z20.*, N10.*, N20.*)
    */
	public int insertUserLoginInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String USERID = dmProp.getString("USERID");
		String LoginDT = dmProp.getString("LoginDT");
		String Remoteaddr = dmProp.getString("Remoteaddr");
		String Remotehost = dmProp.getString("Remotehost");
		String Remoteuser = dmProp.getString("Remoteuser");
		String Useragent = dmProp.getString("Useragent");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" INSERT INTO TB_COMM_Z40 (USERID,LOGINDT,REMOTEADDR,REMOTEHOST,REMOTEUSER,USERAGENT) ")
					.append("  VALUES ("+genQuote(USERID)+","+genQuote(LoginDT)+","+genQuote(Remoteaddr)+","+genQuote(Remotehost)+","+genQuote(Remoteuser)+","+genQuote(Useragent)+") ");
			stmt = conn.createStatement();

			conn.setAutoCommit(false);
			  rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoLogin::updateUserLoginInfo : " + ignored.getMessage());
			}

	 		System.out.println(" GCoLogin::updateUserLoginInfo : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoLogin::updateUserLoginInfo : " + e.getMessage());
			}
			conn.close();
		}
	}

   /**
    * <PRE>
    * �α����� ������� �α�out �ð��� �����Ѵ�.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String USERID : current user id at session
    *                      <LI> String LoginDT : �α��� �ð�
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : ���������(TB_COMM_Z20.*, N10.*, N20.*)
    */
	public int updateUserLogOut(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String USERID = dmProp.getString("USERID");
		String LoginDT = dmProp.getString("LoginDT");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
 		    String LogoutDT = gplus.commlib.util.GCmDateFcts.dateToStr(new java.util.Date(),2);
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" UPDATE TB_COMM_Z40 ")
					.append(" SET LOGOUTDT = "+genQuote(LogoutDT))
					.append(" WHERE USERID = "+genQuote(USERID)+" AND LOGINDT = "+genQuote(LoginDT));

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			  rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoLogin::updateUserLogOut : " + ignored.getMessage());
			}

	 		System.out.println(" GCoLogin::updateUserLogOut : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoLogin::updateUserLogOut : " + e.getMessage());
			}
			conn.close();
		}
	}

}