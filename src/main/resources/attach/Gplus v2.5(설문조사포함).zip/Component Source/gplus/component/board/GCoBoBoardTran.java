package gplus.component.board;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

import gplus.component.doc.*;

/**
 * <PRE>
 * Filename		: GCoBoBoardTran.java
 * Class		: gplus.component.pos.GCoBoBoardTran
 * Fuction		:
 * Comment		:
 * History      : 03/19/2002, ������, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCoBoBoardTran extends GCmTopComponent
{
    /**
     * <PRE>
     *    ȸ���ڵ�, ����, ÷�μ�, �Խù� ��ȣ�� ���޹޾� �Խù��� ������ �����Ѵ�.
     * </PRE>
     *
	 * @author          03/19/2002, ������
	 *
     * @param cp        a GCmProperties holding gplus groupware properties.
     * @param dmProp    GCmProperties
     *                  <UL>relevant fields.
     *                      <LI> String COMCODE : current user companycode at seeeion
     *                      <LI> String Title   : �Խù� ����
     *                      <LI> String Attnum  : ÷�μ�
     *                      <LI> String Notino  : �Խù� ��ȣ
     *                  </UL>
     * @param msgInfo   a GCmMsgInfo holding error codes.
     * @return N/A
     */
	public int updateNoti(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
                String TITLE = dmProp.getString("Title");
                String ATTNUM = dmProp.getString("Attnum");
		String NOTINO = dmProp.getString("Notino");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" UPDATE TB_"+COMCODE+"_A01 SET TITLE = "+ genQuote(TITLE))
					.append(" , ATTNUM =" + genQuote(ATTNUM)+ " WHERE NOTINO = " + genQuote(NOTINO));

			stmt = conn.createStatement();

			conn.setAutoCommit(false);
			rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoBoBoardTran::updateNoti : " + ignored.getMessage());
			}

	 		System.out.println(" GCoBoBoardTran::updateNoti : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoBoBoardTran::updateNoti : " + e.getMessage());
			}
			conn.close();
		}
	}

	/**
     * <PRE>
     *    ȸ���ڵ�, �Խù� ��ȣ�� ���޹޾� �Խù��� ��õ���� �����Ѵ�. 
     * </PRE>
     *
	 * @author          03/19/2002, ������
	 *
     * @param cp        a GCmProperties holding gplus groupware properties.
     * @param dmProp    GCmProperties
     *                  <UL>relevant fields.
     *                      <LI> String COMCODE : current user companycode at seeeion
     *                      <LI> String Notino  : �Խù� ��ȣ
     *                  </UL>
     * @param msgInfo   a GCmMsgInfo holding error codes.
     * @return N/A
     */
	public int updateNom(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String NOTINO = dmProp.getString("NOTINO");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" UPDATE TB_"+COMCODE+"_A01 SET NOMNUM = NOMNUM+1  ")
					.append(" WHERE NOTINO =" + genQuote(NOTINO));

			stmt = conn.createStatement();

			conn.setAutoCommit(false);
			rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoBoBoardTran::getUpdNom : " + ignored.getMessage());
			}

	 		System.out.println(" GCoBoBoardTran::getUpdNom : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoBoBoardTran::getUpdNom : " + e.getMessage());
			}
			conn.close();
		}
	}

	/**
     * <PRE>
     *    ȸ���ڵ�, ������ ��ȣ, ����� ID, �б����, �������,��������,Ÿ�ι��� ��������, ������������
	 *    ���� ���� ������ ���޹޾� �� ����ڿ� ���� ������ �߰��Ѵ�.
     * </PRE>
     *
	 * @author          03/19/2002, ������
	 *
     * @param cp        a GCmProperties holding gplus groupware properties.
     * @param dmProp    GCmProperties
     *                  <UL>relevant fields.
     *                      <LI> String COMCODE   : current user companycode at seeeion
     *                      <LI> String Boxno     : ������ ��ȣ
	 *                      <LI> String Userno    : current user ID at seeeion
     *                      <LI> String Docread   : ���� �б� ����
	 *                      <LI> String Docwrite  : ���� ���� ����
     *                      <LI> String Docdel    : ���� ���� ����
	 *                      <LI> String Docdeladm : Ÿ�ι��� ���� ����(������)
     *                      <LI> String Fldmake   : ���� �ۼ� ����
	 *                      <LI> String Flddel    : ���� ���� ����
     *                  </UL>
     * @param msgInfo   a GCmMsgInfo holding error codes.
     * @return N/A
     */
	public int insertBoxRight(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE   = dmProp.getString("COMCODE");
		String Boxno     = dmProp.getString("Boxno");
		String Userno    = dmProp.getString("Userno");
		String Docread   = dmProp.getString("Docread");
		String Docwrite  = dmProp.getString("Docwrite");
		String Docdel    = dmProp.getString("Docdel");
		String Docdeladm = dmProp.getString("Docdeladm");
		String Fldmake   = dmProp.getString("Fldmake");
		String Flddel    = dmProp.getString("Flddel");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" INSERT INTO TB_"+COMCODE+"_M20 (BOXNO,USERID,DOCREAD,DOCWRITE,DOCDEL,DOCDELADM,FLDMAKE,FLDDEL) ")
					.append(" VALUES ("+genQuote(Boxno)+","+genQuote(Userno)+","+genQuote(Docread)+","+genQuote(Docwrite)+","+genQuote(Docdel)+",")
                                        .append("         "+genQuote(Docdeladm)+","+genQuote(Fldmake)+","+genQuote(Flddel)+") ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			  rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoBoBoardTran::insertBoxRight : " + ignored.getMessage());
			}

	 		System.out.println(" GCoBoBoardTran::insertBoxRight : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoBoBoardTran::insertBoxRight : " + e.getMessage());
			}
			conn.close();
		}
	}

	/**
     * <PRE>
     *    ȸ���ڵ�, ������ ��ȣ, ���ϰ�θ� ���޹޾� ������ ����Ʈ�� ã�Ƽ� ÷�ε� ������ ������ ������ ���� �����ϰ�
	 *    ����Ʈ�� ������ ���� ��Ų��.
     * </PRE>
     *
	 * @author          03/19/2002, ������
	 *
     * @param cp        a GCmProperties holding gplus groupware properties.
     * @param dmProp    GCmProperties
     *                  <UL>relevant fields.
     *                      <LI> String COMCODE   : current user companycode at seeeion
     *                      <LI> String NOTINO    : �Խù� ��ȣ
	 *                      <LI> String PPATH     : �������
     *                  </UL>
     * @param msgInfo   a GCmMsgInfo holding error codes.
     * @return N/A
     */
	public int deleteNoti(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String NOTINO  = dmProp.getString("NOTINO");
		String PPATH   = dmProp.getString("PPATH");

        String strDbType = cp.getProperty("gplus.db.type").toLowerCase();
       	int rv;

		GCmConnection conn = null;
		Statement stmt = null;

        GCoDoDocTran docTran = new GCoDoDocTran();
        GCoBoBoard board = new GCoBoBoard();

		try
		{
            StringBuffer SqlQuery = null;

			conn = GCmDbManager.getInstance().getConnection();

			stmt = conn.createStatement();
			conn.setAutoCommit(false);

            GCmResultSet rsDelList = board.getDelList(cp,dmProp,msgInfo);

            for (int j=1;j<=rsDelList.getRowCount() && rsDelList.next();j++)
	        {
                  dmProp.setProperty("Docno",rsDelList.getString("DOCNO"));
                  dmProp.setProperty("Seq",rsDelList.getString("SEQ"));
                  dmProp.setProperty("FILENAME",rsDelList.getString("FILENAME"));
                  dmProp.setProperty("FILEEXT",rsDelList.getString("FILEEXT"));
                  dmProp.setProperty("VPATH",rsDelList.getString("VPATH"));

                  java.io.File srcFile = new java.io.File(PPATH+rsDelList.getString("VPATH")+rsDelList.getString("FILENAME"));

                  rv = docTran.deleteFile(cp, dmProp, msgInfo);

                  if(srcFile.isFile())
                         srcFile.delete();

             }

             dmProp.setProperty("Docno",rsDelList.getString("DOCNO"));
			 rv = docTran.deleteDoc(cp, dmProp, msgInfo);

		     SqlQuery = new StringBuffer()
                    .append(" DELETE FROM TB_").append(COMCODE).append("_A01 ")
                    .append(" WHERE NOTINO = "+genQuote(NOTINO));
   	         rv = stmt.executeUpdate(SqlQuery.toString());

			 conn.commit();

			 return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoBoBoardTran::deleteNoti : " + ignored.getMessage());
			}

	 		System.out.println(" GCoBoBoardTran::deleteNoti : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoBoBoardTran::deleteNoti : " + e.getMessage());
			}
			conn.close();
		}
	}

	/**
     * <PRE>
     *    �Խù� ����Ʈ�� �߰��Ѵ�.
     * </PRE>
     *
	 * @author          03/19/2002, ������
	 *
     * @param cp        a GCmProperties holding gplus groupware properties.
     * @param dmProp    GCmProperties
     *                  <UL>relevant fields.
     *                      <LI> String COMCODE   : current user companycode at seeeion
     *                      <LI> String Notino    : �Խù� ��ȣ
	 *                      <LI> String Boxno     : ������ ��ȣ
     *                      <LI> String Docno     : ���� ��ȣ
	 *                      <LI> String Parentno  : ���� �Խù� ��ȣ
     *                      <LI> String Title     : ���� ����
	 *                      <LI> String Attnum    : ÷�μ�
     *                      <LI> String Refnum    : ��ȸ��
	 *                      <LI> String Nomnum    : ��õ��
	 *                      <LI> String Childnum  : ���� �Խù� ��
	 *                      <LI> String Reguser   : ����� ID
     *                      <LI> String Regdate   : �������
	 *                      <LI> String Regname   : ����� �̸�
     *                      <LI> String REF       : ���ع�ȣ
	 *                      <LI> String STEPNUM   : ����
     *                      <LI> String RELEVEL   : �亯 ����
     *                  </UL>
     * @param msgInfo   a GCmMsgInfo holding error codes.
     * @return N/A
     */
	public int insertNotify(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE  = dmProp.getString("COMCODE");
        String Notino   = dmProp.getString("Notino");
		String Boxno    = dmProp.getString("Boxno");
		String Docno    = dmProp.getString("Docno");
		String Parentno = dmProp.getString("Parentno");
		String Title    = dmProp.getString("Title");
		String Attnum   = dmProp.getString("Attnum");
		String Refnum   = dmProp.getString("Refnum");
		String Nomnum   = dmProp.getString("Nomnum");
		String Childnum = dmProp.getString("Childnum");
		String Reguser  = dmProp.getString("Reguser");
		String Regdate  = dmProp.getString("Regdate");
		String Regname  = dmProp.getString("Regname");
		String REF      = dmProp.getString("REF");
		String STEPNUM  = dmProp.getString("STEPNUM");
		String RELEVEL  = dmProp.getString("RELEVEL");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
                   .append(" INSERT INTO TB_"+COMCODE+"_A01 (NOTINO,BOXNO,DOCNO,PARENTNO,TITLE,ATTNUM,REFNUM,NOMNUM,CHILDNUM,REGUSER,REGDATE,REGNAME,REF,SORTSTEP,RELEVEL) ")
                   .append(" VALUES("+genQuote(Notino)+","+genQuote(Boxno)+","+genQuote(Docno)+","+genQuote(Parentno)+","+genQuote(Title)+",")
                   .append("       "+Attnum+","+Refnum+","+Nomnum+","+Childnum+","+genQuote(Reguser)+","+genQuote(Regdate)+","+genQuote(Regname)+","+genQuote(REF)+","+genQuote(STEPNUM)+","+genQuote(RELEVEL)+")");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoBoBoardTran::insertNotify : " + ignored.getMessage());
			}

	 		System.out.println(" GCoBoBoardTran::insertNotify : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoBoBoardTran::insertNotify : " + e.getMessage());
			}
			conn.close();
		}
	}

   /**
    * <PRE>
	*	  �亯�ۿ� ���� ���� ��ȭ�� �����Ѵ�.
    * </PRE>
    *
	* @author          03/19/2002, ������
	*
	* @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at seeeion
    *                      <LI> String REF     : ���ع�ȣ
    *                      <LI> String STEPNUM : ����(SORTSTEP)
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return N/A
    */
	public int updateNotiOrder(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
        String REF = dmProp.getString("REF");
		int STEPNUM = dmProp.getInt("STEPNUM");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" UPDATE TB_"+COMCODE+"_A01 SET SORTSTEP = SORTSTEP + 1  ")
					.append(" WHERE REF = " + genQuote(REF))
                                        .append(" AND SORTSTEP > " + STEPNUM);

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoBoBoardTran::updateNotiOrder : " + ignored.getMessage());
			}

	 		System.out.println(" GCoBoBoardTran::updateNotiOrder : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoBoBoardTran::updateNotiOrder : " + e.getMessage());
			}
			conn.close();
		}
	}

   /**
    * <PRE>
    *	 �Խù��� ��ȸ���� ������Ų��.
    * </PRE>
    *
	* @author          03/19/2002, ������
	*
    * @param cp        a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at seeeion
    *                      <LI> String NOTINO  : �Խù� ��ȣ
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return N/A
    */
	public int updateRefCnt(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String NOTINO = dmProp.getString("NOTINO");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" UPDATE TB_"+COMCODE+"_A01 SET REFNUM = REFNUM+1  ")
					.append(" WHERE NOTINO =" + genQuote(NOTINO));

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoBoBoardTran::updateRefcnt : " + ignored.getMessage());
			}

	 		System.out.println(" GCoBoBoardTran::updateRefcnt : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoBoBoardTran::updateRefcnt : " + e.getMessage());
			}
			conn.close();
		}
	}
}