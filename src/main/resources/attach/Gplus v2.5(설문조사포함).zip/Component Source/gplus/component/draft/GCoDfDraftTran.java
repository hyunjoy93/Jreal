package gplus.component.draft;


import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;
import gplus.template.*;
import gplus.component.doc.*;

/**
 * <PRE>
 * Filename	: GCoDfDraftTran.java
 * Class		    : gplus.component.draft.GCoDfDraftTran
 * Fuction	    :
 * Comment	:
 * History       : 1/6/2002, ������, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCoDfDraftTran extends GCmTopComponent
{


       /**
        * <PRE>
        * ���޵� ��忡 ���� �������� ����Ѵ�. ��尡 d�̸� ���� �������� �����ϰ� ��尡 null�̸� �������� ����Ѵ�.
        * ��������ȣ�� ���Ͽ� ����/������ ����� �����Ѵ�. ��������ȣ�� null�� ��� deleteDraftSubLine,deleteDraftLine����
        * �������� �����ϰ� ��尡 d�� �ƴϸ� insertDraftLine���� �������� ����ϰ� insertSubDraftLine���� ��������
        * �������� ����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Mode : ��� (d:����, null:�Է�)
        *                      <LI> String Linenum : ��������ȣ
        *                      <LI> String Line2 : �������
        *                      <LI> String Line3 : �������
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int DraftLineInfoToDb(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String Linenum = dmProp.getString("Linenum");
      	String Linename = dmProp.getString("Linename");
		String Linenote = dmProp.getString("Linenote");
		String Mode = dmProp.getString("Mode");
		String Line = dmProp.getString("Line");
		String Line3 = dmProp.getString("Line3");
        String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		int rv=0;

		GCmConnection conn = null;
		Statement stmt = null;
        StringBuffer SqlQuery = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			stmt = conn.createStatement();

            if ("oracle".equals(strDbType))
            {
	     	     conn.setAutoCommit(false);
            }

            if (!Linenum.equals(""))
            {
  			     SqlQuery = new StringBuffer()
					.append(" DELETE FROM TB_").append(COMCODE).append("_D31 ")
					.append(" WHERE LINENUM = "+genQuote(Linenum));

	             rv = stmt.executeUpdate(SqlQuery.toString());

  			     SqlQuery = new StringBuffer()
					.append(" DELETE FROM TB_").append(COMCODE).append("_D30 ")
					.append(" WHERE LINENUM = "+genQuote(Linenum)+" AND USERID = "+genQuote(USERID));

	             rv = stmt.executeUpdate(SqlQuery.toString());
                            if( rv <= 0 ) throw new Exception(" During DraftLineInfoToDb error !!!");
            }

            if (!Mode.equals("d"))
            {
                 String newLinenum = getMaxNo(COMCODE,strDbType);

			     SqlQuery = new StringBuffer()
					.append(" INSERT INTO TB_").append(COMCODE).append("_D30 ")
                    .append(" (LINENUM,USERID,LINENAME,LINENOTE) ")
                    .append("  VALUES ("+genQuote(newLinenum)+","+genQuote(USERID)+","+genQuote(Linename)+","+genQuote(Linenote)+" )");

	             rv = stmt.executeUpdate(SqlQuery.toString());
                 if( rv <= 0 ) throw new Exception(" During DraftLineInfoToDb error !!!");

                 java.util.Vector vLine2 = gplus.commlib.util.GCmFcts.getSplit(Line,",");

                 int j = 1;
                 for (int i=0;i<vLine2.size();i++)
                 {
                      java.util.Vector vTmp = gplus.commlib.util.GCmFcts.getSplit((String)vLine2.elementAt(i),"#");
			          SqlQuery = new StringBuffer()
				         .append(" INSERT INTO TB_").append(COMCODE).append("_D31 (LINENUM,SEQ,SUBTYPE,SUBAPPRID,STEPNUM,SUBAPPRNAME) ")
				         .append(" VALUES ( "+genQuote(newLinenum)+","+genQuote(gplus.commlib.util.GCmFcts.numToStr(j,3))+","+genQuote(((String)vTmp.elementAt(0)).substring(0,1))+","+genQuote(((String)vTmp.elementAt(0)).substring(1))+","+String.valueOf(i+1)+","+genQuote((String)vTmp.elementAt(1))+" )");
  		              rv = stmt.executeUpdate(SqlQuery.toString());
                      if( rv <= 0 ) throw new Exception(" During DraftLineInfoToDb error !!!");
                      j++;
                 }

                 vLine2 = gplus.commlib.util.GCmFcts.getSplit(Line3,",");
                 for (int i=0;i<vLine2.size();i++)
                 {
                      java.util.Vector vTmp = gplus.commlib.util.GCmFcts.getSplit((String)vLine2.elementAt(i),"#");
			          SqlQuery = new StringBuffer()
 				         .append(" INSERT INTO TB_").append(COMCODE).append("_D31 (LINENUM,SEQ,SUBTYPE,SUBAPPRID,STEPNUM,SUBAPPRNAME) ")
				         .append(" VALUES ( "+genQuote(newLinenum)+","+genQuote(gplus.commlib.util.GCmFcts.numToStr(j,3))+","+genQuote(((String)vTmp.elementAt(0)).substring(0,1))+","+genQuote(((String)vTmp.elementAt(0)).substring(1))+","+String.valueOf(i+1)+","+genQuote((String)vTmp.elementAt(1))+" )");
  		              rv = stmt.executeUpdate(SqlQuery.toString());
                      if( rv <= 0 ) throw new Exception(" During DraftLineInfoToDb error !!!");
                      j++;
                 }
            }

			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoDfDraftTran::DraftLineInfoToDb : " + ignored.getMessage());
			}

	 		System.out.println(" GCoDfDraftTran::DraftLineInfoToDb : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoDfDraftTran::DraftLineInfoToDb : " + e.getMessage());
			}
			conn.close();
		}
	}


	/**
	 * <PRE>
	 *  ���縦 �о����� ǥ��
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�		<BR>
	 *				<LI> String DRFTNO	        : �����Ժ� ��ȹ�ȣ  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 *   ���� �� �ʿ��� �޼ҵ� --> ���� �����ڰ� ���縦 �о����� ������ �� ���ٴ� �� ���� ����
	 */

	public boolean updateReadFlag(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strRegDrftNo = dmProp.getString("REGDRFTNO");


		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
							.append(" UPDATE TB_").append(strComCode).append("_D20 ")
							.append(" SET READFLAG = ").append(genQuote("0"))
							.append(" WHERE REGDRFTNO = " + genQuote(strRegDrftNo));



			conn.executeUpdate(sqlQuery.toString());

			conn.commit();

			return true;

		}
		catch (Exception e)
		{

			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoDfDraftTran :: updateReadFlag" + ignored.getMessage());
			}


			System.out.println("GCoDfDraftTran :: updateReadFlag" + e.getMessage());

			return false;
		}
		finally
		{
			conn.close();
		}
	}




	/**
	 * <PRE>
	 *  ���缱 ����
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�		<BR>
	 *				<LI> String LINENO	        : ���缱��ȣ  <BR>
	 *				<LI> String USERID	        : ����ڹ�ȣ  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 */

	public void deleteDraftLine(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strLineNo = dmProp.getString("LINENO");
		String strUserId = dmProp.getString("USERID");


		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
							.append(" DELETE FROM  TB_").append(strComCode).append("_D30 ")
							.append(" WHERE LINENO = " + genQuote(strLineNo)).append(" AND USERID = " + genQuote(strUserId));



			//System.out.println("DeleteDraftLine() -- SQL  : " + sqlQuery.toString());


			conn.executeUpdate(sqlQuery.toString());


			deleteDraftSubLine(conn, dmProp, msgInfo);			//����,������ ����

			conn.commit();

		}
		catch (Exception e)
		{

			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoDfDraftTran :: deleteDraftLine" + ignored.getMessage());
			}


			System.out.println("GCoDfDraftTran :: deleteDraftLine "+ e.getMessage());



		}
		finally
		{
			conn.close();
		}
	}
/**
	 * <PRE>
	 *  �ӽð����Կ��� ����
	 * </PRE>
	 * @
	 * @param CSaConnection conn : Database Connection
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�		<BR>
	 *				<LI> String BOXNO      : �ӽð����Թ�ȣ  <BR>
	 *				<LI> String DRAFTNO    : �����ȣ  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 */
      public boolean deleteBox(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
      {
        GCmConnection conn = null;
        String pComCode = dmProp.getString("COMCODE");
        String pBox = dmProp.getString("PBOXNO");
        String pDraftNo = dmProp.getString("DRAFTNO");
        try
		{
			conn = GCmDbManager.getInstance().getConnection();

			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
                       .append(" DELETE FROM  TB_").append(pComCode).append("_D20 ")
                       .append(" WHERE BOXNO = " + genQuote(pBox)).append(" AND DRFTNO = " + genQuote(pDraftNo));


                      conn.executeUpdate(sqlQuery.toString());
                      conn.commit();
                      return true;

		}
		catch (Exception e)
		{

			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoDfDraftTran :: deleteBox" + ignored.getMessage());
			}


			System.out.println("GCoDfDraftTran :: deleteBox "+ e.getMessage());
                        return false;
                }
		finally
		{
			conn.close();
		}
	}


	/**
	 * <PRE>
	 *  ����,������ ����
	 * </PRE>
	 *
	 * @param CSaConnection conn : Database Connection
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�		<BR>
	 *				<LI> String LINENO	        : ���缱��ȣ  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 */

	public void deleteDraftSubLine(GCmConnection conn, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		String strComCode = dmProp.getString("COMCODE");
		String strLineNo = dmProp.getString("LINENO");


		try
		{
			StringBuffer sqlQuery = new StringBuffer()
							.append(" DELETE FROM TB_").append(strComCode).append("_D31 ")
							.append(" WHERE LINENO = ").append(genQuote(strLineNo));


			conn.executeUpdate(sqlQuery.toString());

		}
		catch (Exception e)
		{

			System.out.println("GCoDfDraftTran :: delteDraftSubLine " + e.getMessage());

		}

	}




	/**
	 * <PRE>
	 *  ���缱 ����
	 * </PRE>
	 *
	 *
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						    <BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�		    <BR>
	 *				<LI> String USERID	        : ����ڹ�ȣ      <BR>
	 *				<LI> String LINENAME     : ���缱�̸�	    <BR>
	 *				<LI> String STEPNUM      : �����μ�     <BR>
     *				<LI> String LINENOTE      : �޸�  <BR>
	 *				<LI> String REGDATE       : ��������(���缱��ȣ������ �̿�)  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 */

	public void  insertDraftLine(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

		GCmConnection conn = null;

		String strComCode   = dmProp.getString("COMCODE");
		String strUserId        = dmProp.getString("USERID");
		String strLineName   = dmProp.getString("LINENAME");
		String strLineNote     = dmProp.getString("LINENOTE");
		String strRegDate      = dmProp.getString("REGDATE");

		dmProp.setProperty("COMCODE", strComCode);
		dmProp.setProperty("REGDATE", strRegDate);

		gplus.template.GTpDraft draft = new gplus.template.GTpDraft();


		String strLineNo = draft.getMaxLineNo(cp, dmProp, msgInfo);


		try
		{
			conn = GCmDbManager.getInstance().getConnection();


			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
							.append(" INSERT INTO TB_").append(strComCode).append("_D30 ")
							.append(" (LINENO,USERID,LINENAME,LINENOTE) ")
							.append(" VALUES (")
							.append(genQuote(strLineNo)).append(", ")
							.append(genQuote(strUserId)).append(", ")
							.append(genQuote(strLineName)).append(", ")
							.append(genQuote(strLineNote));



			conn.executeUpdate(sqlQuery.toString());

			conn.commit();

		}
		catch (Exception e)
		{

			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoDfDraftTran :: insertDraftLine" + ignored.getMessage());
			}

			System.out.println("GCoDfDraftTran :: insertDraftLine " + e.getMessage());


		}
		finally
		{
			conn.close();
		}
	}


	/**
	 * <PRE>
	 *  ����/������ ����
	 * </PRE>
	 *
	 *
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						    <BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE        : ȸ���ڵ�		    <BR>
	 *				<LI> String LINENO	            : ���缱��ȣ      <BR>
	 *				<LI> String SEQ                  : ����	    <BR>
	 *				<LI> String SUBTYPE          : ��������     <BR>
	 *				<LI> String SUBAPPRID       : �����ڹ�ȣ	<BR>
	 *				<LI> String STEPNUM         : �������� <BR>
	 *				<LI> String SUBAPPRNAME : �������̸�	<BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 */

	public void  insertSubDraftLine(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;

		String strComCode   = dmProp.getString("COMCODE");
		String strLineNo       = dmProp.getString("LINENO");
		String strSeq           = dmProp.getString("SEQ");
		String strSubType    = dmProp.getString("SUBTYPE");
		String strSubApprId  = dmProp.getString("SUBAPPRID");
		String intStepNum     = dmProp.getString("STEPNUM");
		String strSubApprName  = dmProp.getString("SUBAPPRNAME");


		try
		{
			conn = GCmDbManager.getInstance().getConnection();



			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
							.append(" INSERT INTO TB_").append(strComCode).append("_D31 ")
							.append(" (LINENO,SEQ,SUBTYPE,SUBAPPRID,STEPNUM,SUBAPPRNAME) ")
							.append(" VALUES (")
							.append(genQuote(strLineNo)).append(", ")
							.append(genQuote(strSeq)).append(", ")
							.append(genQuote(strSubType)).append(", ")
							.append(genQuote(strSubApprId)).append(", ")
							.append(intStepNum ).append(", ")
							.append(genQuote(strSubApprName));



			conn.executeUpdate(sqlQuery.toString());

			conn.commit();

		}
		catch (Exception e)
		{

			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoDfDraftTran :: insertSubDraftLine" + e.getMessage());
			}


			System.out.println("GCoDfDraftTran :: insertSubDraftLine"  + e.getMessage());


		}
		finally
		{
			conn.close();
		}
	}





	/**
	 * <PRE>
	 *  ��� ����
	 * </PRE>
	 *
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						    <BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE       : ȸ���ڵ�		    <BR>
	 *				<LI> String DOCNO	           : ������ȣ      <BR>
	 *				<LI> String DLVRTYPE       :  �߼ۻ���	    <BR>
	 *				<LI> String APPRTYPE       : �������     <BR>
	 *				<LI> String TITLE               : ����	<BR>
	 *				<LI> String REGDATE         : ����� <BR>
	 *				<LI> String DRFTID             : ����ڹ�ȣ	<BR>
	 *				<LI> String DRFTNAME       : ������̸�      <BR>
	 *				<LI> String DRFTDEPT        : ��Ⱥμ��̸�	    <BR>
	 *				<LI> String DRFTPOS         : ���������     <BR>
	 *				<LI> Integer ATTNUM           : ÷�μ�	<BR>
	 *				<LI> Integer STEPNUM         : �����μ� <BR>
	 *				<LI> String REFNAME         : ������	<BR>
	 *				<LI> String REFDEPT	        : �����μ�      <BR>
	 *				<LI> Integer MAINTERM       : �����Ⱓ	    <BR>
	 *				<LI> String MAINTDATE       : ����������     <BR>
	 *				<LI> Integer KEEPTERM        : �����Ⱓ	<BR>
	 *				<LI> String KEEPDATE	        : ����������      <BR>
	 *				<LI> String DRFTTYPE         : �������	    <BR>
	 *				<LI> String SECLVL            : ���ȵ��     <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 */

	public int  insertDraft(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;
		int rv = 0 ;
		Statement stmt = null;



		try
		{
			conn = GCmDbManager.getInstance().getConnection();


			String strComCode = dmProp.getString("COMCODE");
			String strDocNo     = dmProp.getString("DOCNO");
			String strDlvrType  = dmProp.getString("DLVRTYPE");
			String strApprType = dmProp.getString("APPRTYPE");
			String strTitle         = dmProp.getString("TITLE");
			String strRegDate   = dmProp.getString("REGDATE");
			String strDrftId        = dmProp.getString("DRFTID");
			String strDrftName   = dmProp.getString("DRFTNAME");
			String strDrftDept    = dmProp.getString("DRFTDEPT");
			String strDrftPos     = dmProp.getString("DRFTPOS");
			int      intAttNum      = Integer.parseInt(dmProp.getString("ATTNUM"));
			int      intStepNum   = Integer.parseInt(dmProp.getString("STEPNUM"));
			String strRefName   = dmProp.getString("REFNAME");
			String strRefDept    = dmProp.getString("REFDEPT");
			int      intMaintTerm = Integer.parseInt(dmProp.getString("MAINTTERM"));
			String strMaintDate = dmProp.getString("MAINTDATE");
			int      intKeepTerm = Integer.parseInt(dmProp.getString("KEEPTERM"));
			String strKeepDate = dmProp.getString("KEEPDATE");
			String strDrftType   = dmProp.getString("DRFTTYPE");
			String strSecLvl     = dmProp.getString("SECLVL");
			String strCreDate   = dmProp.getString("CREDATE");



			GTpDraft draft = new GTpDraft();


			String strDraftNo = draft.getMaxDrftNo(cp, dmProp, msgInfo);                   //GCoDfDraft.class ȣ��


			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
							.append(" INSERT INTO TB_").append(strComCode).append("_D10 ")
							.append(" (DRFTNO,DOCNO,DLVRTYPE,APPRTYPE,TITLE,REGDATE,DRFTID,DRFTNAME,DRFTDEPT,DRFTPOS,ATTNUM,STEPNUM,REFNAME,REFDEPT, ")
							.append(" MAINTTERM,MAINTDATE,KEEPTERM,KEEPDATE,DRFTTYPE,SECLVL,CREDATE) ")
							.append(" VALUES (")
							.append(genQuote(strDraftNo)).append(", ")
							.append(genQuote(strDocNo)).append(", ")
							.append(genQuote(strDlvrType)).append(", ")
							.append(genQuote(strApprType)).append(", ")
							.append(genQuote(strTitle)).append(", ")
							.append(genQuote(strRegDate)).append(", ")
							.append(genQuote(strDrftId)).append(", ")
							.append(genQuote(strDrftName)).append(", ")
							.append(genQuote(strDrftDept)).append(", ")
							.append(genQuote(strDrftPos)).append(", ")
							.append(intAttNum).append(", ")
							.append(intStepNum).append(", ")
							.append(genQuote(strRefName)).append(", ")
							.append(genQuote(strRefDept)).append(", ")
							.append(intMaintTerm).append(", ")
							.append(genQuote(strMaintDate)).append(", ")
							.append(intKeepTerm).append(", ")
							.append(genQuote(strKeepDate)).append(", ")
							.append(genQuote(strDrftType)).append(", ")
							.append(genQuote(strSecLvl)).append(" , ")
							.append(genQuote(strCreDate))
							.append(" ) ");


			stmt = conn.createStatement();

			rv = stmt.executeUpdate(sqlQuery.toString());

			conn.commit();

			dmProp.setProperty("DRAFTNO", strDraftNo);

			return rv;

		}
		catch (Exception e)
		{

			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoDfDraftTran :: insertDraft()" + e.getMessage());
			}


			System.out.println("GCoDfDraftTran :: insertDraft()" + e.getMessage());


			return -1;

		}
		finally
		{
			conn.close();
		}
	}



	/**
	 * <PRE>
	 *  �����ڸ�� �Է�
	 * </PRE>
	 *
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						    <BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE       : ȸ���ڵ�		    <BR>
	 *				<LI> String DRAFTNO         : ��ȹ�ȣ      <BR>
	 *				<LI> String SEQ                 : ����	    <BR>
	 *				<LI> String REFTYPE          : ������������     <BR>
	 *				<LI> String APPRID             : �����ڹ�ȣ	<BR>
	 *				<LI> String APPRTYPE        : ������� <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 */

	public boolean  insertAppr(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
		throws GCmProcessingErrorException, GCmParameterErrorException
	{


		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strDraftNo     = dmProp.getString("DRAFTNO");
		String strSeq  = dmProp.getString("SEQ");
		String strRefType = dmProp.getString("REFTYPE");
		String strApprId         = dmProp.getString("APPRID");
		String strApprType  = dmProp.getString("APPRTYPE");
		String strReadDate = dmProp.getString("READDATE");


		try
		{


			GTpUserInfo userInfo = new GTpUserInfo();


			dmProp.setProperty("COMCODE", strComCode);
			dmProp.setProperty("USERID", strApprId);


			GCmResultSet rs = userInfo.getUserInfo(cp, dmProp, msgInfo);


			rs.next();


			conn = GCmDbManager.getInstance().getConnection();


			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
							.append(" INSERT INTO TB_").append(strComCode).append("_D11 ")
							.append(" (DRFTNO,SEQ,REFTYPE,APPRID,APPRNAME,APPRDEPTCODE,APPRDEPTNAME,APPRPOSNAME,READFLAG,APPRTYPE,READDATE ) ")
							.append(" VALUES (")
							.append(genQuote(strDraftNo)).append(", ")
							.append(genQuote(strSeq)).append(", ")
							.append(genQuote(strRefType)).append(", ")
							.append(genQuote(strApprId)).append(", ")
							.append(genQuote(rs.getString("USERNAME"))).append(", ")
							.append(genQuote(rs.getString("ORGNO"))).append(", ")
							.append(genQuote(rs.getString("ORGNAME"))).append(", ")
							.append(genQuote(rs.getString("POSNAME"))).append(", ")
							.append(genQuote("1")).append(", ")
							.append(genQuote(strApprType)).append(", ")
							.append(genQuote(strReadDate)).append(" ) ");


			conn.executeUpdate(sqlQuery.toString());

			conn.commit();

			return true;

		}
		catch (Exception e)
		{

			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoDfDraftTran :: insertAppr" + ignored.getMessage());
			}


			System.out.println("GCoDfDraftTran :: insertAppr"  + e.getMessage());

			return false;

		}
		finally
		{
			conn.close();
		}
	}




	/**
	 * <PRE>
	 *  �������Ժ� ��ȸ�� �Է�(conn����)
	 * </PRE>
	 *
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						    <BR>
	 *				<TT><UL>
     *				<LI> String COMCODE       : ȸ���ڵ�  <BR>
	 *				<LI> String BOXNO            : �Թ�ȣ     <BR>
	 *				<LI> String DRFTNO           : ��ȹ�ȣ	<BR>
	 *				<LI> String REFTYPE         : ������������ <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 */

	public boolean  insertRegDraft(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		String strComCode = dmProp.getString("COMCODE");
		String strBoxNo     = dmProp.getString("BOXNO");
		String strDraftNo  = dmProp.getString("DRAFTNO");
		String strRefType = dmProp.getString("REFTYPE");
		GCmConnection conn = (GCmConnection)dmProp.getObject("CONN");

		try
		{


			//draftFinish() ���� ���ؼ��� �ѱ�� ȣ���ϴ°��
			if ( conn == null)
			{
				conn = GCmDbManager.getInstance().getConnection();
			}



		GTpDraft draft = new GTpDraft();


		String strRegDraftNo= draft.getMaxRegDrftNo(cp, dmProp, msgInfo);                   //GCoDfDraft.class ȣ��


		conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
							.append(" INSERT INTO TB_").append(strComCode).append("_D20 ")
							.append(" (REGDRFTNO,BOXNO,DRFTNO,REFTYPE,READTYPE,TRASHFLAG,READFLAG ) ")
							.append(" VALUES (")
							.append(genQuote(strRegDraftNo)).append(", ")
							.append(genQuote(strBoxNo)).append(", ")
							.append(genQuote(strDraftNo)).append(", ")
							.append(genQuote(strRefType)).append(", ")
							.append(genQuote("1")).append(", ")			//Ȯ������ �ƴ�
							.append(genQuote("1")).append(", ")			//������ �ƴ�
							.append(genQuote("1")).append(" ) ");			//���� Ȯ��  ��������:1, ����:0  -----> ���� �ʿ���� ���




			conn.executeUpdate(sqlQuery.toString());

			conn.commit();

			return true;

		}
		catch (Exception e)
		{

			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoDfDraftTran :: insertRegDraft " + e.getMessage());
			}


			System.out.println("GCoDfDraftTran ::  insertRegDraft" + e.getMessage());

			return false;

		}
		finally
		{
			conn.close();
		}
	}







	/**
	 * <PRE>
	 *  �ӽú����� ���ۼ��� ���
	 *  1. ���������� ���� �� �űԹ������� �Է�
	 *  2. �������Ժ� ��ȸ�� ����
	 *  3. �����ڸ�� ����
	 *  4. ������� ����
	 * </PRE>
	 *
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						    <BR>
	 *				<TT><UL>
     *				<LI> String COMCODE       : ȸ���ڵ�  <BR>
	 *				<LI> String PDRFTNO         : ��ȹ�ȣ	<BR>
	 *				<LI> String PDOCNO          : ������������ <BR>
	 *				<LI> String DOCNO            : ������������ <BR>
	 *				<LI> String TMPPATH         : ������������ <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return intCount ���Է� ó�� ��(������ 2���� �����ؼ� ...)
	 * �Ʒ� �������� ������Ʈ���� ProcessingExceptionó���� ���־�� ��.
	 */

	public int  reSaveDeleteCount(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strDraftNo  = dmProp.getString("DRAFTNO");
		String strPdocNo = dmProp.getString("PDOCNO");
		String strDocNo = dmProp.getString("DOCNO");
		String strTmpPath = dmProp.getString("TMPPATH");



		String strSeq = "";
        String strNewSeq = "";
        int intCount= 2;


		try
		{

		// �����󼼸������ (Select L11 Table)

			GTpDoc doc = new GTpDoc();					//�������� �ν��Ͻ� ����



			dmProp.setProperty("Docno", strPdocNo);
			dmProp.setProperty("Seq", "01");

			GCmResultSet rs = doc.getDocDtlList(cp, dmProp, msgInfo);       //�����󼼸������( L11 Table )



	        // �����󼼸�� ����... (Delete L11 Table)
	        doc.deleteFileAll(cp, dmProp, msgInfo);



			//���Է�(L11)
			while (rs.next())
			{


				strNewSeq = GCmFcts.numToStr(intCount, 2);



				dmProp.setProperty("COMCODE", strComCode);
				dmProp.setProperty("DOCNO", strDocNo);
				dmProp.setProperty("SEQ", strNewSeq);
				dmProp.setProperty("CONTTYPE", rs.getString("CONTTYPE"));
				dmProp.setProperty("TITLE", rs.getString("TITLE"));
				dmProp.setProperty("FILEEXT", rs.getString("FILEEXT"));
				dmProp.setProperty("FILENAME", rs.getString("FILENAME"));
				dmProp.setProperty("VPATH", rs.getString("VPATH"));
				dmProp.setProperty("MIMETYPE", rs.getString("MIMETYPE"));
				dmProp.setProperty("FILESIZE", rs.getString("FILESIZE"));
				dmProp.setProperty("ORGNAME", rs.getString("ORGNAME"));
				dmProp.setProperty("ORGPATH", rs.getString("ORGPATH"));
				dmProp.setProperty("REGUSER", rs.getString("REGUSER"));
				dmProp.setProperty("REGDATE", rs.getString("REGDATE"));
				dmProp.setProperty("MODUSER", rs.getString("MODUSER"));
				dmProp.setProperty("MODDATE", rs.getString("MODDATE"));


				doc.insertAttDoc(cp, dmProp, msgInfo);									//���ο� DOCNO�� Insert

				intCount++;
			}


			conn = GCmDbManager.getInstance().getConnection();



			conn.setAutoCommit(false);


			deleteRegDraftList(conn, strComCode, strDraftNo, msgInfo);		//�������Ժ� ��ȸ�� ���� D20

			deleteDraftManList(conn, strComCode, strDraftNo, msgInfo);		//�����ڸ�� ����	D11

			deleteDraftList(conn, strComCode, strDraftNo, msgInfo);				//������ ����	D10



			conn.commit();

			return intCount;

		}
		catch (Exception e)
		{

			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoDfDraftTran :: reSaveDeleteCount" + e.getMessage());
			}


			System.out.println("GCoDfDraftTran :: reSaveDeleteCount" + e.getMessage());

			return -1;

		}
		finally
		{
			conn.close();
		}
	}




	/**
	 * <PRE>
	 *  �������Ժ� ��ȸ�� ����
	 * </PRE>
	 *
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						    <BR>
	 *				<TT><UL>
     *				<LI> String COMCODE       : ȸ���ڵ�  <BR>
	 *				<LI> String DRFTNO           : ��ȹ�ȣ	<BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 */

	public void  deleteRegDraftList(GCmConnection conn, String comCode, String draftNo , GCmMsgInfo msgInfo)
		throws GCmProcessingErrorException, GCmParameterErrorException
	{



		try
		{


			// parameter check
			if (conn == null)
			{
				throw new GCmParameterErrorException("deleteRegDraftList() connection object is null...");
			}
			else if ((draftNo == null) || (draftNo.equals("")))
			{
				throw new GCmParameterErrorException("deleteRegDraftList() draftNo parameter error...");
			}
			else if ((comCode == null) || (comCode.equals("")))
			{
				throw new GCmParameterErrorException("deleteRegDraftList() comCode parameter error...");
			}



			StringBuffer sqlQuery = new StringBuffer()
							.append(" DELETE FROM TB_").append(comCode).append("_D20 ")
							.append(" WHERE DRFTNO = " + genQuote(draftNo));



			conn.executeUpdate(sqlQuery.toString());



		}
		catch (Exception e)
		{

			System.err.println("GCoDfDraftTran :: deleteRegDraftList" + e.getMessage());

			throw new GCmProcessingErrorException("GCoDfDraftTran :: deleteRegDraftList " + e.getMessage());

		}

	}




/**
	 * <PRE>
	 *  �����ڸ�� ����
	 * </PRE>
	 *
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						    <BR>
	 *				<TT><UL>
     *				<LI> String COMCODE       : ȸ���ڵ�  <BR>
	 *				<LI> String DRFTNO           : ��ȹ�ȣ	<BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 */

	public void  deleteDraftManList(GCmConnection conn, String comCode, String draftNo , GCmMsgInfo msgInfo)
		throws GCmProcessingErrorException, GCmParameterErrorException
	{


		try
		{

			// parameter check
			if (conn == null)
			{
				throw new GCmParameterErrorException("deleteDraftManList() connection object is null...");
			}
			else if ((draftNo == null) || (draftNo.equals("")))
			{
				throw new GCmParameterErrorException("deleteDraftManList() draftNo parameter error...");
			}
			else if ((comCode == null) || (comCode.equals("")))
			{
				throw new GCmParameterErrorException("deleteDraftManList() comCode parameter error...");
			}



			StringBuffer sqlQuery = new StringBuffer()
							.append(" DELETE FROM TB_").append(comCode).append("_D11 ")
							.append(" WHERE DRFTNO = " + genQuote(draftNo));


			conn.executeUpdate(sqlQuery.toString());

		}
		catch (Exception e)
		{


			System.out.println("GCoDfDraftTran :: deleteDraftManList" + e.getMessage());

			throw new GCmProcessingErrorException("GCoDfDraftTran :: deleteDraftManList " + e.getMessage());

		}

	}




/**
	 * <PRE>
	 *  ������ ����
	 * </PRE>
	 *
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						    <BR>
	 *				<TT><UL>
     *				<LI> String COMCODE       : ȸ���ڵ�  <BR>
	 *				<LI> String DRFTNO           : ��ȹ�ȣ	<BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 */

	public void deleteDraftList(GCmConnection conn, String comCode, String draftNo , GCmMsgInfo msgInfo)
		throws GCmProcessingErrorException, GCmParameterErrorException
	{


		try
		{


			// parameter check
			if (conn == null)
			{
				throw new GCmParameterErrorException("deleteDraftList() connection object is null...");
			}
			else if ((draftNo == null) || (draftNo.equals("")))
			{
				throw new GCmParameterErrorException("deleteDraftList() draftNo parameter error...");
			}
			else if ((comCode == null) || (comCode.equals("")))
			{
				throw new GCmParameterErrorException("deleteDraftList() comCode parameter error...");
			}



			StringBuffer sqlQuery = new StringBuffer()
							.append(" DELETE FROM TB_").append(comCode).append("_D10 ")
							.append(" WHERE DRFTNO = " + genQuote(draftNo));


			conn.executeUpdate(sqlQuery.toString());


		}
		catch (Exception e)
		{


			System.out.println("GCoDfDraftTran :: delteDraftList" + e.getMessage());

			throw new GCmProcessingErrorException("GCoDfDraftTran :: deleteDraftList" + e.getMessage());



		}

	}





	/**
	 * <PRE>
	 *  ���������� ����Ϸ�
	 * </PRE>
	 *
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						    <BR>
	 *				<TT><UL>
     *				<LI> String COMCODE       : ȸ���ڵ�  <BR>
	 *				<LI> String DRAFTNO         : �Թ�ȣ     <BR>
	 *				<LI> String DRAFTID           : ��ȹ�ȣ	<BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 */

	public boolean  draftFinish(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strDraftNo     = dmProp.getString("DRAFTNO");
		String strDraftId  = dmProp.getString("DRAFTID");
		String strApprId = "";
		String strSubId = "";
		String strRefType = "";
		String strRet = "";

		try
		{
			conn = GCmDbManager.getInstance().getConnection();


			conn.setAutoCommit(false);


			//���缱�� ������ ã��
			StringBuffer sqlQuery = new StringBuffer()
							.append(" SELECT APPRID FROM TB_").append(strComCode).append("_D11 ")
							.append(" WHERE DRFTNO = " + genQuote(strDraftNo)+" AND REFTYPE = '1' ")
							.append(" ORDER BY SEQ ASC ");

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());


			while(rs.next()) {

				strApprId = rs.getString("APPRID");

				//���缱���� ���������Կ��� �Ϸ����������
				updateDraftFinish(conn, strComCode, strApprId, GCmConstDef.EXECCLASS_DRAFT_SENDBOX, strDraftNo, msgInfo);

			}


			//������������ ���������Կ��� �Ϸ����������
			updateDraftFinish(conn, strComCode, strApprId, GCmConstDef.EXECCLASS_DRAFT_INBOX, strDraftNo, msgInfo);


			//������� ���������Կ��� �Ϸ����������
			updateDraftFinish(conn, strComCode, strDraftId, GCmConstDef.EXECCLASS_DRAFT_SENDBOX, strDraftNo, msgInfo);



			//������ ��� ã��
			StringBuffer sqlQuery2 = new StringBuffer()
							.append(" SELECT APPRID,APPRNAME,REFTYPE FROM TB_").append(strComCode).append("_D11 ")
							.append(" WHERE DRFTNO = " + genQuote(strDraftNo)+" AND REFTYPE = '3' ");

			GCmResultSet rs2 = conn.executeQuery(sqlQuery2.toString());

			GCmResultSet rs3 = null;

			while (rs2.next())
			{
			        StringBuffer sqlQuery3 = new StringBuffer();
				//�Թ�ȣ ã��
				sqlQuery3.append(" SELECT BOXNO FROM TB_").append(strComCode).append("_M10 ")
								.append(" WHERE PARENTNO = '000000000000' AND ")
								.append(" BOXCLASS = '4' AND ")
								.append(" EXECCLASS = '1' AND ")
								.append(" USERID = " + genQuote(rs2.getString("APPRID")));

				rs3 = conn.executeQuery(sqlQuery3.toString());

				rs3.next();

				strRet = rs3.getString("BOXNO");

				if (!strRet.equals(null))
				{

					dmProp.setObject("CONN", conn);
					dmProp.setProperty("COMCODE", strComCode);
					dmProp.setProperty("BOXNO", rs3.getString("BOXNO"));
					dmProp.setProperty("DRAFTNO", strDraftNo);
					dmProp.setProperty("REFTYPE", rs2.getString("REFTYPE"));

					//������ �����Ժ� ��ȸ�� �Է�
					insertRegDraft(cp, dmProp, msgInfo);

				}

			}

			conn.commit();
			return true;

		}
		catch (Exception e)
		{

			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoDfDraftTran :: draftFinish" + ignored.getMessage());
			}


			System.out.println("GCoDfDraftTran :: draftFinisth" + e.getMessage());

			return false;

		}
		finally
		{
			conn.close();
		}
	}






/**
	 * <PRE>
	 *  �����ڸ�� �� �������� �������� ����(������¿� ������¿� ���� �Ե��� ����Ǿ�� �ϹǷ�)
	 * </PRE>
	 *
	 * @param dmProp	GCmProperties ��ü
	 *<�����׸� ����Ʈ><BR>
	 *<TT><UL>
         *<LI> String COMCODE : ȸ���ڵ�  <BR>
	 *<LI> String APPRID  : ������ID	<BR>
	 *<LI> String BOX     : ������(�Ϸ������ : EXECCLASS_DRAFT_ENDBOX , ���������� : EXECCLASS_DRAFT_INBOX)<BR>
	 *</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @
	 */

	public void  updateDraftFinish(GCmConnection conn, String comCode, String apprId , String box , String draftNo, GCmMsgInfo msgInfo)
		throws GCmProcessingErrorException, GCmParameterErrorException
	{
            int intCount = 0;

            try
            {

              // parameter check
              if (conn == null)
              {
	        throw new GCmParameterErrorException("updateDraftFinish() connection object is null...");
              }
              else if ((comCode == null) || (comCode.equals("")))
              {
                throw new GCmParameterErrorException("updateDraftFinish() comCode parameter error...");
              }
              else if ((apprId == null) || (apprId.equals("")))
              {
                throw new GCmParameterErrorException("updateDraftFinish() apprId parameter error...");
              }


              StringBuffer sqlQuery = new StringBuffer()
			    .append(" UPDATE  TB_").append(comCode).append("_D20 ")
			    .append(" SET BOXNO = (SELECT BOXNO FROM TB_").append(comCode).append("_M10")
			    .append(" WHERE USERID = " + genQuote(apprId))
			    .append(" AND BOXCLASS = " + genQuote(GCmConstDef.BOXCLASS_DRAFT))
			    .append(" AND EXECCLASS = " + genQuote(GCmConstDef.EXECCLASS_DRAFT_ENDBOX))
			    .append(" AND BOXTYPE = " + genQuote(GCmConstDef.BOXTYPE_PRIVATE) + " ) " )
                            .append(" WHERE BOXNO = ( SELECT BOXNO FROM TB_").append(comCode).append("_M10")
			    .append(" WHERE USERID = " + genQuote(apprId))
			    .append(" AND BOXCLASS = " + genQuote(GCmConstDef.BOXCLASS_DRAFT))
			    .append(" AND EXECCLASS = " + genQuote(box))
			    .append(" AND BOXTYPE = " + genQuote(GCmConstDef.BOXTYPE_PRIVATE) + ")" )
			    .append(" AND DRFTNO = " + genQuote(draftNo));

              conn.executeUpdate(sqlQuery.toString());

            }
	    catch (Exception e)
	    {

                System.out.println("GCoDfDraftTran :: updateDraftFinish"+ e.getMessage());
                throw new GCmProcessingErrorException("GCoDfDraftTran :: updateDraftFinish " + e.getMessage());
            }
        }


	/**
	 * <PRE>
	 *  �ڷ��Կ�����
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�	<BR>
	 *				<LI> String BOXNO         : �Թ�ȣ  <BR>
	 *				<LI> String DRFTNO        : ���Ϲ�ȣ  <BR>
	 *				<LI> String REGDRFTNO  : ���θ��Ϲ�ȣ <BR>
	 *				<LI> String FLDBOXNO    : ������  <BR>
	 *				<LI> String FLDNO          : ����  <BR>
	 *				<LI> String USERID         : �����ID	<BR>
	 *				<LI> String USERNAME   : ������̸�  <BR>
	 *				<LI> String PPATH          : ���θ��Ϲ�ȣ  <BR>
	 *				<LI> String DOMAIN        : URL	<BR>
	 *				<LI> String READPAGE    : ������ȸ���ϸ� <BR>
	 *				<LI> String HTTPPORT     : ��Ʈ  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  boolean
	 */

        public boolean setCopyFld(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
            GCmConnection conn = null;

            String strComCode = dmProp.getString("COMCODE");
            String strBoxNo     = dmProp.getString("BOXNO");
            String strDrftNo   = dmProp.getString("DRFTNO");
            String strRegDrftNo   = dmProp.getString("REGDRFTNO");
			String strFldBoxNo = dmProp.getString("FLDBOXNO");
            String strFldNo     = dmProp.getString("FLDNO");
            String strUserId   = dmProp.getString("USERID");
            String strUserName   = dmProp.getString("USERNAME");
            String strPpath = dmProp.getString("PPATH");
            String strDomain     = dmProp.getString("DOMAIN");
            String strReadPage   = dmProp.getString("READPAGE");
            String strHttpPort   = dmProp.getString("HTTPPORT");
            String strSecLvl  = dmProp.getString("SECLVL");

            int intRet = 0;

            java.io.File srcFile = null;        // ������ ����
            java.io.File desFile = null;        // ����� ����

            String strDocNo = "";                  // �űԹ�����ȣ
            String strOldDocNo =  "";              // ����������ȣ
            String strTitle = "";                  // ����

            java.util.Vector vDoc = new java.util.Vector();     // ������� ����Ʈ


            GCoDoDoc doc = new GCoDoDoc();
            GCoDoDocTran docTran = new GCoDoDocTran();
            GCoDoDocFolder docFolder = new GCoDoDocFolder();
            GCoDoDocFolderTran docFolderTran = new GCoDoDocFolderTran();

            GTpDraft draft = new GTpDraft();

            try
            {

	        String strRegDate = GCmDateFcts.dateToStr(new java.util.Date(),2);    // �����

    	        // �ش��ȿ� ���� �����ľ�
		GCmResultSet rs = draft.getDraftInfo(cp, dmProp, msgInfo);

		rs.next();

		//����������ȣ
		strOldDocNo = rs.getString("DOCNO");
		//����
		strTitle = rs.getString("TITLE");

	        // �������(����������)�� �Է�
	        // -- ��������
		dmProp.setProperty("Docno", strOldDocNo);

		GCmResultSet rs2 = doc.getDocInfo(cp, dmProp, msgInfo);

		rs2.next();


                // -- �ű��Է�
		dmProp.setProperty("Title", rs2.getString("TITLE"));
		dmProp.setProperty("Doctype", rs2.getString("DOCTYPE"));
		dmProp.setProperty("Attnum", rs2.getString("FILENUM"));
		dmProp.setProperty("Reguser", rs2.getString("REGUSER"));
		dmProp.setProperty("Regdate", rs2.getString("REGDATE"));
		dmProp.setProperty("Moduser", strUserId);
		dmProp.setProperty("Moddate", strRegDate);

		docTran.insertDoc(cp, dmProp, msgInfo);

		strDocNo = dmProp.getProperty("Docno");

	        // ������Ͽ� �Է�
		dmProp.setProperty("Boxno", strFldBoxNo);
		dmProp.setProperty("Docno", strDocNo);
		dmProp.setProperty("Parentno", strFldNo);
		dmProp.setProperty("Boxname", strTitle);
		dmProp.setProperty("Userno", strUserId);
		dmProp.setProperty("Regdate", strRegDate);
		dmProp.setProperty("Trashflag", "1");
		dmProp.setProperty("Comments", "");
		dmProp.setProperty("Refno", "D"+strRegDrftNo+strBoxNo);


		docFolderTran.insertFolder(cp, dmProp, msgInfo);

	        // ������Ͽ� �Է�
		dmProp.setProperty("USERID", strUserId);
		dmProp.setProperty("Boxno", strBoxNo);
		dmProp.setProperty("Fldno", strFldNo);
		dmProp.setProperty("Boxname", "");

		String strFldNoPath = docFolder.getFldnoPath(cp, dmProp, msgInfo);


                String fldpath = "/DATA/" + strComCode + "/BOX/" + strRegDate.substring(0,6)+"/"+strRegDate.substring(6,8) + "/";


	        java.io.File oFile = null;
		java.util.Vector vec= new java.util.Vector();
		String fld = "";
	        String tmp = "";


		tmp = fldpath.substring(0,1);
	        if (tmp.equals("/"))
		  fldpath = fldpath.substring(1,fldpath.length());
                  vec = GCmFcts.getSplit(fldpath,"/");

	        for (int i=0;i<vec.size();i++)
    		{
                    fld += (String)vec.elementAt(i) + "/";
	            oFile = new java.io.File(strPpath + "/" +fld);

    	            if (!oFile.isDirectory()) oFile.mkdir();
		}


                // �����󼼸��
                String seq = "";
                String conttype = "";
                String titleLst = "";
                String fileext = "";
                String oldfilename = "";
                String filename = "";
                String vpath = "";
                String mimetype = "";
                int filesize = 0;
                String orgname = "";
                String orgpath = "";
                String reguserLst = "";
                String regdateLst = "";
                String moduserLst = "";
                String moddateLst = "";
                String despath = fldpath;
				String conts = "";


		// �����󼼸�Ͽ� �Է�
		dmProp.setProperty("Docno", strOldDocNo);
		dmProp.setProperty("Seq", "00");

                GCmResultSet rs3 = doc.getDocDtlList(cp, dmProp, msgInfo);
                dmProp.setProperty("Docno", strOldDocNo);
                dmProp.setProperty("Seq", "01");

                rs2 = doc.getDocInfo(cp, dmProp, msgInfo);
                rs2.next();
                conts = rs2.getString("MSTDOC");

		while(rs3.next())
		{

                    seq = rs3.getString("SEQ");
                    conttype = rs3.getString("CONTTYPE");
                    titleLst = rs3.getString("TITLE");
                    fileext = rs3.getString("FILEEXT");
                    oldfilename = rs3.getString("FILENAME");
                    vpath = rs3.getString("VPATH");
                    mimetype = rs3.getString("MIMETYPE");
                    filesize = rs3.getInt("FILESIZE");
                    orgname = rs3.getString("ORGNAME");
                    orgpath = rs3.getString("ORGPATH");
                    reguserLst = rs3.getString("REGUSER");
                    regdateLst = rs3.getString("REGDATE");
                    moduserLst = rs3.getString("MODUSER");
                    moddateLst = rs3.getString("MODDATE");

                    // �����󼼸�Ͽ� �Է�
                    filename = strDocNo + "_" + seq + fileext;

                    dmProp.setProperty("Docno", strDocNo);
                    dmProp.setProperty("Seq", seq);
                    dmProp.setProperty("Conttype", conttype);
                    dmProp.setProperty("Title", titleLst);
                    dmProp.setProperty("Fileext", fileext);
                    dmProp.setProperty("Filename", filename);
                    dmProp.setProperty("Vpath", fldpath);
                    dmProp.setProperty("Mimetype", mimetype);
                    dmProp.setProperty("Filesize", String.valueOf(filesize));
                    dmProp.setProperty("Orgname", orgname);
                    dmProp.setProperty("Orgpath", orgpath);
                    dmProp.setProperty("Reguser", reguserLst);
                    dmProp.setProperty("Regdate", regdateLst);
                    dmProp.setProperty("Moduser", strUserId);
                    dmProp.setProperty("Moddate", strRegDate);

                    docTran.insertAttDoc(cp, dmProp, msgInfo);


		    // ���Ϻ���...
                    srcFile = new java.io.File(strPpath+vpath,oldfilename);
                    desFile = new java.io.File(strPpath+fldpath,filename);


                    //if (srcFile.isFile())
                    //{

                        // ���������� ���Ŀ� �°� �Է�...
                        //if (seq.equals("02"))
                       	//{
                            // URL ����...
                            StringBuffer para = new StringBuffer();

                            para.append("comcode=").append(strComCode).append("&userid=").append(strUserId)
                                .append("&boxno=").append(strBoxNo).append("&drftno=").append(strDrftNo)
                                .append("&regdrftno=").append(strRegDrftNo).append("&seclvl=").append(strSecLvl).append("&from=copyfld");

                            GCmHtmlPageSaver html = new GCmHtmlPageSaver();

                            String bonmun = html.getHtmlPage(strDomain,Integer.parseInt(strHttpPort),strReadPage,para.toString());

                            dmProp.setProperty("Conts",bonmun);
                            dmProp.setProperty("Docno",strDocNo);

                            docTran.updateContsDoc(cp, dmProp, msgInfo);
                      //---------------------------------------------------�߰� (5.10)
                             if(Integer.parseInt(seq)>01){
                                  GCmFcts.copyFile(srcFile, desFile);
                             }
                      //--------------------------------------------------------------


			    //GCmFcts.setWriteFile(strPpath+fldpath,filename,bonmun);

                        //}
                        //else   GCmFcts.copyFile(srcFile,desFile);
                    //}

		}

		return true;

            }
	    catch (Exception e)
	    {

                System.out.println("GCoDfDraftTran ::  setCopyFld() " + e.getMessage());

		return false;


            }
	    finally
            {

	    }
	}



	public String setDraftTemp(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strBoxNo     = dmProp.getString("BOXNO");
		String strDrftNo   = dmProp.getString("DRFTNO");
		String strRegDrftNo   = dmProp.getString("REGDRFTNO");
		String strFldBoxNo = dmProp.getString("FLDBOXNO");
		String strFldNo     = dmProp.getString("FLDNO");
		String strUserId   = dmProp.getString("USERID");
		//String strUserName   = dmProp.getString("USERNAME");
		//String strPpath = dmProp.getString("PPATH");
		String strDomain     = dmProp.getString("DOMAIN");
		String strReadPage   = dmProp.getString("READPAGE");
		String strHttpPort   = dmProp.getString("HTTPPORT");
		String strSecLvl  = dmProp.getString("SECLVL");
                String bonmun = null;

try{

				// ���������� ���Ŀ� �°� �Է�...


                    // URL ����...
                    StringBuffer para = new StringBuffer();

                    para.append("comcode=").append(strComCode).append("&userid=").append(strUserId)
                        .append("&boxno=").append(strBoxNo).append("&drftno=").append(strDrftNo)
                        .append("&regdrftno=").append(strRegDrftNo).append("&seclvl=").append(strSecLvl).append("&from=copyfld");
					GCmHtmlPageSaver html = new GCmHtmlPageSaver();


					bonmun = html.getHtmlPage(strDomain,Integer.parseInt(strHttpPort),strReadPage,para.toString());


					//GCmFcts.setWriteFile(strPpath+fldpath,filename,bonmun);





			return bonmun;

		}
		catch (Exception e)
		{


			System.out.println("GCoDfDraftTran ::  setCopyFld() " + e.getMessage());

			return bonmun;


		}
		finally
		{

		}
	}

	   /**
        * <PRE>
        * ���繮���� ���Ϸ� ���������� �ӽ÷� ������ ȭ���� �����ϴ� �Լ�
        * </PRE>
        *
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return boolea : ������������
        */
/*public boolean deleteRealFile(String realfile){

  try {
      java.io.File srcFile = new java.io.File(realfile);
         if(srcFile.isFile())
         {
             srcFile.delete();
             return true;
          }
        return false;
      }
      catch (Exception e)
      {
          System.out.println("GCoDraftTran::deleteRealFile()"+e.getMessage());
          return false;
      }
      finally
      {
      }
  }*/



	   /**
        * <PRE>
        * ��������Ͽ� ��ϵǴ� �ű԰�������ȣ�� �����ϴ� �����Լ��̸�,
        * �����Ǵ� �ű԰�������ȣ�� �ش���+�Ϸù�ȣ������ �����ȴ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String strDbType : gplus db type
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return String : �ű԰�������ȣ
        */
    	private String getMaxNo(String comcode,String strDbType)
    	{

		GCmConnection conn = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                           sqlQuery
	          	      .append(" SELECT DECODE(SUBSTR(MAX(LINENUM),1,8),TO_CHAR(sysdate,'YYYYMMDD'),TO_CHAR(TO_NUMBER(MAX(LINENUM))+1),null,TO_CHAR(sysdate,'YYYYMMDD')||'0001') as NO ")
                              .append(" FROM TB_").append(comcode).append("_D30 ")
                              .append(" WHERE LINENUM LIKE TO_CHAR(sysdate,'YYYYMMDD')||'%'");
                        }
                        else if ("mssql".equals(strDbType))
                             {
                                     sqlQuery
                                        .append(" SELECT (CASE SUBSTRING(MAX(LINENUM),1,8) WHEN convert(char(08),getdate(),112) THEN CAST(SUBSTRING(MAX(LINENUM),1,8) AS varchar(8)) + RIGHT('0000'+CAST(SUBSTRING(MAX(LINENUM),9,4)+1 AS varchar(4)),4) ELSE convert(char(08),getdate(),112)+'0001' END) as NO ")
                                        .append(" FROM TB_").append(comcode).append("_D30 ")
                                        .append(" WHERE LINENUM LIKE convert(char(08),getdate(),112)+'%' ");
                             }


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
                	rs.next();

			return rs.getString("NO");

      		}
      		catch (Exception e)
      		{
 			System.out.println(" GCoDfDraftTran::getMaxNo " + e.getMessage());
	 		return null;
      		}
      		finally
      		{
			conn.close();
      		}
    	}


}