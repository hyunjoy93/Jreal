package gplus.component.broadcast;


import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

/**
 * <PRE>
 * Filename	: GCoBroadCast.java
 * Class	: gplus.component.draft.GCoBroadCast
 * Fuction  :
 * Comment	:
 * History  : 26/03/2002, ���߱� �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GCoBroadCast extends GCmTopComponent
{
	/**
	 * <PRE>
	 * ����ī��Ʈ
	 * </PRE>
	 *
	 * @param prop	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�	<BR>
	 *				<LI> String USERID         : �����ID  <BR>
	 *				<LI> String timelogin        : �α��νð�  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  GCmResultSet ���� ��
	 */
	public GCmResultSet getLineInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID  = dmProp.getString("USERID");
        String Lineno = dmProp.getString("Lineno");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                            .append(" SELECT TITLE, NOTE ")
                            .append(" FROM TB_").append(COMCODE).append("_F30 ")
                            .append(" WHERE BROADCASTNO = "+genQuote(Lineno));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		}
		catch (Exception e)
		{
	 		System.err.println(" GCoBroadCast::getLineInfo " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}

	}

	/**
	 * <PRE>
	 * ����ī��Ʈ
	 * </PRE>
	 *
	 * @param prop	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�	<BR>
	 *				<LI> String USERID         : �����ID  <BR>
	 *				<LI> String timelogin        : �α��νð�  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  GCmResultSet ���� ��
	 */
	public GCmResultSet getLineList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID  = dmProp.getString("USERID");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                            .append(" SELECT BROADCASTNO, TITLE, NOTE ")
                            .append(" FROM TB_").append(COMCODE).append("_F30 ")
                            .append(" WHERE USERID = "+genQuote(USERID));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		}
		catch (Exception e)
		{
	 		System.err.println(" GCoBroadCast::getLineList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}

	}

	/**
	 * <PRE>
	 * ����ī��Ʈ
	 * </PRE>
	 *
	 * @param prop	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�	<BR>
	 *				<LI> String USERID         : �����ID  <BR>
	 *				<LI> String timelogin        : �α��νð�  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  GCmResultSet ���� ��
	 */
	public GCmResultSet getBroadUserList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID  = dmProp.getString("USERID");
        String Lineno = dmProp.getString("Lineno");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                            .append(" SELECT ACCTINFO, USERNAME, BROADTYPE ")
                            .append(" FROM TB_").append(COMCODE).append("_F31 ")
                            .append(" WHERE BROADCASTNO = "+genQuote(Lineno));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		}
		catch (Exception e)
		{
	 		System.err.println(" GCoBroadCast::getBroadUserList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}

	}

	/**
	 * <PRE>
	 * ����ī��Ʈ
	 * </PRE>
	 *
	 * @param prop	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�	<BR>
	 *				<LI> String USERID         : �����ID  <BR>
	 *				<LI> String timelogin        : �α��νð�  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  GCmResultSet ���� ��
	 */
	public GCmResultSet getdupName(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID  = dmProp.getString("USERID");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();
			StringBuffer sqlQuery = new StringBuffer()
                            .append(" SELECT USERNAME AS NAME ")
                            .append(" FROM (SELECT USERNAME, COUNT(USERNAME) AS CNT ")
                            .append("       FROM TB_COMM_Z20 ")
                            .append("       GROUP BY USERNAME) T1 ")
                            .append(" WHERE T1.CNT > 1 ");

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		}
		catch (Exception e)
		{
	 		System.err.println(" GCoBroadCast::getdupName " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}

	}

	/**
	 * <PRE>
	 * ����ī��Ʈ
	 * </PRE>
	 *
	 * @param prop	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�	<BR>
	 *				<LI> String USERID         : �����ID  <BR>
	 *				<LI> String timelogin        : �α��νð�  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  GCmResultSet ���� ��
	 */
	public GCmResultSet getAllUserList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;
		String COMCODE = dmProp.getString("COMCODE");
		String USERID  = dmProp.getString("USERID");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

                        StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                           sqlQuery
                              .append(" SELECT USERID,USERNAME, POSNAME||' '||USERNAME AS POSUSERNAME ")
                              .append(" FROM TB_COMM_Z20 T1, TB_"+COMCODE+"_N20 T2 ")
                              .append(" WHERE T1.POSCODE = T2.POSCODE (+) ");
                        }
                        else if ("mssql".equals(strDbType))
                        {
                           sqlQuery
                              .append(" SELECT USERID,USERNAME, POSNAME+' '+USERNAME AS POSUSERNAME ")
                              .append(" FROM TB_COMM_Z20 T1, TB_"+COMCODE+"_N20 T2 ")
                              .append(" WHERE T1.POSCODE *= T2.POSCODE ");
                        }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		}
		catch (Exception e)
		{
	 		System.err.println(" GCoBroadCast::getAllUserList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}

	}

	/**
	 * <PRE>
	 * ����ī��Ʈ
	 * </PRE>
	 *
	 * @param prop	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�	<BR>
	 *				<LI> String USERID         : �����ID  <BR>
	 *				<LI> String timelogin        : �α��νð�  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  GCmResultSet ���� ��
	 */
	public GCmResultSet getFindNameUsers(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;
		String COMCODE = dmProp.getString("COMCODE");
		String USERID  = dmProp.getString("USERID");
		String Username  = dmProp.getString("Username");
        String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

                        StringBuffer sqlQuery = new StringBuffer();
                        if ("oracle".equals(strDbType))
                        {
                           sqlQuery
                            .append(" SELECT T2.POSNAME||' '||T1.USERNAME USERNAME, '2'||T1.USERID ID ")
                            .append(" FROM TB_COMM_Z20 T1, TB_").append(COMCODE).append("_N20 T2 ")
                            .append(" WHERE T1.POSCODE = T2.POSCODE (+) AND USERNAME = "+genQuote(Username));
                        }
                        else if ("mssql".equals(strDbType))
                        {
                           sqlQuery
                            .append(" SELECT T2.POSNAME+' '+T1.USERNAME USERNAME, '2'+T1.USERID ID ")
                            .append(" FROM TB_COMM_Z20 T1, TB_").append(COMCODE).append("_N20 T2 ")
                            .append(" WHERE T1.POSCODE *= T2.POSCODE AND USERNAME = "+genQuote(Username));
                        }


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		}
		catch (Exception e)
		{
	 		System.err.println(" GCoBroadCast::getFindNameUsers " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}

	}

	public GCmResultSet getGrpCardList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
        GCmConnection conn = null;
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
        String pCardGrpNo = dmProp.getString("CardGrpNo");

		try
		{
         		conn = GCmDbManager.getInstance().getConnection();
	        	StringBuffer sqlQuery = new StringBuffer();

  	      	     sqlQuery
                    .append(" SELECT NAMEK,EMAIL,EMAIL1,EMAIL2 ")
                    .append(" FROM TB_").append(COMCODE).append("_F10 ")
                    .append(" WHERE GRPNO = "+genQuote(pCardGrpNo)+" AND USERID = "+genQuote(USERID));

		GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
		return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoBroadCast::getGrpCardList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

	public GCmResultSet getNotGrpCardList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
        GCmConnection conn = null;
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
        String Opt = dmProp.getString("Opt");
        String Q = dmProp.getString("Q");
        String SortID = dmProp.getString("SortID");
        String SortOpt = dmProp.getString("SortOpt");

        String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

        String sortList = SortID + " "+ SortOpt ;
        String optStr = "";

		try
		{
               if (!Opt.equals("") && !Q.equals(""))
               {
                    optStr = " AND LOWER("+Opt+") LIKE '%" + Q.toLowerCase() + "%' ";
               }

         		conn = GCmDbManager.getInstance().getConnection();
	        	StringBuffer sqlQuery = new StringBuffer();

                if ("oracle".equals(strDbType))
                {
	  	      	     sqlQuery
                        .append(" SELECT NAMEK,EMAIL,EMAIL1,EMAIL2 ")
                        .append(" FROM TB_").append(COMCODE).append("_F10 ")
                        .append(" WHERE GRPNO IS NULL AND USERID = "+genQuote(USERID)+" "+optStr)
                        .append(" ORDER BY "+sortList);
                }
                else if("mssql".equals(strDbType))
                     {
	  	       	         sqlQuery
                            .append(" SELECT NAMEK,EMAIL,EMAIL1,EMAIL2 ")
                            .append(" FROM TB_").append(COMCODE).append("_F10 ")
                            .append(" WHERE GRPNO = '' AND USERID = "+genQuote(USERID)+" "+optStr)
                            .append(" ORDER BY "+sortList);
                     }

		GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
		return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoBroadCast::getNotGrpCardList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}


}
