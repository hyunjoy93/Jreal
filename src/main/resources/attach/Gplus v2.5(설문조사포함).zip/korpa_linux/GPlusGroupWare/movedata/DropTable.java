
import java.io.*;
import java.lang.*;
import java.util.*;
import java.sql.*;
import oracle.sql.*;
import oracle.jdbc.driver.*;


public class DropTable
{
	private static Properties m_setupProp = null;
	private static Properties m_sysProp = null;
	private static final String ORACLE_SCHEMA 	= "gplus_schema_oracle.sql";
	private static final String MSSQL_SCHEMA 	= "gplus_schema_mssql.sql";

	private static PrintWriter log = null;

	/**
	 * Main Method
	 */
	public static void main(String[] args)
	{

		String strGplusProperties = ".." + File.separator + "gplus.properties";
		m_setupProp = loadProperties("movesetup.properties");
		m_sysProp = loadProperties(strGplusProperties);

		String strFileName = m_sysProp.getProperty("gplus.log.path") + File.separator + "setup.log";

		try
		{
			log = new PrintWriter(new FileWriter(strFileName, true), true);
		}
		catch (IOException e)
		{
			System.err.println("Can't open the log file: " + strFileName);
			log = new PrintWriter(System.err);
		}

		try
		{
			int nPhase = 1;

			System.out.print("Phase " + nPhase + " >>> dropGPlus Table ");
			log.print("Phase " + nPhase + " >>> dropGPlus Table ");
			DropGPlusTable();
			System.out.println("...DONE");
			log.println("...DONE");
			nPhase++;
		} 
		catch (Exception e) {
			System.out.println(" Exception "+e.getMessage());
			log.println(" Exception "+e.getMessage());
		}
	}

	/**
	 * ���Ϸκ��� Property���� Load�Ѵ�.
	 *
	 * @param strPropertiesFile Property File Location
	 * @return Loaded Properties
	 */
	private static Properties loadProperties(String strPropertiesFile)
	{
		Properties propTmp = new Properties();
    	try
    	{
		    FileInputStream fin = new FileInputStream(strPropertiesFile);
		    propTmp.load(fin);
		    fin.close();
		    return propTmp;
		}
		catch (IOException e)
		{
			System.err.println(e);
			return null;
		}
	}

        public static String replace(String src, String from, String to )
        {
          if ( src == null ) return null;
          if ( from == null ) return src;
          if ( to == null ) to = "";

          StringBuffer buf = new StringBuffer();

          for(int pos; (pos = src.indexOf(from)) >= 0; ) {
              buf.append(src.substring(0,pos));
              buf.append(to);
              src = src.substring(pos+from.length());
          }

          buf.append(src);
          return buf.toString();
       }

    private static String toDB(String str, String dbCharSet)
    {

		try
		{
			return new String (str.getBytes(dbCharSet), "KSC5601");
		}
		catch (Exception e)
		{
			e.printStackTrace(System.err);
			return null;
		}
    }


	/**
	 * ��Ʈ���� �յڷ� Single-quote�� ���δ�.
	 *
	 * @param sqlString
	 * @param strEncoding ��Ʈ���� ���ڵ�
	 * @return Quoted-string
	 */
	private static String genQuote(String sqlString)
	{
		if ((sqlString == null) || (sqlString.equals("")) || (sqlString.equals("`")))
		{
			return ("''");		// blank string
		}
		else
		{
			String resultString = "";
			StringTokenizer st = new StringTokenizer(sqlString, "'");

			resultString += st.nextToken();

			while (st.hasMoreTokens())
			{
				resultString += "''";
				resultString += st.nextToken();
			}

			return ("'" + toDB(resultString, "8859_1") + "'");
		}
	}


	private static void DropGPlusTable()
	{
		Connection conn = null;
		Statement  stmt = null;

		try
		{
			Class.forName(m_sysProp.getProperty("gplus.db.jdbcDriver"));

			String strUrl 		= m_sysProp.getProperty("gplus.db.jdbcUrl");
			String strUser 		= m_sysProp.getProperty("gplus.db.user");
			String strPasswd 	= m_sysProp.getProperty("gplus.db.password");

			String oldComCode 	= m_setupProp.getProperty("gplus.old.companycode");
			String newComCode 	= m_setupProp.getProperty("gplus.new.companycode");

                        StringBuffer SqlQuery = null;
			
			conn = DriverManager.getConnection(strUrl, strUser, strPasswd);
			stmt = conn.createStatement();

                       SqlQuery = new StringBuffer()
                          .append(" UPDATE TB_COMM_Z10 ")
                          .append(" SET COMCODE = '"+oldComCode+"' ")
                          .append(" WHERE COMCODE = '"+newComCode+"' ");
			stmt.executeUpdate(SqlQuery.toString());

                        SqlQuery = new StringBuffer()
                          .append(" UPDATE TB_COMM_Z20 ")
                          .append(" SET COMCODE = '"+oldComCode+"' ")
                          .append(" WHERE COMCODE = '"+newComCode+"' "); 
			stmt.executeUpdate(SqlQuery.toString()); 

                        String[] Tables = {"A01","B10","C10","C11","C20","C30","D10","D11","D20","D30","D31","E10",
                                           "G10","F10","F11","F30","F31","F50","L10","L11","M10",
                                           "M20","N10","N11","N20","N30"};

                        for(int i=0; i<Tables.length;i++) {
                            SqlQuery = new StringBuffer().append("  DROP TABLE TB_"+newComCode+"_"+Tables[i]);
                            stmt.executeUpdate(SqlQuery.toString());
                        }

			conn.commit();

		}
		catch (SQLException e)
		{
			System.out.println("ERROR : createDefaultUser : Default Mall Creation Failure");
			e.printStackTrace();
		}
		catch (ClassNotFoundException e)
		{
			System.out.println("ERROR : createDefaultUser : Can't register JDBC Driver");
			e.printStackTrace();
		}
		catch (Exception e)
		{
			System.out.println("ERROR : createDefaultUser : Unhandled exception");
			e.printStackTrace();
		}
		finally
		{
			try
			{
				stmt.close();
				conn.close();
			}
			catch (SQLException e)
			{
				e.printStackTrace();
			}
		}
	}

    private static String numToStr(String n, int l)
        throws Exception {
        String strRet = "";
        if(n.length() < l) {
          for(int i = 0; i < l - n.length(); i++)
            strRet = "0".concat(String.valueOf(strRet));

          strRet = String.valueOf(strRet) + String.valueOf(n);
        }
        else {
          strRet = n;
        }
        return strRet;
    }


}
