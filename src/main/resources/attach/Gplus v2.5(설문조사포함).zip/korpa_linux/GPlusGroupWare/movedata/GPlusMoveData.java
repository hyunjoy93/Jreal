
import java.io.*;
import java.lang.*;
import java.util.*; 
import java.sql.*;
import oracle.sql.*;
import oracle.jdbc.driver.*;

/**********
 GPLUS GroupWare ���̺� ���̱׷��̼ǽÿ�  ���� ���� 
 
 1) oracle�� init.ora����   SMALL -> # LARGE �� ����
    # db_files = 80                                    # SMALL
    # db_files = 400                                   # MEDIUM
    db_files = 1500                                    # LARGE

    # db_file_multiblock_read_count = 8                # SMALL
    # db_file_multiblock_read_count = 16               # MEDIUM
    db_file_multiblock_read_count = 32                 # LARGE

    # db_block_buffers = 100                           # SMALL
    # db_block_buffers = 550                           # MEDIUM
    db_block_buffers = 3200                            # LARGE

    # shared_pool_size = 3500000                       # SMALL
    # shared_pool_size = 5000000                       # MEDIUM
    shared_pool_size = 9000000                         # LARGE
    
 2) TABLE SPACE �� �÷��ش�...
 
 3) $ORACLE_HOME/dbs/init<SID>.ora ���Ͽ��� shared_pool_size �κ��� �ø��� DB restart �� �ȴ�
    ex)  vi ./app/oracle/product/8.1.7/dbs/initORCL.ora
         shared_pool_size = 419430400  // 4194304 ����  
         large_pool_size = 61440000    // 614400 ����
 
*******************/
 
public class GPlusMoveData
{
	private static Properties m_setupProp = null;
	private static final String ORACLE_SCHEMA 	= "gplus_schema_oracle.sql";
	private static final String MSSQL_SCHEMA 	= "gplus_schema_mssql.sql";

	private static PrintWriter log = null;

	/**
	 * Main Method
	 */
	public static void main(String[] args)
	{
		m_setupProp = loadProperties("movesetup.properties");

		String strFileName = m_setupProp.getProperty("gplus.log.path") + File.separator + "setup.log";

		try
		{
			log = new PrintWriter(new FileWriter(strFileName, true), true);
		}
		catch (IOException e)
		{
			System.err.println("Can't open the log file: " + strFileName);
			log = new PrintWriter(System.err);
		}

		try
		{
			int nPhase = 1;

			System.out.print("Phase " + nPhase + " >>> Create New GPLUS Schema ");
			log.print("Phase " + nPhase + " >>> Create New GPLUS Schema ");
			createNewSchema();
			System.out.println("...DONE");
			log.println("...DONE");
			nPhase++;

			System.out.print("Phase " + nPhase + " >>> moveGPlusData ");
			log.print("Phase " + nPhase + " >>> moveGPlusData ");
			moveGPlusData();
			System.out.println("...DONE");
			log.println("...DONE");
			nPhase++; 

			System.out.print("Phase " + nPhase + " >>> moveGPlusLOBData ");
			log.print("Phase " + nPhase + " >>> moveGPlusLOBData ");
			moveGPlusLOBData();
			System.out.println("...DONE");
			log.println("...DONE");
			nPhase++;   
		} 
		catch (Exception e) {
			System.out.println(" Exception "+e.getMessage());
			log.println(" Exception "+e.getMessage());
		}
	}

	/**
	 * ���Ϸκ��� Property���� Load�Ѵ�.
	 *
	 * @param strPropertiesFile Property File Location
	 * @return Loaded Properties
	 */
	private static Properties loadProperties(String strPropertiesFile)
	{
		Properties propTmp = new Properties();
    	try
    	{
		    FileInputStream fin = new FileInputStream(strPropertiesFile);
		    propTmp.load(fin);
		    fin.close();
		    return propTmp;
		}
		catch (IOException e)
		{
			System.err.println(e);
			return null;
		}
	}


	private static void moveGPlusLOBData()
	{
		Connection conn = null;
		Statement  stmt = null;

		try
		{
			Class.forName(m_setupProp.getProperty("gplus.db.jdbcDriver"));

			String strUrl 		= m_setupProp.getProperty("gplus.db.jdbcUrl");
			String strUser 		= m_setupProp.getProperty("gplus.db.user");
			String strPasswd 	= m_setupProp.getProperty("gplus.db.password");

			String oldComCode 	= m_setupProp.getProperty("gplus.old.companycode");
			String newComCode 	= m_setupProp.getProperty("gplus.new.companycode");
			String olddocroot 	= m_setupProp.getProperty("gplus.old.docroot");
			
			conn = DriverManager.getConnection(strUrl, strUser, strPasswd);
			stmt = conn.createStatement();
                        
			StringBuffer szBuff = new StringBuffer()
                                 .append(" SELECT T1.DOCNO,T2.VPATH,T2.FILENAME,FILEEXT ")
                                 .append(" FROM TB_"+oldComCode+"_L10 T1, TB_"+oldComCode+"_L11 T2 ")
                                 .append(" WHERE T1.DOCNO = T2.DOCNO AND T2.SEQ = '01' ")
//                                 .append("       AND T1.DOCNO > '200201030142' ")
                                 .append(" ORDER BY T1.DOCNO ");

                        ResultSet rsDocFile = stmt.executeQuery(szBuff.toString());
                        int cnt=1;
                        
                        while(rsDocFile.next())
                        {

                          if(rsDocFile.getString("FILEEXT").trim().equals(".htm") ||
                             rsDocFile.getString("FILEEXT").trim().equals(".html") ||
                             rsDocFile.getString("FILEEXT").trim().equals(".txt"))
                          {
                            
                             String pfile = olddocroot+rsDocFile.getString("VPATH")+rsDocFile.getString("FILENAME");
                             String conts = getReadFile(pfile.trim(),"",1);

                            if( conts != null && !conts.trim().equals(""))
                            {
                                  try
                                  {
                                      Connection inconn = DriverManager.getConnection(strUrl, strUser, strPasswd);
                                      Statement  instmt = inconn.createStatement();

                                     System.out.println(" cnt ::  "+ cnt++ + " conts.trim().length() :: "+conts.trim().length()+" rsDocFile.DOCNO  ::  "+rsDocFile.getString("DOCNO"));

   	                              inconn.setAutoCommit(false);

                                      szBuff = new StringBuffer()
                                         .append(" SELECT MSTDOC ")
                                         .append(" FROM TB_"+newComCode+"_L10 ")
                                         .append(" WHERE DOCNO = '"+rsDocFile.getString("DOCNO")+"' FOR UPDATE ");

                                      ResultSet mRs = instmt.executeQuery(szBuff.toString());

	                              if(mRs.next())
		                      {
			                   CLOB rClob = ((OracleResultSet)mRs).getCLOB(1);
			                   Writer oWr = rClob.getCharacterOutputStream();

 			                   oWr.write(conts.trim());
			                   oWr.flush();
			                   oWr.close();
		                      }

//                                    deleteFile(olddocroot+rsDocFile.getString("VPATH"),rsDocFile.getString("FILENAME"));
  	                              inconn.commit();
  	                            
  	                              mRs.close();
  	                              instmt.close();
  	                              inconn.close();
  	                         }
  	                         catch (Exception e)
		                 {
		                       System.out.print(" error :: "+e.getMessage());
			               System.out.println(" $$$$  : DOCNO ==>>  "+rsDocFile.getString("DOCNO")); 
		                 }
                           }
                        }
                     }   // end if while
		}
		catch (SQLException e)
		{
			System.out.println("ERROR : createDefaultUser : Default Mall Creation Failure");
			e.printStackTrace();
		}
		catch (ClassNotFoundException e)
		{
			System.out.println("ERROR : createDefaultUser : Can't register JDBC Driver");
			e.printStackTrace();
		}
		catch (Exception e)
		{
			System.out.println("ERROR : createDefaultUser : Unhandled exception");
			e.printStackTrace();
		}
		finally
		{
			try
			{
				stmt.close();
				conn.close();
			}
			catch (SQLException e)
			{
				e.printStackTrace();
			}
		}
	}


    private static void deleteFile(String pDirPath, String pFileName)
        throws Exception {

        File oFile = new File(pDirPath,pFileName);
        
        if (oFile.isFile())
            oFile.delete();

    }

    private static String getReadFile(String fileName, String prefix, int mode)
        throws Exception {
        String strRet = "";
        String strChk = "";
        File oFile = null;
        FileInputStream fin = null;
        BufferedReader bufFile = null;
        String strBrTag = "";

        if (mode == 0) { //<br>÷��
            strBrTag = "<br>";
        }

        try {
            oFile = new File(fileName);

            if (!oFile.isFile()) return strRet = "";
            if (oFile.length()/1024 > 500 ) return strRet = " file size too big ...";

            fin = new FileInputStream(oFile);
            bufFile = new BufferedReader(new InputStreamReader(fin));

            while ((strChk = bufFile.readLine()) != null) {
                strChk = new String(strChk.getBytes());
                strRet += (prefix + strChk + strBrTag);
            }
        }
        finally {
            if (bufFile != null){ bufFile.close();}
            if (fin != null){ fin.close(); }
            if (oFile != null){ oFile = null; }
        }

        return strRet;
    }


	/**
	 * createDB���� ������ �����ͺ��̽��� ��Ű���� �����Ѵ�.
	 */
	private static void createNewSchema()
	{
		Connection conn = null;
		Statement  stmt = null;

		try
		{
			Class.forName(m_setupProp.getProperty("gplus.db.jdbcDriver"));

			String strUrl 		= m_setupProp.getProperty("gplus.db.jdbcUrl");
			String strUser 		= m_setupProp.getProperty("gplus.db.user");
			String strPasswd 	= m_setupProp.getProperty("gplus.db.password");

			conn = DriverManager.getConnection(strUrl, strUser, strPasswd);
			stmt = conn.createStatement();

			String strDbType = (m_setupProp.getProperty("gplus.db.type")).toLowerCase();
			String strSchemaFile = null;

                        if (strDbType.equals("oracle"))
			{
				strSchemaFile = ORACLE_SCHEMA;
			}
			else if (strDbType.equals("mssql"))
			{
				strSchemaFile = MSSQL_SCHEMA;
			}
			else
			{
				System.out.println("ERROR : Database Type is Wrong or Missing...");
				return;
			}

			StringBuffer szBuff = new StringBuffer()
                                 .append(" alter table TB_COMM_Z10 add (  BOARDLMT             NUMBER NULL, ")
                                 .append("                                DRAFTLMT             NUMBER NULL, ")
                                 .append("                                MAILLMT              NUMBER NULL, ")
                                 .append("                                DOCLMT               NUMBER NULL ) ");
			stmt.executeUpdate(szBuff.toString());

			szBuff = new StringBuffer()
                                 .append(" alter table TB_COMM_Z20 add (  PAGESIZE VARCHAR2(3) NULL ) ");
			stmt.executeUpdate(szBuff.toString());

			BufferedReader br = new BufferedReader(new FileReader(strSchemaFile));

			StringBuffer szCrSchema = new StringBuffer();

			while (br.ready())
			{
				String strLine = br.readLine();

				if (!strLine.trim().startsWith("#"))
				{
					szCrSchema.append(strLine);
					szCrSchema.append("\n");
				}
			}

			StringTokenizer st = new StringTokenizer(replace((szCrSchema.toString()).trim(),
			                  "comcodehere!",m_setupProp.getProperty("gplus.new.companycode")), ";");

			while (st.hasMoreTokens())
			{
				String strQuery = st.nextToken();
				if (!strQuery.equals(""))
				{
					stmt.executeUpdate(strQuery);
				}
			}

		}
		catch (SQLException e)
		{
			System.out.println("ERROR : createSchema : Create Schema failure");
			e.printStackTrace();
		}
		catch (ClassNotFoundException e)
		{
			System.out.println("ERROR : createSchema : Can't register JDBC Driver");
			e.printStackTrace();
		}
		catch (FileNotFoundException e)
		{
			System.out.println("ERROR : createSchema : File not found");
			e.printStackTrace();
		}
		catch (Exception e)
		{
			System.out.println("ERROR : createSchema : Unhandled exception");
			e.printStackTrace();
		}
		finally
		{
			try
			{
				stmt.close();
				conn.close();
			}
			catch (SQLException e)
			{
				e.printStackTrace();
			}
		}
	}

        public static String replace(String src, String from, String to )
        {
          if ( src == null ) return null;
          if ( from == null ) return src;
          if ( to == null ) to = "";

          StringBuffer buf = new StringBuffer();

          for(int pos; (pos = src.indexOf(from)) >= 0; ) {
              buf.append(src.substring(0,pos));
              buf.append(to);
              src = src.substring(pos+from.length());
          }

          buf.append(src);
          return buf.toString();
       }

    private static String toDB(String str, String dbCharSet)
    {

		try
		{
			return new String (str.getBytes(dbCharSet), "KSC5601");
		}
		catch (Exception e)
		{
			e.printStackTrace(System.err);
			return null;
		}
    }


	/**
	 * ��Ʈ���� �յڷ� Single-quote�� ���δ�.
	 *
	 * @param sqlString
	 * @param strEncoding ��Ʈ���� ���ڵ�
	 * @return Quoted-string
	 */
	private static String genQuote(String sqlString)
	{
		if ((sqlString == null) || (sqlString.equals("")) || (sqlString.equals("`")))
		{
			return ("''");		// blank string
		}
		else
		{
			String resultString = "";
			StringTokenizer st = new StringTokenizer(sqlString, "'");

			resultString += st.nextToken();

			while (st.hasMoreTokens())
			{
				resultString += "''";
				resultString += st.nextToken();
			}

			return ("'" + toDB(resultString, "8859_1") + "'");
		}
	}


	private static void moveGPlusData()
	{
		Connection conn = null;
		Statement  stmt = null;

		try
		{
			Class.forName(m_setupProp.getProperty("gplus.db.jdbcDriver"));

			String strUrl 		= m_setupProp.getProperty("gplus.db.jdbcUrl");
			String strUser 		= m_setupProp.getProperty("gplus.db.user");
			String strPasswd 	= m_setupProp.getProperty("gplus.db.password");

			String oldComCode 	= m_setupProp.getProperty("gplus.old.companycode");
			String newComCode 	= m_setupProp.getProperty("gplus.new.companycode");

			conn = DriverManager.getConnection(strUrl, strUser, strPasswd);
			stmt = conn.createStatement();
                        
			conn.setAutoCommit(true);
			StringBuffer szBuff = new StringBuffer()
                                 .append(" INSERT INTO TB_"+newComCode+"_A01 (NOTINO,BOXNO,DOCNO,PARENTNO,TITLE,ATTNUM,REFNUM,NOMNUM,CHILDNUM,REGUSER,REGDATE,REGNAME,REF,SORTSTEP,RELEVEL) ")
                                 .append(" SELECT NOTINO,BOXNO,DOCNO,PARENTNO,TITLE,ATTNUM,REFNUM,NOMNUM,CHILDNUM,REGUSER,REGDATE,REGNAME,REF,SORTSTEP,RELEVEL ")
                                 .append(" FROM TB_"+oldComCode+"_A01 ");
			stmt.executeUpdate(szBuff.toString());

                        szBuff = new StringBuffer()
                          .append(" INSERT INTO TB_"+newComCode+"_B10 (FLDNO,FLDNAME,BOXNO,DOCNO,PARENTNO,REGUSER,REGDATE,TRASHFLAG,COMMENTS,REFNO) ")
                          .append(" SELECT FLDNO,FLDNAME,BOXNO,DOCNO,PARENTNO,REGUSER,REGDATE,TRASHFLAG,COMMENTS,REFNO ")
                          .append(" FROM TB_"+oldComCode+"_B10 ");
			stmt.executeUpdate(szBuff.toString()); 

                        szBuff = new StringBuffer()
                          .append(" INSERT INTO TB_"+newComCode+"_C10 (MAILNO,MAILTYPE,DOCNO,SENDTYPE,TITLE,REGDATE,DLVRTYPE,SNDRID,SNDRNAME,TOID,TONAME,CCID,CCNAME,BCCID,BCCNAME,ATTNUM,RCVRNUM,READNUM) ")
                          .append(" SELECT MAILNO,MAILTYPE,DOCNO,SENDTYPE,TITLE,REGDATE,DLVRTYPE,SNDRID,SNDRNAME,TOID,TONAME,CCID,CCNAME,BCCID,BCCNAME,ATTNUM,RCVRNUM,READNUM ")
                          .append(" FROM TB_"+oldComCode+"_C10 ");
			stmt.executeUpdate(szBuff.toString()); 

                        szBuff = new StringBuffer()
                          .append(" INSERT INTO TB_"+newComCode+"_C11 (MAILNO,RCVRID,RCVRNAME,READFLAG,READDATE,RCVTYPE) ")
                          .append(" SELECT MAILNO,RCVRID,RCVRNAME,READFLAG,READDATE,'3' ")
                          .append(" FROM TB_"+oldComCode+"_C11 ");
			stmt.executeUpdate(szBuff.toString()); 

                        szBuff = new StringBuffer()
                          .append(" INSERT INTO TB_"+newComCode+"_C20 (REGMAILNO,BOXNO,SRTYPE,MAILNO,READFLAG,TRASHFLAG) ")
                          .append(" SELECT REGMAILNO,BOXNO,SRTYPE,MAILNO,READFLAG,TRASHFLAG ")
                          .append(" FROM TB_"+oldComCode+"_C20 ");
			stmt.executeUpdate(szBuff.toString()); 

                        szBuff = new StringBuffer()
                          .append(" INSERT INTO TB_"+newComCode+"_C30 (EMAIL,USERID,ACCTNAME,SMTPID,SMTPSVR,SMTPTYPE,POP3SVR,SMTPPWD,POP3TYPE,DEFLT,SNDRNAME,POP3ID,POP3PWD,SYSFLAG,DELFLAG) ")
                          .append(" SELECT EMAIL,USERID,ACCTNAME,SMTPID,SMTPSVR,SMTPTYPE,POP3SVR,SMTPPWD,POP3TYPE,DEFLT,SNDRNAME,POP3ID,POP3PWD,SYSFLAG,DELFLAG ")
                          .append(" FROM TB_"+oldComCode+"_C30 ");
			stmt.executeUpdate(szBuff.toString()); 

                        szBuff = new StringBuffer()
                          .append(" INSERT INTO TB_"+newComCode+"_D10 (DRFTNO,TITLE,DOCNO,DLVRTYPE,REGDATE,MAINTTERM,APPRTYPE,DRFTID,DRFTNAME,DRFTDEPT,DRFTPOS,ATTNUM,STEPNUM,REFNAME,REFDEPT,MAINTDATE,KEEPTERM,KEEPDATE,DRFTTYPE,SECLVL,CREDATE) ")
                          .append(" SELECT DRFTNO,TITLE,DOCNO,DLVRTYPE,REGDATE,MAINTTERM,APPRTYPE,DRFTID,DRFTNAME,DRFTDEPT,DRFTPOS,ATTNUM,STEPNUM,REFNAME,REFDEPT,MAINTDATE,KEEPTERM,KEEPDATE,DRFTTYPE,SECLVL,CREDATE ")
                          .append(" FROM TB_"+oldComCode+"_D10 ");
			stmt.executeUpdate(szBuff.toString()); 

                        szBuff = new StringBuffer()
                          .append(" INSERT INTO TB_"+newComCode+"_D11 (DRFTNO,SEQ,REFTYPE,APPRID,APPRNAME,APPRDEPTCODE,APPRDEPTNAME,APPRPOSNAME,READFLAG,READDATE,APPRDATE,APPRTYPE,DOCNO,COMMENTS,REALVIEWDATE) ")
                          .append(" SELECT DRFTNO,SEQ,REFTYPE,APPRID,APPRNAME,APPRDEPTCODE,APPRDEPTNAME,APPRPOSNAME,READFLAG,READDATE,APPRDATE,APPRTYPE,DOCNO,COMMENTS,REALVIEWDATE ")
                          .append(" FROM TB_"+oldComCode+"_D11 ");
			stmt.executeUpdate(szBuff.toString()); 

                        szBuff = new StringBuffer()
                          .append(" INSERT INTO TB_"+newComCode+"_D20 (REGDRFTNO,BOXNO,DRFTNO,READTYPE,READFLAG,TRASHFLAG,REFTYPE) ")
                          .append(" SELECT REGDRFTNO,BOXNO,DRFTNO,READTYPE,READFLAG,TRASHFLAG,REFTYPE ")
                          .append(" FROM TB_"+oldComCode+"_D20 ");
			stmt.executeUpdate(szBuff.toString()); 

                        szBuff = new StringBuffer()
                          .append(" INSERT INTO TB_"+newComCode+"_D30 (LINENUM,USERID,LINENAME,LINENOTE) ")
                          .append(" SELECT LINENO,USERID,LINENAME,LINENOTE ")
                          .append(" FROM TB_"+oldComCode+"_D30 ");
			stmt.executeUpdate(szBuff.toString());

/*                        szBuff = new StringBuffer()
                          .append(" INSERT INTO TB_"+newComCode+"_D31 (LINENUM,SEQ,SUBTYPE,SUBAPPRID,STEPNUM,SUBAPPRNAME) ")
                          .append(" SELECT LINENO,SEQ,SUBTYPE,SUBAPPRID,STEPNUM,SUBAPPRNAME ")
                          .append(" FROM TB_"+oldComCode+"_D31 ");

			stmt.executeUpdate(szBuff.toString());
*/			
                        szBuff = new StringBuffer()
                          .append(" INSERT INTO TB_"+newComCode+"_E10 (USERID,WRITERID,SCHDLNO,TITLE,GRPNO,STIME,LTIME,COMMENTS,SDATE,LDATE,RELATMAN,RELATID,RELATAREA,REPEATFLAG,PARENTNO,ALARMFLAG) ")
                          .append(" SELECT USERID,WRITERID,SCHDLNO,TITLE,GRPNO,STIME,LTIME,COMMENTS,SDATE,LDATE,RELATMAN,RELATID,RELATAREA,REPEATFLAG,PARENTNO,ALARMFLAG ")
                          .append(" FROM TB_"+oldComCode+"_E10 ");
			stmt.executeUpdate(szBuff.toString());
			
                        szBuff = new StringBuffer()
                          .append(" INSERT INTO TB_"+newComCode+"_F10 (USERID,CARDNO,GRPNO,NAMEK,NAMEE,NAMEC,SEX,COMNAME,DEPTNAME,BIRTHDAY,ADDR,POSNAME,LUNARFLAG,TELHOME,TELOFFICE,TELWORK,MOBILE,PAGER,HOMEPAGE,TELFAX,EMAIL,COMMENTS,EMAIL1,EMAIL2,PUBFLAG,ORGNO,REGDATE,ZIPCODE) ")
                          .append(" SELECT USERID,CARDNO,GRPNO,NAMEK,NAMEE,NAMEC,SEX,COMNAME,DEPTNAME,BIRTHDAY,ADDR,POSNAME,LUNARFLAG,TELHOME,TELOFFICE,TELWORK,MOBILE,PAGER,HOMEPAGE,TELFAX,EMAIL,COMMENTS,EMAIL1,EMAIL2,PUBFLAG,ORGNO,REGDATE,ZIPCODE ")
                          .append(" FROM TB_"+oldComCode+"_F10 ");
			stmt.executeUpdate(szBuff.toString());
			
                        szBuff = new StringBuffer()
                          .append(" INSERT INTO TB_"+newComCode+"_F11 (CARDNO,MEETNO,USERID,MEETDATE,COMMENTS) ")
                          .append(" SELECT CARDNO,MEETNO,USERID,MEETDATE,COMMENTS ")
                          .append(" FROM TB_"+oldComCode+"_F11 ");
			stmt.executeUpdate(szBuff.toString());
			
                        szBuff = new StringBuffer()
                          .append(" INSERT INTO TB_"+newComCode+"_G10 (GRPNO,GRPNAME,USERID,GRPTYPE) ")
                          .append(" SELECT GRPNO,GRPNAME,USERID,'2' ")
                          .append(" FROM TB_"+oldComCode+"_F20 ");
			stmt.executeUpdate(szBuff.toString());
			
                        szBuff = new StringBuffer()
                          .append(" INSERT INTO TB_"+newComCode+"_G10 (GRPNO,GRPNAME,USERID,GRPCOLOR,GRPTYPE) ")
                          .append(" SELECT GRPNO,GRPNAME,USERID,GRPCOLOR,'1' ")
                          .append(" FROM TB_"+oldComCode+"_E20 ");
			stmt.executeUpdate(szBuff.toString());
			
                        szBuff = new StringBuffer()
                          .append(" INSERT INTO TB_"+newComCode+"_L10 (DOCNO,TITLE,DOCTYPE,FILENUM,REGUSER,MODUSER,REGDATE,MODDATE,MSTDOC,TOTFILESIZE) ")
                          .append(" SELECT DOCNO,TITLE,DOCTYPE,FILENUM,REGUSER,MODUSER,REGDATE,MODDATE,EMPTY_CLOB(),0 ")
                          .append(" FROM TB_"+oldComCode+"_L10 ");
			stmt.executeUpdate(szBuff.toString());

                        szBuff = new StringBuffer()
                          .append(" INSERT INTO TB_"+newComCode+"_L11 (DOCNO,TITLE,SEQ,FILEEXT,CONTTYPE,FILENAME,VPATH,REGUSER,REGDATE,ORGNAME,ORGPATH,MODUSER,MODDATE,MIMETYPE,FILESIZE) ")
                          .append(" SELECT DOCNO,TITLE,SEQ,FILEEXT,CONTTYPE,FILENAME,VPATH,REGUSER,REGDATE,ORGNAME,ORGPATH,MODUSER,MODDATE,MIMETYPE,FILESIZE ")
                          .append(" FROM TB_"+oldComCode+"_L11 ");
			stmt.executeUpdate(szBuff.toString());
			
                        szBuff = new StringBuffer()
                          .append(" INSERT INTO TB_"+newComCode+"_M10 (BOXNO,ICONNO,BOXNAME,PARENTNO,BOXCLASS,EXECCLASS,REGUSER,REGDATE,BOXTYPE,BASEFLAG,PUBFLAG,EXECFLAG,USERID) ")
                          .append(" SELECT BOXNO,ICONNO,BOXNAME,PARENTNO,BOXCLASS,EXECCLASS,REGUSER,REGDATE,BOXTYPE,BASEFLAG,PUBFLAG,EXECFLAG,USERID ")
                          .append(" FROM TB_"+oldComCode+"_M10 ");
			stmt.executeUpdate(szBuff.toString());
			
                        szBuff = new StringBuffer()
                          .append(" INSERT INTO TB_"+newComCode+"_M20 (BOXNO,USERID,DOCREAD,DOCWRITE,DOCDEL,DOCDELADM,FLDMAKE,FLDDEL) ")
                          .append(" SELECT BOXNO,USERID,DOCREAD,DOCWRITE,DOCDEL,DOCDELADM,FLDMAKE,FLDDEL ")
                          .append(" FROM TB_"+oldComCode+"_M20 ");
			stmt.executeUpdate(szBuff.toString());
			
                        szBuff = new StringBuffer()
                          .append(" INSERT INTO TB_"+newComCode+"_N10 (ORGNO,PARENTNO,ORGNAME,READERNO) ")
                          .append(" SELECT ORGNO,PARENTNO,ORGNAME,READERNO ")
                          .append(" FROM TB_"+oldComCode+"_N10 ");
			stmt.executeUpdate(szBuff.toString());
			
                        szBuff = new StringBuffer()
                          .append(" INSERT INTO TB_"+newComCode+"_N11 (ORGNO,USERID,DEFLT) ")
                          .append(" SELECT ORGNO,USERID,DEFLT ")
                          .append(" FROM TB_"+oldComCode+"_N11 ");
			stmt.executeUpdate(szBuff.toString());
			
                        szBuff = new StringBuffer()
                          .append(" INSERT INTO TB_"+newComCode+"_N20 (POSCODE,POSNAME,POSRANK) ")
                          .append(" SELECT POSCODE,POSNAME,POSRANK ")
                          .append(" FROM TB_"+oldComCode+"_N20 ");
			stmt.executeUpdate(szBuff.toString());
			
                        szBuff = new StringBuffer()
                          .append(" INSERT INTO TB_"+newComCode+"_N30 (USERID,ITEMNO,BOXNO,FLDNO) ")
                          .append(" SELECT USERID,ITEMNO,BOXNO,FLDNO ")
                          .append(" FROM TB_"+oldComCode+"_N30 ");
			stmt.executeUpdate(szBuff.toString());

                        szBuff = new StringBuffer()
                          .append(" UPDATE TB_COMM_Z10 ")
                          .append(" SET COMCODE = '"+newComCode+"' ")
                          .append(" WHERE COMCODE = '"+oldComCode+"' ");
			stmt.executeUpdate(szBuff.toString());

                        szBuff = new StringBuffer()
                          .append(" UPDATE TB_COMM_Z20 ")
                          .append(" SET COMCODE = '"+newComCode+"' ")
                          .append(" WHERE COMCODE = '"+oldComCode+"' "); 
			stmt.executeUpdate(szBuff.toString()); 

                        szBuff = new StringBuffer()
                          .append(" UPDATE TB_"+newComCode+"_L11 ")
                          .append(" SET VPATH = REPLACE(VPATH,'"+oldComCode+"','"+newComCode+"') ");
			stmt.executeUpdate(szBuff.toString()); 

/* ���� ���������� �ű� ���� �ؾ���  */

		}
		catch (SQLException e)
		{
			System.out.println("ERROR : createDefaultUser : Default Mall Creation Failure");
			e.printStackTrace();
		}
		catch (ClassNotFoundException e)
		{
			System.out.println("ERROR : createDefaultUser : Can't register JDBC Driver");
			e.printStackTrace();
		}
		catch (Exception e)
		{
			System.out.println("ERROR : createDefaultUser : Unhandled exception");
			e.printStackTrace();
		}
		finally
		{
			try
			{
				stmt.close();
				conn.close();
			}
			catch (SQLException e)
			{
				e.printStackTrace();
			}
		}
	}

    private static String numToStr(String n, int l)
        throws Exception {
        String strRet = "";
        if(n.length() < l) {
          for(int i = 0; i < l - n.length(); i++)
            strRet = "0".concat(String.valueOf(strRet));

          strRet = String.valueOf(strRet) + String.valueOf(n);
        }
        else {
          strRet = n;
        }
        return strRet;
    }


}
