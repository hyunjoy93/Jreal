CREATE TABLE TB_comcodehere!_A01 (
       NOTINO               VARCHAR2(12) NOT NULL,	
       BOXNO                VARCHAR2(12) NULL,		
       DOCNO                VARCHAR2(12) NULL,		
       PARENTNO             VARCHAR2(12) NOT NULL,	
       TITLE                VARCHAR2(100) NULL,		
       ATTNUM               NUMBER NOT NULL,		
       REFNUM               NUMBER NOT NULL,		
       NOMNUM               NUMBER NOT NULL,		
       CHILDNUM             NUMBER NULL,		
       REGUSER              VARCHAR2(10) NULL,		
       REGDATE              VARCHAR2(14) NULL,		
       REGNAME              VARCHAR2(50) NULL,		
       REF                  VARCHAR2(12) NOT NULL,	
       SORTSTEP             NUMBER NOT NULL,		
       RELEVEL              NUMBER NOT NULL		
);


ALTER TABLE TB_comcodehere!_A01
       ADD PRIMARY KEY (NOTINO);

       
CREATE TABLE TB_comcodehere!_B10 (
       FLDNO                VARCHAR2(12) NOT NULL,	
       FLDNAME              VARCHAR2(500) NOT NULL,	
       BOXNO                VARCHAR2(12) NULL,		
       DOCNO                VARCHAR2(12) NULL,		
       PARENTNO             VARCHAR2(12) NOT NULL,	
       REGUSER              VARCHAR2(10) NULL,		
       REGDATE              VARCHAR2(14) NULL,
       TRASHFLAG            VARCHAR2(1) NULL,
       COMMENTS             VARCHAR2(2000) NULL,
       REFNO		    VARCHAR2(25) NULL
);


ALTER TABLE TB_comcodehere!_B10
       ADD PRIMARY KEY (FLDNO);


CREATE TABLE TB_comcodehere!_C10 (
       MAILNO               VARCHAR2(12) NOT NULL,
       MAILTYPE             VARCHAR2(1) NOT NULL,
       DOCNO                VARCHAR2(12) NULL,		
       SENDTYPE             VARCHAR2(1) NULL,
       TITLE                VARCHAR2(1024) NULL,
       REGDATE              VARCHAR2(14) NULL,
       DLVRTYPE             VARCHAR2(1) NULL,
       SNDRID               VARCHAR2(1024) NULL,
       SNDRNAME             VARCHAR2(1024) NULL,
       TOID                 VARCHAR2(4000) NULL,
       TONAME               VARCHAR2(4000) NULL,
       CCID                 VARCHAR2(4000) NULL,
       CCNAME               VARCHAR2(4000) NULL,
       BCCID                VARCHAR2(4000) NULL,
       BCCNAME              VARCHAR2(4000) NULL,
       ATTNUM               NUMBER NULL,
       RCVRNUM              NUMBER NULL,
       READNUM              NUMBER NULL,
       ACCTNAME             VARCHAR2(50) NULL       
);


ALTER TABLE TB_comcodehere!_C10
       ADD PRIMARY KEY (MAILNO,MAILTYPE);


CREATE TABLE TB_comcodehere!_C11 (
       MAILNO               VARCHAR2(12) NOT NULL,
       RCVRID               VARCHAR2(20) NOT NULL,
       RCVTYPE              VARCHAR2(1) NOT NULL,
       RCVRNAME             VARCHAR2(50) NULL,
       READFLAG             VARCHAR2(1) NOT NULL,
       READDATE             VARCHAR2(14) NULL
);


ALTER TABLE TB_comcodehere!_C11
       ADD PRIMARY KEY (MAILNO,RCVRID,RCVTYPE);
       
       
CREATE TABLE TB_comcodehere!_C20 (
       REGMAILNO            VARCHAR2(12) NOT NULL,
       BOXNO                VARCHAR2(12) NULL,		
       SRTYPE               VARCHAR2(1) NOT NULL,
       MAILNO               VARCHAR2(12) NULL,
       READFLAG             VARCHAR2(1) NOT NULL,
       TRASHFLAG            VARCHAR2(1) NULL
);


ALTER TABLE TB_comcodehere!_C20
       ADD PRIMARY KEY (REGMAILNO);
       
       
CREATE TABLE TB_comcodehere!_C30 (
       EMAIL                VARCHAR2(50) NOT NULL,
       USERID               VARCHAR2(10) NOT NULL,
       ACCTNAME             VARCHAR2(50) NOT NULL,
       SMTPID               VARCHAR2(20) NULL,
       SMTPSVR              VARCHAR2(100) NULL,
       SMTPTYPE             VARCHAR2(1) NOT NULL,
       POP3SVR              VARCHAR2(100) NULL,
       SMTPPWD              VARCHAR2(50) NULL,
       POP3TYPE             VARCHAR2(1) NOT NULL,
       DEFLT                VARCHAR2(1) NOT NULL,
       SNDRNAME             VARCHAR2(20) NULL,
       POP3ID               VARCHAR2(20) NULL,
       POP3PWD              VARCHAR2(50) NULL,
       SYSFLAG		    VARCHAR2(1) NULL,
       DELFLAG              VARCHAR2(1) NULL
);


ALTER TABLE TB_comcodehere!_C30
       ADD PRIMARY KEY (USERID, EMAIL);
       
       
CREATE TABLE TB_comcodehere!_D10 (
       DRFTNO               VARCHAR2(12) NOT NULL,
       TITLE                VARCHAR2(100) NOT NULL,
       DOCNO                VARCHAR2(12) NULL,     
       DLVRTYPE             VARCHAR2(1) NULL,
       REGDATE              VARCHAR2(14) NOT NULL,
       MAINTTERM            NUMBER NOT NULL,
       APPRTYPE             VARCHAR2(1) NOT NULL,
       DRFTID               VARCHAR2(10) NOT NULL,
       DRFTNAME             VARCHAR2(20) NOT NULL,
       DRFTDEPT             VARCHAR2(50) NULL,
       DRFTPOS              VARCHAR2(50) NULL,
       ATTNUM               NUMBER NOT NULL,
       STEPNUM              NUMBER NULL,
       REFNAME              VARCHAR2(200) NULL,
       REFDEPT              VARCHAR2(200) NULL,
       MAINTDATE            VARCHAR2(8) NULL,
       KEEPTERM             NUMBER NULL,
       KEEPDATE             VARCHAR2(8) NULL,
       DRFTTYPE             VARCHAR2(1) NULL,
       SECLVL               VARCHAR2(1) NULL,
       CREDATE              VARCHAR2(14)
);


ALTER TABLE TB_comcodehere!_D10
       ADD PRIMARY KEY (DRFTNO);
       
       
CREATE TABLE TB_comcodehere!_D11 (
       DRFTNO               VARCHAR2(12) NOT NULL,
       SEQ                  VARCHAR2(3) NOT NULL,
       REFTYPE              VARCHAR2(1) NOT NULL,
       APPRID               VARCHAR2(10) NOT NULL,
       APPRNAME             VARCHAR2(20) NOT NULL,
       APPRDEPTCODE         VARCHAR2(12) NULL,
       APPRDEPTNAME         VARCHAR2(50) NULL,
       APPRPOSNAME          VARCHAR2(50) NULL,
       READFLAG             VARCHAR2(1) NOT NULL,
       READDATE             VARCHAR2(14) NULL,
       APPRDATE             VARCHAR2(14) NULL,
       APPRTYPE             VARCHAR2(1) NOT NULL,
       DOCNO                VARCHAR2(12) NULL,    
       COMMENTS             VARCHAR2(2000) NULL,
       REALVIEWDATE         VARCHAR2(14) NULL
);


ALTER TABLE TB_comcodehere!_D11
       ADD PRIMARY KEY (DRFTNO, SEQ);
       
       
CREATE TABLE TB_comcodehere!_D20 (
       REGDRFTNO            VARCHAR2(12) NOT NULL,
       BOXNO                VARCHAR2(12) NULL,		
       DRFTNO               VARCHAR2(12) NULL,
       READTYPE             VARCHAR2(1) NULL,
       READFLAG             VARCHAR2(1) NULL,
       TRASHFLAG            VARCHAR2(1) NULL,
       REFTYPE              VARCHAR2(1) NULL
);


ALTER TABLE TB_comcodehere!_D20
       ADD PRIMARY KEY (REGDRFTNO);
       
       
CREATE TABLE TB_comcodehere!_D30 (
       LINENUM              VARCHAR2(12) NOT NULL,
       USERID               VARCHAR2(10) NULL,
       LINENAME             VARCHAR2(50) NULL,
       LINENOTE             VARCHAR2(1000) NULL
);


ALTER TABLE TB_comcodehere!_D30
       ADD PRIMARY KEY (LINENUM);
       
       
CREATE TABLE TB_comcodehere!_D31 (
       LINENUM              VARCHAR2(12) NOT NULL,
       SEQ                  VARCHAR2(3) NOT NULL,
       SUBTYPE              VARCHAR2(1) NULL,
       SUBAPPRID            VARCHAR2(10) NULL,
       STEPNUM              NUMBER NULL,
       SUBAPPRNAME          VARCHAR2(20) NULL
);


ALTER TABLE TB_comcodehere!_D31
       ADD PRIMARY KEY (LINENUM, SEQ);
       
       
CREATE TABLE TB_comcodehere!_E10 (
       USERID               VARCHAR2(10) NOT NULL,
       WRITERID             VARCHAR2(10) NULL,
       SCHDLNO              VARCHAR2(12) NOT NULL,
       TITLE                VARCHAR2(100) NOT NULL,
       GRPNO                VARCHAR2(12) NULL,
       STIME                VARCHAR2(4) NULL,
       LTIME                VARCHAR2(4) NULL,
       COMMENTS             VARCHAR2(4000) NULL,
       SDATE                VARCHAR2(8) NOT NULL,
       LDATE                VARCHAR2(8) NOT NULL,
       RELATMAN             VARCHAR2(1000) NULL,
       RELATID		    VARCHAR2(1000) NULL,
       RELATAREA            VARCHAR2(50) NULL,
       REPEATFLAG           VARCHAR2(2) NOT NULL,
       PARENTNO             VARCHAR2(12) NULL,
       ALARMFLAG            VARCHAR2(1) NOT NULL
);


ALTER TABLE TB_comcodehere!_E10
       ADD PRIMARY KEY (USERID, SCHDLNO);
       
CREATE TABLE TB_comcodehere!_F10 (
       USERID               VARCHAR2(10) NULL,
       CARDNO               VARCHAR2(12) NOT NULL,
       GRPNO                VARCHAR2(12) NULL,
       NAMEK                VARCHAR2(20) NOT NULL,
       NAMEE                VARCHAR2(20) NULL,
       NAMEC                VARCHAR2(20) NULL,
       SEX                  VARCHAR2(1) NULL,
       COMNAME              VARCHAR2(50) NULL,
       DEPTNAME             VARCHAR2(50) NULL,
       BIRTHDAY             VARCHAR2(8) NULL,
       ZIPCODE              VARCHAR2(7) NULL,
       ADDR                 VARCHAR2(100) NULL,
       POSNAME              VARCHAR2(50) NULL,
       LUNARFLAG            VARCHAR2(1) NULL,
       TELHOME              VARCHAR2(20) NULL,
       TELOFFICE            VARCHAR2(20) NULL,
       TELWORK              VARCHAR2(20) NULL,
       MOBILE               VARCHAR2(20) NULL,
       PAGER                VARCHAR2(20) NULL,
       HOMEPAGE             VARCHAR2(100) NULL,
       TELFAX               VARCHAR2(20) NULL,
       EMAIL                VARCHAR2(50) NULL,
       COMMENTS             VARCHAR2(1000) NULL,
       EMAIL1               VARCHAR2(50) NULL,
       EMAIL2               VARCHAR2(50) NULL,
       PUBFLAG              VARCHAR2(1) NOT NULL,
       ORGNO                VARCHAR2(12) NULL,
       REGDATE              VARCHAR2(14) NULL,
       COPIERID             VARCHAR2(10) NULL,
       COPYDATE             VARCHAR2(14) NULL
);


ALTER TABLE TB_comcodehere!_F10
       ADD PRIMARY KEY (CARDNO);
       
       
CREATE TABLE TB_comcodehere!_F11 (
       CARDNO               VARCHAR2(12) NULL,
       MEETNO               VARCHAR2(12) NOT NULL,
       USERID               VARCHAR2(10) NULL,
       MEETDATE             VARCHAR2(14) NULL,
       COMMENTS             VARCHAR2(1000) NULL
);


ALTER TABLE TB_comcodehere!_F11
       ADD PRIMARY KEY (MEETNO);
       
CREATE TABLE TB_comcodehere!_F30 (
       BROADCASTNO          VARCHAR2(12) NOT NULL,
       TITLE                VARCHAR2(100) NOT NULL,
       USERID               VARCHAR2(10) NOT NULL,
       NOTE                 VARCHAR2(1000) NULL
);


ALTER TABLE TB_comcodehere!_F30
       ADD PRIMARY KEY (BROADCASTNO);
       
       
CREATE TABLE TB_comcodehere!_F31 (
       BROADCASTNO           VARCHAR2(12) NOT NULL,
       ACCTINFO              VARCHAR2(50) NOT NULL,
       USERNAME              VARCHAR2(50) NOT NULL,
       BROADTYPE             VARCHAR2(1) NOT NULL
);


ALTER TABLE TB_comcodehere!_F31
       ADD PRIMARY KEY (BROADCASTNO, ACCTINFO);

CREATE TABLE TB_comcodehere!_F50 (
       CARDNO             VARCHAR2(12) NOT NULL,
       USERID             VARCHAR2(10) NOT NULL
);


ALTER TABLE TB_comcodehere!_F50
       ADD PRIMARY KEY (CARDNO,USERID);
       
CREATE TABLE TB_comcodehere!_G10 (
       GRPNO                VARCHAR2(12) NOT NULL,
       GRPTYPE              VARCHAR2(1) NOT NULL,
       GRPNAME              VARCHAR2(50) NULL,
       USERID               VARCHAR2(10) NOT NULL,
       GRPCOLOR             VARCHAR2(10) NULL
);

ALTER TABLE TB_comcodehere!_G10
       ADD PRIMARY KEY (GRPNO,GRPTYPE);

CREATE TABLE TB_comcodehere!_L10 (
       DOCNO                VARCHAR2(12) NOT NULL,
       TITLE                VARCHAR2(500) NULL,
       DOCTYPE              VARCHAR2(1) NOT NULL,
       FILENUM              NUMBER NOT NULL,
       TOTFILESIZE          NUMBER NULL,
       REGUSER              VARCHAR2(10) NOT NULL,
       MODUSER              VARCHAR2(10) NOT NULL,
       REGDATE              VARCHAR2(14) NOT NULL,
       MODDATE              VARCHAR2(14) NOT NULL,
       MSTDOC               CLOB DEFAULT NULL
)

LOB(MSTDOC) STORE AS(
 STORAGE (INITIAL 10M 
          NEXT 10M 
          MINEXTENTS 1 
          MAXEXTENTS UNLIMITED 
          PCTINCREASE 0)
 CHUNK 8192
 CACHE
);

ALTER TABLE TB_comcodehere!_L10
       ADD PRIMARY KEY (DOCNO);

CREATE TABLE TB_comcodehere!_L11 (
       DOCNO                VARCHAR2(12) NOT NULL,
       TITLE                VARCHAR2(500) NULL,
       SEQ                  VARCHAR2(2) NOT NULL,
       FILEEXT              VARCHAR2(11) NULL,
       CONTTYPE             VARCHAR2(1) NOT NULL,
       FILENAME             VARCHAR2(26) NOT NULL,
       VPATH                VARCHAR2(255) NOT NULL,
       REGUSER              VARCHAR2(10) NOT NULL,
       REGDATE              VARCHAR2(14) NOT NULL,
       ORGNAME              VARCHAR2(255) NULL,
       ORGPATH              VARCHAR2(255) NULL,
       MODUSER              VARCHAR2(10) NOT NULL,
       MODDATE              VARCHAR2(14) NOT NULL,
       MIMETYPE             VARCHAR2(255) NULL,
       FILESIZE             NUMBER NULL
);


ALTER TABLE TB_comcodehere!_L11
       ADD PRIMARY KEY (DOCNO, SEQ);
       
       
CREATE TABLE TB_comcodehere!_M10 (
       BOXNO                VARCHAR2(12) NOT NULL,
       ICONNO               VARCHAR2(2) NULL,
       BOXNAME              VARCHAR2(50) NOT NULL,
       PARENTNO             VARCHAR2(12) NOT NULL,
       BOXCLASS             VARCHAR2(1) NOT NULL,
       EXECCLASS            VARCHAR2(1) NOT NULL,
       REGUSER              VARCHAR2(10) NULL,		
       REGDATE              VARCHAR2(14) NULL,
       BOXTYPE              VARCHAR2(1) NOT NULL,
       BASEFLAG             VARCHAR2(1) NOT NULL,
       PUBFLAG              VARCHAR2(1) NOT NULL,
       EXECFLAG             VARCHAR2(1) NOT NULL,
       USERID               VARCHAR2(10) NULL
);


ALTER TABLE TB_comcodehere!_M10
       ADD PRIMARY KEY (BOXNO);
       
       
CREATE TABLE TB_comcodehere!_M20 (
       BOXNO                VARCHAR2(12) NOT NULL,
       USERID               VARCHAR2(10) NOT NULL,
       DOCREAD              VARCHAR2(1) NOT NULL,
       DOCWRITE             VARCHAR2(1) NULL,
       DOCDEL               VARCHAR2(1) NULL,
       DOCDELADM            VARCHAR2(1) NULL,
       FLDMAKE              VARCHAR2(1) NOT NULL,
       FLDDEL               VARCHAR2(1) NULL
);


ALTER TABLE TB_comcodehere!_M20
       ADD PRIMARY KEY (BOXNO, USERID);
       
       
CREATE TABLE TB_comcodehere!_N10 (
       ORGNO                VARCHAR2(12) NOT NULL,
       PARENTNO             VARCHAR2(12) NULL,
       ORGNAME              VARCHAR2(100) NULL,
       READERNO             VARCHAR2(10) NULL
);


ALTER TABLE TB_comcodehere!_N10
       ADD PRIMARY KEY (ORGNO);
       
       
CREATE TABLE TB_comcodehere!_N11 (
       ORGNO                VARCHAR2(12) NOT NULL,
       USERID               VARCHAR2(10) NOT NULL,
       DEFLT                VARCHAR2(1) NOT NULL
);


ALTER TABLE TB_comcodehere!_N11
       ADD PRIMARY KEY (ORGNO, USERID);
       
       
CREATE TABLE TB_comcodehere!_N20 (
       POSCODE              VARCHAR2(2) NOT NULL,
       POSNAME              VARCHAR2(50) NOT NULL,
       POSRANK              VARCHAR2(2) NULL
);


ALTER TABLE TB_comcodehere!_N20
       ADD PRIMARY KEY (POSCODE);
       
       
CREATE TABLE TB_comcodehere!_N30 (
       USERID               VARCHAR2(10) NOT NULL,
       ITEMNO               VARCHAR2(12) NOT NULL,
       BOXNO                VARCHAR2(12) NULL,		
       FLDNO                VARCHAR2(12) NULL
);


ALTER TABLE TB_comcodehere!_N30
       ADD PRIMARY KEY (USERID, ITEMNO);