function Calendar(name,nestref,syear,lyear,year,month,date,x,y,width,height) {
	this.name = name
	this.framename = name+'CalendarFrame'
	this.nestref = nestref
	this.nest = (nestref)? nestref+'.document.' : ''
	this.x = x
	this.y = y
	this.sh = 25
	this.th = 20
	this.w = width
	this.h = height
	this.syear = syear
	this.lyear = lyear
	this.visibility = 'hidden'
	this.obj = name+"CalendarObject"
	eval(this.obj+"=this")
	
	this.initDate = CalendarInitDate
	this.initDate()
	this.dt.year = year
	this.dt.month = month
	this.dt.date = date
	this.changeDateStyle = CalendarChangeDateStyle

	this.enablingdate=false
	this.enablingmonth=false
	this.built = false
	this.loaded = false
	
	this.build = CalendarBuild
	this.draw = CalendarDraw
	this.activate = CalendarActivate
	this.show = CalendarShow
	this.hide = CalendarHide
	this.enableDate=CalendarEnableDate
	this.enableMonth=CalendarEnableMonth
	this.setDate = CalendarSetDate
	this.calDate=CalendarCalDate
	this.drawMonth=CalendarDrawMonth
	this.drawDate=CalendarDrawDate
	
	this.click = CalendarOnClick
	this.mouseOver = CalendarMouseOver
	this.mouseOut = CalendarMouseOut
	this.change = CalendarChange
	this.actionDate = null
	this.actionMonth = null
	
}

function CalendarBuild(write) {

	var dw = this.dt.w
	var dh = this.dt.h
	var prestyle = 'text-align:center; font-weight:500; color:red; padding-top:5; border:0 outset silver; float:left;'
	var selstyle = 'text-align:center; font-weight:500; color:black; padding-top:2; border:0 outset silver; float:left;'
	var nextstyle = 'text-align:center; font-weight:500; color:red; padding-top:5; border:0 outset silver; float:left;'
	var titlestyle = 'text-align:center; font-weight:700; color:white; padding-top:3; border-bottom:1 outset silver; float:left;'
	var datestyle = 'text-align:center; font-weight:500; color:red; padding-top:3; border-bottom:1 outset silver; border-right:1 outset silver; float:left;'
	this.css = (write!=false)? css('OPEN'):''
	this.css += css(this.name+'Calendar',null,null,this.w,this.h,'transparent',this.visibility)+
	css(this.name+'Header',0,0,this.w,this.sh+this.th,'white')+
	css(this.name+'PreMonth',0,0,this.dt.w,this.sh,'silver','display',null,prestyle)+
	css(this.name+'SelYearMonth',this.dt.w,0,this.w-this.dt.w*2,this.sh,'silver','display',null,selstyle)+
	css(this.name+'NextMonth',this.w-this.dt.w,0,this.dt.w,this.sh,'silver','display',null,nextstyle)+
	css(this.name+'Title',0,25,this.dt.w,this.th,'NAVY','display',1,titlestyle)+
	css(this.name+'Body',0,this.sh+this.th,this.w,this.h-this.sh-this.th,'transparent')+
	css(this.dt.name,0,0,this.dt.w,this.dt.h,'silver','display',null,datestyle)
	if (write!=false) {
		this.css += css('CLOSE')
		document.write(this.css)
	}
	this.html = '<DIV ID="'+this.name+'Calendar">\n'+
	'<DIV ID="'+this.name+'Header">\n'+
	'<DIV ID="'+this.name+'PreMonth">\n</DIV>\n'+
	'<DIV ID="'+this.name+'SelYearMonth">\n'+
	'<SELECT ID="'+this.name+'SelYear">\n'
	for (var i=this.lyear;i>=this.syear;i--)
		this.html += '<OPTION value="'+i+'" '+(i==this.year?'SELECTED':'')+'>'+i+'</OPTION>\n'
	this.html += '</SELECT>��\n<SELECT ID="'+this.name+'SelMonth">\n'
	for (var i=1;i<13;i++)
		this.html += '<OPTION value="'+i+'" '+(i==this.month?'SELECTED':'')+'>'+i+'</OPTION>\n'
	this.html+= '</SELECT>��\n'+'</DIV>\n'+
	'<DIV ID="'+this.name+'NextMonth">\n</DIV>\n'+
	'<DIV ID="'+this.name+'Title" style="left:'+(0*this.dt.w)+';">��</DIV>\n'+
	'<DIV ID="'+this.name+'Title" style="left:'+(1*this.dt.w)+';">��</DIV>\n'+
	'<DIV ID="'+this.name+'Title" style="left:'+(2*this.dt.w)+';">ȭ</DIV>\n'+
	'<DIV ID="'+this.name+'Title" style="left:'+(3*this.dt.w)+';">��</DIV>\n'+
	'<DIV ID="'+this.name+'Title" style="left:'+(4*this.dt.w)+';">��</DIV>\n'+
	'<DIV ID="'+this.name+'Title" style="left:'+(5*this.dt.w)+';">��</DIV>\n'+
	'<DIV ID="'+this.name+'Title" style="left:'+(6*this.dt.w)+';">��</DIV>\n'+
	'</DIV>\n'+
	'<DIV ID="'+this.name+'Body">\n'+
	'<IFRAME ID="'+this.framename+'" NAME="'+this.framename+'" WIDTH="0" HEIGHT="0" FRAMEBORDER="YES" BORDER="1"></IFRAME>\n'
	this.calDate(this.dt.year,this.dt.month,this.dt.date)
	var txt=''
	var s=''
	for (var i=0,idx=0;i<6;i++)
		for (var j=0;j<7;j++,idx++) {
			s = (j==0)?';border-left:1 outset silver':''
			if (idx>=this.dt.start && idx<this.dt.last) txt=idx-this.dt.start+1
			else txt=''
			this.html += '<DIV ID="'+this.dt.name+'" style="left:'+j*this.dt.w+';top:'+i*this.dt.h+';'+s+'">'+txt+'\n</DIV>\n'
		}
	this.html += '</DIV>\n'+ '</DIV>\n'
	
	this.built = true

}

function CalendarDraw() {
	if (this.built) document.write(this.html)
}

function CalendarActivate() {
	this.ctr = new Controller(this.name+"Calendar")
	this.ctr.moveTo(this.x,this.y)
	var srcidx = document.all[this.name+'Calendar'].sourceIndex
	var dateobj = document.all[this.dt.name]
	document.all[this.name+'Calendar'].obj = this.obj
	cal = eval('document.all['+srcidx+'].obj')
	fclick=new Function("eval(cal+'.click()')")
	fmouseOver=new Function("eval(cal+'.mouseOver()')")
	fmouseOut=new Function("eval(cal+'.mouseOut()')")
	for (var i=0,idx=0;i<6;i++)
		for (var j=0;j<7;j++,idx++) {
			dateobj[idx].onclick = fclick
			dateobj[idx].onmouseover = fmouseOver
			dateobj[idx].onmouseout = fmouseOut
			dateobj[idx].style.backgroundColor=this.dt.bgcolor.n
			if (j==0) dateobj[idx].style.color=this.dt.color3.n
			else if (j==6) dateobj[idx].style.color=this.dt.color2.n
			else dateobj[idx].style.color=this.dt.color1.n
		} 
	this.dt.srcidx = dateobj[0].sourceIndex
	this.prectr = new Controller(this.name+'PreMonth')
	this.prectr.event.onclick = new Function("eval(cal+'.change()')")
	this.prectr.css.cursor = 'hand'
	this.nextctr = new Controller(this.name+'NextMonth')
	this.nextctr.event.onclick = new Function("eval(cal+'.change()')")
	this.nextctr.css.cursor = 'hand'
	this.yearctr = new Controller(this.name+'SelYear')
	this.yearctr.event.onchange = new Function("eval(cal+'.change()')")
	this.monthctr = new Controller(this.name+'SelMonth')
	this.monthctr.event.onchange = new Function("eval(cal+'.change()')")
	this.drawMonth()
	this.dt.selected = this.dt.srcidx+this.dt.start+this.dt.date-1
	this.changeDateStyle('S',this.dt.selected)
	this.enableMonth(true)
	this.enableDate(true)
}

function CalendarShow() {
	this.ctr.show()
}

function CalendarHide() {
	this.ctr.hide()
}

function CalendarInitDate() {
	this.dt = new Object()
	this.dt.name = this.name+'Date'
	this.dt.w = Math.round(this.w/7)
	this.dt.h = Math.round((this.h-this.sh-this.th)/6)
	this.dt.active = -1
	this.dt.selected = -1
	this.dt.start = -1
	this.dt.max = -1
	this.dt.bgcolor = new Object()
	this.dt.bgcolor.n = 'white'
	this.dt.bgcolor.a = '#d8bfd8'
	this.dt.bgcolor.s = 'tan'
	this.dt.color1 = new Object()
	this.dt.color1.n = 'black'
	this.dt.color1.a = 'black'
	this.dt.color1.s = '#f5fffa'
	this.dt.color2 = new Object()
	this.dt.color2.n = 'navy'
	this.dt.color2.a = 'navy'
	this.dt.color2.s = 'navy'
	this.dt.color3 = new Object()
	this.dt.color3.n = 'darkred'
	this.dt.color3.a = 'darkred'
	this.dt.color3.s = 'darkred'
	this.dt.borderLeft = new Object()
	this.dt.borderLeft.n = '1 outset silver'
	this.dt.borderLeft.a = '1 outset silver'
	this.dt.borderLeft.s = '1 outset silver'
	this.w = this.dt.w*7
	this.h = this.sh+this.th+this.dt.h*6
}

function CalendarChangeDateStyle(mod,sourceIndex) {
	var widx = (sourceIndex-this.dt.srcidx)%7
	style = document.all[sourceIndex].style
	if (mod=='N') {
		style.backgroundColor = this.dt.bgcolor.n
		if (widx==0) { 
			style.color = this.dt.color3.n
			style.borderLeft = this.dt.borderLeft.n
		}
		else if (widx==6) style.color = this.dt.color2.n
		else style.color = this.dt.color1.n
		//style.border = '1 outset '+this.dt.bgcolor.n
	}
	else if (mod=='A') {
		style.backgroundColor = this.dt.bgcolor.a
		if (widx==0) { 
			style.color = this.dt.color3.a
			style.borderLeft = this.dt.borderLeft.a
		}
		else if (widx==6) style.color = this.dt.color2.a
		else style.color = this.dt.color1.a
		//style.border = '1 outset '+this.dt.bgcolor.n
	}
	else if (mod=='S') {
		style.backgroundColor = this.dt.bgcolor.s
		if (widx==0) { 
			style.color = this.dt.color3.s
			style.borderLeft = this.dt.borderLeft.s
		}
		else if (widx==6) style.color = this.dt.color2.s
		else style.color = this.dt.color1.s
		//style.border = '0'
	}
}

function CalendarEnableDate(bool) {
	this.enablingdate=bool
}

function CalendarEnableMonth(bool) {
	this.enablingmonth=bool
}

function CalendarSetDate(year,month,date) {
	this.enableDate(false)
	this.enableMonth(false)
	this.calDate(year,month,date)
	this.drawMonth()
	this.drawDate()
	this.enableDate(true)
	this.enableMonth(true)
}

function CalendarOnClick() {
	if (!this.enablingdate) return
	var idx = event.srcElement.sourceIndex
	if (idx<this.dt.srcidx+this.dt.start || idx>this.dt.srcidx+this.dt.last-1) return
	if (this.dt.selected != -1 && idx != this.dt.selected) this.changeDateStyle('N',this.dt.selected)
	this.dt.selected = idx
	this.dt.date = idx-(this.dt.srcidx+this.dt.start-1)
	if (this.actionDate!=null) this.actionDate()
}

function CalendarMouseOver() {
	if (!this.enablingdate) return
	var idx = event.srcElement.sourceIndex
	if (idx<this.dt.srcidx+this.dt.start || idx>this.dt.srcidx+this.dt.last-1) return
	this.changeDateStyle('A',idx)
}

function CalendarMouseOut() {
	if (!this.enablingdate) return
	var idx = event.srcElement.sourceIndex
	if (idx<this.dt.srcidx+this.dt.start || idx>this.dt.srcidx+this.dt.last-1) return
	if (idx==this.dt.selected) this.changeDateStyle('S',idx)
	else this.changeDateStyle('N',idx)
}

function CalendarChange() {
	if (!this.enablingmonth) return
	var id = event.srcElement.id
	if (id==this.name+'PreMonth') {
		if (this.dt.pre) this.setDate(this.dt.year,this.dt.month-1,null)
	}
	else if (id==this.name+'NextMonth') {
		if (this.dt.next)  this.setDate(this.dt.year,this.dt.month+1,null)
	}
	else if (id==this.name+'SelYear' || id==this.name+'SelMonth')
		this.setDate(this.yearctr.event.value,this.monthctr.event.value)
	if (this.actionMonth!=null) this.actionMonth()
}

function CalendarCalDate(year,month,date) {
	var lastdate = CalendarLastDate(year,month)
	var dt = new Date(year,month-1,date==null?1:Math.min(date,lastdate))
	if (dt.getFullYear() < this.syear || dt.getFullYear() > this.lyear) {
		alert("��¥�� ������ �ѽ��ϴ�.")
		return
	}
	this.dt.year = dt.getFullYear()
	this.dt.month = dt.getMonth()+1
	this.dt.date = dt.getDate()
	var sdt = new Date(this.dt.year,this.dt.month-1,1)
	this.dt.start = sdt.getDay()
	this.dt.last = this.dt.start+lastdate
}

function CalendarDrawMonth() {
	var premon = this.dt.month-1
	if (premon<1) {
		premon=12
		this.dt.pre = (this.syear<=this.dt.year-1)
	}
	else this.dt.pre = true
	var nextmon = this.dt.month+1
	if (nextmon>12) {
		nextmon=1
		this.dt.next = (this.lyear>=this.dt.year+1)
	}
	else this.dt.next = true
	if (this.dt.pre) this.prectr.write(premon+'��')
	else this.prectr.write('X')
	if (this.dt.next) this.nextctr.write(nextmon+'��')
	else this.nextctr.write('X')
	this.yearctr.event.selectedIndex=this.lyear-this.dt.year
	this.monthctr.event.selectedIndex=this.dt.month-1
}

function CalendarDrawDate() {
	var srcidx = document.all[this.name+'Calendar'].sourceIndex
	var dateobj = document.all[this.dt.name]
	for (var i=0;i<this.dt.start;i++)
		dateobj[i].innerText = ''
	for (var i=this.dt.start,d=1;i<this.dt.last;i++,d++)
		dateobj[i].innerText = d
	for (var i=this.dt.last;i<42;i++)
		dateobj[i].innerText = ''
	if (this.dt.selected != -1) this.changeDateStyle('N',this.dt.selected)
	this.dt.selected = this.dt.srcidx+this.dt.start+this.dt.date-1
	this.changeDateStyle('S',this.dt.selected)
}

function CalendarLastDate(year,month) {
	var dt = new Date(year,month-1,1)
	curmon=dt.getMonth()
	var ret=27
	for (;ret<31;ret++) {
		dt.setDate(ret+1)
		if (dt.getMonth()!=curmon) break;
	}
	return ret
}