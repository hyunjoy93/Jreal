function MultiAttach(listname) {
	this.name=listname
	this.popwin=null
	this.listobj=null

	this.popurl='../comm/pop_attach.asp'
	this.popname='w_attach'
	this.popopt='width=420, height=100, toolbar=0 scrollbars=no'
	
	this.activate=MultiAttachActivate
	this.attach=MultiAttachAttach
	this.add=MultiAttachAdd
	this.remove=MultiAttachRemove
	this.getFiles=MultiAttachGetFiles
	this.closePop=MultiAttachClosePop
	
	this.onadd=null
	this.onremove=null
	
	this.addOption=MultiAttachAddOption
}
function MultiAttachActivate() {
	var obj=document.all[this.name]
	if(obj)	this.listobj=obj
	if (this.listobj.length == 0) this.addOption('','�� ÷������ ���� ��')
}
function MultiAttachAttach() {
	this.popwin = window.open(this.popurl,this.popname, this.popopt)
	if (this.popwin) this.popwin.focus()
}
function MultiAttachAdd(filename,orgname) {
	if(this.listobj==null) return
	if (this.listobj.length==1 && this.listobj.options[0].value=='') this.listobj.options.length=0
	this.addOption(filename + '\n' + orgname, orgname)
	if (this.onadd) this.onadd()
}
function MultiAttachRemove() {
	if(this.listobj==null) return
	var idx = this.listobj.selectedIndex

	if (idx<0) alert('����� ÷�������� �����ϼ���')
	else if (this.listobj.options[idx].value != '') {
		this.listobj.options[idx]=null
		this.listobj.selectedIndex=Math.min(idx+1,this.listobj.length-1)
		if (this.listobj.length == 0) this.addOption('','�� ÷������ ���� ��')
		if (this.onremove) this.onremove()
	}
}
function MultiAttachGetFiles() {
	var str=''
	if (this.listobj && (this.listobj.length > 1 || this.listobj.options[0].value != ''))
		for (var i=0; i<this.listobj.length; i++)
			str+=this.listobj.options[i].value+'\n'
	return str
}
function MultiAttachClosePop() {
	if (this.popwin!=null)	this.popwin.close()
}
function MultiAttachAddOption(val,txt) {
	if(this.listobj==null) return
	var e = document.createElement("OPTION")
	e.value = val
	e.text = txt
	this.listobj.options.add(e)
	this.listobj.selectedIndex = this.listobj.length - 1
}
