HELP_BOARD=0
HELP_SCHEDULE=1
HELP_DRAFT=2
HELP_MAIL=3
HELP_DOC=4
HELP_CARD=5
HELP_LETTER=6
HELP_ADMIN=7
HELP_SYSTEMADMIN=8
function Help(x,y,hid,sid,idx) {
	this.name='help'
	this.x=x
	this.y=y
	this.hid=hid
	this.sid=sid
	this.idx=idx
	this.obj = name+"Object"
	eval(this.obj+"=this")

	this.pop=null
	this.draw=HelpDraw
	this.activate=HelpActivate
	this.help=HelpHelp
}
function HelpDraw() {
	this.html='<img ID="'+this.name+'" SRC="../images/subbtn/btn_help.gif" WIDTH="54" HEIGHT="16" ALT="����" style="position:absolute;left:'+(this.x-54)+';top:'+(this.y-16)+';cursor:hand;z-index:2;">'
	document.write(this.html)
}
function HelpActivate() {
	document.all[this.name].obj=this.obj
	helpobj=eval(document.all[this.name].obj)
	document.all[this.name].onclick=new Function('eval(helpobj.help())')
}
function HelpHelp() {
	var url,name,opt
	name='w_help'
	opt='width=700, height=600, toolbar=0, resizable=yes, scrollbars=yes'

	switch(this.hid) {
	case HELP_BOARD: url='../help/help_02.htm'; break;
	case HELP_SCHEDULE: url='../help/help_03.htm'; break;
	case HELP_DRAFT: url='../help/help_04.htm'; break;
	case HELP_MAIL: url='../help/help_05.htm'; break;
	case HELP_DOC: url='../help/help_06.htm'; break;
	case HELP_CARD: url='../help/help_07.htm'; break;
	case HELP_LETTER: url='../help/help_08.htm'; break;
	case HELP_ADMIN: url='../help/help_09.htm'; break;
	case HELP_SYSTEMADMIN: url='../help/help_10.htm'; break;
	default: alert('���� �׸��� �����ϴ�.'); return;
	}
	if (this.idx) url+='#'+this.idx
	if (!this.pop || this.pop.closed) this.pop=window.open(url,name,opt)
	this.pop.focus()
}