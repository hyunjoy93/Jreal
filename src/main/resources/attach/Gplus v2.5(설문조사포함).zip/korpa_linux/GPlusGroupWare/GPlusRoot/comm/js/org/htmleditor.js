/******************************************************************************
 * HTML EDIT SCRIPT --- START
 ******************************************************************************/
// margin-top:4px;margin-bottom:4px;
var HEADER = '<style>P {font-size:10pt;font-family:����;}\n TD {font-size:10pt;} \n</style>';
var newWin = null;

//-----------------------
//  HTML TAG ����
//-----------------------
function makeTag(tag,opt) {
    var selBlock = ifTextArea.document.selection.createRange();

    var selType = ifTextArea.document.selection.type;
    //selBlock.text; //����Ʈ ������ ����...
    //textArea.document.selection.type //select �� ������ ���� Text else None
    if (tag =='A') { // ��ũ ����
        var urltext, urlvalue;

        urlvalue = prompt('Ȩ�������ּҸ� �Է��ϼ���!','http://');
        if (urlvalue == null) return;

        if (selType == 'None' ) urltext = urlvalue; //������ ������ �ʾ����� �޾ƿ°��� �ؽ�Ʈ��
        else urltext = selBlock.text; //�������� �ؽ�Ʈ��

        //http://�� ������ �߰�
        if (urlvalue.substring(0,7).toLowerCase() != 'http://') urlvalue = 'http://' + urlvalue;
        //URL ���� ���ų� http://�� ���� ���� ����~
        if (urlvalue == null || urlvalue.toLowerCase() == 'http://') return;

        var url = '<a href=\"' + urlvalue + '\" target=\"_blank\">' + urltext + '</a>';

        selBlock.pasteHTML(url);
        selBlock.select();
    }
    else if (tag =='T') { // TABLE ����
        var nTd = 0, nTr = 0;
        var tblHtml = '';

        nTr = prompt('�� ���� : ','0');
        nTd = prompt('ĭ ���� : ','0');

        if (nTr == null || nTr == 0 || nTd == null || nTd == 0) return;

        for (var i = 0 ; i < nTr; i++) {
                tblHtml += '<tr>' ;
                for (var j = 0; j < nTd; j++) tblHtml += '<td></td>';
                tblHtml +=  '</tr>';
        }

        tblHtml = '<table border=1>' + tblHtml + '</table>';

        selBlock.pasteHTML(tblHtml);
        selBlock.select();
    }
    else if (opt == null) {
        selBlock.select();
        ifTextArea.document.execCommand(tag);
    }
    else {
        selBlock.select();
        ifTextArea.document.execCommand(tag,'',opt);
    }
}

//-----------------------
//  FONT FACE TAG ����
//-----------------------
function makeFont(frm) {
    var opt = frm[frm.selectedIndex].value;
    if (opt == 'n') return;
    makeTag('fontname',opt);
    frm.selectedIndex = 0;
}

//-----------------------
//  FONT SIZE TAG ����
//-----------------------
function makeFontSize(frm,tag) {
    var opt = frm[frm.selectedIndex].value;
    if (opt == 'n') return;
    makeTag(tag,opt);
    frm.selectedIndex = 0;
}

//-----------------------
//  BGCOLOR TAG ����
//-----------------------
function makeBgColor(s) {
    ifTextArea.document.body.style.backgroundColor=s;
}

//-----------------------
//  COLOR TAG ����
//-----------------------
function selColor(s) {
    var url = '../comm/color.jsp?tag=' + s;
    var name ="selectcolor";
    var opt = "width=400, height=400";
    newWin = window.open(url,name,opt);
    newWin.focus();
}

//-----------------------
//  �˾�â ����
//-----------------------
function closeNewWin() {
    if(newWin != null) newWin.close();
}

//-----------------------
//  EDITOR or TEXTAREA
//-----------------------
function setEditor(frm) {
//    var opt = frm.editor[frm.editor.selectedIndex].value;
    var opt;
    for (var i=0;i<frm.editor.length;i++) {
        if (frm.editor[i].checked) opt = frm.editor[i].value;
    }

    if (frm.tag.value != opt) {
        if (opt == '1') { //Editor ���
            ifTextArea.document.body.innerHTML = frm.comment.value;
            divEditor.style.display = 'inline';
            divText.style.display = 'none';
        }
        else if (opt == '0') { //�±� �����Է�
            frm.comment.value = ifTextArea.document.body.innerHTML;
            divEditor.style.display = 'none';
            divText.style.display = 'inline';
        }

        frm.tag.value = opt;
    }
}
