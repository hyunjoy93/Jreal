function ImageButton() {
	this.btns=new Array()
	
	this.addButton=ImageButtonAddButton
	this.enableButton=ImageButtonEnableButton
}
function ImageButtonAddButton(id,btn,img,on,off) {
	var idx=this.btns.length
	this.btns[idx]=new Object()
	this.btns[idx].id=id
	this.btns[idx].btn=btn
	this.btns[idx].img=img
	this.btns[idx].on=new Image()
	this.btns[idx].on.src=on
	this.btns[idx].off=new Image()
	this.btns[idx].off.src=off
}
function ImageButtonEnableButton(id,bool) {
	for (var i=0;i<this.btns.length;i++) {
		if (id==this.btns[i].id) {
			var btn=document.all[this.btns[i].btn]
			var img=document.all[this.btns[i].img]
			if (btn) btn.disabled=!bool
			if (img) {
				if (bool) img.src=this.btns[i].on.src
				else img.src=this.btns[i].off.src
			}
			break
		}
	}
}
