function PopupWindow(name,url,title,x,y,width,height,menubar,toolbar,scrollbars,resizable) {
	
	this.popwin=new Array()
	this.add=PopupWindowAdd
	this.openWindow=PopupWindowOpenWindow
	this.closeWindow=PopupWindowCloseWindow
	this.closeAll=PopupWindowCloseWindowsAll
	this.setTitle=PopupWindowSetTitle

	if (name) this.add(name,url,title,x,y,width,height,menubar,toolbar,scrollbars,resizable)
}
function PopupWindowAdd(name,url,title,x,y,width,height,menubar,toolbar,scrollbars,resizable) {
	var idx=this.popwin.length
	this.popwin[idx]=new Object()
	this.popwin[idx].obj=null

	this.popwin[idx].name=name
	this.popwin[idx].url=(url=='[object]'?null:url)
	this.popwin[idx].form=(url=='[object]'?url:null)
	this.popwin[idx].title=title
	this.popwin[idx].x=x
	this.popwin[idx].y=y
	this.popwin[idx].w=width
	this.popwin[idx].h=height
	this.popwin[idx].menubar=(menubar?menubar:'no')
	this.popwin[idx].toolbar=(toolbar?toolbar:0)
	this.popwin[idx].scrollbars=(scrollbars?scrollbars:'no')
	this.popwin[idx].resizable=(resizable?resizable:'no')
	this.popwin[idx].location='no'
}
function PopupWindowOpenWindow(name,url,title) {
	for (var i=0;i<this.popwin.length;i++) {
		if (this.popwin[i].name==name) {
			var opt=''
			var ttl=(title?title:this.popwin[i].title)
			if (this.popwin[i].w) opt+=' width='+this.popwin[i].w
			if (this.popwin[i].h) opt+=' height='+this.popwin[i].h
			if (this.popwin[i].menubar) opt+=' menubar='+this.popwin[i].menubar
			if (this.popwin[i].toolbar) opt+=' toolbar='+this.popwin[i].toolbar
			if (this.popwin[i].scrollbars) opt+=' scrollbars='+this.popwin[i].scrollbars
			if (this.popwin[i].resizable) opt+=' resizable='+this.popwin[i].resizable
			if (this.popwin[i].location) opt+=' location='+this.popwin[i].location
			
			if (!this.popwin[i].obj || this.popwin[i].obj.closed) {
				if (url=='[object]') {
					this.popwin[i].form=url
					this.popwin[i].obj=open('about:blank','w_'+this.popwin[i].name,opt)
					this.popwin[i].form.target='w_'+this.popwin[i].name
					setTimeout('popwin.popwin['+i+'].form.submit()',2)
				}
				else if (url!=null)
					this.popwin[i].obj=open(url,'w_'+this.popwin[i].name,opt)
				else if (url==null && this.popwin[i].form!=null) {
					this.popwin[i].obj=open('about:blank','w_'+this.popwin[i].name,opt)
					setTimeout('popwin.popwin['+i+'].form.submit()',2)
				}
				else if (url==null && this.popwin[i].url!=null)
					this.popwin[i].obj=open(this.popwin[i].url,'w_'+this.popwin[i].name,opt)
			}
			if (this.popwin[i].obj && !this.popwin[i].obj.closed && this.popwin[i].url==url) this.popwin[i].obj.focus()
			if (title)
				setTimeout('popwin.setTitle("'+this.popwin[i].name+'","'+title+'")',2)
			else if (this.popwin[i].title)
				setTimeout('popwin.setTitle("'+this.popwin[i].name+'","'+this.popwin[i].title+'")',2)
		}
	}
}
function PopupWindowCloseWindow(name) {
	for (var i=0;i<this.popwin.length;i++) {
		if (this.popwin[i].name==name) {
			if (this.popwin[i].obj && !this.popwin[i].obj.closed) this.popwin[i].obj.close()
		}
	}
}
function PopupWindowCloseWindowsAll() {
	for (var i=0;i<this.popwin.length;i++) {
		if (this.popwin[i].obj && !this.popwin[i].obj.closed) this.popwin[i].obj.close()
	}
}
function PopupWindowSetTitle(name,title) {
	for (var i=0;i<this.popwin.length;i++)
		if (this.popwin[i].name==name) {
			if (this.popwin[i].obj && !this.popwin[i].obj.closed) {
				popwin.popwin[i].obj.document.title=title
				if (this.popwin[i].x || this.popwin[i].y)
					this.popwin[i].obj.moveTo(this.popwin[i].x,this.popwin[i].y)
				break
			}
		}
}