function Alarm(msg,clock) {
	this.msg=msg
	this.clock=clock
	this.obj='AlarmObject'
	eval(this.obj+"=this")
	this.built=false

	this.msgobj=null
	this.clockobj=null
	this.formobj=null

	this.letterpop=null

	this.checktid=null
	this.checkinterval= 30000
	this.checkskip=0
	this.checkmax=5
	this.checking=false
	this.checkform='slip/slip_check.asp'

	this.alarmmsg=new Object()
	this.alarmmsg.txt=new Array()
	this.alarmmsg.color=new Array()
	this.alarmmsg.activity=new Array()
	this.alarmmsg.activity[0]=true
	this.alarmmsg.txt[0]=''
	this.alarmmsg.color[0]='white'
	this.alarmmsg.activity[1]=false
	this.alarmmsg.txt[1]='<span onclick=alarm.readLetter()><img src=images/top/top_btn_slip.gif></span> <span style="position:relative;top:-8">������ �����Ͽ����ϴ�...</span>'
	this.alarmmsg.color[1]='yellow'
	this.alarmmsg.activity[2]=false
	this.alarmmsg.txt[2]='<span><img src=images/top/top_btn_mail.gif></span> <span style="position:relative;top:-8">������ �����Ͽ����ϴ�...</span>'
	this.alarmmsg.color[2]='red'

	this.clocktid=null
	this.clockinterval=1000

	this.setDefaultMsg=AlarmSetDefaultMsg
	this.build=AlarmBuild
	this.draw=AlarmDraw
	this.activate=AlarmActivate

	this.check=AlarmCheck
	this.startChecking=AlarmStartChecking
	this.stopChecking=AlarmStopChecking
	this.alarm=AlarmAlarm
	this.showMsg=AlarmShowMsg

	this.setLetterEvent=AlarmSetLetterEvnet
	this.readLetter=AlarmReadLetter

	this.startClock=AlarmStartClock
	this.stopClock=AlarmStopClock
	this.showClock=AlarmShowClock
}
function AlarmSetDefaultMsg(txt,color) {
	if (txt) this.alarmmsg.txt[0]=txt
	if (color) this.alarmmsg.color[0]=color
}
function AlarmBuild(write) {
	this.html='<DIV ID="idAlarm">\n'+
	'<IFRAME NAME="'+'AlarmBufferFrame" WIDTH="0" HEIGHT="0"></IFRAME>\n'+
	'<FORM ID="frm'+'AlarmCheck" METHOD="POST" ACTION="'+this.checkform+'" TARGET="'+'AlarmBufferFrame"></FORM>\n'+
	'</DIV>'
	this.built=true
}
function AlarmDraw() {
	if (this.built) document.write(this.html)
}
function AlarmActivate() {
	document.all["idAlarm"].obj=this.obj
	this.self = eval('document.all["idAlarm"].obj')
	obj=this.self

	this.msgobj=document.all[this.msg]
	this.clockobj=document.all[this.clock]
	this.formobj=document.all['frmAlarmCheck']

	this.showMsg()
	this.startClock()
	this.startChecking()
}


function AlarmStartChecking() {
	this.stopChecking()
	obj=this.self
	this.checktid=setInterval("eval(obj+'.check()')",this.checkinterval)
}
function AlarmStopChecking() {
	if (this.checktid!=null) clearInterval(this.checktid)
	this.checktid=null
}

function AlarmCheck() {
	if (this.checktid==null || !this.formobj) return
	if (this.checking && this.checkskip++ < this.checkmax) return
	this.formobj.submit()
	this.checking=true
	this.checkskip=0
}

function AlarmAlarm(letter,mail) {
	this.checking=false
	this.alarmmsg.activity[0]=(letter==0 && mail==0)
	this.alarmmsg.activity[1]=(letter!=0)
	this.alarmmsg.activity[2]=(mail!=0)

	this.showMsg()
}
function AlarmShowMsg() {
	if (this.alarmmsg.activity[0]) {
		if (this.msgobj) this.msgobj.innerHTML=this.alarmmsg.txt[0]
		if (this.msgobj) this.msgobj.style.color=this.alarmmsg.color[0]
	}
	else {
		txt=''
		for (var i=1;i<this.alarmmsg.activity.length;i++)
			if (this.alarmmsg.activity[i]) {
				txt+=(txt==''?'':'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;')+
				'<font color='+this.alarmmsg.color[i]+'>'+this.alarmmsg.txt[i]+'</font>'
			}
		if (this.msgobj) this.msgobj.innerHTML='<marquee vspace=8 direction=left scrolldelay=250 >'+txt+'</marquee>'
	}
}

function AlarmSetLetterEvnet(obj) {
	alarmobj=this.self
	obj.onclick=new Function('eval(alarmobj+".readLetter()")')
}
function AlarmReadLetter() {
	var url,name,opt
	url='slip/slip_main.asp'
	name='w_slip'
	opt='width=400, height=500, toolbar=0, resizable=yes, scrollbars=no'

	this.alarmmsg.activity[0]=true
	this.showMsg()

	if (!this.letterpop || this.letterpop.closed) this.letterpop=window.open(url,name,opt)
	this.letterpop.focus()
}
function AlarmStartClock() {
	this.stopClock()
	obj=this.self
	this.clocktid=setInterval("eval(obj+'.showClock()')",this.clockinterval)
}
function AlarmStopClock() {
	if (this.clocktid!=null) clearInterval(this.clocktid)
	this.clocktid=null
}
function AlarmShowClock() {
	var today = new Date()
	var todayYear = today.getFullYear()
	var todayMonth = today.getMonth()+1
	var todayDay = today.getDate()
	var todayHour = today.getHours()
	var todayMin = today.getMinutes()
	var todaySec = today.getSeconds()
	if (todayMonth < 10) { todayMonth = "0" + todayMonth }
	if (todayDay < 10) { todayDay = "0" + todayDay }
	if (todayMin < 10) { todayMin = "0" + todayMin }
	if (todaySec < 10) { todaySec = "0" + todaySec }
	if (todayHour < 12) todayHour = 'AM ' + todayHour
	else todayHour = 'PM ' + (todayHour - 12)

	if (this.clockobj) this.clockobj.innerHTML=todayYear + '/' + todayMonth + '/' + todayDay+'<BR>'+
	todayHour + ':' + todayMin + ':' + todaySec
}
