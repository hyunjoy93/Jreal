function DataWindow(name,nestref,x,y,width,height) {
	this.name = name
	this.framename = name+'DataWindowFrame'
	this.nestref = nestref
	this.nest = (nestref)? nestref+'.document.' : ''
	this.x = x
	this.y = y
	this.w = width
	this.h = height
	this.visibility = 'hidden'
	this.scrolling = 'AUTO'
	this.frameborder='NO'
//	this.msgbox = new Object()
	this.obj = name+"DataWindowObject"
	eval(this.obj+"=this")
	this.built = false
	this.loaded = false
	
	this.build = DataWindowBuild
	this.draw = DataWindowDraw
	this.activate = DataWindowActivate
	this.show = DataWindowShow
	this.hide = DataWindowHide
	this.action = null
	this.load = DataWindowLoad
	this.reset = DataWindowReset
}
function DataWindowBuild(write) {
	this.css = (write!=false)? css('OPEN'):''
	this.css += css(this.name+'DataWindow',this.x,this.y,this.w,this.h,'transparent',this.visibility)
	if (write!=false) {
		this.css += css('CLOSE')
		document.write(this.css)
	}
	this.html = '<DIV ID="'+this.name+'DataWindow">\n'+
	'<IFRAME ID="'+this.framename+'" NAME="'+this.framename+'" WIDTH="100%" HEIGHT="100%" MARGINWIDTH=0 MARGINHEIGHT=0 SCROLLING="' + this.scrolling + '" FRAMEBORDER="'+this.frameborder+'"></IFRAME>\n'+
	'</DIV>\n'
	this.built = true
}
function DataWindowDraw() {
	if (this.built) document.write(this.html)
}

function DataWindowActivate() {
	this.ctr = new Controller(this.name+"DataWindow")
}

function DataWindowShow() {
	this.ctr.show()
}

function DataWindowHide() {
	this.ctr.hide()
}

function DataWindowLoad(url) {
	if (url) {
		this.loaded = true
		document.frames[this.framename].document.location = url
	}
	else if (this.action!=null) {
		this.loaded = true
		this.action()
	}
}

function DataWindowReset() {
	this.loaded = false
}