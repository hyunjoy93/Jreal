function PopMenu(name,nestref,x,y,width,height) {
	this.name = name
	this.nestref = nestref
	this.nest = (nestref)? nestref+'.document.' : ''
	this.x = x
	this.y = y
	this.w = width
	this.h = height
	this.visibility = 'hidden'
	this.obj = name+"PopMenuObject"
	eval(this.obj+"=this")
	this.built = false
	
	this.menu = new Object()
	this.menu.activate = false
	this.menu.textalign='left'
	this.menu.fontsize='9pt'
	this.menu.fontweight='500'
	this.menu.paddingtop='1'
	this.menu.border='1 outset silver'
	this.menu.marginL = 2
	this.menu.marginT = 2
	this.menu.marginR = 2
	this.menu.marginB = 2
	this.menu.bordercolor = 'silver'
	this.menu.bgcolor = 'silver'
	this.menu.activebgcolor='blue'
	this.menu.color = 'black'
	this.menu.activecolor = 'white'
	this.menu.item = new Array()
	
	
	this.build = PopMenuBuild
	this.draw = PopMenuDraw
	this.activate = PopMenuActivate
	this.show = PopMenuShow
	this.hide = PopMenuHide
	
	this.addItem=PopMenuAddItem
	this.selectMenu=PopMenuSelectMenu
	
	this.mouseOut=PopMenuMouseOut
	this.menuMouseOver=PopMenuMenuMouseOver
	this.menuMouseOut=PopMenuMenuMouseOut
}
function PopMenuBuild(write) {
	this.menuProperties = PopMenuMenuProperties
	this.menuProperties()
	var itemstyle='text-align:'+this.menu.textalign+'; font-size:'+this.menu.fontsize+
	'; font-weight:'+this.menu.fontweight+'; color:'+this.menu.color+'; padding-top:'+
	this.menu.paddingtop+'; border:'+this.menu.border+';'
	this.css = (write!=false)? css('OPEN'):''
	this.css += css(this.name+'PopMenu',this.x,this.y,this.w,this.h,this.menu.bordercolor,this.visibility,'1')
	for (var i=0;i<this.menu.item.length;i++)
		this.css+=css(this.name+'PopMenuItem'+i,this.menu.marginL,this.menu.marginT+this.menu.h*i,this.menu.w,this.menu.h,this.menu.bgcolor,'display',null,itemstyle)
	if (write!=false) {
		this.css += css('CLOSE')
		document.write(this.css)
	}
	this.html = '<DIV ID="'+this.name+'PopMenu">\n'
	for (var i=0;i<this.menu.item.length;i++) {
		this.html+='<DIV ID="'+this.name+'PopMenuItem'+i+'">'+this.menu.item[i].cap+'</DIV>\n'
	}
	this.html+='</DIV>\n'
	this.built = true
}
function PopMenuDraw() {
	if (this.built) document.write(this.html)
}
function PopMenuActivate() {
	this.ctr = new Controller(this.name+"PopMenu")
	this.ctr.moveTo(this.x,this.y)
	document.all[this.name+"PopMenu"].obj = this.obj
	m = eval('document.all["'+this.name+'PopMenu"].obj')
	this.ctr.event.onmouseout = new Function("eval(m+'.mouseOut()')")
	for (var i=0;i<this.menu.item.length;i++) {
		this.menu.item[i].ctr = new Controller(this.name+'PopMenuItem'+i)
		this.menu.item[i].ctr.event.onmouseover = new Function("eval(m+'.menuMouseOver()')")
		this.menu.item[i].ctr.event.onmouseout = new Function("eval(m+'.menuMouseOut()')")
		this.menu.item[i].ctr.event.onclick = new Function("eval(m+'.selectMenu()')")
	}
	this.menu.srcidx=this.menu.item[0].ctr.event.sourceIndex
}
function PopMenuShow() {
	this.ctr.show()
	this.menu.activate = false
}
function PopMenuHide() {
	this.ctr.hide()
	this.menu.activate = false
}
function PopMenuAddItem(cap,action) {
	var idx = this.menu.item.length
	this.menu.item[idx] = new Object()
	this.menu.item[idx].cap = cap
	this.menu.item[idx].action = action?action:null
}
function PopMenuMenuProperties() {
	if (this.menu.item.length==0) return
	this.menu.w = this.w-this.menu.marginL-this.menu.marginR
	this.menu.h = Math.round((this.h-this.menu.marginT-this.menu.marginB)/this.menu.item.length)
	this.h = this.menu.h*this.menu.item.length+this.menu.marginT+this.menu.marginB
}
function PopMenuSelectMenu() {
	var idx=event.srcElement.sourceIndex-this.menu.srcidx
	this.hide()
	if (this.menu.item[idx].action!=null) this.menu.item[idx].action()
}
function PopMenuMouseOut() {
	if (this.menu.activate) this.hide()
	this.menu.activate = true
}
function PopMenuMenuMouseOver() {
	event.srcElement.style.backgroundColor=this.menu.activebgcolor
	event.srcElement.style.color=this.menu.activecolor
	event.cancelBubble=true
	event.returnValue=false
	this.menu.activate = true
}
function PopMenuMenuMouseOut() {
	event.srcElement.style.backgroundColor=this.menu.bgcolor
	event.srcElement.style.color=this.menu.color
	event.cancelBubble=true
	event.returnValue=false
	this.menu.activate = true
}
