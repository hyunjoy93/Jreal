	//setMenuColor("black", "white", "blue");	//menu bgcolor, font color, mouseover font color

	//setMenuFont("bold 9pt ����");


	addMenu("userMenu", "ȯ�漳��", "","","");
	addSubMenu("userMenu", "ȯ�漳��","../../adm/adm_main.asp","");
		

	drawMenu();
	