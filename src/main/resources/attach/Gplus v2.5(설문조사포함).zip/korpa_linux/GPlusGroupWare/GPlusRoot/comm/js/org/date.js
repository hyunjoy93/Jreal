function start_clock() {

	var now = new Date();
	var hours = now.getHours();
	var minutes = now.getMinutes();
	var seconds = now.getSeconds();
	var today = now.getDay();
	var month = now.getMonth();
	var year = now.getYear();
	var date = now.getDate();

	if (today == 0) today = "�Ͽ��� "; 
	else if (today == 1) today = "������ ";
	else if (today == 2) today = "ȭ���� ";
	else if (today == 3) today = "������ ";
	else if (today == 4) today = "����� ";
	else if (today == 5) today = "�ݿ��� ";
	else if (today == 6) today = "����� ";

	if (month == 0) month = "1��";
	else if (month == 1) month = "2��";
	else if (month == 2) month = "3��";
	else if (month == 3) month = "4��";
	else if (month == 4) month = "5��";
	else if (month == 5) month = "6�� ";
	else if (month == 6) month = "7��";
	else if (month == 7) month = "8�� ";
	else if (month == 8) month = "9��";
	else if (month == 9) month = "10��";
	else if (month == 10) month = "11��";
	else if (month == 11) month = "12��";

	if(seconds < 10) seconds = "0" + seconds;
	if(minutes < 10) minutes = "0" + minutes;
	if(hours < 12) seconds = seconds + " A.M.";
	else if(hours >= 12) seconds = seconds + " P.M."

	if(hours == 0) hours = hours + 12; 
	else if(hours >12) hours = hours - 12;
	var time = hours + ":" + minutes + ":" + seconds;  

	document.write('<font size="2" >' + year + "��" + month  + date + "��" + today +'</font>'); 

}   
        


