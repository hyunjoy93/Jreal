CREATE TABLE TB_comcodehere!_A01 (
       NOTINO               varchar(12) NOT NULL,	
       BOXNO                varchar(12) NULL,		
       DOCNO                varchar(12) NULL,		
       PARENTNO             varchar(12) NOT NULL,	
       TITLE                varchar(100) NULL,		
       ATTNUM               int NOT NULL,		
       REFNUM               int NOT NULL,		
       NOMNUM               int NOT NULL,		
       CHILDNUM             int NULL,		
       REGUSER              varchar(10) NULL,		
       REGDATE              varchar(14) NULL,		
       REGNAME              varchar(50) NULL,		
       REF                  varchar(12) NOT NULL,	
       SORTSTEP             int NOT NULL,		
       RELEVEL              int NOT NULL		
);


ALTER TABLE TB_comcodehere!_A01
       ADD PRIMARY KEY (NOTINO);

       
CREATE TABLE TB_comcodehere!_B10 (
       FLDNO                varchar(12) NOT NULL,	
       FLDNAME              varchar(500) NOT NULL,	
       BOXNO                varchar(12) NULL,		
       DOCNO                varchar(12) NULL,		
       PARENTNO             varchar(12) NOT NULL,	
       REGUSER              varchar(10) NULL,		
       REGDATE              varchar(14) NULL,
       TRASHFLAG            varchar(1) NULL,
       COMMENTS             varchar(2000) NULL,
       REFNO		    varchar(25) NULL
);


ALTER TABLE TB_comcodehere!_B10
       ADD PRIMARY KEY (FLDNO);


CREATE TABLE TB_comcodehere!_C10 (
       MAILNO               varchar(12) NOT NULL,
       MAILTYPE             varchar(1) NOT NULL,
       DOCNO                varchar(12) NULL,		
       SENDTYPE             varchar(1) NULL,
       TITLE                varchar(1024) NULL,
       REGDATE              varchar(14) NULL,
       DLVRTYPE             varchar(1) NULL,
       SNDRID               varchar(1024) NULL,
       SNDRNAME             varchar(1024) NULL,
       TOID                 varchar(4000) NULL,
       TONAME               varchar(4000) NULL,
       CCID                 varchar(4000) NULL,
       CCNAME               varchar(4000) NULL,
       BCCID                varchar(4000) NULL,
       BCCNAME              varchar(4000) NULL,
       ATTNUM               int NULL,
       RCVRNUM              int NULL,
       READNUM              int NULL,
       ACCTNAME             varchar(50) NULL
);


ALTER TABLE TB_comcodehere!_C10
       ADD PRIMARY KEY (MAILNO,MAILTYPE);


CREATE TABLE TB_comcodehere!_C11 (
       MAILNO               varchar(12) NOT NULL,
       RCVRID               varchar(20) NOT NULL,
       RCVTYPE              varchar(1) NOT NULL,
       RCVRNAME             varchar(50) NULL,
       READFLAG             varchar(1) NOT NULL,
       READDATE             varchar(14) NULL
);


ALTER TABLE TB_comcodehere!_C11
       ADD PRIMARY KEY (MAILNO, RCVRID,RCVTYPE);
       
       
CREATE TABLE TB_comcodehere!_C20 (
       REGMAILNO            varchar(12) NOT NULL,
       BOXNO                varchar(12) NULL,		
       SRTYPE               varchar(1) NOT NULL,
       MAILNO               varchar(12) NULL,
       READFLAG             varchar(1) NOT NULL,
       TRASHFLAG            varchar(1) NULL
);


ALTER TABLE TB_comcodehere!_C20
       ADD PRIMARY KEY (REGMAILNO);
       
       
CREATE TABLE TB_comcodehere!_C30 (
       EMAIL                varchar(50) NOT NULL,
       USERID               varchar(10) NOT NULL,
       ACCTNAME             varchar(50) NOT NULL,
       SMTPID               varchar(20) NULL,
       SMTPSVR              varchar(100) NULL,
       SMTPTYPE             varchar(1) NOT NULL,
       POP3SVR              varchar(100) NULL,
       SMTPPWD              varchar(50) NULL,
       POP3TYPE             varchar(1) NOT NULL,
       DEFLT                varchar(1) NOT NULL,
       SNDRNAME             varchar(20) NULL,
       POP3ID               varchar(20) NULL,
       POP3PWD              varchar(50) NULL,
       SYSFLAG		    varchar(1) NULL,
       DELFLAG              varchar(1) NULL
);


ALTER TABLE TB_comcodehere!_C30
       ADD PRIMARY KEY (USERID, EMAIL);
       
       
CREATE TABLE TB_comcodehere!_D10 (
       DRFTNO               varchar(12) NOT NULL,
       TITLE                varchar(100) NOT NULL,
       DOCNO                varchar(12) NULL,     
       DLVRTYPE             varchar(1) NULL,
       REGDATE              varchar(14) NOT NULL,
       MAINTTERM            int NOT NULL,
       APPRTYPE             varchar(1) NOT NULL,
       DRFTID               varchar(10) NOT NULL,
       DRFTNAME             varchar(20) NOT NULL,
       DRFTDEPT             varchar(50) NULL,
       DRFTPOS              varchar(50) NULL,
       ATTNUM               int NOT NULL,
       STEPNUM              int NULL,
       REFNAME              varchar(200) NULL,
       REFDEPT              varchar(200) NULL,
       MAINTDATE            varchar(8) NULL,
       KEEPTERM             int NULL,
       KEEPDATE             varchar(8) NULL,
       DRFTTYPE             varchar(1) NULL,
       SECLVL               varchar(1) NULL,
       CREDATE              varchar(14)
);


ALTER TABLE TB_comcodehere!_D10
       ADD PRIMARY KEY (DRFTNO);
       
       
CREATE TABLE TB_comcodehere!_D11 (
       DRFTNO               varchar(12) NOT NULL,
       SEQ                  varchar(3) NOT NULL,
       REFTYPE              varchar(1) NOT NULL,
       APPRID               varchar(10) NOT NULL,
       APPRNAME             varchar(20) NOT NULL,
       APPRDEPTCODE         varchar(12) NULL,
       APPRDEPTNAME         varchar(50) NULL,
       APPRPOSNAME          varchar(50) NULL,
       READFLAG             varchar(1) NOT NULL,
       READDATE             varchar(14) NULL,
       APPRDATE             varchar(14) NULL,
       APPRTYPE             varchar(1) NOT NULL,
       DOCNO                varchar(12) NULL,    
       COMMENTS             varchar(2000) NULL,
       REALVIEWDATE         varchar(14) NULL
);


ALTER TABLE TB_comcodehere!_D11
       ADD PRIMARY KEY (DRFTNO, SEQ);
       
       
CREATE TABLE TB_comcodehere!_D20 (
       REGDRFTNO            varchar(12) NOT NULL,
       BOXNO                varchar(12) NULL,		
       DRFTNO               varchar(12) NULL,
       READTYPE             varchar(1) NULL,
       READFLAG             varchar(1) NULL,
       TRASHFLAG            varchar(1) NULL,
       REFTYPE              varchar(1) NULL
);


ALTER TABLE TB_comcodehere!_D20
       ADD PRIMARY KEY (REGDRFTNO);
       
       
CREATE TABLE TB_comcodehere!_D30 (
       LINENUM               varchar(12) NOT NULL,
       USERID               varchar(10) NULL,
       LINENAME             varchar(50) NULL,
       LINENOTE             varchar(1000) NULL
);


ALTER TABLE TB_comcodehere!_D30
       ADD PRIMARY KEY (LINENUM);
       
       
CREATE TABLE TB_comcodehere!_D31 (
       LINENUM               varchar(12) NOT NULL,
       SEQ                  varchar(3) NOT NULL,
       SUBTYPE              varchar(1) NULL,
       SUBAPPRID            varchar(10) NULL,
       STEPNUM              int NULL,
       SUBAPPRNAME          varchar(20) NULL
);


ALTER TABLE TB_comcodehere!_D31
       ADD PRIMARY KEY (LINENUM, SEQ);
       
       
CREATE TABLE TB_comcodehere!_E10 (
       USERID               varchar(10) NOT NULL,
       WRITERID             varchar(10) NULL,
       SCHDLNO              varchar(12) NOT NULL,
       TITLE                varchar(100) NOT NULL,
       GRPNO                varchar(12) NULL,
       STIME                varchar(4) NULL,
       LTIME                varchar(4) NULL,
       COMMENTS             varchar(4000) NULL,
       SDATE                varchar(8) NOT NULL,
       LDATE                varchar(8) NOT NULL,
       RELATMAN             varchar(1000) NULL,
       RELATID		    varchar(1000) NULL,
       RELATAREA            varchar(50) NULL,
       REPEATFLAG           varchar(2) NOT NULL,
       PARENTNO             varchar(12) NULL,
       ALARMFLAG            varchar(1) NOT NULL
);


ALTER TABLE TB_comcodehere!_E10
       ADD PRIMARY KEY (USERID, SCHDLNO);
       
       
CREATE TABLE TB_comcodehere!_G10 (
       GRPNO                varchar(12) NOT NULL,
       GRPNAME              varchar(50) NULL,
       USERID               varchar(10) NOT NULL,
       GRPCOLOR             varchar(10) NULL,
       GRPTYPE              varchar(1) NULL
);


ALTER TABLE TB_comcodehere!_G10
       ADD PRIMARY KEY (GRPNO);
       
       
CREATE TABLE TB_comcodehere!_F10 (
       USERID               varchar(10) NULL,
       CARDNO               varchar(12) NOT NULL,
       GRPNO                varchar(12) NULL,
       NAMEK                varchar(20) NOT NULL,
       NAMEE                varchar(20) NULL,
       NAMEC                varchar(20) NULL,
       SEX                  varchar(1) NULL,
       COMNAME              varchar(50) NULL,
       DEPTNAME             varchar(50) NULL,
       BIRTHDAY             varchar(8) NULL,
       ZIPCODE              varchar(7) NULL,
       ADDR                 varchar(100) NULL,
       POSNAME              varchar(50) NULL,
       LUNARFLAG            varchar(1) NULL,
       TELHOME              varchar(20) NULL,
       TELOFFICE            varchar(20) NULL,
       TELWORK              varchar(20) NULL,
       MOBILE               varchar(20) NULL,
       PAGER                varchar(20) NULL,
       HOMEPAGE             varchar(100) NULL,
       TELFAX               varchar(20) NULL,
       EMAIL                varchar(50) NULL,
       COMMENTS             varchar(1000) NULL,
       EMAIL1               varchar(50) NULL,
       EMAIL2               varchar(50) NULL,
       PUBFLAG              varchar(1) NOT NULL,
       ORGNO                varchar(12) NULL,
       REGDATE              varchar(14) NULL,
       COPIERID             varchar(10) NULL,
       COPYDATE             varchar(14) NULL       
);


ALTER TABLE TB_comcodehere!_F10
       ADD PRIMARY KEY (CARDNO);
       
       
CREATE TABLE TB_comcodehere!_F11 (
       CARDNO               varchar(12) NULL,
       MEETNO               varchar(12) NOT NULL,
       USERID               varchar(10) NULL,
       MEETDATE             varchar(14) NULL,
       COMMENTS             varchar(1000) NULL
);


ALTER TABLE TB_comcodehere!_F11
       ADD PRIMARY KEY (MEETNO);
       
CREATE TABLE TB_comcodehere!_F30 (
       BROADCASTNO          varchar(12) NOT NULL,
       TITLE                varchar(100) NOT NULL,
       USERID               varchar(10) NOT NULL,
       NOTE                 varchar(1000) NULL
);


ALTER TABLE TB_comcodehere!_F30
       ADD PRIMARY KEY (BROADCASTNO);
       
       
CREATE TABLE TB_comcodehere!_F31 (
       BROADCASTNO           varchar(12) NOT NULL,
       ACCTINFO              varchar(50) NOT NULL,
       USERNAME              varchar(50) NOT NULL,
       BROADTYPE             varchar(1) NOT NULL
);


ALTER TABLE TB_comcodehere!_F31
       ADD PRIMARY KEY (BROADCASTNO, ACCTINFO,USERNAME);


CREATE TABLE TB_comcodehere!_F50 (
       CARDNO             varchar(12) NOT NULL,
       USERID             varchar(10) NOT NULL
);


ALTER TABLE TB_comcodehere!_F50
       ADD PRIMARY KEY (CARDNO,USERID);
       
       
CREATE TABLE TB_comcodehere!_L10 (
       DOCNO                varchar(12) NOT NULL,
       TITLE                varchar(500) NULL,
       DOCTYPE              varchar(1) NOT NULL,
       FILENUM              int NOT NULL,
       TOTFILESIZE          int NULL,       
       REGUSER              varchar(10) NOT NULL,
       MODUSER              varchar(10) NOT NULL,
       REGDATE              varchar(14) NOT NULL,
       MODDATE              varchar(14) NOT NULL,
       MSTDOC               text NULL
);


ALTER TABLE TB_comcodehere!_L10
       ADD PRIMARY KEY (DOCNO);
       
       
CREATE TABLE TB_comcodehere!_L11 (
       DOCNO                varchar(12) NOT NULL,
       TITLE                varchar(500) NULL,
       SEQ                  varchar(2) NOT NULL,
       FILEEXT              varchar(11) NULL,
       CONTTYPE             varchar(1) NOT NULL,
       FILENAME             varchar(26) NOT NULL,
       VPATH                varchar(255) NOT NULL,
       REGUSER              varchar(10) NOT NULL,
       REGDATE              varchar(14) NOT NULL,
       ORGNAME              varchar(255) NULL,
       ORGPATH              varchar(255) NULL,
       MODUSER              varchar(10) NOT NULL,
       MODDATE              varchar(14) NOT NULL,
       MIMETYPE             varchar(255) NULL,
       FILESIZE             int NULL
);


ALTER TABLE TB_comcodehere!_L11
       ADD PRIMARY KEY (DOCNO, SEQ);
       
       
CREATE TABLE TB_comcodehere!_M10 (
       BOXNO                varchar(12) NOT NULL,
       ICONNO               varchar(2) NULL,
       BOXNAME              varchar(50) NOT NULL,
       PARENTNO             varchar(12) NOT NULL,
       BOXCLASS             varchar(1) NOT NULL,
       EXECCLASS            varchar(1) NOT NULL,
       REGUSER              varchar(10) NULL,		
       REGDATE              varchar(14) NULL,
       BOXTYPE              varchar(1) NOT NULL,
       BASEFLAG             varchar(1) NOT NULL,
       PUBFLAG              varchar(1) NOT NULL,
       EXECFLAG             varchar(1) NOT NULL,
       USERID               varchar(10) NULL
);


ALTER TABLE TB_comcodehere!_M10
       ADD PRIMARY KEY (BOXNO);
       
       
CREATE TABLE TB_comcodehere!_M20 (
       BOXNO                varchar(12) NOT NULL,
       USERID               varchar(10) NOT NULL,
       DOCREAD              varchar(1) NOT NULL,
       DOCWRITE             varchar(1) NULL,
       DOCDEL               varchar(1) NULL,
       DOCDELADM            varchar(1) NULL,
       FLDMAKE              varchar(1) NOT NULL,
       FLDDEL               varchar(1) NULL
);


ALTER TABLE TB_comcodehere!_M20
       ADD PRIMARY KEY (BOXNO, USERID);
       
       
CREATE TABLE TB_comcodehere!_N10 (
       ORGNO                varchar(12) NOT NULL,
       PARENTNO             varchar(12) NULL,
       ORGNAME              varchar(100) NULL,
       READERNO             varchar(10) NULL
);


ALTER TABLE TB_comcodehere!_N10
       ADD PRIMARY KEY (ORGNO);
       
       
CREATE TABLE TB_comcodehere!_N11 (
       ORGNO                varchar(12) NOT NULL,
       USERID               varchar(10) NOT NULL,
       DEFLT                varchar(1) NOT NULL
);


ALTER TABLE TB_comcodehere!_N11
       ADD PRIMARY KEY (ORGNO, USERID);
       
       
CREATE TABLE TB_comcodehere!_N20 (
       POSCODE              varchar(2) NOT NULL,
       POSNAME              varchar(50) NOT NULL,
       POSRANK              varchar(2) NULL
);


ALTER TABLE TB_comcodehere!_N20
       ADD PRIMARY KEY (POSCODE);
       
       
CREATE TABLE TB_comcodehere!_N30 (
       USERID               varchar(10) NOT NULL,
       ITEMNO               varchar(12) NOT NULL,
       BOXNO                varchar(12) NULL,		
       FLDNO                varchar(12) NULL
);


ALTER TABLE TB_comcodehere!_N30
       ADD PRIMARY KEY (USERID, ITEMNO);