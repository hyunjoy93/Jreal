function TabPage(name,nestref,cnt,x,y,width,height,shid) {
	this.name=name
	this.nestref=nestref
	this.count=cnt
	this.x=x
	this.y=y
	this.w=width
	this.h=height
	this.visibility='hidden'
	this.obj=name+'TabPageObject'
	eval(this.obj+'=this')
	this.built=false

	this.defaultsrc='../images/icon/icon_tab_off.gif'
	this.selectedsrc='../images/icon/icon_tab_on.gif'

	this.tab=new Array(cnt)
	this.tab.name=this.name+'Tab'
	this.tab.x=0
	this.tab.y=0
	this.tab.w=this.w
	this.tab.h=25
	this.tab.space=2
	this.tab.defaultimage=new Image()
	this.tab.selectedimage=new Image()
	this.tab.actived=-1

	this.page=new Array(cnt)
	this.page.name=this.name+'Page'
	this.page.x=0
	this.page.y=this.tab.h
	this.page.w=this.w
	this.page.h=this.h-this.tab.h
	
	this.page.marginL=0
	this.page.marginT=0
	this.page.marginR=0
	this.page.marginB=0
	this.page.colorL='yellow'
	this.page.colorT='yellow'
	this.page.colorR='yellow'
	this.page.colorB='yellow'
	
	for (var i=0;i<cnt;i++) {
		var tabW=Math.round((this.w)/cnt)
		
		this.tab[i]=new Object()
		this.tab[i].name=this.name+'Tab'+i
		this.tab[i].iname=this.name+'Tab'+i+'Img'
		this.tab[i].tname=this.name+'Tab'+i+'Txt'
		this.tab[i].title='Tab'+i
		this.tab[i].onclick=null
		this.tab[i].x=tabW*i
		this.tab[i].y=0
		this.tab[i].w=(i==cnt-1)?this.w-tabW*i:tabW
		this.tab[i].color='black'
		
		this.page[i]=new Object()
		this.page[i].name=this.name+'Page'+i
		this.page[i].vis='hidden'
		this.page[i].sw=(shid?16:0)
		this.page[i].scrolling='YES'
		this.page[i].frameborder='NO'
	}
	
	this.setProperties=TabPageSetProperties
	this.build=TabPageBuild
	this.draw=TabPageDraw
	this.activate=TabPageActivate
	this.show=TabPageShow
	this.hide=TabPageHide
	this.pageAction = TabPagePageAction
	this.pageLoad = TabPagePageLoad
	this.selectTab = TabPageSelectTab
	
	this.resetDatawindow=TabPageResetDatawindow
}
function TabPageSetProperties() {
	this.page.h=this.h-this.tab.h
	
	this.tab.defaultimage.src=this.defaultsrc
	this.tab.selectedimage.src=this.selectedsrc

	for (var i=0;i<this.count;i++) {
		this.tab[i].h=this.tab.h-this.tab.space
		
		this.page[i].x=this.page.marginL
		this.page[i].y=this.page.marginT
		this.page[i].w=this.page.w-this.page.marginL-this.page.marginR
		this.page[i].h=this.page.h-this.page.marginT-this.page.marginB
	}
}
function TabPageBuild(write) {
	this.setProperties()
	this.css = (write!=false)? css('OPEN'):''
	this.css += css(this.name+'TabPage',this.x,this.y,this.w,this.h,'transparent',this.visibility)+
	css(this.tab.name,this.tab.x,this.tab.y,this.tab.w,this.tab.h)+
	css(this.page.name,this.page.x,this.page.y,this.page.w,this.page.h)+
	css(this.page.name+'L',0,0,this.page.marginL,this.page.h,this.page.colorL)+
	css(this.page.name+'T',0,0,this.page.w,this.page.marginT,this.page.colorT)+
	css(this.page.name+'R',this.page.w-this.page.marginR,0,this.page.marginR,this.page.h,this.page.colorR,'display',10)+
	css(this.page.name+'B',0,this.page.h-this.page.marginB,this.page.w,this.page.marginB,this.page.colorB)
	for(var i=0;i<this.count;i++) {
		this.css += css(this.tab[i].name,this.tab[i].x,this.tab[i].y,this.tab[i].w,this.tab[i].h)
		this.css += css(this.tab[i].iname,0,0,this.tab[i].w,this.tab[i].h,'transparent','display')
		this.css += css(this.tab[i].tname,0,0,this.tab[i].w,this.tab[i].h,'transparent','display','1','text-align:center;font-size:9pt; font-weight:500; padding-top:5;')
		this.css += css(this.page[i].name,this.page[i].x,this.page[i].y,this.page[i].w,this.page[i].h,'transparent',this.page[i].vis)
	}
	for(var i=0;i<this.count;i++) {
		this.page[i].datawindow=new DataWindow(this.name+i,this.page.name,0,0,this.page[i].w+this.page[i].sw,this.page[i].h)
		this.page[i].datawindow.scrolling=this.page[i].scrolling
		this.page[i].datawindow.frameborder=this.page[i].frameborder
		this.page[i].datawindow.build(false)
		this.css += this.page[i].datawindow.css
	}
	if (write!=false) {
		this.css += css('CLOSE')
		document.write(this.css)
	}
	this.html = '<DIV ID="'+this.name+'TabPage">\n'+'<DIV ID="'+this.tab.name+'">\n'
	for (var i=0;i<this.count;i++) {
		this.html += '<DIV ID="'+this.tab[i].name+'">'+
		'<DIV ID="'+this.tab[i].tname+'">'+this.tab[i].title+'</DIV>'+'<img ID="'+this.tab[i].iname+'">'+
		'</DIV>\n'
	}	
	this.html+='</DIV>\n'+'<DIV ID="'+this.page.name+'">\n'+
	'<DIV ID="'+this.page.name+'L"></DIV>\n'+
	'<DIV ID="'+this.page.name+'T"></DIV>\n'+
	'<DIV ID="'+this.page.name+'R"></DIV>\n'+
	'<DIV ID="'+this.page.name+'B"></DIV>\n'
	for (var i=0;i<this.count;i++)
		this.html += '<DIV ID="'+this.page[i].name+'">\n'+this.page[i].datawindow.html+'</DIV>\n'
	this.html += '</DIV>\n'+'</DIV>\n'
	this.built = true
}
function TabPageDraw() {
	if (this.built) document.write(this.html)
}
function TabPageActivate() {
	this.ctr = new Controller(this.name+"TabPage")
	for (var i=0;i<this.count;i++) {
		this.tab[i].ctr=new Controller(this.tab[i].name)
		this.tab[i].ictr=new Controller(this.tab[i].iname)
		this.tab[i].tctr=new Controller(this.tab[i].tname)
		this.tab[i].ctr.event.tabpage=this.obj
		this.tab[i].ctr.event.onclick=new Function("eval(this.tabpage+'.selectTab()')")
		this.tab[i].ctr.css.cursor='hand'
		this.tab[i].ictr.event.src=this.tab.defaultimage.src
		this.page[i].ctr=new Controller(this.page[i].name)
		this.page[i].datawindow.activate()
	}
}
function TabPageShow() {
	this.ctr.show()
}
function TabPageHide() {
	this.ctr.hide()
}
function TabPagePageAction(tabid,fct1,fct2) {
	this.page[tabid].datawindow.action=fct1?fct1:null
	this.tab[tabid].onclick=fct2?fct2:null
}
function TabPagePageLoad(tabid,url) {
	this.page[tabid].datawindow.load(url)
}
function TabPageSelectTab(tabid,dataload) {
	var idx=tabid
	if (tabid==null) {
		var id=event.srcElement.id
		for (var i=0;i<this.count;i++)
			if (this.tab[i].tname==id) {
				idx=i
				break
			}
	}
	if (idx!=this.tab.actived) {
		if (this.tab.actived!=-1) {
			this.tab[this.tab.actived].ictr.event.src=this.tab.defaultimage.src
			this.page[this.tab.actived].ctr.hide()
			this.page[this.tab.actived].datawindow.ctr.hide()
		}
		if (idx!=null) {
			this.tab[idx].ictr.event.src=this.tab.selectedimage.src
			this.page[idx].ctr.show()
			this.page[idx].datawindow.ctr.show()
			this.tab.actived=idx
		}
	}
	if (idx!=null) {
		if (this.tab[idx].onclick) this.tab[idx].onclick()
		if (dataload==true || this.page[idx].datawindow.loaded==false) this.pageLoad(idx)
	}
}
function TabPageResetDatawindow(tabid) {
	this.page[tabid?tabid:this.tab.actived].datawindow.reset()
}