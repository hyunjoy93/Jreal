function BarMenu(x,y,width,height,mid) {
	this.x=x
	this.y=y
	this.w=width
	this.h=height
	this.visibility='hidden'
	this.obj='BarMenuObject'
	eval(this.obj+"=this")
	this.built = false

	this.activemenu=mid?mid:0
	this.reversedmenu=null
	this.sliding=false
	
	this.env=new Object()
	this.menu=new Array()
	
	this.getEnv=BarMenuGetEnv
	this.addMenu=BarMenuAddMenu
	this.addMenuItem=BarMenuAddMenuItem
	this.build=BarMenuBuild
	this.draw=BarMenuDraw
	this.activate=BarMenuActivate
	this.selectMenu=BarMenuSelectMenu
	this.reverseMenu=BarMenuReverseMenu

	this.mouseDownItem=BarMenuMouseDownItem
	this.mouseUpItem=BarMenuMouseUpItem
	this.mouseOverItem=BarMenuMouseOverItem
	this.mouseOutItem=BarMenuMouseOutItem
	
	this.mouseDownArrow=BarMenuMouseDownArrow
	this.mouseUpArrow=BarMenuMouseUpArrow
	this.mouseOverArrow=BarMenuMouseOverArrow
	this.mouseOutArrow=BarMenuMouseOutArrow
	
	this.slideMenu=BarMenuSlideMenu
	this.slideItems=BarmenuSlideItems
	this.setArrows=BarMenuSetArrows
	this.setClipMenu=BarMenuSetClipMenu
	this.getClip=BarMenuGetClip
	this.resize=BarMenuResize

	this.getEnv()
}
function BarMenuGetEnv() {
	this.env.border=new Object()
	this.env.border.w=0
	this.env.border.style='ridge'
	this.env.border.color='#dddddd'

	this.env.button=new Object()
	this.env.button.h=21
	this.env.button.fontfamily='±¼¸²ü'
	this.env.button.fontsize=9
	this.env.button.fontcolor='black'
	this.env.button.reversedcolor='blue'

	this.env.item=new Object()
	this.env.item.space=18
	this.env.item.iconw=38
	this.env.item.iconh=28
	this.env.item.margin=20
	this.env.item.fontfamily='±¼¸²ü'
	this.env.item.fontsize=9
	this.env.item.fontcolor='black'

	this.env.arrow=new Object()
	this.env.arrow.w=15
	this.env.arrow.h=15
	this.env.arrow.marginl=10
	this.env.arrow.margint=20
	this.env.arrow.slidestep=this.env.item.space+this.env.item.iconh+this.env.item.margin+this.env.item.fontsize
	this.env.arrow.slidespeed=10
	//this.env.arrow.up='../images/menu_icon/arrowdown.gif'
	//this.env.arrow.down='../images/menu_icon/arrowup.gif'

	this.env.margin=10
	this.env.bgcolor='trasparent'
	this.env.slidespeed=50
	this.env.screenw=this.w
	this.env.screenh= this.h-2*this.env.border.w
}

function BarMenuAddMenu(label) {
	idx=this.menu.length
	this.menu[idx]=new Object()
	this.menu[idx].label=label
	this.menu[idx].bh=this.env.button.h
	this.menu[idx].ff=this.env.button.fontfamily
	this.menu[idx].fs=this.env.button.fontsize
	this.menu[idx].fc=this.env.button.fontcolor
	this.menu[idx].item=new Array()
	return idx
}
function BarMenuAddMenuItem(mid,label,img,href,target) {
	idx=this.menu[mid].item.length
	this.menu[mid].item[idx]=new Object()
	this.menu[mid].item[idx].label=label
	this.menu[mid].item[idx].ff=this.env.item.fontfamily
	this.menu[mid].item[idx].fs=this.env.item.fontsize
	this.menu[mid].item[idx].fc=this.env.item.fontcolor
	this.menu[mid].item[idx].img=img
	this.menu[mid].item[idx].href=href
	this.menu[mid].item[idx].target=target
}
function BarMenuBuild() {
	this.html='<DIV id="BarMenuContainer" '+style(this.x,this.y,this.w,this.h,this.env.bgcolor,this.visibility,0,'border:'+this.env.border.w+' '+this.env.border.style+' '+this.env.border.color+';')+'>\n'
	//+'<img id="ArrowUp" height="'+this.env.arrow.h+'" width="'+this.env.arrow.w+'" src="'+this.env.arrow.up+'" '
	//+style(0,0,null,null,null,'hidden',500,'cursor:hand;')
	//+' onMouseDown="barmenu.mouseDownArrow(this)" onMouseUp="barmenu.mouseUpArrow(this)"'
	//+' onMouseOver="barmenu.mouseOverArrow(this)" onMouseOut="barmenu.mouseOutArrow(this)">\n'
	//+'<img id="ArrowDown" height="'+this.env.arrow.h+'" width="'+this.env.arrow.w+'" src="'+this.env.arrow.down+'" ' 
	//+style(0,0,null,null,null,'hidden',500,'cursor:hand;')
	//+' onMouseDown="barmenu.mouseDownArrow(this)" onMouseUp="barmenu.mouseUpArrow(this)"'
	//+' onMouseOver="barmenu.mouseOverArrow(this)" onMouseOut="barmenu.mouseOutArrow(this)">\n'

	var menu_y,menu_h,btn_t,item_t,label_t
	var menu_w=this.w-this.env.border.w*2
	var item_x=Math.ceil((this.w-this.env.border.w*2-this.env.item.iconw)/2)-1
	for (var i=this.menu.length-1;i>=0;i--) {
		var btnstyle=styleFont(this.env.button.fontfamily,this.env.button.fontsize,this.env.button.fontcolor)+'cursor:hand;'
		
		
				if(i==0) {
			this.html+='<img src="images/icon/board.gif" ID="MenuButton0" '
			+style(0,0,menu_w,this.env.button.h,null,null,100,btnstyle)
			+' onDblClick="barmenu.selectMenu('+i+');this.blur()" onClick="barmenu.selectMenu('+i+');this.blur()">\n'
			menu_y=this.env.button.h
		}	
		if (i==1) {
			btn_t=this.h-(this.menu.length-i)*this.env.button.h-this.env.border.w*2
			this.html+='<img src="images/icon/draft.gif"  ID="MenuButton'+i+'"  '
			+style(0,btn_t,menu_w,this.env.button.h,null,null,100,btnstyle)
			+' onDblClick="barmenu.selectMenu('+i+');this.blur()" onClick="barmenu.selectMenu('+i+');this.blur()">\n'
			menu_y=this.env.button.h+(this.h-(this.menu.length-i)*this.env.button.h-this.env.border.w*2)
		}
		if (i==2) {
			btn_t=this.h-(this.menu.length-i)*this.env.button.h-this.env.border.w*2
			this.html+='<img src="images/icon/wmail.gif"  ID="MenuButton'+i+'"  '
			+style(0,btn_t,menu_w,this.env.button.h,null,null,100,btnstyle)
			+' onDblClick="barmenu.selectMenu('+i+');this.blur()" onClick="barmenu.selectMenu('+i+');this.blur()">\n'
			menu_y=this.env.button.h+(this.h-(this.menu.length-i)*this.env.button.h-this.env.border.w*2)
		}
		if (i==3) {
			btn_t=this.h-(this.menu.length-i)*this.env.button.h-this.env.border.w*2
			this.html+='<img src="images/icon/doc.gif"  ID="MenuButton'+i+'"  '
			+style(0,btn_t,menu_w,this.env.button.h,null,null,100,btnstyle)
			+' onDblClick="barmenu.selectMenu('+i+');this.blur()" onClick="barmenu.selectMenu('+i+');this.blur()">\n'
			menu_y=this.env.button.h+(this.h-(this.menu.length-i)*this.env.button.h-this.env.border.w*2)
		}			
		if (i==4) {
			btn_t=this.h-(this.menu.length-i)*this.env.button.h-this.env.border.w*2
			this.html+='<img src="images/icon/pims.gif"  ID="MenuButton'+i+'"  '
			+style(0,btn_t,menu_w,this.env.button.h,null,null,100,btnstyle)
			+' onDblClick="barmenu.selectMenu('+i+');this.blur()" onClick="barmenu.selectMenu('+i+');this.blur()">\n'
			menu_y=this.env.button.h+(this.h-(this.menu.length-i)*this.env.button.h-this.env.border.w*2)
		}					
		

		menu_h=this.env.margin*2
			+this.menu[i].item.length*(this.env.item.iconh+this.env.item.margin+this.env.item.fontsize)
			+(this.menu[i].item.length-1)*this.env.item.space		

		this.html+='<DIV id="MenuItems'+i+'" '
		+style(0,menu_y,menu_w,null,null,null,i,'height:'+menu_h+';clip:rect(0 0 0 0);')+'>\n'
			this.html+='<table><tr><td height=10 class="submenuoff1"></td></tr></table><table border="0" cellspacing="0" cellpadding="0" bgcolor="#DDDBD6" >'
		for (var j=0;j<this.menu[i].item.length;j++) {
			item_t=this.env.margin+j*(this.env.item.space+this.env.item.iconh+this.env.item.fontsize)
			label_t=this.env.margin+this.env.item.iconh+this.env.item.margin+j*(this.env.item.space+this.env.item.iconh+this.env.item.fontsize)

			this.html+='<tr><td  class="submenuoff" style="vertical-align:top">'
			this.html+='<img src="'+this.menu[i].item[j].img+'" border="0" hspace="0" vspace="0">&nbsp;'
			this.html+='</td><td class="submenuoff" width="'+menu_w+'" style="vertical-align:top">'
 			this.html+='<a href="'+this.menu[i].item[j].href+'" ' + ' target="MAIN" onfocus="this.blur()">'

			this.html+=this.menu[i].item[j].label

			this.html+='</a></td></tr>'
		}	
		this.html+='</table>'
		this.html+='</DIV>\n'

	}
	this.html+='</DIV>\n'
			

}
function BarMenuDraw() {
	document.write(this.html)
}
function BarMenuActivate() {
	for (var i=0;i<this.menu.length;i++) this.env.screenh-=this.menu[i].bh
	this.setClipMenu(this.activemenu,0,this.env.screenw,this.env.screenh,0)
	this.setArrows()
	BarMenuContainer.style.visibility='visible'
}
function BarMenuSelectMenu(mid) {
	//if(this.sliding || mid==this.activemenu) return
	this.sliding=true
	//ArrowUp.style.visibility='hidden'
	//ArrowDown.style.visibility='hidden'
	this.slideMenu(mid)
	this.selid = mid
	if (this.menu[mid].item[0] || this.menu[mid].item[1]) {
		
	
		if (mid == 1 || mid == 2) {
			eval(this.menu[mid].item[1].target+'.location="'+this.menu[mid].item[1].href+'"')		
		} else {
			eval(this.menu[mid].item[0].target+'.location="'+this.menu[mid].item[0].href+'"')	
			}

/*
		if (mid == 0)
			eval(this.menu[mid].item[0].target+'.location="'+this.menu[mid].item[0].href+'"')
		else if (mid == 1)
			eval(this.menu[mid].item[1].target+'.location="'+this.menu[mid].item[1].href+'"')		
		else if (mid == 2)		
			eval(this.menu[mid].item[1].target+'.location="'+this.menu[mid].item[1].href+'"')				
		else
			eval(this.menu[mid].item[0].target+'.location="'+this.menu[mid].item[0].href+'"')		
			*/
	}
}
function BarMenuReverseMenu(mid) {
	oldbtn=document.all['MenuButton'+this.reversedmenu]
	newbtn=document.all['MenuButton'+mid]
	if (oldbtn) oldbtn.style.color=this.env.button.fontcolor
	if (newbtn) newbtn.style.color=this.env.button.reversedcolor
	this.reversedmenu=mid
}
function BarMenuMouseDownItem(item) {
	if(this.sliding) return
	item.style.border="2 inset #ffffff"
}
function BarMenuMouseUpItem(item) {
	if(this.sliding) return
	item.style.border="1 outset #ffffff"
	if(item.link.indexOf('javascript')!=-1) eval(item.link)
	else eval(item.targetFrame+'.location="'+item.link+'"')
	this.reverseMenu(item.id.substring(4))
}
function BarMenuMouseOverItem(item) {
	if(this.sliding) return
	item.style.border="1 outset #ffffff"
}
function BarMenuMouseOutItem(item) {
	if(this.sliding) return
	item.style.border="0 none black"
}
function BarMenuMouseDownArrow(arrow) {
	if(this.sliding) return
	arrow.style.border='1 inset #ffffff'
}
function BarMenuMouseUpArrow(arrow) {
	if(this.sliding) return
	this.sliding=true
	arrow.style.border='0 none black'
	//this.slideItems(arrow.id=='ArrowUp')
}
function BarMenuMouseOverArrow(arrow) {
	if(this.sliding) return
	arrow.style.border='1 outset #ffffff'
}
function BarMenuMouseOutArrow(arrow) {
	if(this.sliding) return
	arrow.style.border='0 none black'
}
function BarMenuSlideMenu(mid,cnt,steps) {
	if(mid==this.activemenu) return

	if(cnt==null) cnt=this.env.screenh
	if(steps==null) steps=1
	
	cnt-=Math.floor(steps)
	if(cnt<0) steps+=cnt
	var step=Math.floor(steps)
	
	if(mid>this.activemenu) {
		for(var i=1;i<=mid;i++)
			if(this.activemenu<i) {
				document.all['MenuButton'+i].style.pixelTop-=step;
				document.all['MenuItems'+i].style.pixelTop-=step;
			}
	}
	else {
		for(var i=mid+1;i<this.menu.length;i++)
			if(this.activemenu>=i) {
				document.all['MenuButton'+i].style.pixelTop+=step
				document.all['MenuItems'+i].style.pixelTop+=step
			}
	}

	var clip=this.getClip(document.all["MenuItems"+mid])
	this.setClipMenu(mid,parseInt(clip[1]),this.env.screenw,(parseInt(clip[3])+step),0)

	var clip=this.getClip(document.all["MenuItems"+this.activemenu])
	this.setClipMenu(this.activemenu,parseInt(clip[1]),this.env.screenw,(parseInt(clip[3])-step),0)

	steps*=this.env.slidespeed
	
	if(cnt>0) setTimeout('barmenu.slideMenu('+mid+','+cnt+','+steps+')',20)
	else {
		this.activemenu=mid
		this.setArrows()
		this.sliding=false
	}
}
function BarmenuSlideItems(up,cnt)
{
	if(cnt==null) cnt=Math.floor(this.env.arrow.slidestep/this.env.arrow.slidespeed)
	var plus=(up?-1:1)
	var step=this.env.arrow.slidespeed*plus

	var items=document.all['MenuItems'+this.activemenu]
	items.style.pixelTop+=step
	var clip=this.getClip(items)
    this.setClipMenu(this.activemenu,(parseInt(clip[1])-step),parseInt(clip[2]),(parseInt(clip[3])-step),parseInt(clip[4]))
	cnt--

	if(cnt>0) setTimeout('barmenu.slideItems('+up+','+cnt+')',20)
	else {
		if(Math.abs(step)*this.env.arrow.slidespeed!=this.env.arrow.slidestep) {
			var rest=this.env.arrow.slidestep%this.env.arrow.slidespeed
			items.style.pixelTop+=plus*rest
			var clip=this.getClip(items)
		    this.setClipMenu(this.activemenu,(parseInt(clip[1])-plus*rest),parseInt(clip[2]),(parseInt(clip[3])-plus*rest),parseInt(clip[4]))
		}		    
		this.setArrows()
		this.sliding=false
	}		
}
function BarMenuSetArrows() {
	var btn=document.all['MenuButton'+this.activemenu].style
	var item=document.all['MenuItems'+this.activemenu].style
	var top=btn.pixelTop+btn.pixelHeight
	
	//ArrowUp.style.pixelTop=btn.pixelTop+btn.pixelHeight+this.env.screenh-ArrowDown.height-this.env.arrow.margint
	//ArrowUp.style.pixelLeft=this.w-ArrowUp.width-this.env.border.w-this.env.arrow.marginl
	//ArrowDown.style.pixelTop=btn.pixelTop+btn.pixelHeight+this.env.arrow.margint
	//ArrowDown.style.pixelLeft=this.w-ArrowDown.width-this.env.border.w-this.env.arrow.marginl

	//if(item.pixelTop<top)	ArrowDown.style.visibility='visible'
	//else ArrowDown.style.visibility='hidden'

	//if(item.pixelHeight-(top-item.pixelTop)>this.env.screenh) ArrowUp.style.visibility='visible'
	//else ArrowUp.style.visibility='hidden'
}
function BarMenuGetClip(obj) {
    filter = /rect\((\d*)px (\d*)px (\d*)px (\d*)px\)/
    var str=obj.style.clip
    return str.match(filter)
}
function BarMenuSetClipMenu(mid,top,right,bottom,left) {
	document.all['MenuItems'+mid].style.clip=clip='rect('+top+' '+right+' '+bottom+' '+left+')'
}
function BarMenuResize(s) {
	// this.activemenuº¸´נ¾Ʒ¡G ¸𶥠¸޴ºµꁇ style.top; º¯°澃ő¾ݠȔ... L| body size¿ˠ»󟡯dy sizeG ÷L¸¸ŭ +-
	/*
	var gap = s - this.h
	alert(gap)
	for(var i=this.activemenu+1;i<this.menu.length;i++) {
		alert();
			document.all['MenuButton'+i].style.top=this.h+gap
			document.all['MenuItems'+i].style.top=this.h+gap
	}

	this.h=s
	this.env.screenh= this.h-2*this.env.border.w	
	*/
}
function style(left,top,width,height,color,vis,z,etc) {
	var str='style="position:'+((left!=null && top!=null)?'absolute;':'relative;')
	if (left!=null) str += 'left:'+left+';'
	if (top!=null) str += 'top:'+top+';'
	if (width!=null) str += 'width:'+width+';'
	if (height!=null) str += 'height:'+height+'; clip:rect(0,'+width+','+height+',0); '
	if (color!=null) str += 'background-color:'+color+';'
	if (vis!=null) str += 'visibility:'+vis+';'
	if (z!=null) str += 'z-index:'+z+';'
	if (etc!=null) str += etc
	str += '"'
	return str
}
function styleFont(family,size,color,align) {
	var str=''
	if (family!=null) str='font-family:'+family+';'
	if (size!=null) str+='font-size:'+size+'pt;'
	if (color!=null) str+='color:'+color+';'
	if (align!=null) str+='text-align:'+align+';'
	return str
}
