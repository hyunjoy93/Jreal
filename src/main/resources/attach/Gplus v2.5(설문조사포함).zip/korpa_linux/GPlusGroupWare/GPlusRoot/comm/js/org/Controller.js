function Controller(id,nestref,iframe) {
	this.id = id
	this.css = (iframe)? parent.frames[iframe].document.all[id].style : document.all[id].style
	this.x = this.css.pixelLeft
	this.y = this.css.pixelTop
	this.nestref = nestref
	this.doc = document
	this.event = (iframe)? parent.frames[iframe].document.all[id] : document.all[id]
	this.obj = id + "Controller"
	eval(this.obj + "=this")
	this.show = ControllerShow
	this.hide = ControllerHide
	this.moveTo = ControllerMoveTo
	this.write = ControllerWrite
}

function ControllerShow() {
	this.css.visibility = "visible"
}

function ControllerHide() {
	this.css.visibility = "hidden"
}

function ControllerMoveTo(x,y) {
	if (x!=null) {
		this.x = x
		this.css.left = this.x
	}
	if (y!=null) {
		this.y = y
		this.css.top = this.y
	}
}
function css(id,left,top,width,height,color,vis,z,etc) {
	if (id=="OPEN") return '<STYLE TYPE="text/css">\n'
	else if (id=="CLOSE") return '</STYLE>'
	var str = (left!=null && top!=null)? '#'+id+' {position:absolute; left:'+left+'; top:'+top+'; ' : '#'+id+' {position:relative; '
//	var str = (pos!=null)? '#'+id+' {position:absolute; ' : '#'+id+' {position:relative; '
//	if (left!=null) str += 'left:'+left+'; '
//	if (top!=null) str += 'top:'+top+'; '
	if (width!=null) str += 'width:'+width+'; '
	if (height!=null) str += 'height:'+height+'; clip:rect(0,'+width+','+height+',0); '
	if (color!=null) str += 'background-color:'+color+'; '// layer-background-color:'+color+'; '
	if (vis!=null) str += 'visibility:'+vis+'; '
	if (z!=null) str += 'z-index:'+z+'; '
	//str += 'margin:0; padding:0; float:left;'
	if (etc!=null) str += etc
	str += '}\n'
	return str
}

function ControllerWrite(html) {
	this.event.innerHTML = html
}