function FindUser(listid) {
	this.popwin=null
	this.list=new Array()
	this.users=new Array()
	
	this.poproot='../'
	this.popurl='comm/pop_finduser.jsp'
	this.popname='w_user'
	this.popopt='width=500, height=350, toolbar=0 scrollbars=yes'

	this.setListObject=FindUserSetListObject
	this.activate=FindUserActivate
	this.find=FindUserFind
	this.add=FindUserAdd
	this.remove=FindUserRemove
	this.removeAll=FindUserRemoveAll
	this.getUsers=FindUserGetUsers
	this.closePop=FindUserClosePop	
	this.setUsers=FindUserSetUsers
	this.getUserID=FindUserGetUserID
	
	this.onadd=null
	this.onremove=null
	
	this.addOption=FindUserAddOption

	if(listid) this.setListObject(listid,true,'�� �޴»�� ��� ��')
}
function FindUserSetListObject(id,multi,title) {
	var idx=this.list.length
	this.list[idx]=new Object()
	this.list[idx].obj=null
	this.list[idx].id=id
	this.list[idx].multi=multi
	this.list[idx].title=title
	return idx
}
function FindUserActivate() {
	for (var i=0;i<this.list.length;i++) {
		var obj=document.all[this.list[i].id]
		if(obj)	{
			this.list[i].obj=obj
			if (obj.length==0) this.addOption(i,'',this.list[i].title)
		}
	}
}
function FindUserFind(id) {
	var idx=(id==null?0:id)
	var url=this.poproot+this.popurl+'?type='+(this.list[idx].multi?'M':'S')+'&id='+idx
	if (!this.popwin || this.popwin.closed) this.popwin=window.open(url,this.popname,this.popopt)
	if (this.popwin) this.popwin.focus()
}
function FindUserAdd(uid,name,id) {	
	var idx=(id==null?0:id)
	if (this.list[idx].multi) {	
		if (typeof(uid)=='object') {
			var users = new Array()
			for (var i=0;i<uid.length;i++) {
				var dup=false
				for(var j=0;j<this.list[idx].obj.length;j++)
					if(this.list[idx].obj.options[j].value==uid[i]) {dup=true; break;}
				if (dup==false) users[users.length]=i
			}	
			for (var i=0;i<users.length;i++) this.addOption(idx,uid[users[i]],name[users[i]])		
			if (users.length>0 && this.onadd) this.onadd()
		}
		else {
			for(var j=0;j<this.list[idx].obj.length;j++)
				if(this.list[idx].obj.options[j].value==uid) return 
			this.addOption(idx,uid,name)
			this.onadd()			
		}		
		
	}
	else {
		this.list[idx].obj.length=0
		this.addOption(idx,uid,name)
		if (this.onadd) this.onadd()
	}
}
function FindUserRemove(id,uid) {
	var idx=(id==null?0:id)
	if (this.list[idx].multi) {
		if (uid) {
			for (var i=0;i<this.list[idx].obj.length;i++)
				if (this.list[idx].obj.options[i].value==uid) this.list[idx].obj.options[i]=null
			if (this.onremove) this.onremove()
		}
		else {
			var sidx = this.list[idx].obj.selectedIndex
			if (sidx<1) alert('����� �̸��� �����ϼ���')
			else {
				this.list[idx].obj.options[sidx]=null
				if (this.list[idx].obj.length>1)
					this.list[idx].obj.selectedIndex=Math.min(sidx+1,this.list[idx].obj.length-1)
				if (this.onremove) this.onremove()
			}
		}
	}
	else {
		this.list[idx].obj.length=0
		this.addOption(idx,'',this.list[idx].title)
		if (this.onremove) this.onremove()
	}
}
function FindUserRemoveAll(id) {
	var idx=(id==null?0:id)
	for (var i=this.list[idx].obj.length-1;i>0;i--)
		this.list[idx].obj.options[i]=null
	if (this.onremove) this.onremove()
}
function FindUserGetUsers(id) {
	var idx=(id==null?0:id)
	var str=''
	if (this.list[idx].multi) {
		for (var i=1; i<this.list[idx].obj.length; i++)
			str+=this.list[idx].obj.options[i].value+'\n'
	}
	else str=this.list[idx].obj.options[0].value
	return str
}
function FindUserClosePop() {
	if (this.popwin && !this.popwin.closed)	this.popwin.close()
}
function FindUserAddOption(idx,val,txt) {
	if(this.list[idx].obj==null) return
	var e = document.createElement("OPTION")
	e.value = val
	e.text = txt
	this.list[idx].obj.options.add(e)
	if (val!='') this.list[idx].obj.selectedIndex = this.list[idx].obj.length - 1
}
function FindUserSetUsers(users,names,titles,id) { 
	id=id?id:0
	this.users[id]=new Object() 
	this.users[id].uid=users.split(',')
	this.users[id].name=names.split(',')
	this.users[id].title=titles.split(',')
	return this.users[id].uid.length==this.users[id].name.length
}
function FindUserGetUserID(name,id) { 
	id=id?id:0
	var cnt=0
	if (!this.users[id].name) return null
	var idx
	for (var i=0;i<this.users[id].name.length;i++) 
		if (this.users[id].name[i]==name) { 
			cnt++ 
			idx=i
		}
	if (cnt==1) { 
		var ret=new Array()
		ret[0]=this.users[id].uid[idx]		
		ret[1]=this.users[id].title[idx]
		return ret
	}
	else if (cnt>1) return 'DUP'
	else return null
}