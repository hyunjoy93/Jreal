var BITBoard_currpage=0
function BITBoard(sz,pg,cnt) {
	this.pagesize=sz?sz:10
	this.pageno=pg?pg:1
	this.pagecount=cnt?cnt:0
	BITBoard_currpage=this.pageno
	this.obj = 'BITBoard'
	eval(this.obj+"=this")

	this.activate=BITBoardActivate

	this.showPage=BITBoardShowPage
	this.previous=BITBoardPrevious
	this.next=BITBoardNext
	this.changeSize=BITBoardChangeSize
	
	this.currentPage=BITBoardCurrentPage

	this.setButtons=BITBoardSetButtons
	this.releaseButtons=BITBoardReleaseButtons
}
function BITBoardActivate(btns) {
	this.setButtons(btns)
	this.showPage(BITBoard_currpage)
}
function BITBoardCurrentPage() {
	return BITBoard_currpage
}
function BITBoardShowPage(pg) {
	BITBoard_currpage=pg
	if(showPage) showPage(pg)
}
function BITBoardPrevious() {
	if(BITBoard_currpage>1) this.showPage(BITBoard_currpage-1)
}
function BITBoardNext() {
	if(BITBoard_currpage<this.pagecount) this.showPage(parseInt(BITBoard_currpage)+1)
}
function BITBoardChangeSize(sz) {
	if(changePageSize && sz && sz!=this.pagesize) changePageSize(BITBoard_currpage,sz)
}
function BITBoardSetButtons(btns) {
	if(btns) {
		btns.showPage=this.showPage
		btns.changePageSize=this.changeSize
		btns.redraw(this.pagesize,BITBoard_currpage,this.pagecount)
	}
}
function BITBoardReleaseButtons(btns) {
	if(btns) {
		btns.showPage=null
		btns.changePageSize=null
	}
}

function BITBoardButtons(sz,pg,cnt,preimg,predimg,nextimg,nextdimg) {
	this.pagesize=sz?sz:10
	this.pageno=pg?pg:1
	this.pagecount=cnt?cnt:0
	this.obj = 'BITBoardButtons'
	eval(this.obj+"=this")

	this.preimg=new Image()
	this.preimg.src=preimg?preimg:'../images/subbtn/btn_pre_on.gif'
	this.predimg=new Image()
	this.predimg.src=predimg?predimg:'../images/subbtn/btn_pre_off.gif'
	this.nextimg=new Image()
	this.nextimg.src=nextimg?nextimg:'../images/subbtn/btn_next_on.gif'
	this.nextdimg=new Image()
	this.nextdimg.src=nextdimg?nextdimg:'../images/subbtn/btn_next_off.gif'

	this.build=BITBoardButtonsBuild
	this.activate=BITBoardButtonsActivate
	this.show=BITBoardButtonsShow
	this.hide=BITBoardButtonsHide
	this.draw=BITBoardButtonsDraw
	this.redraw=BITBoardButtonsRedraw
	
	this.previous=BITBoardButtonsPrevious
	this.next=BITBoardButtonsNext
	this.changePage=BITBoardButtonsChangePage
	this.changeSize=BITBoardButtonsChangeSize

	this.mouseOver=BITBoardButtonsMouseOver
	this.mouseOut=BITBoardButtonsMouseOut

	this.showPage=null
	this.changePageSize=null
}
function BITBoardButtonsBuild() {
	this.html='<DIV ID="idBoardButtons" style="font-size:9pt;">\n<IMG ID="idBoardPrePage" style="height:18;">\n'+
	'(<SELECT ID="idBoardPageNo" SIZE="1" style="width:40;font-size:9pt;">\n'
	for(var i=1;i<=this.pagecount;i++)
		this.html+='<OPTION VALUE="'+i+'">'+i+'</OPTION>\n'
	this.html+='</SELECT>/<SPAN ID="idBoardTotalPage">1</SPAN>��)\n<IMG ID="idBoardNextPage" style="height:18;">\n'+
	'<SELECT ID="idBoardPageSize" SIZE="1" style="width:55;font-size:9pt;">\n'
	var sz=new Array(2,5,10,15,20,30,50,70,100,150,200,300)
	for(var i=0;i<sz.length;i++)
		this.html+='<OPTION VALUE="'+sz[i]+'">'+sz[i]+'����</OPTION>\n'
	this.html+='</SELECT>\n</DIV>'
}
function BITBoardButtonsActivate() {
	document.bitboardbtns=this.obj
	btns = eval('document.bitboardbtns')

	idBoardPrePage.onclick=new Function("eval(btns+'.previous()')")
	idBoardPrePage.onmouseover=new Function("eval(btns+'.mouseOver(1)')")
	idBoardPrePage.onmouseout=new Function("eval(btns+'.mouseOut()')")

	idBoardNextPage.onclick=new Function("eval(btns+'.next()')")
	idBoardNextPage.onmouseover=new Function("eval(btns+'.mouseOver(2)')")
	idBoardNextPage.onmouseout=new Function("eval(btns+'.mouseOut()')")

	idBoardPageNo.onchange=new Function("eval(btns+'.changePage()')")
	idBoardPageSize.onchange=new Function("eval(btns+'.changeSize()')")
	
	this.redraw(this.pagesize,this.pageno,this.pagecount?this.pagecount:1)
}
function BITBoardButtonsShow() {
	if(idBoardButtons) idBoardButtons.style.visibility='visible'
}
function BITBoardButtonsHide() {
	if(idBoardButtons) idBoardButtons.style.visibility='hidden'
}
function BITBoardButtonsDraw() {
	document.write(this.html)
}
function BITBoardButtonsRedraw(sz,pg,cnt) {
	for(var i=0;sz&&i<idBoardPageSize.length;i++)
		if(idBoardPageSize.options[i].value==sz) {
			idBoardPageSize.selectedIndex = i
			break;
		}
	for(var i=idBoardPageNo.length;i<cnt;i++) {
		var e=document.createElement("OPTION")
		e.value=i+1;
		e.text=i+1;
		idBoardPageNo.options.add(e)
	}
	for(var i=idBoardPageNo.length-1;i>cnt-1;i--)
		idBoardPageNo.options[i]=null;
	if(idBoardPageNo.length>0) idBoardPageNo.selectedIndex=pg>idBoardPageNo.length?1:pg-1

	idBoardPrePage.src=pg>1?this.preimg.src:this.predimg.src
	idBoardNextPage.src=pg<cnt?this.nextimg.src:this.nextdimg.src
	idBoardButtons.style.display=''
	
	idBoardTotalPage.innerText=cnt
	
	this.pagesize=sz
	this.pageno=pg
	this.pagecount=cnt
}
function BITBoardButtonsPrevious() {
	if(this.showPage && this.pageno>1) {
		this.redraw(this.pagesize,this.pageno-1,this.pagecount)
		this.showPage(this.pageno)
	}
}
function BITBoardButtonsNext() {
	if(this.showPage && this.pageno<this.pagecount) {
		this.redraw(this.pagesize,parseInt(this.pageno)+1,this.pagecount)
		this.showPage(this.pageno)
	}
}
function BITBoardButtonsChangePage() {
	if(this.showPage) {
		this.redraw(this.pagesize,idBoardPageNo.value,this.pagecount)
		this.showPage(idBoardPageNo.value)
	}
}
function BITBoardButtonsChangeSize() {
	if(this.changePageSize) this.changePageSize(idBoardPageSize.value)
}
function BITBoardButtonsMouseOver(id) {
	if(id==1) event.srcElement.style.cursor=this.pageno>1?'hand':''
	else if (id==2) event.srcElement.style.cursor=this.pageno<this.pagecount?'hand':''
}
function BITBoardButtonsMouseOut() {
	event.srcElement.style.cursor = '';
}
