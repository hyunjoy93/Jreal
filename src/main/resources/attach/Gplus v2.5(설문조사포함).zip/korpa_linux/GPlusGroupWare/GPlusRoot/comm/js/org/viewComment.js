function js_getSplitSize(text,size) {
      
      var strTmp = ""; 
        
      for (i=0;i<text.length;i++) 
      { 
         if ((text.charAt(i) == '\n') || (text.charAt(i) == '\r'))
            strTmp += '~';     
         else 
            strTmp += text.charAt(i);      
      }

      var retstr = '';
      
      if(strTmp.indexOf('~~') < 0) {
        var iLoop = 0;

        while (strTmp != null){

           if(iLoop+size < strTmp.length) {
               retstr = retstr + strTmp.substring(iLoop,iLoop+size)+'<br>';
            }
            else {
                retstr = retstr + strTmp.substring(iLoop,strTmp.length);
                break;
            } 
            iLoop = iLoop+size;
        }
      }
      else {
      	 var cnt = 1;
         for (i=0;i<strTmp.length;i++) 
         { 
           if( cnt >= size) {
              retstr += '<br>';
              cnt = 1;
           }
           
           if ((strTmp.charAt(i) == '~')){
             retstr += '<br>';     
             i++;
             cnt = 1;
           }
           else {
             retstr += strTmp.charAt(i);      
             cnt++;
           }
        }   
     }

     var row = js_getCountRow(retstr);

     ShowDegreeHelp(retstr,row); 
}

function js_comment_fix(text,size) {
  if(viewflag == 0) { 
      var strTmp = ""; 
      for (i=0;i<text.length;i++) 
      { 
         if ((text.charAt(i) == '\n') || (text.charAt(i) == '\r'))
            strTmp += '~';     
         else 
            strTmp += text.charAt(i);      
      }

      var retstr = '';
      
      if(strTmp.indexOf('~~') < 0) {
        var iLoop = 0;

        while (strTmp != null){

           if(iLoop+size < strTmp.length) {
               retstr = retstr + strTmp.substring(iLoop,iLoop+size)+'<br>';
            }
            else {
                retstr = retstr + strTmp.substring(iLoop,strTmp.length);
                break;
            } 
            iLoop = iLoop+size;
        }
      }
      else {
      	 var cnt = 1;
         for (i=0;i<strTmp.length;i++) 
         { 
           if( cnt >= size) {
              retstr += '<br>';
              cnt = 1;
           }
           
           if ((strTmp.charAt(i) == '~')){
             retstr += '<br>';     
             i++;
             cnt = 1;
           }
           else {
             retstr += strTmp.charAt(i);      
             cnt++;
           }
         }   
     }
	var row = js_getCountRow(retstr);
	 ShowDegreeHelp(retstr,row); 
     viewflag = 1;
  }
  else {
      viewflag = 0;
      nd();
  }
}


function js_getCountRow(src) {

      var count = 1;
      var pos = 0;
      while(src.indexOf('<br>',pos)>0) {
    	 count++;
      	 pos = src.indexOf('<br>',pos)+4;
      }
     return(count);
}


var viewflag = 0;

function comment_fix(text,count) {
  if(viewflag == 0) { 	
      ShowDegreeHelp(text,count);
      viewflag = 1;
  }
  else {
      viewflag = 0;
      nd();
  }
}

function drc(text) {
	dtc(1,text);
}

var charrow = 0;

function ShowDegreeHelpList(text,count) {
    
     if(viewflag != 1) {
     	 if(count > 10) {
     	    charrow = count+2;
     	 }
     	 else {
	    charrow = count;
	 }
	 ShowDegree1(1,text);
     }
}

function ShowDegreeHelp(text,count) {
    
     if(viewflag != 1) {
     	 if(count > 10) {
     	    charrow = count+2;
     	 }
     	 else {
	    charrow = count;
	 }
	 ShowDegree(1,text);
     }
}
function drn(text1,text2) {
	dtn(1,text1,text2);
}

function nd() {
     if(viewflag != 1) {
	if ( cnt >= 1 ) { sw = 0 };
		if ( sw == 0 ) {
			snow = 0;
			hideObject(over);
		} else {
			cnt++;
	}
     }
}

function ShowDegree(d,text) {
	txt = "<TABLE bgcolor=#EAFEF5 WIDTH="+width+" height='100%' STYLE=\"border:1 #5B2746 solid\" CELLPADDING=" + border + " CELLSPACING=0>" +
	        "<TR ><TD><TABLE WIDTH=100% BORDER=0 CELLPADDING=0 CELLSPACING=0  >"+
	                 "<TR><TD width=7><br></TD><TD valign='middle'height='25' align='center'><font color=red>��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��</font></TD>"+
	                 "<TD align=right style=padding-right:7></TD></TR></TABLE>"+
	                 "<TABLE WIDTH=100% BORDER=0 CELLPADDING=2 CELLSPACING=0 >"+
	                 "<TR><TD style=padding-left:7>"+ text + "<br></TD></TR></TABLE>"+
	        "</TD></TR></TABLE>"
	      
	layerWrite(txt);
	dir = d;
	disp();
}

function ShowDegree1(d,text) {
	txt = "<TABLE WIDTH="+width+" height='100%' STYLE=\"border:1 #5B2746 solid\" CELLPADDING=" + border + " CELLSPACING=0>" +
	        "<TR><TD>"+
	                 "<TABLE WIDTH=100% CELLPADDING=2 CELLSPACING=0 valign='middle' bgcolor='#000000'>"+
	                "<tr><td width = '30' bgcolor='#EEBC73'>����</td><td width='40' bgcolor='#EEBC73'>����</td><td width='30' bgcolor='#EEBC73'>����</td><td width='30' bgcolor='#EEBC73'>����</td><td bgcolor='#EEBC73'>�ð�</td></tr>"+text+"</TABLE>"+
	        "</TD></TR></TABLE>"
	      
	layerWrite(txt);
	dir = d;
	disp();
}

function disp() {
	if(intCheck == 0) {  
		if (snow == 0) {
			if (dir == 2) { // Center
				moveTo(over,x + document.body.scrollLeft+offsetx-(width/2),y+document.body.scrollTop+offsety);
			}
			if (dir == 1) { // Right
			        var xleft=x+document.body.scrollLeft;
			       if((x+document.body.scrollLeft+width) > document.body.offsetWidth)
			          xleft = document.body.offsetWidth - width - 20;
				moveTo(over,xleft,y+document.body.scrollTop+550-charrow*13);
			}
			if (dir == 0) { // Left
				moveTo(over,y+document.body.scrollTop-offsetx-width,y+document.body.scrollTop+offsety);
			}
			showObject(over);
			snow = 1;
			
		}
	
	}
	else
	{
		
		if (snow == 0) {
			if (dir == 2) { // Center
				moveTo(over,x + document.body.scrollLeft+offsetx-(width/2),y+document.body.scrollTop+offsety);
			}
			if (dir == 1) { // Right
			        var xleft=x+document.body.scrollLeft;
			       if((x+document.body.scrollLeft+width) > document.body.offsetWidth)
			          xleft = document.body.offsetWidth - width - 20;
				moveTo(over,xleft,y+document.body.scrollTop+550-charrow*13);
			}
			if (dir == 0) { // Left
				moveTo(over,y+document.body.scrollTop-offsetx-width,y+document.body.scrollTop+offsety);
			}
			snow = 1;
						
	      }
	}
}

function mouseMove(e) {
    
    //alert(document.body.scrollTop);
  if(viewflag != 1) {
    
    if( document.body.scrollTop < 700 ) {
    
		x=event.x +document.body.scrollLeft ; y=event.y+ document.body.scrollTop + 20;
	}
	
	else {
	
		x=event.x +document.body.scrollLeft ; y=event.y+ document.body.scrollTop - 90;
	
	}
	
	if (snow) {
		if (dir == 2) { // Center
			moveTo(over,x+offsetx-(width/2),y+offsety);
		}
		if (dir == 1) { // Right
		        var xleft=x+document.body.scrollLeft;
		       if((x+document.body.scrollLeft+width) > document.body.offsetWidth)
		          xleft = document.body.offsetWidth - width - 20;
			moveTo(over,xleft,y + 550-charrow*13);
		}
		if (dir == 0) { // Left
			moveTo(over,x-offsetx-width,y+offsety);
		}
	}
   }
}

function layerWrite(txt) {
	document.all["overDiv"].innerHTML = txt	
}

function showObject(obj) {
	obj.visibility = "visible"
}

function hideObject(obj) {
	obj.visibility = "hidden"
}

function moveTo(obj,xL,yL) {
    obj.left = xL
    obj.top = yL - 45
}
