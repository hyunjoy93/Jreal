var MenuFont    = "bold 9pt ����";		//menu font
var MenuBGColor = "#6699CC";			//menu background color
var MenuTFColor = "white";				//menu text font color 
var MenuMOColor = "yellow";				//menu mouseover font color

var MenuIDPrefix = "Menu_";             //�޴���ũID�� ���� prefix
var SubMIDPrefix = "SubM_";				//�����޴���ũID�� ���� prefix
var CRLF = String.fromCharCode(10);		
var char34 = String.fromCharCode(34);

var HTMLStr;
var x = 0;
var y = 0;
var x2 = 0;
var y2 = 0;
var bMenubarLoaded = false;
var MaxMenu = 30;						//������ �ִ�޴���
var TotalMenu = 0;						//�޴� �Ѱ��� ����
var arrMenuItem = new Array(30);		//menuItem() ��ü�� �����ϴ� �迭
var PreEventMenu;

document.write("<SPAN id=StartMenu STYLE='display:none;'></SPAN>");

// MenuBar Template�� �����Ѵ�.
HTMLStr = 
	"<DIV ID='idMenu' STYLE='position:relative;height:20;width:100%;'>" +
	"<DIV ID='idSubMenu' STYLE='position:absolute;top:0;left:0;height:20;background-color:black;' NOWRAP><!--MENU_TITLES--></DIV>" +
	"</DIV>" +
	"<SCRIPT TYPE='text/javascript'>" + 
	"   var PreEventMenu = StartMenu;" + 
	"</SCRIPT>"

function drawMenu()
{
	document.write(HTMLStr);
	bMenubarLoaded = true;

	idMenu.style.backgroundColor = MenuBGColor;
	idSubMenu.style.backgroundColor = MenuBGColor;

	for (i = 0; i < TotalMenu; i++) 
	{
		thisMenu = document.all(arrMenuItem[i].IDStr);
		if (thisMenu != null)
		{
			if (arrMenuItem[i].type == "A")
				thisMenu.style.width = arrMenuItem[i].unit;
			else 
				thisMenu.style.width = Math.round(arrMenuItem[i].width * arrMenuItem[i].unit) + 'em';
		}
	}
}

function setMenuFont(sFont)
{	MenuFont = sFont;
}

function setMenuColor(bgColor, fontColor, mouseoverColor)
{	
	if (bgColor   != "")	  MenuBGColor = bgColor;
	if (fontColor != "")	  MenuTFColor = fontColor;
	if (mouseoverColor != "") MenuMOColor = mouseoverColor;
}

function setSubMenuWidth(MenuIDStr, WidthType, WidthUnit)
{
	var fFound = false;
	if (TotalMenu == MaxMenu)
	{
		alert("�޴��� �ִ�� " + MaxMenu + "�� �ʰ��Ͽ����ϴ�.");
		return;
	}
	
	for (i = 0; i < TotalMenu; i++)
		if (arrMenuItem[i].IDStr == MenuIDStr)
		{
			fFound = true;
			break;
		}

	if (!fFound)
	{
		arrMenuItem[i] = new menuItem(MenuIDStr);
		TotalMenu += 1;
	}

	if (!fFound && WidthType.toUpperCase().indexOf("DEFAULT") != -1)
	{
		arrMenuItem[i].type = "A";
		arrMenuItem[i].unit = 120;
	}
	else
	{
		arrMenuItem[i].type = (WidthType.toUpperCase().indexOf("ABSOLUTE") != -1)? "A" : "R";
		arrMenuItem[i].unit = WidthUnit;
	}
}

// �޴�Object �Լ�
function menuItem(MenuIDStr)
{
	this.IDStr = MenuIDStr;
	this.type  = "";
	this.unit  = 0;
	this.width = 0;
	this.count = 0;
}

function updateSubMenuWidth(MenuIDStr)
{
	for (i = 0; i < TotalMenu; i++)
		if (arrMenuItem[i].IDStr == MenuIDStr)
		{
			if (arrMenuItem[i].width < MenuIDStr.length) 
				arrMenuItem[i].width = MenuIDStr.length;
			arrMenuItem[i].count = arrMenuItem[i].count + 1;
			break;
		}
}

function addMenu(MenuIDStr, MenuDisplayStr, MenuHelpStr, MenuURLStr, TargetStr)
{
	tagStr  = "<!--MENU_TITLES-->";
	
	MenuStr = CRLF + "<A TARGET='" + TargetStr + "' TITLE='" + MenuHelpStr + "'" +
			"   ID='" + MenuIDPrefix + MenuIDStr + "'" +
			"   STYLE='text-decoration:none;cursor:hand;font:" + MenuFont + ";background-color:" + MenuBGColor + ";color:" + MenuTFColor + ";'";
			
	if (MenuURLStr != "")
		MenuStr += " HREF='" + MenuURLStr + "'";
	else
		MenuStr += " HREF='' onclick='window.event.returnValue=false;'";
		
	MenuStr += 	" onmouseout="  + char34 + "mouseMenu('out' ,'" + MenuIDStr + "'); hideMenu();" + char34 + 
				" onmouseover=" + char34 + "mouseMenu('over','" + MenuIDStr + "'); doMenu('"+ MenuIDStr + "');" + char34 + ">" +
				"&nbsp;" + MenuDisplayStr + "&nbsp;</a>";
				
	MenuStr += "<SPAN STYLE='font:" + MenuFont + ";color:" + MenuTFColor + "'>&nbsp;|</SPAN>";
	MenuStr += tagStr;
	
	HTMLStr = HTMLStr.replace(tagStr, MenuStr);	
	setSubMenuWidth(MenuIDStr,"default",0);
}

function addSubMenu(MenuIDStr, SubMenuStr, SubMenuURLStr, TargetStr)
{
	var LookUpTag  = "<!--" + MenuIDStr + "-->";
	var sPos = HTMLStr.indexOf(LookUpTag);
	
	if (sPos <= 0)
	{
		HTMLStr += CRLF + CRLF + "<SPAN ID='" + MenuIDStr + "'" +
				" STYLE='display:none;position:absolute;width:120;background-color:" + MenuBGColor + ";padding-top:0;padding-left:0;padding-bottom:20;z-index:9;'" +
				" onmouseout='hideMenu();'>" + "<DIV STYLE='position:relative;left:0;top:8;'>";
	}

	TempStr = CRLF + "<A ID='" + SubMIDPrefix + MenuIDStr + "'" +
			"   STYLE='text-decoration:none;cursor:hand;font:" + MenuFont + ";color:" + MenuTFColor + "'" +
			"   HREF='" + SubMenuURLStr + "' TARGET='" + TargetStr + "'" +
			" onmouseout="  + char34 + "mouseMenu('out' ,'" + MenuIDStr + "');" + char34 + 
			" onmouseover=" + char34 + "mouseMenu('over','" + MenuIDStr + "');" + char34 + ">" +
			"&nbsp;" + SubMenuStr + "</A><BR>" + LookUpTag;
			
	if (sPos <= 0)
		HTMLStr += TempStr + "</DIV></SPAN>";
	else
		HTMLStr = HTMLStr.replace(LookUpTag, TempStr);	

	updateSubMenuWidth(MenuIDStr);	
}

function addSubMenuLine(MenuIDStr)
{
	var LookUpTag = "<!--" + MenuIDStr + "-->";
	var sPos = HTMLStr.indexOf(LookUpTag);
	if (sPos > 0)
	{
		TempStr = CRLF + "<HR STYLE='color:" + MenuTFColor + "' SIZE=1>" + LookUpTag;
		HTMLStr = HTMLStr.replace(LookUpTag, TempStr);
	}
}

function mouseMenu(id, MenuIDStr) 
{
	if (id.toUpperCase().indexOf("OUT") != -1)
		window.event.srcElement.style.color = MenuTFColor;
	else
		window.event.srcElement.style.color = MenuMOColor;
}

function doMenu(MenuIDStr) 
{
	var thisMenu = document.all(MenuIDStr);
	window.event.cancelBubble = true;	//�̺�Ʈ�� ��������̵��� ���´�.
										//�̺�Ʈ�� �⺻������ ��������retunValue��...
	if (PreEventMenu == null || thisMenu == null || thisMenu == PreEventMenu)
		return false;

	// Reset dropdown menu
	PreEventMenu.style.display = "none";
	showElement("SELECT");
	showElement("OBJECT");
	PreEventMenu = thisMenu;

	// Set dropdown menu display position
	x  = window.event.srcElement.offsetLeft +
	 	 window.event.srcElement.offsetParent.offsetLeft;
	x2 = x + window.event.srcElement.offsetWidth;
	y  = idMenu.offsetHeight;
	thisMenu.style.top  = y;
	thisMenu.style.left = x;
	thisMenu.style.clip = "rect(0 0 0 0)";
	thisMenu.style.display = "block";

	// delay 2 millsecond to allow the value of PreEventMenu.offsetHeight be set
	window.setTimeout("showMenu()", 2);
	return true;
}

function showMenu() 
{
	if (PreEventMenu != null) 
	{ 
		y2 = y + PreEventMenu.offsetHeight;

		PreEventMenu.style.clip = "rect(auto auto auto auto)";
		hideElement("SELECT");
		hideElement("OBJECT");
	}
}

function hideMenu()
{
	if (PreEventMenu && PreEventMenu != StartMenu) 
	{
		cY = event.clientY + document.body.scrollTop;
		if ( (event.clientX >= (x+5) && event.clientX <= x2) &&
			 (cY > (y-10) && cY <= y2) )
		{
			window.event.cancelBubble = true;
			return; 
		}

		PreEventMenu.style.display = "none";
		PreEventMenu = StartMenu;
		window.event.cancelBubble = true;

		showElement("SELECT");
		showElement("OBJECT");
	}
}

function hideElement(elmID)
{
	for (i = 0; i < document.all.tags(elmID).length; i++)
	{
		obj = document.all.tags(elmID)[i];
		if (! obj || ! obj.offsetParent)
			continue;

		// Find the element's offsetTop and offsetLeft relative to the BODY tag.
		objLeft   = obj.offsetLeft;
		objTop    = obj.offsetTop;
		objParent = obj.offsetParent;
		while (objParent.tagName.toUpperCase() != "BODY")
		{
			objLeft  += objParent.offsetLeft;
			objTop   += objParent.offsetTop;
			objParent = objParent.offsetParent;
		}
		// Adjust the element's offsetTop relative to the dropdown menu
		objTop = objTop - y;

		if (x > (objLeft + obj.offsetWidth) || objLeft > (x + PreEventMenu.offsetWidth))
			;
		else if (objTop > PreEventMenu.offsetHeight)
			;
		else
			obj.style.visibility = "hidden";
	}
}

function showElement(elmID)
{
	for (i = 0; i < document.all.tags(elmID).length; i++)
	{
		obj = document.all.tags(elmID)[i];
		if (! obj || ! obj.offsetParent)
			continue;
		obj.style.visibility = "";
	}
}

