function DocTree() {
	this.obj = "DocTreeObject"
	eval(this.obj + "=this")
	this.img_linkspace=new Image();
	this.img_linknon=new Image();
	this.img_expand1=new Image();
	this.img_expand2=new Image();
	this.img_expand3=new Image();
	this.img_collapse1=new Image();
	this.img_collapse2=new Image();
	this.img_collapse3=new Image();
	this.selectedAnchor = null; //���õǾ� ������ �����Ը�ũ��ü�� �����Ѵ�.
	this.build=DocTreeBuild
	this.activate=DocTreeActivate
	this.selectText=DocTreeSelectText
	this.expand=DocTreeExpand
	this.collapse=DocTreeCollapse
	this.selectFolder=DocTreeSelectFolder
	this.click=DocTreeClick
	this.setImgPath=DocTreeSetImgPath
}
function DocTreeBuild() {
	document.write('<STYLE TYPE="text/css">\n')
	document.write('<!--\n')
	document.write('DIV\n')
	document.write('{\n')
	document.write('FONT-FAMILY: ����ü;\n')
	document.write('FONT-SIZE: 9pt;\n')
	//document.write('text-decoration:none;\n')    //�߰�����(1026)
	document.write('}\n')
	document.write('#img_folder {width:19;height:16;border:0;cursor:hand;}\n')
	document.write('#img_linkspace {width:19;height:16;border:0;}\n')
	document.write('#img_linknone {width:19;height:16;border:0;}\n')
	document.write('//-->\n')
	document.write('</style>\n')
	document.tree=this.obj
	document.onclick = new Function("eval(document.tree+'.click()')")
}
function DocTreeActivate() {
	var linkspace = document.all["img_linkspace"]
	var linknon = document.all["img_linknon"]
	for (var i=0;i<document.all.length;i++) {
		if (document.all[i].id.substring(0,3)=='idE') {
			document.all[i++].src=this.img_collapse3.src
			document.all[i].src=this.img_collapse1.src
		}
	}
	if (linkspace) {
		if (linkspace.length)
			for (var i=0;i<linkspace.length;i++) linkspace[i].src=this.img_linkspace.src
		else linkspace.src=this.img_linkspace.src
	}
	if (linknon) {
		if (linknon.length)
			for (var i=0;i<linknon.length;i++) linknon[i].src=this.img_linknon.src
		else linknon.src=this.img_linknon.src
	}
}
function DocTreeSelectText(srcE) {
	if (!srcE) return
	if (this.selectedAnchor) {
		this.selectedAnchor.style.color="";
		this.selectedAnchor.style.backgroundColor="";
	}
	srcE.style.color="white";
	srcE.style.backgroundColor="blue";
	this.selectedAnchor = srcE;
}
function DocTreeExpand(srcE){
	var srcIdx=srcE.parentElement.sourceIndex;
	var childIdx=srcE.parentElement.children.length;
	for (i=srcIdx+1;i<=srcIdx+childIdx;i++) {
		if (document.all[i].id.substring(0,3)=="idE") {
			var img = document.all[i]
			if (img.src==this.img_collapse1.src) img.src=this.img_expand1.src;
			else if (img.src==this.img_collapse2.src) img.src=this.img_expand2.src;
			else if (document.all[i].src==this.img_collapse3.src) img.src=this.img_expand3.src;
		}
	}
	document.all[srcIdx+childIdx+1].style.display='';
}
function DocTreeCollapse(srcE) {
	var srcIdx=srcE.parentElement.sourceIndex;
	var childIdx=srcE.parentElement.children.length;
	for (i=srcIdx+1;i<=srcIdx+childIdx;i++) {
		if (document.all[i].id.substring(0,3)=="idE") {
			var img = document.all[i]
			if (img.src==this.img_expand1.src)	img.src=this.img_collapse1.src;
			else if (img.src==this.img_expand2.src)	img.src=this.img_collapse2.src;
			else if (img.src==this.img_expand3.src)	img.src=this.img_collapse3.src;
		}
	}
	document.all[srcIdx+childIdx+1].style.display='none';
}
function DocTreeSelectFolder(folderid) {
	var srcE=document.all['idA'+folderid]
	if (srcE) this.selectText(srcE)
	if (!document.all['idE'+folderid]) return
	for(srcE=document.all['idE'+folderid][0];srcE&&srcE.parentElement.id=='idF';) {
		if (srcE.parentElement && srcE.parentElement.parentElement) {
			srcE=document.all[srcE.parentElement.parentElement.sourceIndex-1]
			this.expand(srcE)
		}
		else srcE=null
	}
	
}
function DocTreeClick() {
	if (event.srcElement.id.substring(0,3)=="idA") this.selectText(event.srcElement)
	if (event.srcElement.id.substring(0,3)=="idE") {
		var srcIdx=event.srcElement.parentElement.sourceIndex;
		srcIdx+=event.srcElement.parentElement.children.length+1;
		var nested=document.all[srcIdx];
		var isExpanded=nested.style.display=='';
		if(isExpanded) this.collapse(event.srcElement)
		else this.expand(event.srcElement)
	}
}
function DocTreeSetImgPath(s) {
	if (s==null) s="../"
	this.img_linkspace.src=s+"images/icon/folder/icon_fld_lnks.gif"
	this.img_linknon.src=s+"images/icon/folder/icon_fld_lnkn.gif"
	this.img_expand1.src=s+"images/icon/folder/icon_fld_open.gif";
	this.img_expand2.src=s+"images/icon/folder/icon_fld_expm.gif";
	this.img_expand3.src=s+"images/icon/folder/icon_fld_expe.gif";
	this.img_collapse1.src=s+"images/icon/folder/icon_fld_close.gif";
	this.img_collapse2.src=s+"images/icon/folder/icon_fld_colm.gif";
	this.img_collapse3.src=s+"images/icon/folder/icon_fld_cole.gif";
}