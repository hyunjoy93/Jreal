if (!printIsNativeSupport())  window.print = printFrame;

function printFrame(frame,title) {
	if (!frame) frame = window;
	if (frame.document.readyState !== "complete") return;

	var focused = document.activeElement;
	var orgTitle = frame.document.title;
	if (title) frame.document.title = title;
	frame.focus();

	if (printIsNativeSupport()) {
		frame.self.print();
		frame.document.title = orgTitle;
		if (focused && !focused.disabled) focused.focus();
	}
	else {
		window.ExecprintWB = function() {
			execScript("on error resume next: printWB.ExecWB 6, 1", "VBScript");
			printWB.outerHTML = "";
			frame.document.title = orgTitle;
			if (focused && !focused.disabled) focused.focus();
			window.ExecprintWB = null;
		}
		document.body.insertAdjacentHTML("beforeEnd",'<object id="printWB" width=0 height=0 \
		classid="clsid:8856F961-340A-11D0-A96B-00C04FD705A2"></object>');
		window.ExecprintWB = ExecprintWB;
		setTimeout("window.ExecprintWB()",0);
	}
}

function printIsNativeSupport() {
	var agent = window.navigator.userAgent;
	var i = agent.indexOf("MSIE ")+5;
	return parseInt(agent.substr(i)) >= 5 && agent.indexOf("5.0b1") < 0;
}
