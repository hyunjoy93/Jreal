package gplus.template;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

import gplus.component.card.*;


/**
 * <PRE>
 * Filename		: GTpCardGroup.java
 * Class		:
 * Function		:
 * Comment		:
 * History  : 12/10/2001, ������, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GTpCardGroup {

   /**
    * <PRE>
    * ���޵� ���Թ�ȣ�� ������ ���Ը�ϰ� ���Ա׷����� �ǵ��� �ش�.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String USERID : current user id at session
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : �������� (GRPNO, GRPNAME, ORGNAME )
    */

      	 public GCmResultSet getCardGrpList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoCaCardGroup Card = new GCoCaCardGroup();

	 	try
	 	{
	 		return Card.getCardGrpList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println( "CardGroup.getCardGrpList" );
	 		return null;
	 	}
           }

   /**
    * <PRE>
    * ���޵� ���Թ�ȣ�� ������ ���Ը�ϰ� ���Ա׷����� �ǵ��� �ش�.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String USERID : current user id at session
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : �������� (GRPNO, GRPNAME, ORGNAME )
    */

      	 public GCmResultSet getMailCardGrpList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoCaCardGroup Card = new GCoCaCardGroup();

	 	try
	 	{
	 		return Card.getMailCardGrpList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println( "CardGroup.getCardGrpList" );
	 		return null;
	 	}
           }

   /**
    * <PRE>
    * ���޵� �׷��� ����� �� ���.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String USERID : current user id at session
    *                      <LI> String GRPNO : �׷��ڵ� 
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet :  �׷��� ����� �� ��� 
    */

      	 public GCmResultSet getGrpUsed(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoCaCardGroup Card = new GCoCaCardGroup();

	 	try
	 	{
	 		return Card.getGrpUsed(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println( "GTpCardGroup.getGrpUsed" );
	 		return null;
	 	}

	}	// end component call



   /**
    * <PRE>
    * �ߺ��� �׷���� üũ.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String USERID : current user id at session
    *                      <LI> String GRPNAME : �׷��̸�
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet :  �ߺ��� �׷���� �ִ��� Ȯ��.
    */

      	 public GCmResultSet getGrpNameDup(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoCaCardGroup Card = new GCoCaCardGroup();

	 	try
	 	{
	 		return Card.getGrpNameDup(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println( "GTpCardGroup.getGrpNameDup" );
	 		return null;
	 	}

	}	// end component call

   /**
    * <PRE>
    *  ���޵� ����� �׷��� ����. 
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String USERID : current user id at session
    *                      <LI> String GRPNO : �׷��ڵ�
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : 
    */


      	 public int deleteCardGroup(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoCaCardGroupTran Card = new GCoCaCardGroupTran();

	 	try
	 	{
	 		return Card.deleteCardGroup(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println( "GTpCardGroup::deleteCardGroup" );
	 		return -1;
	 	}

	}	// end component call



   /**
    * <PRE>
    *  ���޵� ����� �׷��� ����
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String USERID : current user id at session
    *                      <LI> String GRPNAME : �׷��̸�
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : �׷� ����
    */

      	 public int insertCardGroup(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoCaCardGroupTran Card = new GCoCaCardGroupTran();

	 	try
	 	{
	 		return Card.insertCardGroup(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println( "GTpCardGroup::insertCardGroup" );
	 		return -1;
	 	}

	}	// end component call




}