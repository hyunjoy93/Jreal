package gplus.template;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;


import gplus.component.common.*;


/**
 * <PRE>
 * Filename		: GTpZipcode.java
 * Class		:
 * Function		:
 * Comment		:
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GTpZipcode
{
       /**
        * <PRE>
        * ���޵� ���̸��� ���Ͽ� �ش��ϴ� ���̸��� �����ϰ� �ִ� �����ּҸ� �˻��Ͽ� �����ش�. 
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String addrname : ���̸�
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet ������ȣ list (zipcode,si_do,gu_gun,dong,bunji_range)
        */	 	 
	public GCmResultSet selectZipcode(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoCnZipCode zipcode = new GCoCnZipCode();

	 	try
	 	{
	 		return zipcode.getAddressList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
		        System.out.println(" GTpZipcode::selectZipcode : " + e.getMessage());
	 		return null;
	 	}

	}	// end component call
}	// end GTpZipcode


