package gplus.template;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;
import com.jspsmart.upload.*;

import gplus.component.board.*;
import gplus.component.research.*;
import gplus.component.userinfo.*;
import gplus.component.org.*;
import gplus.component.doc.*;

/**
 * <PRE>
 * Filename		: GTpUserInfo.java
 * Class		:
 * Function		:
 * Comment		:
 * History      : 03/19/2002, ������, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GTpResearch
{

      public int insertResearchUser(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
      {
	    GCoReResearchTran researchTran = new GCoReResearchTran();

            try
            {
                  return researchTran.insertResearchUser(cp, dmProp, msgInfo);
            }
            catch (Exception e)
            {
	          System.out.println(" GCoReResearchTran :: insertResearchUser : " + e.getMessage());
	          return -1;
            }
      }

      public int insertResearchObject(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
      {
	    GCoReResearchTran researchTran = new GCoReResearchTran();

            try
            {
                  return researchTran.insertResearchObject(cp, dmProp, msgInfo);
            }
            catch (Exception e)
            {
	          System.out.println(" GCoReResearchTran :: insertResearchObject : " + e.getMessage());
	          return -1;
            }
      }

      public int insertResearchDetailObject(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
      {
	    GCoReResearchTran researchTran = new GCoReResearchTran();

            try
            {
                  return researchTran.insertResearchDetailObject(cp, dmProp, msgInfo);
            }
            catch (Exception e)
            {
	          System.out.println(" GCoReResearchTran :: insertResearchDetailObject : " + e.getMessage());
	          return -1;
            }
      }

       public int insertResearchMain(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
       {

            GCoReResearchTran researchTran = new GCoReResearchTran();

	    try
            {
                   return researchTran.insertResearchMain(cp, dmProp, msgInfo);
            }
	    catch (Exception e)
            {
	          System.err.println(" GCoReResearchTran :: insertResearchMain : " + e.getMessage());
	          return -1;
	    }

	}

        public int updateUser(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
       {

            GCoReResearchTran researchTran = new GCoReResearchTran();

	    try
            {
                   return researchTran.updateUser(cp, dmProp, msgInfo);
            }
	    catch (Exception e)
            {
	          System.err.println(" GCoReResearchTran :: updateUser : " + e.getMessage());
	          return -1;
	    }

	}

        public GCmResultSet getResultCount(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
                GCoReResearch research = new GCoReResearch();
 	 	try
	 	{
                        return research.getResultCount(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpResearch::getResultCount : " + e.getMessage());
	 		return null;
	 	}
	}

        public GCmResultSet getUserFlag(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
                GCoReResearch research = new GCoReResearch();
 	 	try
	 	{
                        return research.getUserFlag(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpResearch::getUserFlag : " + e.getMessage());
	 		return null;
	 	}
	}

        public GCmResultSet getRecordCount(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
                GCoReResearch research = new GCoReResearch();
 	 	try
	 	{
                        return research.getRecordCount(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpResearch::getRecordCount : " + e.getMessage());
	 		return null;
	 	}
	}

        public GCmResultSet getUserCount(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
                GCoReResearch research = new GCoReResearch();
 	 	try
	 	{
                        return research.getUserCount(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpResearch::getUserCount : " + e.getMessage());
	 		return null;
	 	}
	}

        public GCmResultSet getResearchList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
                GCoReResearch research = new GCoReResearch();
 	 	try
	 	{
                        return research.getResearchList(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpResearch::getResearchList : " + e.getMessage());
	 		return null;
	 	}
	}

        public GCmResultSet getResearchInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoReResearch research = new GCoReResearch();

	 	try
	 	{
	 		return research.getResearchInfo(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpResearch::getResearchInfo : " + e.getMessage());
	 		return null;
	 	}
	}

        public GCmResultSet getUserList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoReResearch research = new GCoReResearch();

	 	try
	 	{
	 		return research.getUserList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpResearch::getUserCount : " + e.getMessage());
	 		return null;
	 	}
	}

         public GCmResultSet getResearchObject(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoReResearch research = new GCoReResearch();

	 	try
	 	{
	 		return research.getResearchObject(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpResearch::getResearchObject : " + e.getMessage());
	 		return null;
	 	}
	}

         public GCmResultSet getResearchObjectDetail(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoReResearch research = new GCoReResearch();

	 	try
	 	{
	 		return research.getResearchObjectDetail(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpResearch::getResearchObjectDetail : " + e.getMessage());
	 		return null;
	 	}
	}

        public GCmResultSet getUserName(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoReResearch research = new GCoReResearch();

	 	try
	 	{
	 		return research.getUserName(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpResearch::getUserName : " + e.getMessage());
	 		return null;
	 	}
	}

        public GCmResultSet getDelList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoReResearch research = new GCoReResearch();

	 	try
	 	{
	 		return research.getDelList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpResearch::getDelList : " + e.getMessage());
	 		return null;
	 	}
	}

        public GCmResultSet getSuggestion(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoReResearch research = new GCoReResearch();

	 	try
	 	{
	 		return research.getSuggestion(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpResearch::getSuggestion : " + e.getMessage());
	 		return null;
	 	}
	}

        public GCmResultSet getDelSubList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoReResearch research = new GCoReResearch();

	 	try
	 	{
	 		return research.getDelSubList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpResearch::getDelSubList : " + e.getMessage());
	 		return null;
	 	}
	}

         public GCmResultSet getDelUser(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoReResearch research = new GCoReResearch();

	 	try
	 	{
	 		return research.getDelUser(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpResearch::getDelUser : " + e.getMessage());
	 		return null;
	 	}
	}



         public int insertSuggestion(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoReResearchTran researchTran = new GCoReResearchTran();

	 	try
	 	{
	 		return researchTran.insertSuggestion(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" researchTran::insertSuggestion : " + e.getMessage());
	 		return -1;
	 	}
	}

         public int updateBoxNo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoReResearchTran researchTran = new GCoReResearchTran();

	 	try
	 	{
	 		return researchTran.updateBoxNo(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" researchTran::updateBoxNo : " + e.getMessage());
	 		return -1;
	 	}
	}

         public int updateDate(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoReResearchTran researchTran = new GCoReResearchTran();

	 	try
	 	{
	 		return researchTran.updateDate(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" researchTran::updateDate : " + e.getMessage());
	 		return -1;
	 	}
	}

         public int updateResearchMain(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoReResearchTran researchTran = new GCoReResearchTran();

	 	try
	 	{
	 		return researchTran.updateResearchMain(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" researchTran::updateResearchMain : " + e.getMessage());
	 		return -1;
	 	}
	}

         public int updateStatus(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoReResearchTran researchTran = new GCoReResearchTran();

	 	try
	 	{
	 		return researchTran.updateStatus(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" researchTran::updateStatus : " + e.getMessage());
	 		return -1;
	 	}
	}

        public int deleteQ10(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoReResearchTran researchTran = new GCoReResearchTran();

	 	try
	 	{
	 		return researchTran.deleteQ10(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" researchTran::deleteQ10 : " + e.getMessage());
	 		return -1;
	 	}
	}

        public int deleteQ20(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoReResearchTran researchTran = new GCoReResearchTran();

	 	try
	 	{
	 		return researchTran.deleteQ20(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" researchTran::deleteQ20 : " + e.getMessage());
	 		return -1;
	 	}
	}

        public int deleteQ30(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoReResearchTran researchTran = new GCoReResearchTran();

	 	try
	 	{
	 		return researchTran.deleteQ30(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" researchTran::deleteQ30 : " + e.getMessage());
	 		return -1;
	 	}
	}

        public int deleteQ11(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoReResearchTran researchTran = new GCoReResearchTran();

	 	try
	 	{
	 		return researchTran.deleteQ11(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" researchTran::deleteQ11 : " + e.getMessage());
	 		return -1;
	 	}
	}

        public int deleteQ12(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoReResearchTran researchTran = new GCoReResearchTran();

	 	try
	 	{
	 		return researchTran.deleteQ12(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" researchTran::deleteQ12 : " + e.getMessage());
	 		return -1;
	 	}
	}








}
