package gplus.template;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

import gplus.component.broadcast.*;

/**
 * <PRE>
 * Filename		: GTpBroadCast.java
 * Class		:
 * Function		:
 * Comment		:
 * History  : 26/03/2002, ���߱� �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GTpBroadCast
{
	 public GCmResultSet getLineInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoBroadCast broadcast = new GCoBroadCast();

	 	try
	 	{
	 		return broadcast.getLineInfo(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(" GTpBroadCast :: getLineInfo " + e.getMessage());
	 		return null;
	 	}

	}	// getDraftCount1 component call

	 public GCmResultSet getLineList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoBroadCast broadcast = new GCoBroadCast();

	 	try
	 	{
	 		return broadcast.getLineList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(" GTpBroadCast :: getLineList " + e.getMessage());
	 		return null;
	 	}

	}	// getDraftCount1 component call

	 public GCmResultSet getBroadUserList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoBroadCast broadcast = new GCoBroadCast();

	 	try
	 	{
	 		return broadcast.getBroadUserList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(" GTpBroadCast :: getBroadUserList " + e.getMessage());
	 		return null;
	 	}

	}	// getDraftCount1 component call


      public GCmResultSet getdupName(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoBroadCast broadcast = new GCoBroadCast();

	 	try
	 	{
	 		return broadcast.getdupName(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(" GTpBroadCast :: getdupName " + e.getMessage());
	 		return null;
	 	}

	}	// getDraftCount1 component call

	 public GCmResultSet getAllUserList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoBroadCast broadcast = new GCoBroadCast();

	 	try
	 	{
	 		return broadcast.getAllUserList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(" GTpBroadCast :: getAllUserList " + e.getMessage());
	 		return null;
	 	}

	}	// getDraftCount1 component call

	 public GCmResultSet getFindNameUsers(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoBroadCast broadcast = new GCoBroadCast();

	 	try
	 	{
	 		return broadcast.getFindNameUsers(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(" GTpBroadCast :: getFindNameUsers " + e.getMessage());
	 		return null;
	 	}

	}	// getDraftCount1 component call

	 public GCmResultSet getGrpCardList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoBroadCast broadcast = new GCoBroadCast();

	 	try
	 	{
	 		return broadcast.getGrpCardList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(" GTpBroadCast :: getGrpCardList " + e.getMessage());
	 		return null;
	 	}

	}	// getDraftCount1 component call

	 public GCmResultSet getNotGrpCardList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoBroadCast broadcast = new GCoBroadCast();

	 	try
	 	{
	 		return broadcast.getNotGrpCardList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.err.println(" GTpBroadCast :: getNotGrpCardList " + e.getMessage());
	 		return null;
	 	}

	}	// getDraftCount1 component call

       /**
        * <PRE>
        * ���޵� ��忡 ���� �������� ����Ѵ�. ��尡 d�̸� ���� �������� �����ϰ� ��尡 null�̸� �������� ����Ѵ�.
        * ��������ȣ�� ���Ͽ� ����/������ ����� �����Ѵ�. ��������ȣ�� null�� ��� deleteDraftSubLine,deleteDraftLine����
        * �������� �����ϰ� ��尡 d�� �ƴϸ� insertDraftLine���� �������� ����ϰ� insertSubDraftLine���� ��������
        * �������� ����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Mode : ��� (d:����, null:�Է�)
        *                      <LI> String Linenum : ��������ȣ
        *                      <LI> String Line2 : �������
        *                      <LI> String Line3 : �������
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int broadCastLineToDb(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoBroadCastTran broadcastTran = new GCoBroadCastTran();

	 	try
	 	{
	 		return broadcastTran.broadCastLineToDb(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpBroadCast::broadCastLineToDb : " + e.getMessage());
	 		return -1;
	 	}
	}

   	public int EMailInfoToDb(GCmProperties prop, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoBroadCastTran broadcastTran = new GCoBroadCastTran();
		String Mode = dmProp.getString("Mode");

        int rv = 0;

	 	try
	 	{
               if (!Mode.equals("d"))
               {
                    rv = broadcastTran.updateBroadList(prop, dmProp, msgInfo);
               }
               else
               {
                    rv = broadcastTran.deleteBroadList(prop, dmProp, msgInfo);
               }

               return rv;
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpBroadCast::EMailInfoToDb : " + e.getMessage());
	 		return -1;
	 	}
	}	// end component call
}