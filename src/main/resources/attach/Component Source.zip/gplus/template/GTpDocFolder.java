package gplus.template;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

import gplus.component.doc.*;

import com.jspsmart.upload.*;


/**
 * <PRE>
 * Filename		: GTpDoc.java
 * Class		: gplus.component.doc.GTpDoc
 * Function		:
 * Comment		:
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GTpDocFolder
{

    private String submenu = "";

       /**
        * <PRE>
        * ������ ������ ���޹޾� ������ �����ϱ� ������ �����ؾ� ��  ������  ������.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID :  ����� ���̵�
        * 		       <LI> String BOXNO :  �� ��ȣ
        *		       <LI> String FLDNO :  ����  ��ȣ
        *  		       <LI> String TARGET :  �̵��� ���� ��ȣ
        *  		       <LI> String PPATH :  ���α׷� ��ġ�Ȱ��
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        *
        */
   	public int getFldCopy(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoDoDocFolder doctran = new GCoDoDocFolder();

	 	try
	 	{

	 		return doctran.getFldCopy(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpDocFolder::getFldCopy : " + e.getMessage());
	 		return -1;
	 	}

	}	// end component call

       /**
        * <PRE>
        * ������ �̵��� ������ ���޹޾� ������ �̵���Ŵ.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : ����� ���̵�
        *                      <LI> String BOXNO : �� ��ȣ
        *                      <LI> String FLDNO : ����  ��ȣ        
        *                      <LI> String TARGET : �̵��� ���� ��ȣ
        *                      <LI> String PPATH : ���α׷� ��ġ�Ȱ��
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.      
        */

	public int getFldMove(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoDoDocFolder doctran = new GCoDoDocFolder();

	 	try
	 	{

	 		return doctran.getFldMove(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpDocFolder::getFldMove : " + e.getMessage());
	 		return -1;
	 	}

	}	// end component call


       /**
        * <PRE>
        *  ���� ���� ������ �̵��� ���� ���θ� ���޹޾� ���� ������ ������ �̵���. 
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID :  ����� ���̵�
        *                      <LI> String BOXNO :  �� ��ȣ
        *                      <LI> String FLDNO :  ���� ��ȣ
        *                      <LI> String PARENTNO :  ������ ��ȣ
        *                      <LI> String TARGET :  �̵��� ���� ��ȣ
        *                      <LI> String PPATH :  ���α׷� ��Ʈ ���丮 
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        */

 	public int getFldDocMove(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoDoDocFolderTran doctran = new GCoDoDocFolderTran();

	 	try
	 	{

	 		return doctran.getFldDocMove(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpDoc::getFldDocMove : " + e.getMessage());
	 		return -1;
	 	}

	}	// end component call


       /**
        * <PRE>
        *  ���� ���� ������ �̵��� ���� ���θ� ���޹޾� ���� ������ ������ ������. 
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : ����� ���̵�
        *                      <LI> String BOXNO : �� ��ȣ
        *                      <LI> String FLDNO : ���� ��ȣ
        *                      <LI> String PARENTNO: ������ ��ȣ
        *                      <LI> String TARGET : �̵��� ���� ��ȣ
        *                      <LI> String PPATH : ���α׷� ��Ʈ ���丮 
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        */

   	public int getFldDocCopy(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoDoDocFolderTran doctran = new GCoDoDocFolderTran();

	 	try
	 	{
	 		return doctran.getFldDocCopy(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpDoc::getFldDocCopy : " + e.getMessage());
	 		return -1;
	 	}

	}	// end component call

       /**
        * <PRE>
        *  ���� ������ ���޹޾� ���� ���� ��Ͽ� ���� ���� ������ ����.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE    : current user companycode at session        
        *                      <LI> String BOXNO      :  �� ��ȣ
        *                      <LI> String FLDNO      :  ���� ��ȣ
        *                      <LI> String FLDNAME    :  ���� �̸�
        *                      <LI> String COMMENTS   :  ����
        *                      <LI> String REGDATE    :  �����
        *                      <LI> String PARENTNO   :  ������ ��ȣ
        *                      <LI> String DOCNO      :  ������ȣ
        *                      <LI> String REGUSER    :  ����� 
        *                      <LI> String TRASHFLAG  :  ������
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        */
   	public int updateFolderEdit(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoDoDocFolderTran doctran = new GCoDoDocFolderTran();

	 	try
	 	{
	 		return doctran.updateFolderEdit(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpDoc::updateFolderEdit : " + e.getMessage());
	 		return -1;
	 	}

	}	// end component call


       /**
        * <PRE>
        *  ���� ������ ���޹޾� ���� ���� ��Ͽ��� FLDNAME�� FLDNO ���� ���� ������ ����.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE    : current user companycode at session
        *                      <LI> String FLDNO      :  ���� ��ȣ
        *                      <LI> String FLDNAME    :  ���� �̸�
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        */

	public int updateFolder(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoDoDocFolderTran doctran = new GCoDoDocFolderTran();

	 	try
	 	{
	 		return doctran.updateFolder(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpDoc::updateFolder : " + e.getMessage());
	 		return -1;
	 	}

	}	// end component call

       /**
        * <PRE>
        *  ���� ������ ���޹޾� ���� �� ���( L11 ) , �������( L10 ) , �����������( B10 ) 
		*  �� ���Ѱ� ����.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE :  current user companycode at session
        *                      <LI> String USERID :  ����� ���̵�
        *                      <LI> String BOXNO :  �� ��ȣ
        *                      <LI> String FLDNO :  ���� ��ȣ
        *                      <LI> String PPATH :  ���α׷� ��ġ���
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        */

	public int deleteFolder(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoDoDocFolderTran doctran = new GCoDoDocFolderTran();

	 	try
	 	{
	 		return doctran.deleteFolder(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpDoc::deleteFolder : " + e.getMessage());
	 		return -1;
	 	}

	}	// end component call


       /**
        * <PRE>
        *  ���� ������ ���޹޾� ���� �� ���( L11 ) , �������( L10 ) , �����������( B10 ) 
        *  �� ���Ѱ��� ���� �Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE    : current user companycode at session
        *                      <LI> String USERID     :  ����� ���̵�
        *                      <LI> String FLDNO      :  ���� ��ȣ
        *                      <LI> String PPATH      :  ���α׷� ��ġ ��� 
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        */

	public int deleteList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoDoDocFolderTran doctran = new GCoDoDocFolderTran();

	 	try
	 	{
	 		return doctran.deleteList(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpDoc::deleteList : " + e.getMessage());
	 		return -1;
	 	}

	}	// end component call


       /**
        * <PRE>
        * �Թ�ȣ�� ������ ��ȣ�� ���޹޾� ���� ������ ������ȣ�� �����̸��� ������.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String BOXNO :  �� ��ȣ
        *                      <LI> String ROOTNO : ������ ��ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.   
        * @return          GCmResultSet : FLDNO,FLDNAME
        */

	public GCmResultSet getFindFldno(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

	 	GCoDoDocFolder docfolder = new GCoDoDocFolder();

	 	try
	 	{
	 		return docfolder.getFindFldno(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpDocFolder::getFindFldno : " + e.getMessage());
	 		return null;
	 	}

	}


       /**
        * <PRE>
        *  ���޵� ������ ���� ���õ� ������ ���丮 ������ �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session   
        *                      <LI> String USERID : ����� ���̵�
        *                      <LI> String Boxno : �� ��ȣ
        *                      <LI> String Fldno :  ���� ��ȣ
        *                      <LI> String Boxname : �� �̸�
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.   
        * @return          GCmResultSet : A.BOXNO,A.BOXNAME,A.BOXTYPE,B.DOCREAD,B.DOCWRITE,C.FLDNAME,C.FLDNO
        *                                 
        */
	public String getFldnoPath(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

	 	GCoDoDocFolder docfolder = new GCoDoDocFolder();

	 	try
	 	{
	 		return docfolder.getFldnoPath(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpDocFolder::getFldnoPath : " + e.getMessage());
	 		return null;
	 	}

	}

       /**
        * <PRE>
        * �Թ�ȣ�� ������ ��ȣ�� ���޹޾� �� ���Ͽ��� �Թ�ȣ�� ���̸��� ������.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String BOXNO : �� ��ȣ
        *                      <LI> String ROOTNO : ������ ��ȣ
        *                      <LI> String BOXCLASS : �� ����
        *                      <LI> String BOXTYPE : �� ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.   
        * @return          GCmResultSet : BOXNO, BOXNAME
        *
        */
	public GCmResultSet getFindBoxno(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoDoDocFolder doc = new GCoDoDocFolder();

	 	try
	 	{
	 		return doc.getFindBoxno(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpDocFolder :: getFindBoxno: " + e.getMessage());
	 		return null;
	 	}

	}	// end component call


       /**
        * <PRE>
        *  ���޵� �Թ�ȣ�� ���õ� ������ Ʈ���������� �׷� ��.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Boxno : �� ��ȣ        
        *                      <LI> String rootno : ����������ȣ 
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.   
        * @return          GCmResultSet :  Tree
        */
	public String getDrawDocFolderTree(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

	 		GCoDoDocFolder folder = new GCoDoDocFolder();
	 		String retTree = "";

	 	try
	 	{



	 		GCmResultSet rsTree = folder.getDrawDocFolderTree(cp, dmProp, msgInfo);
	 		String menuview = dmProp.getString("menuview");
	 		String linkImage = dmProp.getString("linkImage");

	 		int count = 1;
	 		while (rsTree.next())
	 		{
	 		      retTree += "<DIV ID=idF>";
                              retTree += linkImage;
                              retTree += ("<IMG ID=idE" + rsTree.getString("FLDNO") + " align=absmiddle width=19 height=16>");
                              retTree += ("<IMG ID=idE" + rsTree.getString("FLDNO") + " align=absmiddle width=19 height=16>");
                              retTree += ("<A ID=idA" + rsTree.getString("FLDNO") + " href=\"JavaScript:");

                              if (menuview != null && menuview.equals("YES"))
                              {
                                    retTree += ("selectFld('" + rsTree.getString("FLDNO") + "','" + rsTree.getString("BOXNO") + "')"+";\""+" oncontextmenu=\"showMenu('" + rsTree.getString("FLDNO") + "','" + rsTree.getString("BOXNO") + "'); return event.ctrlKey;\"");


                              }
                              else
                              {
                              	    retTree += ("selectFld('" + rsTree.getString("FLDNO") + "')"+ ";\"");
                              }

                              retTree += (" parentno=\"" + dmProp.getString("rootno") + "\">" + rsTree.getString("FLDNAME") + "</A>");
                              retTree += ("</DIV>");
                              retTree += ("<DIV ID=idL style=display:none>");

                              dmProp.setProperty("rootno",rsTree.getString("FLDNO"));
                              dmProp.setProperty("Boxno",rsTree.getString("BOXNO"));
                              dmProp.setProperty("linkImage",linkImage+"<IMG ID=img_linkspace align=absmiddle width=19 height=16>");

                              retTree += getDrawDocFolderTree(cp,dmProp,msgInfo);

                              retTree += ("</DIV>");


	 		      count++;
 			  }
 			  return retTree;
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpDocFolder::getDrawDocFolderTree : " + e.getMessage());
	 		return null;
	 	}

	}	// end component call


       /**
        * <PRE>
        *  ���޵� ���ǿ� ���� ���� ����� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String PARENTNO : ���� ������ȣ
        *                      <LI> String SORTID : ���� ���� �ܾ�
        *                      <LI> String SORTOPT : ���� ����
        *                      <LI> String OPT : �˻� ����
        *                      <LI> String Q : �˻� ���� �ܾ�
        *                      <LI> String SDATE : ������ 
        *                      <LI> String LDATE : ������
        *                      <LI> String CURPAGE : ���� ������
        *                      <LI> String PAGESIZE : �� ������
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.   
        * @return          GCmResultSet :  
        */
	public GCmResultSet getFldDocList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
                GCoDoDocFolder doc = new GCoDoDocFolder();

	 	try
	 	{
                        return doc.getFldDocList(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpDocFolder::getFldDocList : " + e.getMessage());
	 		return null;
	 	}
        }


       /**
        * <PRE>
        *  ���޵� ���ǿ� ���� �Ǽ��� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String PARENTNO : ������ ��ȣ
        *                      <LI> String OPT :  �˻� ����
        *                      <LI> String Q :  �˻� ���� �ܾ�
        *                      <LI> String SDATE : ���� �ð�
        *                      <LI> String LDATE : ���� �ð�
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.   
        * @return          GCmResultSet :  Tree
        */

	public GCmResultSet getRecordCount(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoDoDocFolder doc = new GCoDoDocFolder();

	 	try
	 	{
	 		return doc.getRecordCount(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpDocFolder :: getRecordCount: " + e.getMessage());
	 		return null;
	 	}

	}	// end component call



       /**
        * <PRE>
        *  ���޵� �������� ���� �Թ�ȣ�� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String ROOTNO : �����Թ�ȣ
        *                      <LI> String BOXCLASS : �� ����
        *                      <LI> String BOXTYPE : �� ����
        *                      <LI> String USERID : ����� ���̵�

        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.   
        * @return          GCmResultSet : BOXNO
        *                                 
        */

	public GCmResultSet getFindUserBoxno(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoDoDocFolder doc = new GCoDoDocFolder();

	 	try
	 	{
	 		return doc.getFindUserBoxno(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpDocFolder :: getFindUserBoxno: " + e.getMessage());
	 		return null;
	 	}

	}	// end component call

       /**
        * <PRE>
        *  ���޵� ����ڿ� ����  ���õ� �������� ����Ʈ �Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session   
        *                      <LI> String USERID : ����� ���̵�
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.   
        * @return          GCmResultSet : A.BOXNO,A.BOXNAME,A.BOXTYPE,B.DOCREAD,B.DOCWRITE,C.FLDNAME,C.FLDNO
        *                                 
        */


	public GCmResultSet getFldBoxList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoDoDocFolder doc = new GCoDoDocFolder();

	 	try
	 	{
	 		return doc.getFldBoxList(cp, dmProp, msgInfo);

	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpDocFolder :: getFldBoxList: " + e.getMessage());
	 		return null;
	 	}

	}	// end component call


       /**
        * <PRE>
        *  ���޵� �Թ�ȣ�� ���� �������� ����� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String BOXNO : �� ��ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.   
        * @return          GCmResultSet : FLDNO,BOXNO,DOCNO,PARENTNO,FLDNAME,REGUSER,REGDATE,
        *                                 TRASHFLAG,COMMENTS,REFNO
        */

	public GCmResultSet getFldInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
	 	GCoDoDocFolder doc = new GCoDoDocFolder();

	 	try
	 	{
	 		return doc.getFldInfo(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpDocFolder :: getFldInfo: " + e.getMessage());
	 		return null;
	 	}

	 }	// end component call

       /**
        * <PRE>
        *  ���޵� ������ȣ�� ����������ȣ�� ���� ����Ʈ���� ���� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String BOXNO : �� ��ȣ
        *                      <LI> String ROOTFLDNO : ���� ������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.   
        * @return          GCmResultSet : Tree
        */
	public String getDrawTree(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoDoDocFolder doc = new GCoDoDocFolder();
                String retTree = "";

	 	try
	 	{
	 		GCmResultSet rsTree = doc.getDrawTree(cp, dmProp, msgInfo);
 		        String linkImage = dmProp.getString("linkImage");
 		        String menuview = dmProp.getString("menuview");

	 		int count = 1;
	 		while (rsTree.next())
	 		{
	 		      retTree += "<DIV ID=idF>";
                              retTree += linkImage;
                              retTree += ("<IMG ID=idE" + rsTree.getString("FLDNO") + " align=absmiddle width=19 height=16>");
                              retTree += ("<IMG ID=idE" + rsTree.getString("FLDNO") + " align=absmiddle width=19 height=16>");
                              retTree += ("<A ID=idA" + rsTree.getString("FLDNO") + " href=\"JavaScript:selectOrg('" + rsTree.getString("FLDNO") + "');\"");
                              if (menuview != null && menuview.equals("YES")) {
                                    retTree += (" oncontextmenu=\"showMenu('" + rsTree.getString("FLDNO") + "'); return event.ctrlKey;\"");
                              }
                              retTree += (">" + rsTree.getString("FLDNAME") + "</A>");
                              retTree += ("</DIV>");
                              retTree += ("<DIV ID=idL style=display:none>");

                           if( count == rsTree.getRowCount())
                           {
       						  dmProp.setProperty("rootno",rsTree.getString("FLDNO"));
       						  dmProp.setProperty("linkImage",linkImage+"<IMG ID=img_linkspace align=absmiddle width=19 height=16>");

                               retTree += getDrawTree(cp,dmProp,msgInfo);
                           }
                           else
                           {
       						    dmProp.setProperty("rootno",rsTree.getString("FLDNO"));
       						    dmProp.setProperty("linkImage",linkImage+"<IMG ID=img_linknon align=absmiddle width=19 height=16>");

                               retTree += getDrawTree(cp,dmProp,msgInfo);
                           }

                           retTree += ("</DIV>");
	 		   count++;
 			}
 			return retTree;
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpDoc::getDrawTree : " + e.getMessage());
	 		return null;
	 	}

	}	// end component call


       /**
        * <PRE>
        *  ���� ������ ���޹޾�  �����������( B10 )�� ���Ѱ��� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE    : current user companycode at session
        *                      <LI> String Userno     :  ����� ���̵�
        *                      <LI> String Boxno      :  �Թ�ȣ
        *                      <LI> String Docno      :  ������ȣ
        *                      <LI> String Parentno   :  ����������ȣ
        *                      <LI> String Boxname    :  ���̸�
        *                      <LI> String Regdate    :  �����
        *                      <LI> String Trashflag  :  ������
        *                      <LI> String Comments   :  ����
        *                      <LI> String Refno      :  ���ù�ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        */


	public int insertFolder(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCoDoDocFolderTran doctran = new GCoDoDocFolderTran();

	 	try
	 	{
	 		return doctran.insertFolder(cp, dmProp, msgInfo);
	 	}
	 	catch (Exception e)
	 	{
	 		System.out.println(" GTpDoc::insertFolder : " + e.getMessage());
	 		return -1;
	 	}

	}	// end component call



}