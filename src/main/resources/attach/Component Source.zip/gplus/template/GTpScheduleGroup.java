package gplus.template;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

import gplus.component.pims.*;

/**
 * <PRE>
 * Filename		: GTpScheduleGroup.java
 * Class		:
 * Function		:
 * Comment		:
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GTpScheduleGroup
{

       /**
        * <PRE>
        * ����ڿ� ���� �׷����� ����Ʈ.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : ����� ���̵�        
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
     public GCmResultSet getScheduleGroupList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
     {
		 GCoPiScheduleGroup schdlgroup = new GCoPiScheduleGroup();

		 try
		 {
			 return schdlgroup.getScheduleGroupList(cp, dmProp, msgInfo);
		 }
		 catch (Exception e)
		 {
			 System.out.println(" GTpSchdl::getPosCodeList: " + e.getMessage());
			 return null;
		 }

      }	// end component call


       /**
        * <PRE>
        * ����ڿ� ���� �׷�����.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : ����� ���̵�        
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
      public GCmResultSet getScheduleGroupInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
      {
		 GCoPiScheduleGroup schdlgroup = new GCoPiScheduleGroup();

		 try
		 {
		 	return schdlgroup.getScheduleGroupInfo(cp, dmProp, msgInfo);
		 }
		 catch (Exception e)
		 {
		 	System.out.println(" GTpSchdl::getPosCodeList: " + e.getMessage());
		 	return null;
		 }

	   }	// end component call



       /**
        * <PRE>
        * ���������� ��Ͽ� �ش� ������� ������ ����, ���, ������Ʈ �Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> Mode d ���� 
        *                      <LI> Mode s �űԵ��
        *                      <LI> Mode u  ������Ʈ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */

     public int GrpManager(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
     {
		  int rv = 0;
	
		  GCoPiScheduleGroupTran schdlgroupTran = new GCoPiScheduleGroupTran();

		  String Mode = dmProp.getString("Mode");

	  try
	  {
                if (Mode.equals("d")) { // ����...
                      rv = schdlgroupTran.deleteScheduleGroup(cp, dmProp, msgInfo);
                }
                else if (Mode.equals("s")) { // �űԵ��...
                          rv = schdlgroupTran.insertScheduleGroup(cp, dmProp, msgInfo);
                     }
                     else if (Mode.equals("u")) { // update�� ���...
                              rv = schdlgroupTran.updateScheduleGroup(cp, dmProp, msgInfo);
                     }
	  }
	  catch (Exception e)
	  {
	       System.out.println(" GTpSchdl::getPosCodeList: " + e.getMessage());
	       rv = -1;
	  }

	 return rv;
    }	// end component call

}	// end GTpLogin