package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_Z10.java
 * Class    : GEmTB_Z10
 * Function : Data model of representing parameter data for TB_COMM_Z10 Table
 * Comment  : table : TB_COMM_Z10
 * History  : 
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_Z10 {

    private String m_strComCode = null;
    private String m_strComName = null;
    private String m_strChkFileDate = null;
    private String m_strChkFileInt = null;
    private String m_strLmtFileSize = null;
    private String m_strCurFileSize = null;
    private String m_strDocRead = null;
    private String m_strDocWrite = null;
    private String m_strDocDel = null;
    private String m_strFldMake = null;
    private String m_strFldDel = null;
    private String m_strBrdRead = null;
    private String m_strBrdWrite = null;
    private String m_strBrdDel = null;
    private String m_strChkAlarmInt = null;
    private String m_strMaxNotiTab = null;
    private String m_strMaxNotiLvl = null;
    private String m_strMailSvr = null;
    private String m_strSmtpSvr = null;
    private String m_strDefltEmail = null;
    private String m_strMaxUser = null;
    private String m_strAddr = null;
    private String m_strTel = null;
    private String m_strFax = null;
    private String m_strCeo = null;
    private String m_strManager = null;

    public String getStrComCode() { return m_strComCode; }
    public String getStrComName() { return m_strComName; }
    public String getStrChkFileDate() { return m_strChkFileDate; }
    public String getStrChkFileInt() { return m_strChkFileInt; }
    public String getStrLmtFileSize() { return m_strLmtFileSize; }
    public String getStrCurFileSize() { return m_strCurFileSize; }
    public String getStrDocRead() { return m_strDocRead; }
    public String getStrDocWrite() { return m_strDocWrite; }
    public String getStrDocDel() { return m_strDocDel; }
    public String getStrFldMake() { return m_strFldMake; }
    public String getStrFldDel() { return m_strFldDel; }
    public String getStrBrdRead() { return m_strBrdRead; }
    public String getStrBrdWrite() { return m_strBrdWrite; }
    public String getStrBrdDel() { return m_strBrdDel; }
    public String getStrChkAlarmInt() { return m_strChkAlarmInt; }
    public String getStrMaxNotiTab() { return m_strMaxNotiTab; }
    public String getStrMaxNotiLvl() { return m_strMaxNotiLvl; }
    public String getStrMailSvr() { return m_strMailSvr; }
    public String getStrSmtpSvr() { return m_strSmtpSvr; }
    public String getStrstrDefltEmail() { return m_strDefltEmail; }
    public String getStrMaxUser() { return m_strMaxUser; }
    public String getStrAddr() { return m_strAddr; }
    public String getStrTel() { return m_strTel; }
    public String getStrFax() { return m_strFax; }
    public String getStrCeo() { return m_strCeo; }
    public String getStrManager() { return m_strManager; }

    public void setStrComCode(String s) { m_strComCode = s; }
    public void setStrComName(String s) { m_strComName = s; }
    public void setStrChkFileDate(String s) { m_strChkFileDate = s; }
    public void setStrChkFileInt(String s) { m_strChkFileInt = s; }
    public void setStrLmtFileSize(String s) { m_strLmtFileSize = s; }
    public void setStrCurFileSize(String s) { m_strCurFileSize = s; }
    public void setStrDocRead(String s) { m_strDocRead = s; }
    public void setStrDocWrite(String s) { m_strDocWrite = s; }
    public void setStrDocDel(String s) { m_strDocDel = s; }
    public void setStrFldMake(String s) { m_strFldMake = s; }
    public void setStrFldDel(String s) { m_strFldDel = s; }
    public void setStrBrdRead(String s) { m_strBrdRead = s; }
    public void setStrBrdWrite(String s) { m_strBrdWrite = s; }
    public void setStrBrdDel(String s) { m_strBrdDel = s; }
    public void setStrChkAlarmInt(String s) { m_strChkAlarmInt = s; }
    public void setStrMaxNotiTab(String s) { m_strMaxNotiTab = s; }
    public void setStrMaxNotiLvl(String s) { m_strMaxNotiLvl = s; }
    public void setStrMailSvr(String s) { m_strMailSvr = s; }
    public void setStrSmtpSvr(String s) { m_strSmtpSvr = s; }
    public void setStrDefltEmail(String s) { m_strDefltEmail = s; }
    public void setStrMaxUser(String s) { m_strMaxUser = s; }
    public void setStrAddr(String s) { m_strAddr = s; }
    public void setStrTel(String s) { m_strTel = s; }
    public void setStrFax(String s) { m_strFax = s; }
    public void setStrCeo(String s) { m_strCeo = s; }
    public void setStrManager(String s) { m_strManager = s; }
}

