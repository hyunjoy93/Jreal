package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_M10.java
 * Class    : GEmTB_M10
 * Function : Data model of representing parameter data for TB_COMCODE_M10 Table
 * Comment  : table : TB_COMCODE_M10
 * History  : 
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_M10 {

    private String m_strBoxNo = null;
    private String m_strIconNo = null;
    private String m_strBoxName = null;
    private String m_strParentNo = null;
    private String m_strBoxClass = null;
    private String m_strExecClass = null;
    private String m_strRegUser = null;
    private String m_strRegDate = null;
    private String m_strBoxType = null;
    private String m_strBaseFlag = null;
    private String m_strPubFlag = null;
    private String m_strExecFlag = null;
    private String m_strUserId = null;

    public String getStrBoxNo() { return m_strBoxNo; }
    public String getStrIconNo() { return m_strIconNo; }
    public String getStrBoxName() { return m_strBoxName; }
    public String getStrParentNo() { return m_strParentNo; }
    public String getStrBoxClass() { return m_strBoxClass; }
    public String getStrExecClass() { return m_strExecClass; }
    public String getStrRegUser() { return m_strRegUser; }
    public String getStrRegDate() { return m_strRegDate; }
    public String getStrBoxType() { return m_strBoxType; }
    public String getStrBaseFlag() { return m_strBaseFlag; }
    public String getStrPubFlag() { return m_strPubFlag; }
    public String getStrExecFlag() { return m_strExecFlag; }
    public String getStrUserId() { return m_strUserId; }

    public void setStrBoxNo(String s) { m_strBoxNo = s; }
    public void setStrIconNo(String s) { m_strIconNo = s; }
    public void setStrBoxName(String s) { m_strBoxName = s; }
    public void setStrParentNo(String s) { m_strParentNo = s; }
    public void setStrBoxClass(String s) { m_strBoxClass = s; }
    public void setStrExecClass(String s) { m_strExecClass = s; }
    public void setStrRegUser(String s) { m_strRegUser = s; }
    public void setStrRegDate(String s) { m_strRegDate = s; }
    public void setStrBoxType(String s) { m_strBoxType = s; }
    public void setStrBaseFlag(String s) { m_strBaseFlag = s; }
    public void setStrPubFlag(String s) { m_strPubFlag = s; }
    public void setStrExecFlag(String s) { m_strExecFlag = s; }
    public void setStrUserId(String s) { m_strUserId = s; }
}