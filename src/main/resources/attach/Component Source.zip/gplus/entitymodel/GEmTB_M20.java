package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_M20.java
 * Class    : GEmTB_M20
 * Function : Data model of representing parameter data for TB_COMCODE_M20 Table
 * Comment  : table : TB_COMCODE_M20
 * History  : 
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_M20 {

    private String m_strBoxNo = null;
    private String m_strUserId = null;
    private String m_strDocRead = null;
    private String m_strDocWrite = null;
    private String m_strDocDel = null;
    private String m_strDocDelAdm = null;
    private String m_strFldMake = null;
    private String m_strFldDel = null;

    public String getStrBoxNo() { return m_strBoxNo; }
    public String getStrUserId() { return m_strUserId; }
    public String getStrDocRead() { return m_strDocRead; }
    public String getStrDocWrite() { return m_strDocWrite; }
    public String getStrDocDel() { return m_strDocDel; }
    public String getStrDocDelAdm() { return m_strDocDelAdm; }
    public String getStrFldMake() { return m_strFldMake; }
    public String getStrFldDel() { return m_strFldDel; }

    public void setStrBoxNo(String s) { m_strBoxNo = s; }
    public void setStrUserId(String s) { m_strUserId = s; }
    public void setStrDocRead(String s) { m_strDocRead = s; }
    public void setStrDocWrite(String s) { m_strDocWrite = s; }
    public void setStrDocDel(String s) { m_strDocDel = s; }
    public void setStrDocDelAdm(String s) { m_strDocDelAdm = s; }
    public void setStrFldMake(String s) { m_strFldMake = s; }
    public void setStrFldDel(String s) { m_strFldDel = s; }
}
