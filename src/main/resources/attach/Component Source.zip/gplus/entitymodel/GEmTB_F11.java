package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_F11.java
 * Class    : GEmTB_F11
 * Function : Data model of representing parameter data for TB_COMCODE_F11 Table
 * Comment  : table : TB_COMCODE_F11
 * History  : 
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_F11 {

    private String m_strCardNo = null;
    private String m_strMeetNo = null;
    private String m_strUserId = null;
    private String m_strMeetDate = null;
    private String m_strComments = null;

    public String getStrCardNo() { return m_strCardNo; }
    public String getStrMeetNo() { return m_strMeetNo; }
    public String getStrUserId() { return m_strUserId; }
    public String getStrMeetDate() { return m_strMeetDate; }
    public String getStrComments() { return m_strComments; }

    public void setStrCardNo(String s) { m_strCardNo = s; }
    public void setStrMeetNo(String s) { m_strMeetNo = s; }
    public void setStrUserId(String s) { m_strUserId = s; }
    public void setStrMeetDate(String s) { m_strMeetDate = s; }
    public void setStrComments(String s) { m_strComments = s; }
}
