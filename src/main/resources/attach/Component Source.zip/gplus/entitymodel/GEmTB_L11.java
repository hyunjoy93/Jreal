package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_L11.java
 * Class    : GEmTB_L11
 * Function : Data model of representing parameter data for TB_COMCODE_L11 Table
 * Comment  : table : TB_COMCODE_L11
 * History  : 
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_L11 {

    private String m_strDocNo = null;
    private String m_strSeq = null;
    private String m_strContType = null;
    private String m_strTitle = null;
    private String m_strFileExt = null;
    private String m_strFileName = null;
    private String m_strVPath = null;
    private String m_strMimeType = null;
    private String m_strFileSize = null;
    private String m_strOrgName = null;
    private String m_strOrgPath = null;
    private String m_strRegUser = null;
    private String m_strRegDate = null;
    private String m_strModUser = null;
    private String m_strModDate = null;

    public String getStrDocNo() { return m_strDocNo; }
    public String getStrSeq() { return m_strSeq; }
    public String getStrContType() { return m_strContType; }
    public String getStrTitle() { return m_strTitle; }
    public String getStrFileExt() { return m_strFileExt; }
    public String getStrFileName() { return m_strFileName; }
    public String getStrVPath() { return m_strVPath; }
    public String getStrMimeType() { return m_strMimeType; }
    public String getStrFileSize() { return m_strFileSize; }
    public String getStrOrgName() { return m_strOrgName; }
    public String getStrOrgPath() { return m_strOrgPath; }
    public String getStrRegUser() { return m_strRegUser; }
    public String getStrRegDate() { return m_strRegDate; }
    public String getStrModUser() { return m_strModUser; }
    public String getStrModDate() { return m_strModDate; }

    public void setStrDocNo(String s) { m_strDocNo = s; }
    public void setStrSeq(String s) { m_strSeq = s; }
    public void setStrContType(String s) { m_strContType = s; }
    public void setStrTitle(String s) { m_strTitle = s; }
    public void setStrFileExt(String s) { m_strFileExt = s; }
    public void setStrFileName(String s) { m_strFileName = s; }
    public void setStrVPath(String s) { m_strVPath = s; }
    public void setStrMimeType(String s) { m_strMimeType = s; }
    public void setStrFileSize(String s) { m_strFileSize = s; }
    public void setStrOrgName(String s) { m_strOrgName = s; }
    public void setStrOrgPath(String s) { m_strOrgPath = s; }
    public void setStrRegUser(String s) { m_strRegUser = s; }
    public void setStrRegDate(String s) { m_strRegDate = s; }
    public void setStrModUser(String s) { m_strModUser = s; }
    public void setStrModDate(String s) { m_strModDate = s; }
}