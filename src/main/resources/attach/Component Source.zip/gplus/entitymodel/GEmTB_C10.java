package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_C10.java
 * Class    : GEmTB_C10
 * Function : Data model of representing parameter data for TB_COMCODE_C10 Table
 * Comment  : table : TB_COMCODE_C10
 * History  :
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_C10 {

    private String m_strMailNo = null;
    private String m_strMailType = null;
    private String m_strDocNo = null;
    private String m_strSendType = null;
    private String m_strTitle = null;
    private String m_strRegDate = null;
    private String m_strDlvrType = null;
    private String m_strSndrId = null;
    private String m_strSndrName = null;
    private String m_strToId = null;
    private String m_strToName = null;
    private String m_strCcId = null;
    private String m_strCcName = null;
    private String m_strBccId = null;
    private String m_strBccName = null;
    private String m_strAttNum = null;
    private String m_strRcvrNum = null;
    private String m_strReadNum = null;

    public String getStrMailNo() { return m_strMailNo; }
    public String getStrMailType() { return m_strMailType; }
    public String getStrDocNo() { return m_strDocNo; }
    public String getStrSendType() { return m_strSendType; }
    public String getStrTitle() { return m_strTitle; }
    public String getStrRegDate() { return m_strRegDate; }
    public String getStrDlvrType() { return m_strDlvrType; }
    public String getStrSndrId() { return m_strSndrId; }
    public String getStrSndrName() { return m_strSndrName; }
    public String getStrToId() { return m_strToId; }
    public String getStrToName() { return m_strToName; }
    public String getStrCcId() { return m_strCcId; }
    public String getStrCcName() { return m_strCcName; }
    public String getStrBccId() { return m_strBccId; }
    public String getStrBccName() { return m_strBccName; }
    public String getStrAttNum() { return m_strAttNum; }
    public String getStrRcvrNum() { return m_strRcvrNum; }
    public String getStrReadNum() { return m_strReadNum; }

    public void setStrMailNo(String s) { m_strMailNo = s; }
    public void setStrMailType(String s) { m_strMailType = s; }
    public void setStrDocNo(String s) { m_strDocNo = s; }
    public void setStrSendType(String s) { m_strSendType = s; }
    public void setStrTitle(String s) { m_strTitle = s; }
    public void setStrRegDate(String s) { m_strRegDate = s; }
    public void setStrDlvrType(String s) { m_strDlvrType = s; }
    public void setStrSndrId(String s) { m_strSndrId = s; }
    public void setStrSndrName(String s) { m_strSndrName = s; }
    public void setStrToId(String s) { m_strToId = s; }
    public void setStrToName(String s) { m_strToName = s; }
    public void setStrCcId(String s) { m_strCcId = s; }
    public void setStrCcName(String s) { m_strCcName = s; }
    public void setStrBccId(String s) { m_strBccId = s; }
    public void setStrBccName(String s) { m_strBccName = s; }
    public void setStrAttNum(String s) { m_strAttNum = s; }
    public void setStrRcvrNum(String s) { m_strRcvrNum = s; }
    public void setStrReadNum(String s) { m_strReadNum = s; }
}
