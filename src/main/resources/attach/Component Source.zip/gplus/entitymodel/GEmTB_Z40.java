package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_Z40.java
 * Class    : GEmTB_Z40
 * Function : Data model of representing parameter data for TB_COMM_Z40 Table
 * Comment  : table : TB_COMM_Z40
 * History  : 
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_Z40 {

    private String m_strUserId = null;
    private String m_strLogInDt = null;
    private String m_strRemoteAddr = null;
    private String m_strRemoteHost = null;
    private String m_strRemoteUser = null;
    private String m_strUserAgent = null;
    private String m_strLogOutDt = null;

    public String getStrUserId() { return m_strUserId; }
    public String getStrLogInDt() { return m_strLogInDt; }
    public String getStrRemoteAddr() { return m_strRemoteAddr; }
    public String getStrRemoteHost() { return m_strRemoteHost; }
    public String getStrRemoteUser() { return m_strRemoteUser; }
    public String getStrUserAgent() { return m_strUserAgent; }
    public String getStrLogOutDt() { return m_strLogOutDt; }

    public void setStrUserId(String s) { m_strUserId = s; }
    public void setStrLogInDt(String s) { m_strLogInDt = s; }
    public void setStrRemoteAddr(String s) { m_strRemoteAddr = s; }
    public void setStrRemoteHost(String s) { m_strRemoteHost = s; }
    public void setStrRemoteUser(String s) { m_strRemoteUser = s; }
    public void setStrUserAgent(String s) { m_strUserAgent = s; }
    public void setStrLogOutDt(String s) { m_strLogOutDt = s; }
}