package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_D20.java
 * Class    : GEmTB_D20
 * Function : Data model of representing parameter data for TB_COMCODE_D20 Table
 * Comment  : table : TB_COMCODE_D20 
 * History  : 
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_D20 {

    private String m_strRegDrftNo = null;
    private String m_strBoxNo = null;
    private String m_strDrftNo = null;
    private String m_strReadType = null;
    private String m_strReadFlag = null;
    private String m_strTrashFlag = null;
    private String m_strRefType = null;

    public String getStrRegDrftNo() { return m_strRegDrftNo; }
    public String getStrBoxNo() { return m_strBoxNo; }
    public String getStrDrftNo() { return m_strDrftNo; }
    public String getStrReadType() { return m_strReadType; }
    public String getStrReadFlag() { return m_strReadFlag; }
    public String getStrTrashFlag() { return m_strTrashFlag; }
    public String getStrRefType() { return m_strRefType; }

    public void setStrRegDrftNo(String s) { m_strRegDrftNo = s; }
    public void setStrBoxNo(String s) { m_strBoxNo = s; }
    public void setStrDrftNo(String s) { m_strDrftNo = s; }
    public void setStrReadType(String s) { m_strReadType = s; }
    public void setStrReadFlag(String s) { m_strReadFlag = s; }
    public void setStrTrashFlag(String s) { m_strTrashFlag = s; }
    public void setStrRefType(String s) { m_strRefType = s; }
}
