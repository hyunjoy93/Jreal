package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_C30.java
 * Class    : GEmTB_C30
 * Function : Data model of representing parameter data for TB_COMCODE_C30 Table
 * Comment  : table : TB_COMCODE_C30 
 * History  : 
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_C30 {

    private String m_strEmail = null;
    private String m_strUserId = null;
    private String m_strAcctName = null;
    private String m_strSmtpId = null;
    private String m_strSmtpSvr = null;
    private String m_strSmtpType = null;
    private String m_strPop3Svr = null;
    private String m_strSmtpPwd = null;
    private String m_strPop3Type = null;
    private String m_strDeflt = null;
    private String m_strSndrName = null;
    private String m_strPop3Id = null;
    private String m_strPop3Pwd = null;
    private String m_strSysFlag = null;
    private String m_strDelFlag = null;

    public String getStrEmail() { return m_strEmail; }
    public String getStrUserId() { return m_strUserId; }
    public String getStrAcctName() { return m_strAcctName; }
    public String getStrSmtpId() { return m_strSmtpId; }
    public String getStrSmtpSvr() { return m_strSmtpSvr; }
    public String getStrSmtpType() { return m_strSmtpType; }
    public String getStrPop3Svr() { return m_strPop3Svr; }
    public String getStrSmtpPwd() { return m_strSmtpPwd; }
    public String getStrPop3Type() { return m_strPop3Type; }
    public String getStrDeflt() { return m_strDeflt; }
    public String getStrSndrName() { return m_strSndrName; }
    public String getStrPop3Id() { return m_strPop3Id; }
    public String getStrPop3Pwd() { return m_strPop3Pwd; }
    public String getStrSysFlag() { return m_strSysFlag; }
    public String getStrDelFlag() { return m_strDelFlag; }

    public void setStrEmail(String s) { m_strEmail = s; }
    public void setStrUserId(String s) { m_strUserId = s; }
    public void setStrAcctName(String s) { m_strAcctName = s; }
    public void setStrSmtpId(String s) { m_strSmtpId = s; }
    public void setStrSmtpSvr(String s) { m_strSmtpSvr = s; }
    public void setStrSmtpType(String s) { m_strSmtpType = s; }
    public void setStrPop3Svr(String s) { m_strPop3Svr = s; }
    public void setStrSmtpPwd(String s) { m_strSmtpPwd = s; }
    public void setStrPop3Type(String s) { m_strPop3Type = s; }
    public void setStrDeflt(String s) { m_strDeflt = s; }
    public void setStrSndrName(String s) { m_strSndrName = s; }
    public void setStrPop3Id(String s) { m_strPop3Id = s; }
    public void setStrPop3Pwd(String s) { m_strPop3Pwd = s; }
    public void setStrSysFlag(String s) { m_strSysFlag = s; }
    public void setStrDelFlag(String s) { m_strDelFlag = s; }
}
