package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_C20.java
 * Class    : GEmTB_C20
 * Function : Data model of representing parameter data for TB_COMCODE_C20 Table
 * Comment  : table : TB_COMCODE_C20 
 * History  : 
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_C20 {

    private String m_strRegMailNo = null;
    private String m_strBoxNo = null;
    private String m_strSrType = null;
    private String m_strMailNo = null;
    private String m_strReadFlag = null;
    private String m_strTrashFlag = null;

    public String getStrRegMailNo() { return m_strRegMailNo; }
    public String getStrBoxNo() { return m_strBoxNo; }
    public String getStrSrType() { return m_strSrType; }
    public String getStrMailNo() { return m_strMailNo; }
    public String getStrReadFlag() { return m_strReadFlag; }
    public String getStrTrashFlag() { return m_strTrashFlag; }

    public void setStrRegMailNo(String s) { m_strRegMailNo = s; }
    public void setStrBoxNo(String s) { m_strBoxNo = s; }
    public void setStrSrType(String s) { m_strSrType = s; }
    public void setStrMailNo(String s) { m_strMailNo = s; }
    public void setStrReadFlag(String s) { m_strReadFlag = s; }
    public void setStrTrashFlag(String s) { m_strTrashFlag = s; }
}