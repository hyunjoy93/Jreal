package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_Z30.java
 * Class    : GEmTB_Z30
 * Function : Data model of representing parameter data for TB_COMM_Z30 Table
 * Comment  : table : TB_COMM_Z30
 * History  : 
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_Z30 {

    private String m_strIconNo = null;
    private String m_strVpath = null;
    private String m_strFileName = null;

    public String getStrIconNo() { return m_strIconNo; }
    public String getStrVpath() { return m_strVpath; }
    public String getStrFileName() { return m_strFileName; }

    public void setStrIconNo(String s) { m_strIconNo = s; }
    public void setStrVpath(String s) { m_strVpath = s; }
    public void setStrFileName(String s) { m_strFileName = s; }
}