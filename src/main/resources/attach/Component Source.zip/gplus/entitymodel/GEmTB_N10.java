package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_N10.java
 * Class    : GEmTB_N10
 * Function : Data model of representing parameter data for TB_COMCODE_N10 Table
 * Comment  : table : TB_COMCODE_N10
 * History  : 
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_N10 {

    private String m_strOrgNo = null;
    private String m_strParentNo = null;
    private String m_strOrgName = null;
    private String m_strReaderNo = null;

    public String getStrOrgNo() { return m_strOrgNo; }
    public String getStrParentNo() { return m_strParentNo; }
    public String getStrOrgName() { return m_strOrgName; }
    public String getStrReaderNo() { return m_strReaderNo; }

    public void setStrOrgNo(String s) { m_strOrgNo = s; }
    public void setStrParentNo(String s) { m_strParentNo = s; }
    public void setStrOrgName(String s) { m_strOrgName = s; }
    public void setStrReaderNo(String s) { m_strReaderNo = s; }
}