package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_F30.java
 * Class    : GEmTB_F30
 * Function : Data model of representing parameter data for TB_COMCODE_F30 Table
 * Comment  : table : TB_COMCODE_F30
 * History  : 
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_F30 {

    private String m_strAddrBookNo = null;
    private String m_strTitle = null;
    private String m_strUserId = null;

    public String getStrAddrBookNo() { return m_strAddrBookNo; }
    public String getStrTitle() { return m_strTitle; }
    public String getStrUserId() { return m_strUserId; }

    public void setStrAddrBookNo(String s) { m_strAddrBookNo = s; }
    public void setStrTitle(String s) { m_strTitle = s; }
    public void setStrUserId(String s) { m_strUserId = s; }
}
