package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_D30.java
 * Class    : GEmTB_D30
 * Function : Data model of representing parameter data for TB_COMCODE_D30 Table
 * Comment  : table : TB_COMCODE_D30 
 * History  : 
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_D30 {

    private String m_strLineNum = null;
    private String m_strUserId = null;
    private String m_strLineName = null;
    private String m_strStepNum = null;
    private String m_strApprId1 = null;
    private String m_strApprName1 = null;
    private String m_strApprId2 = null;
    private String m_strApprName2 = null;
    private String m_strApprId3 = null;
    private String m_strApprName3 = null;
    private String m_strApprId4 = null;
    private String m_strApprName4 = null;
    private String m_strApprId5 = null;
    private String m_strApprName5 = null;
    private String m_strApprId6 = null;
    private String m_strApprName6 = null;
    private String m_strApprId7 = null;
    private String m_strApprName7 = null;
    private String m_strLineNote = null;

    public String getStrLineNum() { return m_strLineNum; }
    public String getStrUserId() { return m_strUserId; }
    public String getStrLineName() { return m_strLineName; }
    public String getStrStepNum() { return m_strStepNum; }
    public String getStrApprId1() { return m_strApprId1; }
    public String getStrApprName1() { return m_strApprName1; }
    public String getStrApprId2() { return m_strApprId2; }
    public String getStrApprName2() { return m_strApprName2; }
    public String getStrApprId3() { return m_strApprId3; }
    public String getStrApprName3() { return m_strApprName3; }
    public String getStrApprId4() { return m_strApprId4; }
    public String getStrApprName4() { return m_strApprName4; }
    public String getStrApprId5() { return m_strApprId5; }
    public String getStrApprName5() { return m_strApprName5; }
    public String getStrApprId6() { return m_strApprId6; }
    public String getStrApprName6() { return m_strApprName6; }
    public String getStrApprId7() { return m_strApprId7; }
    public String getStrApprName7() { return m_strApprName7; }
    public String getStrLineNote() { return m_strLineNote; }

    public void setStrLineNum(String s) { m_strLineNum = s; }
    public void setStrUserId(String s) { m_strUserId = s; }
    public void setStrLineName(String s) { m_strLineName = s; }
    public void setStrStepNum(String s) { m_strStepNum = s; }
    public void setStrApprId1(String s) { m_strApprId1 = s; }
    public void setStrApprName1(String s) { m_strApprName1 = s; }
    public void setStrApprId2(String s) { m_strApprId2 = s; }
    public void setStrApprName2(String s) { m_strApprName2 = s; }
    public void setStrApprId3(String s) { m_strApprId3 = s; }
    public void setStrApprName3(String s) { m_strApprName3 = s; }
    public void setStrApprId4(String s) { m_strApprId4 = s; }
    public void setStrApprName4(String s) { m_strApprName4 = s; }
    public void setStrApprId5(String s) { m_strApprId5 = s; }
    public void setStrApprName5(String s) { m_strApprName5 = s; }
    public void setStrApprId6(String s) { m_strApprId6 = s; }
    public void setStrApprName6(String s) { m_strApprName6 = s; }
    public void setStrApprId7(String s) { m_strApprId7 = s; }
    public void setStrApprName7(String s) { m_strApprName7 = s; }
    public void setStrLineNote(String s) { m_strLineNote = s; }
}