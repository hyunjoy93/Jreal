package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_N30.java
 * Class    : GEmTB_N30
 * Function : Data model of representing parameter data for TB_COMCODE_N30 Table
 * Comment  : table : TB_COMCODE_N30
 * History  : 
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_N30 {

    private String m_strUserId = null;
    private String m_strItemNo = null;
    private String m_strBoxNo = null;
    private String m_strFldNo = null;

    public String getStrUserId() { return m_strUserId; }
    public String getStrItemNo() { return m_strItemNo; }
    public String getStrBoxNo() { return m_strBoxNo; }
    public String getStrFldNo() { return m_strFldNo; }

    public void setStrUserId(String s) { m_strUserId = s; }
    public void setStrItemNo(String s) { m_strItemNo = s; }
    public void setStrBoxNo(String s) { m_strBoxNo = s; }
    public void setStrFldNo(String s) { m_strFldNo = s; }
}
