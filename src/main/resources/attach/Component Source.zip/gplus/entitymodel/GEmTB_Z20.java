package gplus.entitymodel;

/**
 * <PRE>
 * Filename : GEmTB_Z20.java
 * Class    : GEmTB_Z20
 * Function : Data model of representing parameter data for TB_COMM_Z20 Table
 * Comment  : table : TB_COMM_Z20
 * History  :
 * </PRE>
 * @version 1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GEmTB_Z20 {

    private String m_strUserId = null;
    private String m_strPassWd = null;
    private String m_strOrgNo = null;
    private String m_strPosCode = null;
    private String m_strUserName = null;
    private String m_strSecLvl = null;
    private String m_strAlarmFlag = null;
    private String m_strAlarmTime = null;
    private String m_strAlarmRepeat = null;
    private String m_strAlarmType = null;
    private String m_strAlarmMailOn = null;
    private String m_strAlarmDrftOn = null;
    private String m_strLogInFlag = null;
    private String m_strLogInDate = null;
    private String m_strBoxNo = null;
    private String m_strSignDocNo = null;
    private String m_strComCode = null;
    private String m_strTel1 = null;
    private String m_strTel2 = null;
    private String m_strTel3 = null;
    private String m_strZipCode = null;
    private String m_strAddr = null;
    private String m_strInDate = null;
    private String m_strBirthDay = null;
    private String m_strLunarFlag = null;
    private String m_strPageSize = null;

    public String getStrUserId() { return m_strUserId; }
    public String getStrPassWd() { return m_strPassWd; }
    public String getStrOrgNo() { return m_strOrgNo; }
    public String getStrPosCode() { return m_strPosCode; }
    public String getStrUserName() { return m_strUserName; }
    public String getStrSecLvl() { return m_strSecLvl; }
    public String getStrAlarmFlag() { return m_strAlarmFlag; }
    public String getStrAlarmTime() { return m_strAlarmTime; }
    public String getStrAlarmRepeat() { return m_strAlarmRepeat; }
    public String getStrAlarmType() { return m_strAlarmType; }
    public String getStrAlarmMailOn() { return m_strAlarmMailOn; }
    public String getStrAlarmDrftOn() { return m_strAlarmDrftOn; }
    public String getStrLogInFlag() { return m_strLogInFlag; }
    public String getStrLogInDate() { return m_strLogInDate; }
    public String getStrBoxNo() { return m_strBoxNo; }
    public String getStrSignDocNo() { return m_strSignDocNo; }
    public String getStrComCode() { return m_strComCode; }
    public String getStrTel1() { return m_strTel1; }
    public String getStrTel2() { return m_strTel2; }
    public String getStrTel3() { return m_strTel3; }
    public String getStrZipCode() { return m_strZipCode; }
    public String getStrAddr() { return m_strAddr; }
    public String getStrInDate() { return m_strInDate; }
    public String getStrBirthDay() { return m_strBirthDay; }
    public String getStrLunarFlag() { return m_strLunarFlag; }
    public String getStrPageSize() { return m_strPageSize; }

    public void setStrUserId(String s) { m_strUserId = s; }
    public void setStrPassWd(String s) { m_strPassWd = s; }
    public void setStrOrgNo(String s) { m_strOrgNo = s; }
    public void setStrPosCode(String s) { m_strPosCode = s; }
    public void setStrUserName(String s) { m_strUserName = s; }
    public void setStrSecLvl(String s) { m_strSecLvl = s; }
    public void setStrAlarmFlag(String s) { m_strAlarmFlag = s; }
    public void setStrAlarmTime(String s) { m_strAlarmTime = s; }
    public void setStrAlarmRepeat(String s) { m_strAlarmRepeat = s; }
    public void setStrAlarmType(String s) { m_strAlarmType = s; }
    public void setStrAlarmMailOn(String s) { m_strAlarmMailOn = s; }
    public void setStrAlarmDrftOn(String s) { m_strAlarmDrftOn = s; }
    public void setStrLogInFlag(String s) { m_strLogInFlag = s; }
    public void setStrLogInDate(String s) { m_strLogInDate = s; }
    public void setStrBoxNo(String s) { m_strBoxNo = s; }
    public void setStrSignDocNo(String s) { m_strSignDocNo = s; }
    public void setStrComCode(String s) { m_strComCode = s; }
    public void setStrTel1(String s) { m_strTel1 = s; }
    public void setStrTel2(String s) { m_strTel2 = s; }
    public void setStrTel3(String s) { m_strTel3 = s; }
    public void setStrZipCode(String s) { m_strZipCode = s; }
    public void setStrAddr(String s) { m_strAddr = s; }
    public void setStrInDate(String s) { m_strInDate = s; }
    public void setStrBirthDay(String s) { m_strBirthDay = s; }
    public void setStrLunarFlag(String s) { m_strLunarFlag = s; }
    public void setStrPageSize(String s) { m_strPageSize = s; }
}
