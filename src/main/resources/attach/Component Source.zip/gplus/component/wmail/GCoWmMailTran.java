package gplus.component.wmail;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;
import gplus.component.doc.*;
import gplus.template.*;

/**
 * <PRE>
 * Filename	: GCoWmMailTran.java
 * Class		    : gplus.component.draft.GCoWmMailTran
 * Fuction	    :
 * Comment	:
 * History       : 2/7/2002, ������, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCoWmMailTran extends GCmTopComponent
{

	/**
	 * <PRE>
	 *  ���ϸ�� �Է�
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE : ȸ���ڵ�	<BR>
	 *				<LI> String MAILNO     : ���Ϲ�ȣ  <BR>
	 *				<LI> String DOCNO      : ������ȣ  <BR>
	 *				<LI> String MAILTYPE  : ��������  <BR>
	 *				<LI> String SENDTYPE : ���߽Ż���      <BR>
	 *				<LI> String DLVRTYPE  : �߼ۻ���  <BR>
	 *				<LI> String TITLE         : ����  <BR>
	 *				<LI> String REGDATE   : �ۼ��Ͻ�  <BR>
	 *				<LI> String SNDRID      : �߽���         <BR>
	 *				<LI> String SNDRNAME : �߽����̸�  <BR>
	 *				<LI> String TOID           : ������  <BR>
	 *				<LI> String TONAME     : �������̸�  <BR>
	 *				<LI> String CCID          : ������         <BR>
	 *				<LI> String CCNAME    : �������̸�  <BR>
	 *				<LI> String BCCID        : ���������  <BR>
	 *				<LI> String BCCNAME  : ����������̸�  <BR>
	 *				<LI> String ATTNUM     : ÷�����ϼ�         <BR>
	 *				<LI> String RCVRNUM  : �����ڼ�  <BR>
	 *				<LI> String READNUM   : Ȯ���ڼ�  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  boolean
	 */

	public boolean insertMail(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strMailNo   = dmProp.getString("MAILNO");
		String strDocNo   = dmProp.getString("DOCNO");
		String strSeqno   = dmProp.getString("SEQNO");
		String strMailType  = dmProp.getString("MAILTYPE");
		String strSendType = dmProp.getString("SENDTYPE");
		String strDlvrType   = dmProp.getString("DLVRTYPE");
		String strTitle         = dmProp.getString("TITLE");
		String strRegDate   = dmProp.getString("REGDATE");
		String strSndrId     = dmProp.getString("SNDRID");
		String strSndrName  = dmProp.getString("SNDRNAME");
		String strToId          = dmProp.getString("TOID");
		String strToName    = dmProp.getString("TONAME");
		String strCcId        = dmProp.getString("CCID");
		String strCcName   = dmProp.getString("CCNAME");
		String strBccId      = dmProp.getString("BCCID");
		String strBccName  = dmProp.getString("BCCNAME");
		int      intAttNum   = dmProp.getInt("ATTNUM");
		int      intRcvrNum   = dmProp.getInt("RCVRNUM");
		int      intReadNum     = dmProp.getInt("READNUM");
   		String strAcctName  = dmProp.getString("ACCTNAME");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
							.append(" INSERT INTO TB_").append(strComCode).append("_C10 ")
							.append(" (MAILNO, DOCNO, MAILTYPE, SENDTYPE, DLVRTYPE, TITLE, REGDATE, ")
							.append(" SNDRID, SNDRNAME, TOID, TONAME, CCID, CCNAME, BCCID, BCCNAME, ")
							.append(" ATTNUM, RCVRNUM, READNUM ");
            if(strAcctName != null && !strAcctName.equals(""))
                    sqlQuery.append(", ACCTNAME ");

            sqlQuery.append(" ) VALUES ( ")
					.append( genQuote(strMailNo) + ", ")
					.append( genQuote(strDocNo) + ", ")
					.append( genQuote(strMailType) + ", ")
					.append( genQuote(strSendType) + ", ")
					.append( genQuote(strDlvrType) + ", ")
					.append( genQuote(strTitle) + ", ")
					.append( genQuote(strRegDate) + ", ")
					.append( genQuote(strSndrId) + ", ")
					.append( genQuote(strSndrName) + ", ")
					.append( genQuote(strToId) + ", ")
					.append( genQuote(strToName) + ", ")
					.append( genQuote(strCcId) + ", ")
					.append( genQuote(strCcName) + ", ")
					.append( genQuote(strBccId) + ", ")
					.append( genQuote(strBccName) + ", ")
					.append( intAttNum ).append(", ")
					.append( intRcvrNum ).append(", ")
					.append( intReadNum );

            if(strAcctName != null && !strAcctName.equals(""))
                    sqlQuery.append(", "+genQuote(strAcctName));

            sqlQuery.append(" ) ");


           // System.out.println("insertMail--->"+sqlQuery.toString());
			conn.executeUpdate(sqlQuery.toString());

			conn.commit();
			return true;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoWmMailTran :: insertMail" + ignored.getMessage());
			}


			System.out.println("GCoWmMailTran :: insertMail " + e.getMessage());

			return false;

		}
		finally
		{
			conn.close();
		}
	}





	/**
	 * <PRE>
	 *  ��/�߽��ں����θ��ϸ���Է�
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE  : ȸ���ڵ�	<BR>
	 *				<LI> String BOXNO       : �Թ�ȣ  <BR>
	 *				<LI> String MAILNO      : ���Ϲ�ȣ  <BR>
	 *				<LI> String SRTYPE      : ���߽�����   <BR>
	 *				<LI> String READFLAG  : Ȯ�ο���  <BR>
	 *				<LI> String TRASHFLAG : ������  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  boolean
	 */

	public boolean insertRegMail(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;



		try
		{
			conn = GCmDbManager.getInstance().getConnection();


			String strComCode = dmProp.getString("COMCODE");
			String strBoxNo    = dmProp.getString("BOXNO");
			String strMailNo   = dmProp.getString("MAILNO");
			String strSrType = dmProp.getString("SRTYPE");
			String strReadFlag   = dmProp.getString("READFLAG");
			String strTrashFlag   = dmProp.getString("TRASHFLAG");



			GTpMail mail  = new GTpMail();


			String strRegMailNo = mail.getMaxRegMailNo(cp, dmProp, msgInfo);


			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
							.append(" INSERT INTO TB_").append(strComCode).append("_C20 ")
							.append(" (REGMAILNO, BOXNO, MAILNO, SRTYPE, READFLAG, TRASHFLAG) ")
							.append(" VALUES ( ")
							.append( genQuote(strRegMailNo) + ", ")
							.append( genQuote(strBoxNo) + ", ")
							.append( genQuote(strMailNo) + ", ")
							.append( genQuote(strSrType) + ", ")
							.append( genQuote(strReadFlag) + ", ")
							.append( genQuote(strTrashFlag))
							.append(" ) ");
//System.out.println("insertRegMail--->"+sqlQuery.toString());
			conn.executeUpdate(sqlQuery.toString());

			conn.commit();

			return true;

		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoWmMailTran :: insertRegMail" + ignored.getMessage());
			}


			System.out.println("GCoWmMailTran :: insertRegMail" + e.getMessage());

			return false;


		}
		finally
		{
			conn.close();
		}
	}






	/**
	 * <PRE>
	 *  �����ں� �系���� ���Ÿ�� �Է�
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE  : ȸ���ڵ�	<BR>
	 *				<LI> String MAILNO      : ���Ϲ�ȣ  <BR>
	 *				<LI> String RCVRID       : ������   <BR>
	 *				<LI> String RCVRNAME : �����ڸ�  <BR>
	 *				<LI> String READFLAG  : Ȯ�ο���  <BR>
	 *				<LI> String READDATE  : Ȯ���Ͻ�  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  boolean
	 */
	public boolean insertRcvMail(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strMailNo   = dmProp.getString("MAILNO");
		String strRcvrId = dmProp.getString("RCVRID");
		String strRcvrName  = dmProp.getString("RCVRNAME");
		String strReadFlag   = dmProp.getString("READFLAG");
		String strReadDate  = dmProp.getString("READDATE");
		String strRcvType  = dmProp.getString("RCVTYPE");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();
			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
							.append(" INSERT INTO TB_").append(strComCode).append("_C11 ")
							.append(" (MAILNO, RCVRID, RCVRNAME, READFLAG, READDATE,RCVTYPE) ")
							.append(" VALUES ( ")
							.append( genQuote(strMailNo) + ", ")
							.append( genQuote(strRcvrId) + ", ")
							.append( genQuote(strRcvrName) + ", ")
							.append( genQuote(strReadFlag) + ", ")
							.append( genQuote(strReadDate) + ", ")
							.append( genQuote(strRcvType))
							.append(" ) ");

//System.out.println("insertRcvMail--->"+sqlQuery.toString());
			conn.executeUpdate(sqlQuery.toString());

			conn.commit();

			return true;

		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoWmMailTran  :: insertRcvMail" + ignored.getMessage());
			}

			System.out.println("GCoWmMailTran :: insertRcvMail " +  e.getMessage());

			return false;


		}
		finally
		{
			conn.close();
		}
	}






	/**
	 * <PRE>
	 *  ���Ϲ�ȣ�� �ش��ϴ� �����Ժ� ���ϸ�� ���� ����.. ������ ������ �ٽ� �߼�/�����Ҷ� �߻�
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE  : ȸ���ڵ�	<BR>
	 *				<LI> String REGMAILNO      : ���Ϲ�ȣ  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  boolean
	 */

	public boolean deleteRegMail(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strRegMailNo   = dmProp.getString("REGMAILNO");



		try
		{
			conn = GCmDbManager.getInstance().getConnection();


			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
							.append(" DELETE FROM TB_").append(strComCode).append("_C20 ")
							.append(" WHERE REGMAILNO =  " + genQuote(strRegMailNo));


			conn.executeUpdate(sqlQuery.toString());

			conn.commit();

			return true;

		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoWmMailTran :: deleteRegMail " + ignored.getMessage());
			}

			System.out.println("GCoWmMailTran :: deleteRegMail "  + e.getMessage());

			return false;


		}
		finally
		{
			conn.close();
		}
	}




	/**
	 * <PRE>
	 *  ���������Կ��� ���������� ���� Table��� ����
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE   : ȸ���ڵ�	<BR>
	 *				<LI> String MAILNO       : ���Ϲ�ȣ  <BR>
	 *				<LI> String REGMAILNO : ���θ��Ϲ�ȣ <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  boolean
	 */

	public boolean deleteMailAll(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	throws GCmProcessingErrorException, GCmParameterErrorException
	{


		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strMailNo = dmProp.getString("MAILNO");
		String strRegMailNo   = dmProp.getString("REGMAILNO");
		String strPpath = dmProp.getString("PPATH");
		String strDocNo = "";
                String strSeq = "";
                String strFileName = "";
                String strFileExt = "";
                String strVpath = "";
                String strFilePath = "";
                java.io.File delFile = null;
		int intCnt = 0;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			if ((strMailNo == null) || (strMailNo.equals("")))
			{
				throw new GCmParameterErrorException("deleteMailAll() MAILNO parameter error..");
			}

			conn.setAutoCommit(false);
			StringBuffer sqlQuery = new StringBuffer()
							.append(" DELETE FROM TB_").append(strComCode).append("_C20 ")
							.append(" WHERE REGMAILNO =  " + genQuote(strRegMailNo));

			conn.executeUpdate(sqlQuery.toString());
			//���� ī��Ʈ(������ ����������� ������� ������ �Կ� ���� ���Ϲ�ȣ,�ٸ� ���θ��Ϲ�ȣ�� ������ �����ǹǷ�)
			StringBuffer sqlQuery2 = new StringBuffer()
							.append(" SELECT COUNT(*) FROM TB_").append(strComCode).append("_C20 ")
							.append(" WHERE MAILNO =  " + genQuote(strMailNo));

			GCmResultSet rs = conn.executeQuery(sqlQuery2.toString());
			while(rs.next())
			{
				intCnt = rs.getInt(1);
			}
			//�ٸ� ����ڿ��Ե� ������ �������� �ʴ� ���(�系������ ������ ���������԰� ������ ���������Կ� ����)�� �Ʒ� ���̺��鿡�� ��� ����
			if (intCnt == 0)
			{
				//������ȣ �˻�
				StringBuffer sqlQuery3 = new StringBuffer()
								.append(" SELECT DOCNO FROM TB_").append(strComCode).append("_C10 ")
								.append(" WHERE MAILNO =  " + genQuote(strMailNo));
				GCmResultSet rs2 = conn.executeQuery(sqlQuery3.toString());
				while(rs2.next())
				{
					strDocNo = rs2.getString("DOCNO");
				}
				//�����ϼ��Ÿ�Ͽ��� ����(C11 TABLE)
				StringBuffer sqlQuery4 = new StringBuffer()
								.append(" DELETE FROM TB_").append(strComCode).append("_C11 ")
								.append(" WHERE MAILNO = " + genQuote(strMailNo));
				conn.executeUpdate(sqlQuery4.toString());
				//���ϸ�Ͽ��� ����(C10 TABLE)
				StringBuffer sqlQuery5 = new StringBuffer()
								.append(" DELETE FROM TB_").append(strComCode).append("_C10 ")
								.append(" WHERE MAILNO = " + genQuote(strMailNo));
				conn.executeUpdate(sqlQuery5.toString());
				StringBuffer sqlQuery6 = new StringBuffer()
								.append(" SELECT DOCNO, SEQ, CONTTYPE, TITLE, FILEEXT, FILENAME, VPATH, MIMETYPE, FILESIZE, ORGNAME, ")
								.append(" ORGPATH,REGUSER,REGDATE,MODUSER,MODDATE FROM TB_").append(strComCode).append("_L11 ")
								.append(" WHERE DOCNO = " + genQuote(strDocNo));
				GCmResultSet rs3 = conn.executeQuery(sqlQuery6.toString());
				while(rs3.next())
				{
                                    StringBuffer sqlQuery7 = new StringBuffer();
				    strSeq = rs3.getString("SEQ");
                                    strFileName = rs3.getString("FILENAME");
                                    strFileExt = rs3.getString("FILEEXT");
                                    strVpath = rs3.getString("VPATH");
                                    strFilePath = strPpath + strVpath + strFileName;
					//�����󼼸�� ����
					sqlQuery7.append(" DELETE FROM TB_").append(strComCode).append("_L11 ")
								  .append(" WHERE DOCNO = " + genQuote(strDocNo))
								  .append(" AND SEQ = " + genQuote(strSeq));
					conn.executeUpdate(sqlQuery7.toString());
					delFile = new java.io.File(strPpath,strVpath + strFileName);
					if (delFile.isFile()) delFile.delete();
				}
				//������Ͽ��� ����
				StringBuffer sqlQuery8 = new StringBuffer()
							.append(" DELETE FROM TB_").append(strComCode).append("_L10 ")
							.append(" WHERE DOCNO = "+genQuote(strDocNo));

				conn.executeUpdate(sqlQuery8.toString());
				//eml File����
				 if (!strVpath.equals(""))
				 {
                                      delFile = new java.io.File( strPpath, strVpath + strDocNo + "_00.eml");
                                      if (delFile.isFile()) delFile.delete();
				}
			}
			conn.commit();
			return true;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoWmMailTran :: deleteMailAll " + ignored.getMessage());
			}
			System.out.println("GCoWmMailTran :: deleteMailAll " + e.getMessage());
			return false;


		}
		finally
		{
			conn.close();
		}
	}



	/**
	 * <PRE>
	 *  ���Ϲ�ȣ�� �ش��ϴ� ���ϸ�ϻ���
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE  : ȸ���ڵ�	<BR>
	 *				<LI> String MAILNO      : ���Ϲ�ȣ  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  boolean
	 */

	public boolean deleteMail(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strRegMailNo   = dmProp.getString("MAILNO");



		try
		{
			conn = GCmDbManager.getInstance().getConnection();


			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
							.append(" DELETE FROM TB_").append(strComCode).append("_C10 ")
							.append(" WHERE MAILNO =  " + genQuote(strRegMailNo));


			conn.executeUpdate(sqlQuery.toString());

			conn.commit();

			return true;

		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoWmMailTran :: deleteMail" + ignored.getMessage());
			}


			System.out.println("GCoWmMailTran :: deleteMail" + e.getMessage());

			return false;


		}
		finally
		{
			conn.close();
		}
	}






	/**
	 * <PRE>
	 *  �������̵�
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�	<BR>
	 *				<LI> String USERID         : ���Ϲ�ȣ  <BR>
	 *				<LI> String REGMAILNO  : ȸ���ڵ�	<BR>
	 *				<LI> String TARGET        : ������   <BR>
	 *				<LI> String SRC              : ������	<BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  boolean
	 */

	public boolean moveBox(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strUserId   = dmProp.getString("USERID");
		String strRegMailNo = dmProp.getString("REGMAILNO");
		String strTarget   = dmProp.getString("TARGET");
		String strSrc = dmProp.getString("SRC");



		try
		{
			conn = GCmDbManager.getInstance().getConnection();


			conn.setAutoCommit(false);

			StringBuffer sqlQuery = new StringBuffer()
							.append(" UPDATE TB_").append(strComCode).append("_C20 ")
							.append(" SET BOXNO = ( SELECT BOXNO FROM TB_").append(strComCode).append("_M10 ")
							.append(" WHERE BOXCLASS = " + genQuote(GCmConstDef.BOXCLASS_MAIL))
							.append(" AND EXECCLASS = " + genQuote(strTarget))
							.append(" AND BOXTYPE = " + genQuote(GCmConstDef.BOXTYPE_PRIVATE))
							.append(" AND USERID = " + genQuote(strUserId)).append(" ) ")
							.append(" WHERE BOXNO = (SELECT BOXNO FROM TB_").append(strComCode).append("_M10 ")
							.append(" WHERE BOXCLASS = " + genQuote(GCmConstDef.BOXCLASS_MAIL))
							.append(" AND EXECCLASS = " + genQuote(strSrc))
							.append(" AND BOXTYPE = " + genQuote(GCmConstDef.BOXTYPE_PRIVATE))
							.append(" AND USERID = " + genQuote(strUserId))
							.append(" ) ")
							.append(" AND REGMAILNO = " + genQuote(strRegMailNo));


			conn.executeUpdate(sqlQuery.toString());

			conn.commit();

			return true;

		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoWmMailTran :: moveBox" + ignored.getMessage());
			}


			System.out.println("GCoWmMailTran :: moveBox" + e.getMessage());

			return false;


		}
		finally
		{
			conn.close();
		}
	}






	/**
	 * <PRE>
	 *  �Ժ���(�Ϲ���->����������, ����������->����)
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�	<BR>
	 *				<LI> String BOXNO         : �Թ�ȣ  <BR>
	 *				<LI> String EXECCLASS : ������  <BR>
	 *				<LI> String PPATH          : ���  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  boolean
	 */

	public boolean emptyBox(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;



		String strDelBoxNo = "";


		try
		{
			conn = GCmDbManager.getInstance().getConnection();


			String strComCode = dmProp.getString("COMCODE");
			String strUserId  = dmProp.getString("USERID");
			String strBoxNo     = dmProp.getString("BOXNO");
			String strExecClass  = dmProp.getString("EXECCLASS");
			String strPpath  = dmProp.getString("PPATH");

			conn.setAutoCommit(false);

			if (strExecClass.equals(GCmConstDef.EXECCLASS_MAIL_DELBOX)) { // ����������



				StringBuffer sqlQuery = new StringBuffer()
								.append(" SELECT REGMAILNO, MAILNO FROM TB_").append(strComCode).append("_C20 ")
								.append(" WHERE BOXNO =  " + genQuote(strBoxNo));


				GCmResultSet rs = conn.executeQuery(sqlQuery.toString());



				while(rs.next())
				{

					GCmProperties dmDel = new GCmProperties();

					dmDel.setValue("COMCODE", strComCode);
					dmDel.setValue("MAILNO", rs.getString("MAILNO"));
					dmDel.setValue("REGMAILNO", rs.getString("REGMAILNO"));
					dmDel.setValue("PPATH", strPpath);
					deleteMailAll(cp, dmDel, msgInfo);
				}
			}
			else	{   //�Ϲ�������

				StringBuffer sqlQuery2 = new StringBuffer()
								.append(" SELECT BOXNO FROM TB_").append(strComCode).append("_M10 ")
								.append(" WHERE BOXCLASS = " + genQuote(GCmConstDef.BOXCLASS_MAIL))
								.append(" AND EXECCLASS = " + genQuote(GCmConstDef.EXECCLASS_MAIL_DELBOX))
								.append(" AND BOXTYPE = " + genQuote(GCmConstDef.BOXTYPE_PRIVATE))
								.append(" AND USERID = " + genQuote(strUserId));
				GCmResultSet rs2 = conn.executeQuery(sqlQuery2.toString());

				while(rs2.next())
				{
					strDelBoxNo = rs2.getString("BOXNO");
				}

				if (!strDelBoxNo.equals("")) 	{
					StringBuffer sqlQuery3 = new StringBuffer()
									.append(" UPDATE TB_").append(strComCode).append("_C20 ")
									.append(" SET BOXNO = " + genQuote(strDelBoxNo))
									.append(" WHERE BOXNO = " + genQuote(strBoxNo));
					conn.executeUpdate(sqlQuery3.toString());
				}
			}
			conn.commit();
			return true;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoWmMailTran :: deleteMailAll " + ignored.getMessage());
			}
			System.out.println("GCoWmMailTran :: deleteMailAll " + e.getMessage());
			return false;
		}
		finally
		{
			conn.close();
		}
	}




	/**
	 * <PRE>
	 *  �������̵�
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�	<BR>
	 *				<LI> String BOXNO         : �Թ�ȣ  <BR>
	 *				<LI> String REGMAILNO  : ���θ��Ϲ�ȣ  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  boolean
	 */
	public boolean updateMoveMail(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strBoxNo     = dmProp.getString("BOXNO");
		String strRegMailNo   = dmProp.getString("REGMAILNO");


		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			conn.setAutoCommit(false);

			StringBuffer sqlQuery3 = new StringBuffer()
									.append(" UPDATE TB_").append(strComCode).append("_C20 ")
									.append(" SET BOXNO = " + genQuote(strBoxNo))
									.append(" WHERE REGMAILNO = " + genQuote(strRegMailNo));



			System.out.println("updateMoveMail()   - SQL  : " +  sqlQuery3.toString());

					conn.executeUpdate(sqlQuery3.toString());


			conn.commit();

			return true;

		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();	// Transaction Rollback
			}
			catch (SQLException ignored)
			{
				System.out.println("GCoWmMailTran :: updateMoveMail" + ignored.getMessage());
			}


			System.out.println("GCoWmMailTran :: updateMoveMail" + e.getMessage());

			return false;


		}
		finally
		{
			conn.close();
		}
	}






	/**
	 * <PRE>
	 *  �ڷ��Կ�����
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�	<BR>
	 *				<LI> String BOXNO         : �Թ�ȣ  <BR>
	 *				<LI> String MAILNO        : ���Ϲ�ȣ  <BR>
	 *				<LI> String REGMAILNO  : ���θ��Ϲ�ȣ <BR>
	 *				<LI> String FLDBOXNO    : ������  <BR>
	 *				<LI> String FLDNO          : ����  <BR>
	 *				<LI> String USERID         : �����ID	<BR>
	 *				<LI> String USERNAME   : ������̸�  <BR>
	 *				<LI> String PPATH          : ���θ��Ϲ�ȣ  <BR>
	 *				<LI> String DOMAIN        : URL	<BR>
	 *				<LI> String READPAGE    : ������ȸ���ϸ� <BR>
	 *				<LI> String HTTPPORT     : ��Ʈ  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  boolean
	 */
	/*
	public boolean setCopyFld(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strBoxNo     = dmProp.getString("BOXNO");
		String strMailNo   = dmProp.getString("MAILNO");
		String strRegMailNo   = dmProp.getString("REGMAILNO");
		String strFldBoxNo = dmProp.getString("FLDBOXNO");
		String strFldNo     = dmProp.getString("FLDNO");
		String strUserId   = dmProp.getString("USERID");
		String strUserName   = dmProp.getString("USERNAME");
		String strPpath = dmProp.getString("PPATH");
		String strDomain     = dmProp.getString("DOMAIN");
		String strReadPage   = dmProp.getString("READPAGE");
		String strHttpPort   = dmProp.getString("HTTPPORT");

		int intRet = 0;

        java.io.File srcFile = null;        // ������ ����
        java.io.File desFile = null;        // ����� ����


        String strDocNo = "";                  // �űԹ�����ȣ
        String strOldDocNo =  "";              // ����������ȣ
        String strTitle = "";                  // ����
        java.util.Vector vDoc = new java.util.Vector();     // ������� ����Ʈ



		GTpDoc doc = new GTpDoc();
		GTpDocFolder docFolder = new GTpDocFolder();
		GTpMail mail = new GTpMail();
                GCoDoDocTran docTran = new GCoDoDocTran();

		try
		{
	        String strRegDate = GCmDateFcts.dateToStr(new java.util.Date(),2);    // �����

			dmProp.setProperty("COMCODE", strComCode);
			dmProp.setProperty("REGMAILNO", strRegMailNo);


			GCmResultSet rs = mail.getMailInfo(cp, dmProp, msgInfo);

			rs.next();

			strOldDocNo = rs.getString("DOCNO");
			strTitle = rs.getString("TITLE");


			// �������(����������)�� �Է�
	        // -- ��������
			dmProp.setProperty("Docno", strOldDocNo);

			GCmResultSet rs3 = doc.getDocInfo(cp, dmProp, msgInfo);

			rs3.next();


		    // -- �ű��Է�
			dmProp.setProperty("Title", rs3.getString("TITLE"));
			dmProp.setProperty("Doctype", "2");
			dmProp.setProperty("Attnum", rs3.getString("FILENUM"));
			dmProp.setProperty("Reguser", rs3.getString("REGUSER"));
			dmProp.setProperty("Regdate", rs3.getString("REGDATE"));
			dmProp.setProperty("Moduser", strUserId);
			dmProp.setProperty("Moddate", strRegDate);


			doc.insertDoc(cp, dmProp, msgInfo);


			strDocNo = dmProp.getProperty("Docno");



	        // ������Ͽ� �Է�
			dmProp.setProperty("Boxno", strFldBoxNo);
			dmProp.setProperty("Docno", strDocNo);
			dmProp.setProperty("Parentno", strFldNo);
			dmProp.setProperty("Boxname", strTitle);
			dmProp.setProperty("Userno", strUserId);
			dmProp.setProperty("Regdate", strRegDate);
			dmProp.setProperty("Trashflag", "1");
			dmProp.setProperty("Comments", "");
			dmProp.setProperty("Refno", "C"+strRegMailNo+strBoxNo);



			docFolder.insertFolder(cp, dmProp, msgInfo);



			dmProp.setProperty("USERID", strUserId);
			dmProp.setProperty("Boxno", strBoxNo);
			dmProp.setProperty("Fldno", strFldNo);
			dmProp.setProperty("Boxname", "");

			String strFldNoPath = docFolder.getFldnoPath(cp, dmProp, msgInfo);

	        //String fldpath = "/DATA/" + strComCode + "/BOX/" + strFldBoxNo + "/" + strFldNoPath; // �����
                String fldpath = "/DATA/" + strComCode + "/BOX/" + strRegDate.substring(0,6) +"/"+strRegDate.substring(6,8)+ "/" + strFldNoPath; // �����
                java.io.File oFile = null;
		    java.util.Vector vec= new java.util.Vector();
			String fld = "";
	        String tmp = "";


			tmp = fldpath.substring(0,1);
	        if (tmp.equals("/"))
		        fldpath = fldpath.substring(1,fldpath.length());

			vec = GCmFcts.getSplit(fldpath,"/");

	        for (int i=0;i<vec.size();i++)
			{
				fld += (String)vec.elementAt(i) + "/";
	            oFile = new java.io.File(strPpath + "/" +fld);

		        if (!oFile.isDirectory()) oFile.mkdir();
			}



			// �����󼼸��
		    String seq = "";
	        String conttype = "";
		    String titleLst = "";
			String fileext = "";
	        String oldfilename = "";
		    String filename = "";
			String vpath = "";
	        String mimetype = "";
		    int filesize = 0;
			String orgname = "";
	        String orgpath = "";
		    String reguserLst = "";
			String regdateLst = "";
	        String moduserLst = "";
		    String moddateLst = "";
			String despath = fldpath;


			// �����󼼸�Ͽ� �Է�
			dmProp.setProperty("Docno", strOldDocNo);
			dmProp.setProperty("Seq", "00");

			GCmResultSet rs2 = doc.getDocDtlList(cp, dmProp, msgInfo);


			while(rs2.next())
			{

	            seq = rs2.getString("SEQ");
		        conttype = rs2.getString("CONTTYPE");
			    titleLst = rs2.getString("TITLE");
				fileext = rs2.getString("FILEEXT");
	            oldfilename = rs2.getString("FILENAME");
		        vpath = rs2.getString("VPATH");
                           mimetype = rs2.getString("MIMETYPE");
	            filesize = rs2.getInt("FILESIZE");
		        orgname = rs2.getString("ORGNAME");
			    orgpath = rs2.getString("ORGPATH");
	            reguserLst = rs2.getString("REGUSER");
		        regdateLst = rs2.getString("REGDATE");
			    moduserLst = rs2.getString("MODUSER");
	            moddateLst = rs2.getString("MODDATE");

				// �����󼼸�Ͽ� �Է�
	            filename = strDocNo + "_" + seq + fileext;


				dmProp.setProperty("Docno", strDocNo);
				dmProp.setProperty("Seq", seq);
				dmProp.setProperty("Conttype", conttype);
				dmProp.setProperty("Title", titleLst);
				dmProp.setProperty("Fileext", fileext);
				dmProp.setProperty("Filename", filename);
				dmProp.setProperty("Vpath", fldpath);
				dmProp.setProperty("Mimetype", mimetype);
				dmProp.setProperty("Filesize", String.valueOf(filesize));
				dmProp.setProperty("Orgname", orgname);
				dmProp.setProperty("Orgpath", orgpath);
				dmProp.setProperty("Reguser", reguserLst);
				dmProp.setProperty("Regdate", regdateLst);
				dmProp.setProperty("Moduser", strUserId);
				dmProp.setProperty("Moddate", strRegDate);

				doc.insertAttDoc(cp, dmProp, msgInfo);


	                        // ���Ϻ���...
				srcFile = new java.io.File(strPpath+vpath,oldfilename);
	                        desFile = new java.io.File(strPpath+fldpath,filename);

				//if (srcFile.isFile()){

                                    // if (seq.equals("01")) { // ���������� ���Ŀ� �°� �Է�...

                                      // URL ����...

						StringBuffer para = new StringBuffer();

					    para.append("comcode=").append(strComCode).append("&userid=").append(strUserId)
						    .append("&boxno=").append(strBoxNo).append("&mailno=").append(strMailNo)
							.append("&regmailno=").append(strRegMailNo).append("&from=copyfld");

						GCmHtmlPageSaver html = new GCmHtmlPageSaver();

						String bonmun = html.getHtmlPage(strDomain,Integer.parseInt(strHttpPort),strReadPage,para.toString());

						//GCmFcts.setWriteFile(strPpath+fldpath,filename,bonmun);
                                             //-------------------5.10 �߰��κ�
                                                dmProp.setProperty("Conts",bonmun);
                                                dmProp.setProperty("Docno",strDocNo);

                                                docTran.updateContsDoc(cp, dmProp, msgInfo);

                                                 if(Integer.parseInt(seq)>01){
                                                      GCmFcts.copyFile(srcFile, desFile);
                                                 }
                                             //---------------------



				   // }

                                   // else   GCmFcts.copyFile(srcFile,desFile);
				//}

			}


			return true;

		}
		catch (Exception e)
		{

			System.out.println("GCoWmMailTran ::  setCopyFld() " + e.getMessage());

			return false;


		}
		finally
		{

		}
	}
	*/

	public boolean setCopyFld(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strBoxNo     = dmProp.getString("BOXNO");
		String strMailNo   = dmProp.getString("MAILNO");
		String strRegMailNo   = dmProp.getString("REGMAILNO");
		String strFldBoxNo = dmProp.getString("FLDBOXNO");
		String strFldNo     = dmProp.getString("FLDNO");
		String strUserId   = dmProp.getString("USERID");
		String strUserName   = dmProp.getString("USERNAME");
		String strPpath = dmProp.getString("PPATH");
		String strDomain     = dmProp.getString("DOMAIN");
		String strReadPage   = dmProp.getString("READPAGE");
		String strHttpPort   = dmProp.getString("HTTPPORT");

		int intRet = 0;

        java.io.File srcFile = null;        // ������ ����
        java.io.File desFile = null;        // ����� ����


        String strDocNo = "";                  // �űԹ�����ȣ
        String strOldDocNo =  "";              // ����������ȣ
        String strTitle = "";                  // ����
        java.util.Vector vDoc = new java.util.Vector();     // ������� ����Ʈ



		GTpDoc doc = new GTpDoc();
		GTpDocFolder docFolder = new GTpDocFolder();
		GTpMail mail = new GTpMail();
                GCoDoDocTran docTran = new GCoDoDocTran();

		try
		{
	        String strRegDate = GCmDateFcts.dateToStr(new java.util.Date(),2);    // �����

			dmProp.setProperty("COMCODE", strComCode);
			dmProp.setProperty("REGMAILNO", strRegMailNo);


			GCmResultSet rs = mail.getMailInfo(cp, dmProp, msgInfo);

			rs.next();

			strOldDocNo = rs.getString("DOCNO");
			strTitle = rs.getString("TITLE");


			// �������(����������)�� �Է�
	        // -- ��������
			dmProp.setProperty("Docno", strOldDocNo);

			GCmResultSet rs3 = doc.getDocInfo(cp, dmProp, msgInfo);

			rs3.next();


		    // -- �ű��Է�
			dmProp.setProperty("Title", rs3.getString("TITLE"));
			dmProp.setProperty("Doctype", "2");
			dmProp.setProperty("Attnum", rs3.getString("FILENUM"));
			dmProp.setProperty("Reguser", rs3.getString("REGUSER"));
			dmProp.setProperty("Regdate", rs3.getString("REGDATE"));
			dmProp.setProperty("Moduser", strUserId);
			dmProp.setProperty("Moddate", strRegDate);


			doc.insertDoc(cp, dmProp, msgInfo);


			strDocNo = dmProp.getProperty("Docno");



	        // ������Ͽ� �Է�
			dmProp.setProperty("Boxno", strFldBoxNo);
			dmProp.setProperty("Docno", strDocNo);
			dmProp.setProperty("Parentno", strFldNo);
			dmProp.setProperty("Boxname", strTitle);
			dmProp.setProperty("Userno", strUserId);
			dmProp.setProperty("Regdate", strRegDate);
			dmProp.setProperty("Trashflag", "1");
			dmProp.setProperty("Comments", "");
			dmProp.setProperty("Refno", "C"+strRegMailNo+strBoxNo);



			docFolder.insertFolder(cp, dmProp, msgInfo);



			dmProp.setProperty("USERID", strUserId);
			dmProp.setProperty("Boxno", strBoxNo);
			dmProp.setProperty("Fldno", strFldNo);
			dmProp.setProperty("Boxname", "");

			String strFldNoPath = docFolder.getFldnoPath(cp, dmProp, msgInfo);

	        //String fldpath = "/DATA/" + strComCode + "/BOX/" + strFldBoxNo + "/" + strFldNoPath; // �����
                String fldpath = "/DATA/" + strComCode + "/BOX/" + strRegDate.substring(0,6) +"/"+strRegDate.substring(6,8)+ "/" + strFldNoPath; // �����
                java.io.File oFile = null;
		    java.util.Vector vec= new java.util.Vector();
			String fld = "";
	        String tmp = "";


			tmp = fldpath.substring(0,1);
	        if (tmp.equals("/"))
		        fldpath = fldpath.substring(1,fldpath.length());

			vec = GCmFcts.getSplit(fldpath,"/");

	        for (int i=0;i<vec.size();i++)
			{
				fld += (String)vec.elementAt(i) + "/";
	            oFile = new java.io.File(strPpath + "/" +fld);

		        if (!oFile.isDirectory()) oFile.mkdir();
			}



			// �����󼼸��
		    String seq = "";
	        String conttype = "";
		    String titleLst = "";
			String fileext = "";
	        String oldfilename = "";
		    String filename = "";
			String vpath = "";
	        String mimetype = "";
		    int filesize = 0;
			String orgname = "";
	        String orgpath = "";
		    String reguserLst = "";
			String regdateLst = "";
	        String moduserLst = "";
		    String moddateLst = "";
			String despath = fldpath;


			// �����󼼸�Ͽ� �Է�
			dmProp.setProperty("Docno", strOldDocNo);
			dmProp.setProperty("Seq", "00");

			GCmResultSet rs2 = doc.getDocDtlList(cp, dmProp, msgInfo);


			while(rs2.next())
			{

	            seq = rs2.getString("SEQ");
		        conttype = rs2.getString("CONTTYPE");
			    titleLst = rs2.getString("TITLE");
				fileext = rs2.getString("FILEEXT");
	            oldfilename = rs2.getString("FILENAME");
		        vpath = rs2.getString("VPATH");
                           mimetype = rs2.getString("MIMETYPE");
	            filesize = rs2.getInt("FILESIZE");
		        orgname = rs2.getString("ORGNAME");
			    orgpath = rs2.getString("ORGPATH");
	            reguserLst = rs2.getString("REGUSER");
		        regdateLst = rs2.getString("REGDATE");
			    moduserLst = rs2.getString("MODUSER");
	            moddateLst = rs2.getString("MODDATE");

				// �����󼼸�Ͽ� �Է�
	            filename = strDocNo + "_" + seq + fileext;


				dmProp.setProperty("Docno", strDocNo);
				dmProp.setProperty("Seq", seq);
				dmProp.setProperty("Conttype", conttype);
				dmProp.setProperty("Title", titleLst);
				dmProp.setProperty("Fileext", fileext);
				dmProp.setProperty("Filename", filename);
				dmProp.setProperty("Vpath", fldpath);
				dmProp.setProperty("Mimetype", mimetype);
				dmProp.setProperty("Filesize", String.valueOf(filesize));
				dmProp.setProperty("Orgname", orgname);
				dmProp.setProperty("Orgpath", orgpath);
				dmProp.setProperty("Reguser", reguserLst);
				dmProp.setProperty("Regdate", regdateLst);
				dmProp.setProperty("Moduser", strUserId);
				dmProp.setProperty("Moddate", strRegDate);

				doc.insertAttDoc(cp, dmProp, msgInfo);


	                        // ���Ϻ���...
				srcFile = new java.io.File(strPpath+vpath,oldfilename);
	                        desFile = new java.io.File(strPpath+fldpath,filename);

				//if (srcFile.isFile()){

                                    // if (seq.equals("01")) { // ���������� ���Ŀ� �°� �Է�...

                                      // URL ����...

						StringBuffer para = new StringBuffer();

					    para.append("comcode=").append(strComCode).append("&userid=").append(strUserId)
						    .append("&boxno=").append(strBoxNo).append("&mailno=").append(strMailNo)
							.append("&regmailno=").append(strRegMailNo).append("&from=copyfld");

						GCmHtmlPageSaver html = new GCmHtmlPageSaver();

						String bonmun = html.getHtmlPage(strDomain,Integer.parseInt(strHttpPort),strReadPage,para.toString());

						//GCmFcts.setWriteFile(strPpath+fldpath,filename,bonmun);
                                             //-------------------5.10 �߰��κ�
                                                dmProp.setProperty("Conts",bonmun);
                                                dmProp.setProperty("Docno",strDocNo);

                                                docTran.updateContsDoc(cp, dmProp, msgInfo);

                                                 if(Integer.parseInt(seq)>01){
                                                      GCmFcts.copyFile(srcFile, desFile);
                                                 }
                                             //---------------------



				   // }

                                   // else   GCmFcts.copyFile(srcFile,desFile);
				//}

			}


			return true;

		}
		catch (Exception e)
		{

			System.out.println("GCoWmMailTran ::  setCopyFld() " + e.getMessage());

			return false;


		}
		finally
		{

		}
	}



}