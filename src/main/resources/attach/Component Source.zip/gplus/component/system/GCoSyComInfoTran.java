package gplus.component.system;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

/**
 * <PRE>
 * Filename		: GCoSyComInfoTran.java
 * Class		: gplus.component.pos.GCoSyComInfoTran
 * Fuction		: ȸ�� �⺻���� �� �ý��� ������ ������
 * Comment		:
 * History      : 03/19/2002, ������, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCoSyComInfoTran extends GCmTopComponent
{
   /**
    * <PRE>
    *    ���޵� ȸ�����ڵ带 ���Ͽ� �ش� ȸ����ȯ�������� ��ȭ��ũ��� ����ȭ��ũ�� �˻����� ����Ѵ�.
    * </PRE>
    *
    * @param cp        a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE  : current user companycode at session
    *                      <LI> String nKbTotal : ��ȭ��ũ��
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          N/A
    */
	public int updateCurFileSize(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String nKbTotal = dmProp.getString("nKbTotal");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" UPDATE TB_COMM_Z10 ")
					.append(" SET CURFILESIZE = "+genQuote(nKbTotal)+", CHKFILEDATE = "+genQuote(gplus.commlib.util.GCmDateFcts.dateToStr(new java.util.Date(),2)))
					.append(" WHERE COMCODE = "+genQuote(COMCODE));

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			  rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoSyComInfoTran::updateCurFileSize : " + ignored.getMessage());
			}

	 		System.out.println(" GCoSyComInfoTran::updateCurFileSize : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoSyComInfoTran::updateCurFileSize : " + e.getMessage());
			}
			conn.close();
		}
	}

   /**
    * <PRE>
    *    ���޵� ȸ�����ڵ带 ���Ͽ� �ش� �⺻���ϼ����� �⺻SMTP���� ������ ����ϸ�,
    *    ���ϸ�� ����� ��ü�� �⺻���ϼ����� �⺻SMTP������ �ϰ� �����Ѵ�.
    * </PRE>
    *
    * @param cp        a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String Mailsvr : �⺻���ϼ���
    *                      <LI> String Smtpsvr : �⺻SMTP����
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          N/A
    */
	public int updateMailSvrSave(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Mailsvr = dmProp.getString("Mailsvr");
		String Smtpsvr = dmProp.getString("Smtpsvr");
                String Boardlmt = dmProp.getString("boardLmt");
                String Draftlmt = dmProp.getString("draftLmt");
                String Maillmt = dmProp.getString("mailLmt");
                String Doclmt = dmProp.getString("docLmt");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();
			stmt = conn.createStatement();

                        int boardLmt = Integer.parseInt(Boardlmt)* (1024 * 1024);
                        int draftLmt = Integer.parseInt(Draftlmt)* (1024 * 1024);
                        int mailLmt = Integer.parseInt(Maillmt)* (1024 * 1024);
                        int docLmt = Integer.parseInt(Doclmt)* (1024 * 1024);

			conn.setAutoCommit(true);

			StringBuffer SqlQuery = new StringBuffer()
					.append(" UPDATE TB_COMM_Z10 ")
					.append(" SET MAILSVR = "+genQuote(Mailsvr)+", SMTPSVR = "+genQuote(Smtpsvr))
                                        .append(" , BOARDLMT = "+boardLmt)
                                        .append(" , DRAFTLMT = "+draftLmt)
                                        .append(" , MAILLMT = "+mailLmt)
                                        .append(" , DOCLMT = "+docLmt)
					.append(" WHERE COMCODE = "+genQuote(COMCODE));

			rv = stmt.executeUpdate(SqlQuery.toString());

            if( rv <= 0 ) throw new Exception("1 During insertNewCompany error !!!");

			SqlQuery = new StringBuffer()
			    .append(" UPDATE TB_"+COMCODE+"_C30 ")
			    .append(" SET POP3SVR= "+genQuote(Mailsvr)+", SMTPSVR = "+genQuote(Smtpsvr))
                            .append(" WHERE DEFLT = '0' ");
			stmt.executeUpdate(SqlQuery.toString());
          //  if( rv <= 0 ) throw new Exception("2 During insertNewCompany error !!!");

			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
                                System.out.println(" GCoSyComInfoTran::updateMailSvrSave 1: " + e.getMessage());
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoSyComInfoTran::updateMailSvrSave 2: " + ignored.getMessage());
			}

	 		System.out.println(" GCoSyComInfoTran::updateMailSvrSave 3: " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoSyComInfoTran::updateMailSvrSave : " + e.getMessage());
			}
			conn.close();
		}
	}


   /**
    * <PRE>
    *    ���޵� �Ķ��Ÿ���� �޾Ƽ� ȸ������ ����� ������ �����Ѵ�.
    * </PRE>
    *
    * @param cp        a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE     : current user companycode at session
    *                      <LI> String COMNAME     : ȸ���̸�
    *                      <LI> String ADDR        : ȸ���ּ�
    *                      <LI> String CEO         : CEO�̸�
    *                      <LI> String FAX         : FAX��ȣ
    *                      <LI> String TEL         : ��ȭ��ȣ
	*                      <LI> String MANAGER     : ������ ID
    *                      <LI> String MAXUSER     : �ִ� ����� ��
    *                      <LI> String CURFILESIZE : ���� ���� Size
	*                      <LI> String LMTFILESIZE : ���ѵ� ���� Size
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          N/A
    */

    public int updateComInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE     = dmProp.getString("COMCODE");
        String COMNAME     = dmProp.getString("COMNAME");
        String ADDR        = dmProp.getString("ADDR");
        String CEO         = dmProp.getString("CEO");
        String FAX         = dmProp.getString("FAX");
        String TEL         = dmProp.getString("TEL");
        String MANAGER     = dmProp.getString("MANAGER");
        String MAXUSER     = dmProp.getString("MAXUSER");
        String CURFILESIZE = dmProp.getString("CURFILESIZE");
        String LMTFILESIZE = dmProp.getString("LMTFILESIZE");


		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" UPDATE TB_COMM_Z10 ")
					.append(" SET COMNAME= "+genQuote(COMNAME)+", LMTFILESIZE = "+ genQuote(LMTFILESIZE))
                    .append(" , CURFILESIZE= "+ genQuote(CURFILESIZE) +", MAXUSER = "+ genQuote(MAXUSER) )
                    .append(" , ADDR= "+genQuote(ADDR)+", TEL = "+genQuote(TEL))
                    .append(" , FAX= "+genQuote(FAX)+", CEO = "+genQuote(CEO))
                    .append(" , MANAGER= "+genQuote(MANAGER))
					.append(" WHERE COMCODE = "+genQuote(COMCODE));

			stmt = conn.createStatement();
			conn.setAutoCommit(false);

            rv = stmt.executeUpdate(SqlQuery.toString());

			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoSyComInfoTran::updateComInfo : " + ignored.getMessage());
			}

	 		System.out.println(" GCoSyComInfoTran::updateComInfo : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoSyComInfoTran::updateComInfo : " + e.getMessage());
			}
			conn.close();
		}
	}

   /**
    * <PRE>
    *    ���ο� ȸ���縦 ����Ѵ�.
    * </PRE>
    *
    * @param cp        a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE     : current user companycode at session
    *                      <LI> String COMNAME     : ȸ���̸�
	*                      <LI> String CURFILESIZE : ���� ���� Size
	*                      <LI> String LMTFILESIZE : ���ѵ� ���� Size
	*                      <LI> String MAXUSER     : �ִ� ����� ��
    *                      <LI> String ADDR        : ȸ���ּ�
	*                      <LI> String TEL         : ��ȭ��ȣ
	*                      <LI> String FAX         : FAX��ȣ
    *                      <LI> String CEO         : CEO�̸�
	*                      <LI> String MANAGER     : ������ ID
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          N/A
    */
    public int insertComInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE     = dmProp.getString("COMCODE");
        String COMNAME     = dmProp.getString("COMNAME");
        String LMTFILESIZE = dmProp.getString("LMTFILESIZE");
        String CURFILESIZE = dmProp.getString("CURFILESIZE");
        String MAXUSER     = dmProp.getString("MAXUSER");
        String ADDR        = dmProp.getString("ADDR");
        String TEL         = dmProp.getString("TEL");
        String FAX         = dmProp.getString("FAX");
        String CEO         = dmProp.getString("CEO");
        String MANAGER     = dmProp.getString("MANAGER");

        int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" INSERT INTO TB_COMM_Z10 (COMCODE,COMNAME,LMTFILESIZE,CURFILESIZE,MAXUSER, ")
                    .append(" ADDR,TEL,FAX,CEO,MANAGER) VALUES (")
					.append(genQuote(COMCODE)).append(",").append(genQuote(COMNAME)).append(",")
                    .append(genQuote(LMTFILESIZE)).append(",").append(genQuote(CURFILESIZE)).append(",")
                    .append(genQuote(MAXUSER)).append(",").append(genQuote(ADDR)).append(",")
                    .append(genQuote(TEL)).append(",").append(genQuote(FAX)).append(",")
                    .append(genQuote(CEO)).append(",").append(genQuote(MANAGER)).append(")");


			stmt = conn.createStatement();
			conn.setAutoCommit(false);

            rv = stmt.executeUpdate(SqlQuery.toString());

			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoSyComInfoTran::insertComInfo : " + ignored.getMessage());
			}

	 		System.out.println(" GCoSyComInfoTran::insertComInfo : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoSyComInfoTran::insertComInfo : " + e.getMessage());
			}
			conn.close();
		}
	}

   /**
    * <PRE>
    *    �Խ�/����/����/�������� ��Ͽ� ���ο� ȸ�������� �߰��Ѵ�.
    * </PRE>
    *
    * @param cp        a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE   : current user companycode at session
    *                      <LI> String PARENTNO  : ������ ��ȣ
	*                      <LI> String BOXCLASS  : ������
	*                      <LI> String EXECCLASS : ������ ����
	*                      <LI> String BOXTYPE   : ������
    *                      <LI> String BOXNAME   : ���̸�
	*                      <LI> String BASEFLAG  : �⺻�Կ���
	*                      <LI> String PUBFLAG   : �����Կ���
    *                      <LI> String EXECFLAG  : �����Կ���
	*                      <LI> String ADMIN     : ������ ID
	*                      <LI> String USERID    : ������
	*                      <LI> String REGDATE   : �����
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          N/A
    */
    public int insertBox(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE     = dmProp.getString("COMCODE");
        String PARENTNO    = dmProp.getString("PARENTNO");
        String BOXCLASS    = dmProp.getString("BOXCLASS");
        String EXECCLASS   = dmProp.getString("EXECCLASS");
        String BOXTYPE     = dmProp.getString("BOXTYPE");
        String BOXNAME     = dmProp.getString("BOXNAME");
        String BASEFLAG    = dmProp.getString("BASEFLAG");
        String PUBFLAG     = dmProp.getString("PUBFLAG");
        String EXECFLAG    = dmProp.getString("EXECFLAG");
        String ADMIN       = dmProp.getString("ADMIN");
        String USERID      = dmProp.getString("USERID");
        String REGDATE     = dmProp.getString("REGDATE");

        int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" INSERT INTO TB_").append(COMCODE).append("_M10 ( ")
                    .append(" BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,BOXTYPE,BOXNAME, ")
                    .append(" BASEFLAG,PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE) VALUES (")
					.append(genQuote(COMCODE))
                    .append(" ,'', ")
                    .append(genQuote(PARENTNO)).append(",").append(genQuote(BOXCLASS)).append(",")
                    .append(genQuote(EXECCLASS)).append(",").append(genQuote(BOXTYPE)).append(",")
                    .append(genQuote(BOXNAME)).append(",").append(genQuote(BASEFLAG)).append(",")
                    .append(genQuote(PUBFLAG)).append(",").append(genQuote(EXECFLAG)).append(",")
                    .append(genQuote(USERID)).append(",").append(genQuote(REGDATE)).append(")");


			stmt = conn.createStatement();
			conn.setAutoCommit(false);

            rv = stmt.executeUpdate(SqlQuery.toString());

			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoSyComInfoTran::insertBox : " + ignored.getMessage());
			}

	 		System.out.println(" GCoSyComInfoTran::insertBox : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoSyComInfoTran::insertBox : " + e.getMessage());
			}
			conn.close();
		}
	}

   /**
    * <PRE>
    *    ��ϵǾ� �ִ� ȸ���縦 �����Ѵ�.
    * </PRE>
    *
    * @param cp        a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE   : current user companycode at session
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          N/A
    */

    public int deleteCompany(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE     = dmProp.getString("COMCODE");

                int rv;
                String[] Tables = {"A01","B10","C10","C11","C20","C30","D10","D11","D20","D30","D31","E10",
                                   "G10","F10","F11","F30","F31","F50","L10","L11","M10",
                                   "M20","N10","N11","N20","N30"};

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			conn.setAutoCommit(false);

			StringBuffer SqlQuery = new StringBuffer();
			stmt = conn.createStatement();

                        for(int i=0; i<Tables.length;i++) {
                            SqlQuery = new StringBuffer()
                                   .append("  DROP TABLE TB_").append(COMCODE).append("_"+Tables[i]);
                            rv = stmt.executeUpdate(SqlQuery.toString());
                        }

                        SqlQuery = new StringBuffer()
                             .append(" DELETE FROM TB_COMM_Z10 WHERE COMCODE = "+genQuote(COMCODE));
                        rv = stmt.executeUpdate(SqlQuery.toString());

                        SqlQuery = new StringBuffer()
                             .append(" DELETE FROM TB_COMM_Z20 WHERE COMCODE = "+genQuote(COMCODE));
                        rv = stmt.executeUpdate(SqlQuery.toString());

			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoSyComInfoTran::deleteCompany : " + ignored.getMessage());
			}

	 		System.out.println(" GCoSyComInfoTran::deleteCompany : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoSyComInfoTran::deleteCompany : " + e.getMessage());
			}
			conn.close();
		}
	}

   /**
    * <PRE>
    *    Defalut�� �Խ�/����/����/�������� �����Ѵ�.
    * </PRE>
    *
    * @param cp        a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
	*                      <LI> String USERID       : ������
    *                      <LI> String COMCODE      : current user companycode at session
    *                      <LI> String Comname      : ȸ���̸�
	*                      <LI> String Admin        : ������ ID
	*                      <LI> String Passwd       : �н�����
	*                      <LI> String Addr         : ȸ���� �ּ�
	*                      <LI> String Tel          : ��ȭ��ȣ
    *                      <LI> String Fax          : FAX��ȣ
	*                      <LI> String Ceo          : CEO ID
	*                      <LI> String Manager      : ������ ID
    *                      <LI> String Maxuser      : �ִ� �ο���
	*                      <LI> String Lmtfilesize  : ���� ��뷮
	*                      <LI> String Curfilesize  : ���� ��뷮
	*                      <LI> String Maxnotitab   : �ִ� �Խù� ���� ����
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          N/A
    */
    public int insertNewCompany(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String USERID      = dmProp.getString("USERID");
		String Comcode     = dmProp.getString("Comcode");
		String Comname     = dmProp.getString("Comname");
		String Admin       = dmProp.getString("Admin");
		String Passwd      = dmProp.getString("Passwd");
		String Addr        = dmProp.getString("Addr");
		String Tel         = dmProp.getString("Tel");
		String Fax         = dmProp.getString("Fax");
		String Ceo         = dmProp.getString("Ceo");
		String Manager     = dmProp.getString("Manager");
		String Maxuser     = dmProp.getString("Maxuser");
		String Lmtfilesize = dmProp.getString("Lmtfilesize");
		String Curfilesize = dmProp.getString("Curfilesize");
		String Maxnotitab  = dmProp.getString("Maxnotitab");

        String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

        int rv = 0;

		GCmConnection conn = null;
		Statement stmt = null;
        StringBuffer sqlQueryBuff = null;

		try
		{
            String Regdate = gplus.commlib.util.GCmDateFcts.dateToStr(new java.util.Date(),2);

			conn = GCmDbManager.getInstance().getConnection();
            stmt = conn.createStatement();
			String strSchemaFile = null;

            conn.setAutoCommit(true);

            if (strDbType.equals("oracle"))
			{
				strSchemaFile = cp.getProperty("gplus.system.docroot")+"/System/gplus_schema_oracle.sql";
			}
			else if (strDbType.equals("mssql"))
			{
				strSchemaFile = cp.getProperty("gplus.system.docroot")+"/System/gplus_schema_mssql.sql";
			}

			BufferedReader br = new BufferedReader(new FileReader(strSchemaFile));
			StringBuffer szCrSchema = new StringBuffer();

			while (br.ready())
			{
				String strLine = br.readLine();

				if (!strLine.trim().startsWith("#"))
				{
					szCrSchema.append(strLine);
					szCrSchema.append("\n");
				}
			}

			StringTokenizer st = new StringTokenizer(replace((szCrSchema.toString()).trim(),
			                  "comcodehere!",Comcode), ";");

			while (st.hasMoreTokens())
			{
				String strQuery = st.nextToken();

				if (!strQuery.equals(""))
				{
					stmt.executeUpdate(strQuery);
				}
			}
                        sqlQueryBuff = new StringBuffer()
                                 .append(" INSERT INTO TB_COMM_Z10 (COMCODE,COMNAME,LMTFILESIZE,CURFILESIZE,MAXUSER,ADDR,TEL,FAX,CEO,MANAGER,BOARDLMT,DRAFTLMT,MAILLMT,DOCLMT) VALUES (")
                                 .append(" "+genQuote(Comcode)+","+genQuote(Comname)+","+Lmtfilesize+","+Curfilesize+","+Maxuser+","+genQuote(Addr)+",")
                                 .append(" "+genQuote(Tel)+","+genQuote(Fax)+","+genQuote(Ceo)+","+genQuote(Manager)+",2,2,2,2)");

	                rv = stmt.executeUpdate(sqlQueryBuff.toString());
                        if( rv <= 0 ) throw new Exception(" During insertNewCompany error !!!");

                        String Boxno = getMaxBoxNo(Comcode,strDbType);

                        sqlQueryBuff = new StringBuffer()
								.append(" INSERT INTO TB_"+Comcode+"_M10 (BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,BOXTYPE,BOXNAME,BASEFLAG,PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE) ")
                                .append(" VALUES("+genQuote(Boxno)+",'','000000000000','2','2','2',"+genQuote(Admin+" ������")+",'1',")
                                .append("        '1','0',"+genQuote(Admin)+","+genQuote(USERID)+","+genQuote(Regdate)+") ");

	                rv = stmt.executeUpdate(sqlQueryBuff.toString());
                        if( rv <= 0 ) throw new Exception(" During insertNewCompany error !!!");

                        String docboxno = Boxno;

                        sqlQueryBuff = new StringBuffer()
								.append(" INSERT INTO TB_"+Comcode+"_M20 (BOXNO,USERID,DOCREAD,DOCWRITE,DOCDEL,DOCDELADM,FLDMAKE,FLDDEL) ")
								.append(" VALUES ("+genQuote(Boxno)+","+genQuote(Admin)+",'0','0','0','0','0','0') ");

	                rv = stmt.executeUpdate(sqlQueryBuff.toString());
                        if( rv <= 0 ) throw new Exception(" During insertNewCompany error !!!");

                        String Folderno = getMaxFolderNo(Comcode,strDbType);

                        sqlQueryBuff = new StringBuffer()
								.append(" INSERT INTO TB_"+Comcode+"_B10 (FLDNO,BOXNO,DOCNO,PARENTNO,FLDNAME,REGUSER,REGDATE,TRASHFLAG,COMMENTS,REFNO) ")
								.append(" VALUES ("+genQuote(Folderno)+","+genQuote(Boxno)+",'','000000000000',"+genQuote(Admin+" ������")+","+genQuote(Admin)+",")
                                       .append("         "+genQuote(Regdate)+",'','','')");

	                rv = stmt.executeUpdate(sqlQueryBuff.toString());
                        if( rv <= 0 ) throw new Exception(" During insertNewCompany error !!!");

                        String Boxname = "";
                        for (int i =1; i<5; i++) {
                          if(i==1)
                          {
                              Boxname = "����������";
                          }
                          else if(i==2)
                          {
                              Boxname = "����������";
                          }
                          else if(i==3)
                          {
                              Boxname = "����������";
                          }
                          else if(i==4)
                          {
                              Boxname = "�ӽú�����";
                          }

                          Boxno = getMaxBoxNo(Comcode,strDbType);

                          sqlQueryBuff = new StringBuffer()
	  							.append(" INSERT INTO TB_"+Comcode+"_M10 (BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,BOXTYPE,BOXNAME,BASEFLAG,PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE) ")
                                .append(" VALUES("+genQuote(Boxno)+",'','000000000000','3',"+genQuote(String.valueOf(i))+",'2',"+genQuote(Boxname)+",'1',")
                                .append("        '1','0',"+genQuote(Admin)+","+genQuote(USERID)+","+genQuote(Regdate)+") ");

	                  rv = stmt.executeUpdate(sqlQueryBuff.toString());
                          if( rv <= 0 ) throw new Exception(" During insertNewCompany error !!!");

                          sqlQueryBuff = new StringBuffer()
					  	         .append(" INSERT INTO TB_"+Comcode+"_M20 (BOXNO,USERID,DOCREAD,DOCWRITE,DOCDEL,DOCDELADM,FLDMAKE,FLDDEL) ")
						         .append(" VALUES ("+genQuote(Boxno)+","+genQuote(Admin)+",'0','0','0','0','0','0') ");

	                  rv = stmt.executeUpdate(sqlQueryBuff.toString());
                          if( rv <= 0 ) throw new Exception(" During insertNewCompany error !!!");
                       }

                       for (int i =1; i<6; i++) {

                          if(i==1)
                          {
                              Boxname = "����������";
                          }
                          else if(i==2)
                          {
                              Boxname = "����������";
                          }
                          else if(i==3)
                          {
                              Boxname = "�Ϸ������";
                          }
                          else if(i==4)
                          {
                              Boxname = "�ݷ�������";
                          }
                          else if(i==5)
                          {
                              Boxname = "�ӽú�����";
                          }

                          Boxno = getMaxBoxNo(Comcode,strDbType);
                          sqlQueryBuff = new StringBuffer()
	  					         .append(" INSERT INTO TB_"+Comcode+"_M10 (BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,BOXTYPE,BOXNAME,BASEFLAG,PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE) ")
                                 .append(" VALUES("+genQuote(Boxno)+",'','000000000000','4',"+genQuote(String.valueOf(i))+",'2',"+genQuote(Boxname)+",'1',")
                                 .append("        '1','0',"+genQuote(Admin)+","+genQuote(USERID)+","+genQuote(Regdate)+") ");

	                  rv = stmt.executeUpdate(sqlQueryBuff.toString());
                          if( rv <= 0 ) throw new Exception(" During insertNewCompany error !!!");

                          sqlQueryBuff = new StringBuffer()
			  					 .append(" INSERT INTO TB_"+Comcode+"_M20 (BOXNO,USERID,DOCREAD,DOCWRITE,DOCDEL,DOCDELADM,FLDMAKE,FLDDEL) ")
						         .append(" VALUES ("+genQuote(Boxno)+","+genQuote(Admin)+",'0','0','0','0','0','0') ");

	                  rv = stmt.executeUpdate(sqlQueryBuff.toString());
                          if( rv <= 0 ) throw new Exception(" During insertNewCompany error !!!");

                       }

            	       sqlQueryBuff = new StringBuffer()
							   .append(" INSERT INTO TB_").append(Comcode).append("_N11 (ORGNO,USERID,DEFLT) ")
							   .append(" VALUES ('000000000000',"+genQuote(Admin)+",'0') ");

                       rv = stmt.executeUpdate(sqlQueryBuff.toString());
                       if( rv <= 0 ) throw new Exception(" During insertNewCompany error !!!");

            	       sqlQueryBuff = new StringBuffer()
								.append(" INSERT INTO TB_COMM_Z20 ")
								.append(" ( USERID,PASSWD,ORGNO,POSCODE,USERNAME,SECLVL,ALARMFLAG,ALARMTIME,ALARMREPEAT,BOXNO,COMCODE,PAGESIZE) ")
                                        .append("   VALUES("+genQuote(Admin)+","+genQuote(Passwd)+",'000000000000','00',"+genQuote(Admin)+",'7','1',0,0,"+genQuote(docboxno)+","+genQuote(Comcode)+",'20')");

                       rv = stmt.executeUpdate(sqlQueryBuff.toString());
                       if( rv <= 0 ) throw new Exception(" During insertNewCompany error !!!");

                       Boxno = getMaxBoxNo(Comcode,strDbType);

                       sqlQueryBuff = new StringBuffer()
 					            .append(" INSERT INTO TB_"+Comcode+"_M10 (BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,BOXTYPE,BOXNAME,BASEFLAG,PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE) ")
                                .append(" VALUES("+genQuote(Boxno)+",'','000000000000','1','1','1','ȸ��Խ���','0',")
                                .append("        '0','1',"+genQuote(Admin)+","+genQuote(USERID)+","+genQuote(Regdate)+") ");

						rv = stmt.executeUpdate(sqlQueryBuff.toString());
                       if( rv <= 0 ) throw new Exception(" During insertNewCompany error !!!");

                       String parentboxno = Boxno;

                       Boxno = getMaxBoxNo(Comcode,strDbType);
                       sqlQueryBuff = new StringBuffer()
 								 .append(" INSERT INTO TB_"+Comcode+"_M10 (BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,BOXTYPE,BOXNAME,BASEFLAG,PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE) ")
								 .append(" VALUES("+genQuote(Boxno)+",'',"+genQuote(parentboxno)+",'1','1','1','��������','0',")
                                 .append("        '0','0',"+genQuote(Admin)+","+genQuote(USERID)+","+genQuote(Regdate)+") ");

	               rv = stmt.executeUpdate(sqlQueryBuff.toString());
                       if( rv <= 0 ) throw new Exception(" During insertNewCompany error !!!");

                       Boxno = getMaxBoxNo(Comcode,strDbType);
                       sqlQueryBuff = new StringBuffer()
		                         .append(" INSERT INTO TB_"+Comcode+"_M10 (BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,BOXTYPE,BOXNAME,BASEFLAG,PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE) ")
                                 .append(" VALUES("+genQuote(Boxno)+",'',"+genQuote(parentboxno)+",'1','1','1','����Խ���','0',")
                                 .append("        '0','0',"+genQuote(Admin)+","+genQuote(USERID)+","+genQuote(Regdate)+") ");

	               rv = stmt.executeUpdate(sqlQueryBuff.toString());
                       if( rv <= 0 ) throw new Exception(" During insertNewCompany error !!!");

                       Boxno = getMaxBoxNo(Comcode,strDbType);
                       sqlQueryBuff = new StringBuffer()
		 			              .append(" INSERT INTO TB_"+Comcode+"_M10 (BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,BOXTYPE,BOXNAME,BASEFLAG,PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE) ")
                                  .append(" VALUES("+genQuote(Boxno)+",'',"+genQuote(parentboxno)+",'1','1','1','������','0',")
                                  .append("        '0','0',"+genQuote(Admin)+","+genQuote(USERID)+","+genQuote(Regdate)+") ");

	               rv = stmt.executeUpdate(sqlQueryBuff.toString());
                       if( rv <= 0 ) throw new Exception(" During insertNewCompany error !!!");

                       Boxno = getMaxBoxNo(Comcode,strDbType);
                       sqlQueryBuff = new StringBuffer()
 					              .append(" INSERT INTO TB_"+Comcode+"_M10 (BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,BOXTYPE,BOXNAME,BASEFLAG,PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE) ")
                                  .append(" VALUES("+genQuote(Boxno)+",'','000000000000','2','1','1','ȸ�繮����','0',")
                                  .append("        '0','0','sys',"+genQuote(USERID)+","+genQuote(Regdate)+") ");

	               rv = stmt.executeUpdate(sqlQueryBuff.toString());
                       if( rv <= 0 ) throw new Exception(" During insertNewCompany error !!!");


                       Folderno = getMaxFolderNo(Comcode,strDbType);

                       sqlQueryBuff = new StringBuffer()
						        .append(" INSERT INTO TB_"+Comcode+"_B10 (FLDNO,BOXNO,DOCNO,PARENTNO,FLDNAME,REGUSER,REGDATE,TRASHFLAG,COMMENTS,REFNO) ")
								.append(" VALUES ("+genQuote(Folderno)+","+genQuote(Boxno)+",'','000000000000','ȸ�繮����','sys',")
                                .append("         "+genQuote(Regdate)+",'','','')");

		               rv = stmt.executeUpdate(sqlQueryBuff.toString());
                       if( rv <= 0 ) throw new Exception(" During insertNewCompany error !!!");

                       return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
				dmProp.setProperty("COMCODE",Comcode);
				this.deleteCompany(cp,dmProp,msgInfo);
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoSyComInfoTran::insertNewCompany : " + ignored.getMessage());
			}

	 		System.out.println(" GCoSyComInfoTran::insertNewCompany : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoSyComInfoTran::insertNewCompany : " + e.getMessage());
			}
			conn.close();
		}
	}

    private String replace(String src, String from, String to )
    {
        if ( src == null ) return null;
             if ( from == null ) return src;
             if ( to == null ) to = "";

             StringBuffer buf = new StringBuffer();

             for(int pos; (pos = src.indexOf(from)) >= 0; ) {
                 buf.append(src.substring(0,pos));
                 buf.append(to);
                 src = src.substring(pos+from.length());
             }

              buf.append(src);
              return buf.toString();
    }

   /**
    * <PRE>
    *    �Խ�/����/����/����Ը�Ͽ� ��ϵǴ� �ű����� ��Ͻ� �ʿ��� �ű��Թ�ȣ�� �����ϴ� �����Լ��̸�,
    *    �����Ǵ� �Թ�ȣ�� �ش���+�Ϸù�ȣ������ �����ȴ�.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String strDbType : gplus db type
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return String : �ű��Թ�ȣ
    */
   	private String getMaxBoxNo(String comcode,String strDbType)
    {
		GCmConnection conn = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                             sqlQuery
		        	.append(" SELECT DECODE(SUBSTR(MAX(BOXNO),1,8),TO_CHAR(sysdate,'YYYYMMDD'),TO_CHAR(TO_NUMBER(MAX(BOXNO))+1),null,TO_CHAR(sysdate,'YYYYMMDD')||'0001') as NO ")
                           	.append(" FROM TB_").append(comcode).append("_M10 ")
                           	.append(" WHERE BOXNO LIKE TO_CHAR(sysdate,'YYYYMMDD')||'%'");
                        }
                        else if ("mssql".equals(strDbType))
                             {
                                     sqlQuery
                                        .append(" SELECT (CASE SUBSTRING(MAX(BOXNO),1,8) WHEN convert(char(08),getdate(),112) THEN CAST(SUBSTRING(MAX(BOXNO),1,8) AS varchar(8)) + RIGHT('0000'+CAST(SUBSTRING(MAX(BOXNO),9,4)+1 AS varchar(4)),4) ELSE convert(char(08),getdate(),112)+'0001' END) as NO ")
                                        .append(" FROM TB_").append(comcode).append("_M10 ")
                                        .append(" WHERE BOXNO LIKE convert(char(08),getdate(),112)+'%' ");
                             }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
                	rs.next();

			return rs.getString("NO");

      		}
      		catch (Exception e)
      		{
 			System.out.println(" GCoMeBoxsTran::getMaxNo " + e.getMessage());
	 		return null;
      		}
      		finally
      		{
			conn.close();
      		}
    	}

   /**
    * <PRE>
    *    �����Կ� ��ϵǴ� �ű� �������� ��Ͻ� �ʿ��� �ű� ������ȣ�� �����ϴ� �����Լ��̸�,
    *    �����Ǵ� ������ȣ�� �ش���+�Ϸù�ȣ������ �����ȴ�.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String strDbType : gplus db type
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return String : �ű� �����Թ�ȣ
    */
    private String getMaxFolderNo(String comcode,String strDbType)
	{

	    GCmConnection conn = null;

	    try
	    {
		    conn = GCmDbManager.getInstance().getConnection();

		    StringBuffer sqlQuery = new StringBuffer();

                    if ("oracle".equals(strDbType))
                    {
		    	sqlQuery
		           .append(" SELECT DECODE(SUBSTR(MAX(FLDNO),1,8),TO_CHAR(sysdate,'YYYYMMDD'),TO_CHAR(TO_NUMBER(MAX(FLDNO))+1),null,TO_CHAR(sysdate,'YYYYMMDD')||'0001') as NO ")
                           .append(" FROM TB_").append(comcode).append("_B10 ")
                           .append(" WHERE FLDNO LIKE TO_CHAR(sysdate,'YYYYMMDD')||'%'");
                    }
                    else if ("mssql".equals(strDbType))
                         {
                                sqlQuery
                                   .append(" SELECT (CASE SUBSTRING(MAX(FLDNO),1,8) WHEN convert(char(08),getdate(),112) THEN CAST(SUBSTRING(MAX(FLDNO),1,8) AS varchar(8)) + RIGHT('0000'+CAST(SUBSTRING(MAX(FLDNO),9,4)+1 AS varchar(4)),4) ELSE convert(char(08),getdate(),112)+'0001' END) as NO ")
                                   .append(" FROM TB_").append(comcode).append("_B10 ")
                                   .append(" WHERE FLDNO LIKE convert(char(08),getdate(),112)+'%' ");
                         }

    		    GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
                    rs.next();

		    return rs.getString("NO");

            }
            catch (Exception e)
            {
 		  System.out.println(" GCoDoDocFolderTran::getMaxNo " + e.getMessage());
	 	  return null;
            }
            finally
            {
		  conn.close();
            }
      }

}