package gplus.component.org;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

/**
 * <PRE>
 * Filename		: GCoOrOrgInfo.java
 * Class		: gplus.component.pos.GCoOrOrgInfo
 * Fuction		: ���������� ��ȸ��
 * Comment		:
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCoOrOrgInfo extends GCmTopComponent
{
       /**
        * <PRE>
        * ���޵� ������ȣ�� ������ �����ȯ�� �������� ���������μ����� ������ �˻��Ͽ� �ǵ��� �ָ�
        * ������� �����μ���, ���޸��� �Բ� �ǵ��� �ش�. ������ȣ�� "000000000000"�� ���� ��ü ������
        * ����Ʈ�� �ǵ��� �ش�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Orgno : ������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : �μ��� ����Ʈ �� �������� (USERID,COMCODE,PASSWD,ORGNO,POSCODE,USERNAME,SECLVL,TEL1,TEL2,TEL3,
        *                                 ZIPCODE,ADDR,ALARMFLAG,ALARMTIME,ALARMREPEAT,ALARMTYPE,ALARMMAILON,ALARMDRFTON,
        *                                 LOGINFLAG,LOGINDATE,BOXNO,SIGNDOCNO,INDATE,BIRTHDAY,LUNARFLAG,ORGNAME,POSNAME)
        */
	public GCmResultSet getOrgUserList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;
                String strSortSql = "";
		String COMCODE = dmProp.getString("COMCODE");
		String Orgno = dmProp.getString("Orgno");
                String optSql = dmProp.getString("optSql");
                String strSortId = dmProp.getString("SORTID");
		String strSortOpt = dmProp.getString("SORTOPT");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();


		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

                        strSortSql = getSortSQL(strSortId, strSortOpt);


                        if ("oracle".equals(strDbType))
                        {
                           sqlQuery
                              .append(" SELECT A.USERID, A.USERNAME, A.POSCODE, A.ORGNO, A.TEL1,A.TEL2,A.TEL3, B.ORGNAME, C.POSNAME, D.DEFLT ")
                              .append(" FROM TB_COMM_Z20 A, TB_").append(COMCODE).append("_N10 B, TB_").append(COMCODE).append("_N20 C, TB_").append(COMCODE).append("_N11 D ")
                              .append(" WHERE A.USERID = D.USERID AND A.POSCODE = C.POSCODE(+) AND B.ORGNO = D.ORGNO AND ")
                              .append(" A.COMCODE = "+genQuote(COMCODE));
                        }
                        else if ("mssql".equals(strDbType))
                        {
                                   sqlQuery
                                      .append(" SELECT A.USERID, A.USERNAME, A.POSCODE, A.ORGNO, A.TEL1,A.TEL2,A.TEL3, B.ORGNAME, C.POSNAME, D.DEFLT ")
                                      .append(" FROM TB_COMM_Z20 A, TB_").append(COMCODE).append("_N10 B, TB_").append(COMCODE).append("_N20 C, TB_").append(COMCODE).append("_N11 D ")
                                      .append(" WHERE A.USERID = D.USERID AND A.POSCODE *= C.POSCODE AND B.ORGNO = D.ORGNO AND ")
                                      .append("       A.COMCODE = "+genQuote(COMCODE));
                        }

                        if(Orgno != null && !Orgno.equals("000000000000"))
                        {
                              if(!(optSql.equals(""))){
                                    optSql = optSql.substring(0,optSql.length()-1);
                                    sqlQuery.append(" AND D.ORGNO IN ( "+optSql+" )");
                              }else{
                                    sqlQuery.append(" AND D.ORGNO = "+genQuote(Orgno));
                              }
                        }

                        sqlQuery.append(" ORDER BY ").append(strSortSql);


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoOrOrgInfo::getOrgUserList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}


        /**
        * <PRE> 05.03�Ͽ� �߰���
        * ���޵� �����ڵ带 ������ �����ȯ�� �������� �ش� �����ڵ��� �̸��� ���̵� ����Ʈ�� �ǵ��� �ش�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String PosCode : �����ڵ�
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : ���޺� ���̵�, �̸� ����Ʈ (USERID,USERNAME)
        */

        public GCmResultSet getOrgPosCodeUserList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;
                String COMCODE = dmProp.getString("COMCODE");
		String PosCode = dmProp.getString("PosCode");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();


		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();


                        if ("oracle".equals(strDbType))
                        {
                           sqlQuery
                              .append(" SELECT A.USERID, A.USERNAME, C.ORGNAME ")
                              .append(" FROM TB_COMM_Z20 A, TB_").append(COMCODE).append("_N20 B , TB_").append(COMCODE).append("_N10 C")
                              .append(" WHERE A.COMCODE =" + genQuote(COMCODE))
                              .append(" AND A.POSCODE = B.POSCODE ")
                              .append(" AND B.POSCODE =" + genQuote(PosCode))
                              .append(" AND A.ORGNO = C.ORGNO ")
                              .append(" ORDER BY USERNAME");
                        }
                        else if ("mssql".equals(strDbType))
                        {
                            sqlQuery
                              .append(" SELECT USERID, USERNAME ")
                              .append(" FROM TB_COMM_Z20 A, TB_").append(COMCODE).append("_N20 B , TB_").append(COMCODE).append("_N10 C")
                              .append(" WHERE A.COMCODE =" + genQuote(COMCODE))
                              .append(" AND A.POSCODE = B.POSCODE ")
                              .append(" AND B.POSCODE =" + genQuote(PosCode))
                              .append(" AND A.ORGNO = C.ORGNO ")
                              .append(" ORDER BY USERNAME");
                        }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoOrOrgInfo::getOrgUserList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}




       /**
        * <PRE>
        * ���޵� ������ȣ�� ������ �����ȯ�� �������� ���������μ����� ������ �˻��Ͽ� �ǵ��� �ָ�
        * ������� �����μ���, ���޸��� �Բ� �ǵ��� �ش�. ������ȣ�� "000000000000"�� ���� ��ü ������
        * ����Ʈ�� �ǵ��� �ش�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Orgno : ������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : �μ��� ����Ʈ �� �������� (USERID,COMCODE,PASSWD,ORGNO,POSCODE,USERNAME,SECLVL,TEL1,TEL2,TEL3,
        *                                 ZIPCODE,ADDR,ALARMFLAG,ALARMTIME,ALARMREPEAT,ALARMTYPE,ALARMMAILON,ALARMDRFTON,
        *                                 LOGINFLAG,LOGINDATE,BOXNO,SIGNDOCNO,INDATE,BIRTHDAY,LUNARFLAG,ORGNAME,POSNAME)
        */
	public GCmResultSet getOrgUserByName(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;
                String strSortId = dmProp.getString("SORTID");
		String strSortOpt = dmProp.getString("SORTOPT");
                String strSortSql = "";

		String COMCODE = dmProp.getString("COMCODE");
                String opt = dmProp.getString("pOpt");
                String q = dmProp.getString("pQ");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();
                String optSql = "";

                if (opt.toUpperCase().equals("USERID"))
                  optSql = " A.USERID LIKE '%"+q+"%'";
                else
                  optSql = " A.USERNAME LIKE '%"+q+"%'";

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();
                        strSortSql = getSortSQL(strSortId, strSortOpt);

                        if ("oracle".equals(strDbType))
                        {
			      sqlQuery
                                 .append(" SELECT A.USERID, A.USERNAME, A.POSCODE, A.ORGNO, B.ORGNAME, C.POSNAME, D.DEFLT, A.TEL1,A.TEL2,A.TEL3 ")
                                 .append(" FROM TB_COMM_Z20 A, TB_").append(COMCODE).append("_N10 B, TB_").append(COMCODE).append("_N20 C, TB_").append(COMCODE).append("_N11 D ")
                                 .append(" WHERE A.USERID = D.USERID AND A.POSCODE = C.POSCODE(+) AND B.ORGNO = D.ORGNO AND ")
                                 .append("       A.COMCODE = "+genQuote(COMCODE)+" AND "+ optSql +" ORDER BY ").append(strSortSql);
                        }
                        else if ("mssql".equals(strDbType))
                             {
                                     sqlQuery
                                        .append(" SELECT A.USERID, A.USERNAME, A.POSCODE, A.ORGNO, B.ORGNAME, C.POSNAME, D.DEFLT, A.TEL1,A.TEL2,A.TEL3 ")
                                        .append(" FROM TB_COMM_Z20 A, TB_").append(COMCODE).append("_N10 B, TB_").append(COMCODE).append("_N20 C, TB_").append(COMCODE).append("_N11 D ")
                                        .append(" WHERE A.USERID = D.USERID AND A.POSCODE *= C.POSCODE AND B.ORGNO = D.ORGNO AND ")
                                        .append("       A.COMCODE = "+genQuote(COMCODE)+" AND "+ optSql +" ORDER BY ").append(strSortSql);
                              }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoOrOrgInfo::getOrgUserList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

	/**
	 * ����
	 * @param sortid    ��������
	 * @param sortopt   ���Ĺ��
	 * @return	���ڰ�
	 */
     private String getSortSQL(String sortid, String sortopt) throws Exception {

	String sorting = " A.USERID ASC ";

	if (sortid != null && !sortid.equals("") && !sortopt.equals(""))
        {
              if(sortid.equals("POSRANK")){
                  sorting = "C."+sortid + " " + sortopt;
              }else{
                  sorting = "A."+sortid + " " + sortopt;
              }
         }

         return sorting;
     }



       /**
        * <PRE>
        * ���޵� ������ȣ�� ������ �����ȯ�� �������� ���������μ��� �̸��� ���������� �� �˻��Ͽ� �ǵ��� �ش�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Orgno : ������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : �μ��� ����Ʈ ( USERNAME, ORNO,PARENTNO,ORGNAME,READERNO )
        */
	public GCmResultSet getOrgInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String Orgno = dmProp.getString("Orgno");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
			    sqlQuery
                               .append(" SELECT A.USERNAME, B.* ")
                               .append(" FROM TB_COMM_Z20 A, TB_").append(COMCODE).append("_N10 B ")
                               .append(" WHERE A.USERID (+)= B.READERNO AND B.ORGNO = "+genQuote(Orgno));
                        }
                        else if ("mssql".equals(strDbType))
                             {
			    	   sqlQuery
                                      .append(" SELECT A.USERNAME, B.* ")
                                      .append(" FROM TB_COMM_Z20 A, TB_").append(COMCODE).append("_N10 B ")
                                      .append(" WHERE A.USERID =* B.READERNO AND B.ORGNO = "+genQuote(Orgno));
                             }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoOrOrgInfo::getOrgInfo :" + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

       /**
        * <PRE>
        * ������ Tree�� �����ϱ� ���ؼ� ���޵� ������ ����������� �˻��Ͽ� �ش��ϴ� ������������ �ǵ��� �ָ�
        * �����̸����� �������� �����Ǿ� �ǵ��� �ش�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String rootno : ����������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : ���������� ����Ʈ (ORGNO,PARENTNO,ORGNAME,READERNO)
        */
	public GCmResultSet getDrawTree(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String rootno = dmProp.getString("rootno");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT ORGNO,PARENTNO,ORGNAME,READERNO ")
                           .append(" FROM TB_").append(COMCODE).append("_N10 ")
                           .append(" WHERE PARENTNO = "+genQuote(rootno))
                           .append(" ORDER BY ORGNAME ");

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoOrOrgInfo::getDrawTree : " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}


        public GCmResultSet getDrawList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String orgno = dmProp.getString("Orgno");

                dmProp.setProperty("ORGNO",orgno);


		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT ORGNO ")
                           .append(" FROM TB_").append(COMCODE).append("_N10 ")
                           .append(" WHERE PARENTNO = "+genQuote(orgno))
                           .append(" ORDER BY ORGNAME ");

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

                        return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoOrOrgInfo::getDrawList : " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵�������ȣ�� ���ϴ� �μ��� �μ������� �ǵ��� �ش�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Orgno : ������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : �μ����� (CNT)
        */
	public GCmResultSet getOrgNoApplyUser(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String Orgno = dmProp.getString("Orgno");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT COUNT(*) AS CNT ")
                           .append(" FROM TB_").append(COMCODE).append("_N11 ")
                           .append(" WHERE ORGNO = "+genQuote(Orgno));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoOrOrgInfo::getOrgNoApplyUser " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� ������ȣ�� ���ϴ� �����μ��� �μ����� �ǵ��� �ش�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Orgno : ������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : �����μ��� (CNT)
        */
	public GCmResultSet getOrgNoApplyOrg(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String Orgno = dmProp.getString("Orgno");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT COUNT(*) AS CNT ")
                           .append(" FROM TB_").append(COMCODE).append("_N10 ")
                           .append(" WHERE PARENTNO = "+genQuote(Orgno));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoOrOrgInfo::getOrgNoApplyOrg " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� �ټ��� ����� ID�� ����ڵ��� ������ �Խ�/����/����/����Ը���� �˻��Ͽ� �Թ�ȣ�� �ǵ��� �ش�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at seeeion
        *                      <LI> String Userno : ����ڹ�ȣ  (ex)�ټ��� ID�� aa,bb,cc���·� ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : �Խ�/����/����/����Ը�� ����Ʈ (BOXNO)
        */
	public GCmResultSet getDeleteBoxList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String Userno = dmProp.getString("Userno");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT BOXNO ")
                           .append(" FROM TB_").append(COMCODE).append("_M10 ")
                           .append(" WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') AND BOXCLASS = '2' AND EXECCLASS = '2' " );

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoOrOrgInfo::getDeleteBoxList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

}