package gplus.component.org;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;
import com.jspsmart.upload.*;

import gplus.component.menu.*;
import gplus.component.system.*;

/**
 * <PRE>
 * Filename		: GCoOrOrgInfoTran.java
 * Class		: gplus.component.pos.GCoOrOrgInfoTran
 * Fuction		: ���������� ������ (���� �������� ����)
 * Comment		:
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCoOrOrgInfoTran extends GCmTopComponent
{
       /**
        * <PRE>
        * ���������� ��Ͽ� �ش� ������� ������ȣ�� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : current user id at session : �����
        *                      <LI> EntityModel tbz20 : getStrOrgNo ������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int updateUserOrgNo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
                GEmTB_Z20 tbz20 = (GEmTB_Z20)dmProp.getObject("tbz20");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" UPDATE TB_").append(COMCODE).append("_N11 ")
					.append(" SET ORGNO = "+genQuote(tbz20.getStrOrgNo()))
					.append(" WHERE USERID = "+genQuote(USERID));

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::updateUserOrgNo : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::updateUserOrgNo : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::updateUserOrgNo : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ������������Ͽ� �ű� ���� �μ����� ����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Orgno : ������ȣ
        *                      <LI> String Userno : ����ڹ�ȣ
        *                      <LI> String Deflt : �⺻����������
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int insertOrgUser(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Orgno = dmProp.getString("Orgno");
		String Userno = dmProp.getString("Userno");
		String Deflt = dmProp.getString("Deflt");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" INSERT INTO TB_").append(COMCODE).append("_N11 (ORGNO,USERID,DEFLT) ")
					.append(" VALUES ("+genQuote(Orgno)+","+genQuote(Userno)+","+genQuote(Deflt)+") ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::insertOrgUser : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::insertOrgUser : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::insertOrgUser : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * �������� �űԺμ��� ����Ѵ�.
        * ��ϵǴ� �űԺμ��� getMaxNo�Լ��� ���Ͽ� �����Ǹ� �ش���+�Ϸù�ȣ������ �����ȴ�.
        * ��ϵ� �����μ��� dmProp�� Orgno�� ��ϵȸ� ������ ������Ʈ,JSP��� �����Ҽ� �ִ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Parentno : ����������ȣ
        *                      <LI> String Orgname : �μ��̸�
        *                      <LI> String Readerno : ������
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int insertOrg(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Parentno = dmProp.getString("Parentno");
		String Orgname = dmProp.getString("Orgname");
		String Readerno = dmProp.getString("Readerno");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();
                        String Orgno = getMaxNo(COMCODE,strDbType);

			StringBuffer SqlQuery = new StringBuffer()
					.append(" INSERT INTO TB_").append(COMCODE).append("_N10 (ORGNO,PARENTNO,ORGNAME,READERNO) ")
					.append(" VALUES ("+genQuote(Orgno)+","+genQuote(Parentno)+","+genQuote(Orgname)+","+genQuote(Readerno)+") ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

                        dmProp.setProperty("Orgno",Orgno);

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::insertOrg : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::insertOrg : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::insertOrg : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���������� ���޵� �μ��� �ش��ϴ� �μ��� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Orgno : ������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteOrg(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Orgno = dmProp.getString("Orgno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" DELETE FROM TB_").append(COMCODE).append("_N10 ")
					.append(" WHERE ORGNO = "+genQuote(Orgno));

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteOrg : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::deleteOrg : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteOrg : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���������� ���޵� �μ������� �ش��ϴ� �μ��� �μ����� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Orgno : ������ȣ
        *                      <LI> String Orgname : �����̸�
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int updateOrgName(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Orgno = dmProp.getString("Orgno");
		String Orgname = dmProp.getString("Orgname");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" UPDATE TB_").append(COMCODE).append("_N10 ")
					.append(" SET ORGNAME = "+genQuote(Orgname))
					.append(" WHERE ORGNO = "+genQuote(Orgno));

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::updateOrgName : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::updateOrgName : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::updateOrgName : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * �Խ�/����/����/����Ը�Ͽ� ��ϵǴ� �ű����� ��Ͻ� �ʿ��� �ű��Թ�ȣ�� �����ϴ� �����Լ��̸�,
        * �����Ǵ� �Թ�ȣ�� �ش���+�Ϸù�ȣ������ �����ȴ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String strDbType : gplus db type
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return String : �ű��Թ�ȣ
        */
    	private String getMaxBoxNo(String comcode,String strDbType)
        {
		GCmConnection conn = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                             sqlQuery
		        	.append(" SELECT DECODE(SUBSTR(MAX(BOXNO),1,8),TO_CHAR(sysdate,'YYYYMMDD'),TO_CHAR(TO_NUMBER(MAX(BOXNO))+1),null,TO_CHAR(sysdate,'YYYYMMDD')||'0001') as NO ")
                           	.append(" FROM TB_").append(comcode).append("_M10 ")
                           	.append(" WHERE BOXNO LIKE TO_CHAR(sysdate,'YYYYMMDD')||'%'");
                        }
                        else if ("mssql".equals(strDbType))
                             {
                                     sqlQuery
                                        .append(" SELECT (CASE SUBSTRING(MAX(BOXNO),1,8) WHEN convert(char(08),getdate(),112) THEN CAST(SUBSTRING(MAX(BOXNO),1,8) AS varchar(8)) + RIGHT('0000'+CAST(SUBSTRING(MAX(BOXNO),9,4)+1 AS varchar(4)),4) ELSE convert(char(08),getdate(),112)+'0001' END) as NO ")
                                        .append(" FROM TB_").append(comcode).append("_M10 ")
                                        .append(" WHERE BOXNO LIKE convert(char(08),getdate(),112)+'%' ");
                             }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
                	rs.next();

			return rs.getString("NO");

      		}
      		catch (Exception e)
      		{
 			System.out.println(" GCoMeBoxsTran::getMaxNo " + e.getMessage());
	 		return null;
      		}
      		finally
      		{
			conn.close();
      		}
    	}


       /**
        * <PRE>
        * �������� ��ϵǴ� �ű����� ��Ͻ� �ʿ��� �ű�������ȣ�� �����ϴ� �����Լ��̸�,
        * �����Ǵ� ������ȣ�� �ش���+�Ϸù�ȣ������ �����ȴ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String strDbType : gplus db type
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return String : �ű�������ȣ
        */
    	private String getMaxNo(String comcode,String strDbType)
    	{

		GCmConnection conn = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();
			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                           sqlQuery
                              .append(" SELECT DECODE(SUBSTR(MAX(ORGNO),1,8),TO_CHAR(sysdate,'YYYYMMDD'),TO_CHAR(TO_NUMBER(MAX(ORGNO))+1),null,TO_CHAR(sysdate,'YYYYMMDD')||'0001') as NO ")
                              .append(" FROM TB_").append(comcode).append("_N10 ")
                              .append(" WHERE ORGNO LIKE TO_CHAR(sysdate,'YYYYMMDD')||'%'");
                        }
                        else if ("mssql".equals(strDbType))
                             {
                                     sqlQuery
                                        .append(" SELECT (CASE SUBSTRING(MAX(ORGNO),1,8) WHEN convert(char(08),getdate(),112) THEN CAST(SUBSTRING(MAX(ORGNO),1,8) AS varchar(8)) + RIGHT('0000'+CAST(SUBSTRING(MAX(ORGNO),9,4)+1 AS varchar(4)),4) ELSE convert(char(08),getdate(),112)+'0001' END) as NO ")
                                        .append(" FROM TB_").append(comcode).append("_N10 ")
                                        .append(" WHERE ORGNO LIKE convert(char(08),getdate(),112)+'%' ");
                             }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
                	rs.next();

			return rs.getString("NO");

      		}
      		catch (Exception e)
      		{
 			System.out.println(" GCoOrOrgInfoTran::getMaxNo " + e.getMessage());
	 		return null;
      		}
      		finally
      		{
			conn.close();
      		}
    	}

       /**
        * <PRE>
        * ���޵� ������ ��ȣ�� ���Ͽ� �Խ�/����/����/����Ը�Ͽ��� BOXCLASS = '2'�̰� EXECCLASS = '2'�� �Թ�ȣ�� �˻��Ͽ� �Խù���Ͽ���
        * ������ȣ�� 1���� ū������ �ش� ���� �˻��Ͽ� ������ȣ�� �˻��Ͽ� �񼭸�Ͽ��� �ش� ������ �ϰ� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Userno : ������ (ex)�ټ��� �����ڴ� aa,bb,cc���·� ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteUserDocMaster(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Userno = dmProp.getString("Userno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
			    .append(" DELETE FROM TB_").append(COMCODE).append("_L10 ")
			    .append(" WHERE DOCNO IN (SELECT DOCNO ")
			    .append("                 FROM TB_").append(COMCODE).append("_B10 ")
			    .append("                 WHERE DOCNO > '1' AND BOXNO IN (SELECT BOXNO ")
			    .append("                                                 FROM TB_").append(COMCODE).append("_M10 ")
			    .append("                                                 WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') AND BOXCLASS = '2' AND EXECCLASS = '2') ) ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserDocMaster : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::deleteUserDocMaster : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserDocMaster : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� ������ ��ȣ�� ���Ͽ� �Խ�/����/����/����Ը�Ͽ��� BOXCLASS = '2'�̰� EXECCLASS = '2'�� �Թ�ȣ�� �˻��Ͽ� �Խù���Ͽ���
        * ������ȣ�� 1���� ū������ �ش� ���� �˻��Ͽ� ������ȣ�� �˻��Ͽ� �񼭻󼼸�Ͽ��� �ش� ������ �ϰ� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Userno : ������ (ex)�ټ��� �����ڴ� aa,bb,cc���·� ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteUserDocDetail(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Userno = dmProp.getString("Userno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
			    .append(" DELETE FROM TB_").append(COMCODE).append("_L11 ")
			    .append(" WHERE DOCNO IN (SELECT DOCNO ")
			    .append("                 FROM TB_").append(COMCODE).append("_B10 ")
			    .append("                 WHERE DOCNO > '1' AND BOXNO IN (SELECT BOXNO ")
			    .append("                                                 FROM TB_").append(COMCODE).append("_M10 ")
			    .append("                                                 WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') AND BOXCLASS = '2' AND EXECCLASS = '2') ) ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserDocDetail : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::deleteUserDocDetail : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserDocDetail : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� ������ ��ȣ�� ���Ͽ� �Խ�/����/����/����Ը�Ͽ��� BOXCLASS = '2'�̰� EXECCLASS = '2'�� �Թ�ȣ�� �˻��Ͽ�
        * �Խù���Ͽ��� �ش� �Խù��� �ϰ� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Userno : ������ (ex)�ټ��� �����ڴ� aa,bb,cc���·� ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteUserFolder(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Userno = dmProp.getString("Userno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
			    .append(" DELETE FROM TB_").append(COMCODE).append("_B10 ")
                            .append(" WHERE BOXNO IN  (SELECT BOXNO ")
			    .append("                  FROM TB_").append(COMCODE).append("_M10 ")
			    .append("                  WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') AND BOXCLASS = '2' AND EXECCLASS = '2') ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserFolder : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::deleteUserFolder : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserFolder : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� ������ ��ȣ�� ���Ͽ� �Խ�/����/����/����Ը�Ͽ��� BOXCLASS = '3'�̰� EXECCLASS = '2'�� �Թ�ȣ�� �˻��Ͽ�
        * �����Ժ� ���ϸ�Ͽ��� �ش� ������ �ϰ� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Userno : ������ (ex)�ټ��� �����ڴ� aa,bb,cc���·� ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteUserMailBox(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Userno = dmProp.getString("Userno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
			    .append(" DELETE FROM TB_").append(COMCODE).append("_C20 ")
                            .append(" WHERE BOXNO IN ( SELECT BOXNO ")
			    .append("                  FROM TB_").append(COMCODE).append("_M10 ")
			    .append("                  WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') AND BOXCLASS = '3' AND EXECCLASS = '2') ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserMailBox : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::deleteUserMailBox : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserMailBox : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� ������ ��ȣ�� ���Ͽ� �Խ�/����/����/����Ը�Ͽ��� BOXCLASS = '3'�̰� EXECCLASS = '2'�� �Թ�ȣ�� �˻��Ͽ�
        * ���ڸ��ϰ�����Ͽ��� �ش� ������ �ϰ� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Userno : ������ (ex)�ټ��� �����ڴ� aa,bb,cc���·� ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteUserMailAccount(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Userno = dmProp.getString("Userno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
			    .append(" DELETE FROM TB_").append(COMCODE).append("_C30 ")
			    .append(" WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserMailAccount : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::deleteUserMailAccount : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserMailAccount : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� �����ڹ�ȣ�� ���Ͽ� �����ڸ�Ͽ��� �������������� ����,������ �����ڸ���� ������
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Userno : �����ڹ�ȣ (ex)�ټ��� �����ڹ�ȣ�� aa,bb,cc���·� ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteUserSubDraft(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Userno = dmProp.getString("Userno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
			    .append(" DELETE FROM TB_").append(COMCODE).append("_D11 ")
			    .append(" WHERE APPRID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ")
                            .append("       AND (REFTYPE = '2' OR REFTYPE = '3') ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserSubDraft : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::deleteUserSubDraft : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserSubDraft : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� �����ڹ�ȣ�� ���Ͽ� ���Ѹ�ϰ� �����ڸ�Ͽ��� �������������� ������ �����ڸ���� ��ȹ�ȣ�� ������
        * �˻��Ͽ� �ش��ϴ� ������ ����� ������
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Userno : �����ڹ�ȣ (ex)�ټ��� �����ڹ�ȣ�� aa,bb,cc���·� ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteUserMainDraft(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Userno = dmProp.getString("Userno");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                             SqlQuery
			       .append(" DELETE FROM TB_").append(COMCODE).append("_D11 ")
  			       .append(" WHERE (DRFTNO,SEQ) IN (SELECT A.DRFTNO,A.SEQ ")
			       .append("                        FROM TB_").append(COMCODE).append("_D11 A, TB_").append(COMCODE).append("_D10 B ")
			       .append("                        WHERE A.SEQ < '08' AND A.APPRID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ")
                               .append("                              AND A.DRFTNO = B.DRFTNO AND A.REFTYPE = '1') ");
                        }
                        else if ("mssql".equals(strDbType))
                             {
                                     SqlQuery
			               .append(" DELETE FROM TB_").append(COMCODE).append("_D11 ")
  			               .append(" WHERE (DRFTNO) IN (SELECT A.DRFTNO ")
			               .append("                        FROM TB_").append(COMCODE).append("_D11 A, TB_").append(COMCODE).append("_D10 B ")
			               .append("                        WHERE A.SEQ < '08' AND A.APPRID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ")
                                       .append("                              AND A.DRFTNO = B.DRFTNO AND A.REFTYPE = '1') AND ")
  			               .append("        (SEQ) IN (SELECT A.SEQ ")
			               .append("                        FROM TB_").append(COMCODE).append("_D11 A, TB_").append(COMCODE).append("_D10 B ")
			               .append("                        WHERE A.SEQ < '08' AND A.APPRID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ")
                                       .append("                              AND A.DRFTNO = B.DRFTNO AND A.REFTYPE = '1') ");
                             }
			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserMainDraft : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::deleteUserMainDraft : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserMainDraft : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� ����ڸ� ���Ͽ� ��������Ͽ��� �ش��ϴ� ��������ȣ�� �˻��Ͽ� �ش� ��������
        * ����/��������Ͽ��� ������
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Userno : ����� (ex)�ټ��� ����ڴ� aa,bb,cc���·� ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteUserSubDraftLine(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Userno = dmProp.getString("Userno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
			    .append(" DELETE FROM TB_").append(COMCODE).append("_D31 ")
			    .append(" WHERE LINENUM IN ( SELECT LINENUM ")
			    .append("                   FROM TB_").append(COMCODE).append("_D30 ")
			    .append("                   WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"')) ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserSubDraftLine : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::deleteUserSubDraftLine : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserSubDraftLine : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� ����ڸ� ���Ͽ� ��������Ͽ��� �ش� ����� �������� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Userno : ����� (ex)�ټ��� ����ڴ� aa,bb,cc���·� ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteUserDraftLine(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Userno = dmProp.getString("Userno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
			    .append(" DELETE FROM TB_").append(COMCODE).append("_D30 ")
			    .append(" WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserDraftLine : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::deleteUserDraftLine : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserDraftLine : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� �ۼ��ڸ� ���Ͽ� ������Ͽ��� �ش� ��������� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Userno : �ۼ��� (ex)�ټ��� �ۼ��ڴ� aa,bb,cc���·� ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteUserSchdule(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Userno = dmProp.getString("Userno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
			    .append(" DELETE FROM TB_").append(COMCODE).append("_E10 ")
			    .append(" WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserSchdule : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::deleteUserSchdule : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserSchdule : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� ����ڹ�ȣ�� ���Ͽ� �����׷��Ͽ��� �ش� �����׷����� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Userno : ����ڹ�ȣ (ex)�ټ��� ����ڹ�ȣ�� aa,bb,cc���·� ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteUserSchduleGroup(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Userno = dmProp.getString("Userno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
			    .append(" DELETE FROM TB_").append(COMCODE).append("_G10 ")
			    .append(" WHERE GRPTYPE = '1' AND USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserSchduleGroup : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::deleteUserSchduleGroup : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserSchduleGroup : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� ����ڸ� ���Ͽ� ���Ը�Ͽ��� �ش� ���Ը���� �ϰ������Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Userno : ����� (ex)�ټ��� ����ڴ� aa,bb,cc���·� ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteUserCard(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Userno = dmProp.getString("Userno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
			    .append(" DELETE FROM TB_").append(COMCODE).append("_F10 ")
			    .append(" WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserCard : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::deleteUserCard : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserCard : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� ����ڸ� ���Ͽ� ���Կ������� �ش� ���Կ����� �ϰ������Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Userno : ����� (ex)�ټ��� ����ڴ� aa,bb,cc���·� ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteUserCardHistory(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Userno = dmProp.getString("Userno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
			    .append(" DELETE FROM TB_").append(COMCODE).append("_F11 ")
			    .append(" WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserCardHistory : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::deleteUserCardHistory : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserCardHistory : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� ����ڸ� ���Ͽ� ���Ա׷��Ͽ��� �ش� ���Ա׷����� �ϰ������Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Userno : ����ڹ�ȣ (ex)�ټ��� ����ڹ�ȣ�� aa,bb,cc���·� ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteUserCardGroup(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Userno = dmProp.getString("Userno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
			    .append(" DELETE FROM TB_").append(COMCODE).append("_G10 ")
			    .append(" WHERE GRPTYPE = '2' AND USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserCardGroup : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::deleteUserCardGroup : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserCardGroup : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� ����ڸ� ���Ͽ� �系���� �ּҷϿ��� �ش��ϴ� �ּҷϹ�ȣ�� �˻��ϰ� �系�����ּҸ�Ͽ���
        * �ش� �ּҷϹ�ȣ�� ��ġ�ϴ� �系�����ּҸ���� �ϰ������Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Userno : ����� (ex)�ټ��� ����ڴ� aa,bb,cc���·� ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteUserCardBookDetail(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Userno = dmProp.getString("Userno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
			    .append(" DELETE FROM TB_").append(COMCODE).append("_F31 ")
			    .append(" WHERE BROADCASTNO IN ( SELECT BROADCASTNO ")
                            .append("                       FROM TB_").append(COMCODE).append("_F30 ")
                            .append("                       WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"')) ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserCardBookDetail : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::deleteUserCardBookDetail : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserCardBookDetail : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� ����ڸ� ���Ͽ� �系���� �ּҷϿ��� �ش��ϴ� �系�����ּҷ��� �ϰ������Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Userno : ����� (ex)�ټ��� ����ڴ� aa,bb,cc���·� ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteUserCardBook(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Userno = dmProp.getString("Userno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
			    .append(" DELETE FROM TB_").append(COMCODE).append("_F30 ")
                            .append(" WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserCardBook : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::deleteUserCardBook : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserCardBook : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� �����ڿ� ���ϴ� �Խ�/����/����/����Ը�Ͽ��� �ش��ϴ� �Ը���� �ϰ������Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Userno : ������ (ex)�ټ��� �����ڴ� aa,bb,cc���·� ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteUserBox(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Userno = dmProp.getString("Userno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
			    .append(" DELETE FROM TB_").append(COMCODE).append("_M10 ")
                            .append(" WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserBox : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::deleteUserBox : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserBox : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� ����ڹ�ȣ�� ���ϴ� �����Ի����ѿ��� �ش��ϴ� �������� �ϰ������Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Userno : ����ڹ�ȣ (ex)�ټ��� ����ڹ�ȣ�� aa,bb,cc���·� ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteUserBoxRight(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Userno = dmProp.getString("Userno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
			    .append(" DELETE FROM TB_").append(COMCODE).append("_M20 ")
                            .append(" WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserBoxRight : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::deleteUserBoxRight : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUserBoxRight : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� ����ڹ�ȣ�� ���ϴ� ������������Ͽ��� �ش��ϴ� ����ڸ� �ϰ������Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Userno : ����ڹ�ȣ (ex)�ټ��� ����ڹ�ȣ�� aa,bb,cc���·� ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteOrgUser(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Userno = dmProp.getString("Userno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
			    .append(" DELETE FROM TB_").append(COMCODE).append("_N11 ")
                            .append(" WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteOrgUser : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::deleteOrgUser : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteOrgUser : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� ����ڹ�ȣ�� ���ϴ� �����ȯ���������� �ش��ϴ� ����ڸ� �ϰ������Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Userno : ����ڹ�ȣ (ex)�ټ��� ����ڹ�ȣ�� aa,bb,cc���·� ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteUser(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Userno = dmProp.getString("Userno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
			    .append(" DELETE FROM TB_COMM_Z20 ")
                            .append(" WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUser : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::deleteUser : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::deleteUser : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * �űԻ���ڸ� �����Ѵ�. ������� �̹���ȭ���� �����ϰ�, insertBox,insertBoxRight,insertFolder �� ���α⺻������, ��������
        * �����Ѵ�. insertOrgUser,insertNewUser�� �����Ͽ� ���������� ��ϰ� ����� ȯ�������� �űԻ���ڸ� ����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> EntityModel tbz20 : �����ȯ������ ������ ��
        *                      <LI> object smtUpload : �̹��� ȭ���� ������ �ִ� ���� smtUpload ��ü
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int processNewUserAdd(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		GEmTB_Z20 tbz20 = (GEmTB_Z20)dmProp.getObject("tbz20");
                SmartUpload smtUpload = (SmartUpload)dmProp.getObject("smtUpload");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();
	 	GCoMeBoxs boxinfo = new GCoMeBoxs();
                GCoSyComInfo cominfo = new GCoSyComInfo();
		int rv;

		GCmConnection conn = null;
		Statement stmt = null;
                StringBuffer SqlQuery = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			stmt = conn.createStatement();
			conn.setAutoCommit(true);

   			int fileCnt = smtUpload.getFiles().getCount();
    			String filename = tbz20.getStrUserId();
    			String strDocroot = cp.getProperty("gplus.system.docroot");
    			String imgpath = "/DATA/" + COMCODE + "/IMAGE/";
    			gplus.commlib.util.GCmFcts.folderMake(strDocroot,"/DATA/"+COMCODE+"/IMAGE/");

    			for (int i=0;i<fileCnt;i++)
    			{
	        		com.jspsmart.upload.File upFile = smtUpload.getFiles().getFile(i);

	        		if (!upFile.isMissing())
	        		{
			            filename = tbz20.getStrUserId() + "." + upFile.getFileExt();
			            upFile.saveAs(imgpath + filename,upFile.SAVEAS_VIRTUAL);
        			}
    			}

    			String Regdate = gplus.commlib.util.GCmDateFcts.dateToStr(new java.util.Date(),2);
                        String Boxno = getMaxBoxNo(COMCODE,strDbType);

			SqlQuery = new StringBuffer()
		 		   .append(" INSERT INTO TB_"+COMCODE+"_M10 (BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,BOXTYPE,BOXNAME,BASEFLAG,PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE) ")
                                   .append(" VALUES("+genQuote(Boxno)+",'','000000000000',"+genQuote(GCmConstDef.BOXCLASS_BOX)+",")
                                   .append("        "+genQuote(GCmConstDef.EXECCLASS_BOX_PRIVATE)+","+genQuote(GCmConstDef.BOXTYPE_PRIVATE)+","+genQuote(tbz20.getStrUserName() + " ������")+","+genQuote(GCmConstDef.BASEFLAG_ON)+",")
                                   .append("        "+genQuote(GCmConstDef.PUBFLAG_OFF)+","+genQuote(GCmConstDef.EXECFLAG_ON)+","+genQuote(tbz20.getStrUserId())+","+genQuote(USERID)+","+genQuote(Regdate)+") ");
		        rv = stmt.executeUpdate(SqlQuery.toString());
                        if( rv <= 0 ) throw new Exception(" During processNewUserAdd error !!!");

			SqlQuery = new StringBuffer()
				   .append(" INSERT INTO TB_"+COMCODE+"_M20 (BOXNO,USERID,DOCREAD,DOCWRITE,DOCDEL,DOCDELADM,FLDMAKE,FLDDEL) ")
				   .append(" VALUES ("+genQuote(Boxno)+","+genQuote(tbz20.getStrUserId())+",'0','0','0','0','0','0') ");

		        rv = stmt.executeUpdate(SqlQuery.toString());

                        if( rv <= 0 ) throw new Exception(" During processNewUserAdd error !!!");

                        String Folderno = getFolderNo(COMCODE,strDbType);

			SqlQuery = new StringBuffer()
					.append(" INSERT INTO TB_"+COMCODE+"_B10 (FLDNO,BOXNO,DOCNO,PARENTNO,FLDNAME,REGUSER,REGDATE,TRASHFLAG,COMMENTS,REFNO) ")
					.append(" VALUES ("+genQuote(Folderno)+","+genQuote(Boxno)+",'','000000000000',"+genQuote(tbz20.getStrUserName() + " ������")+","+genQuote(tbz20.getStrUserId())+",")
                                        .append("         "+genQuote(Regdate)+",'','','')");
		        rv = stmt.executeUpdate(SqlQuery.toString());
                        if( rv <= 0 ) throw new Exception(" During processNewUserAdd error !!!");

    			for (int i =1; i<5; i++) {
                                String Boxname = "";
        			if(Integer.parseInt(GCmConstDef.EXECCLASS_MAIL_INBOX) == i)
					Boxname = "����������";
        			else if(Integer.parseInt(GCmConstDef.EXECCLASS_MAIL_SENDBOX) == i)
					Boxname = "����������";
                  		else if(Integer.parseInt(GCmConstDef.EXECCLASS_MAIL_DELBOX) == i)
					Boxname = "����������";
                       		else if(Integer.parseInt(GCmConstDef.EXECCLASS_MAIL_TEMPBOX) == i)
					Boxname = "�ӽú�����";

                                Boxno = getMaxBoxNo(COMCODE,strDbType);

			        SqlQuery = new StringBuffer()
		 		           .append(" INSERT INTO TB_"+COMCODE+"_M10 (BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,BOXTYPE,BOXNAME,BASEFLAG,PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE) ")
                                           .append(" VALUES("+genQuote(Boxno)+",'','000000000000',"+genQuote(GCmConstDef.BOXCLASS_MAIL)+",")
                                           .append("        "+genQuote(gplus.commlib.util.GCmFcts.numToStr(i,1))+","+genQuote(GCmConstDef.BOXTYPE_PRIVATE)+","+genQuote(Boxname)+","+genQuote(GCmConstDef.BASEFLAG_OFF)+",")
                                           .append("        "+genQuote(GCmConstDef.PUBFLAG_OFF)+","+genQuote(GCmConstDef.EXECFLAG_ON)+","+genQuote(tbz20.getStrUserId())+","+genQuote(USERID)+","+genQuote(Regdate)+") ");
		                rv = stmt.executeUpdate(SqlQuery.toString());
                                if( rv <= 0 ) throw new Exception(" During processNewUserAdd error !!!");

			        SqlQuery = new StringBuffer()
				           .append(" INSERT INTO TB_"+COMCODE+"_M20 (BOXNO,USERID,DOCREAD,DOCWRITE,DOCDEL,DOCDELADM,FLDMAKE,FLDDEL) ")
				           .append(" VALUES ("+genQuote(Boxno)+","+genQuote(tbz20.getStrUserId())+",'0','0','0','0','0','0') ");
		                rv = stmt.executeUpdate(SqlQuery.toString());
                                if( rv <= 0 ) throw new Exception(" During processNewUserAdd error !!!");
    			}

			for (int i =1; i<6; i++) {
                                String Boxname = "";
        			if(Integer.parseInt(GCmConstDef.EXECCLASS_DRAFT_INBOX) == i)
					Boxname = "����������";
        			else if(Integer.parseInt(GCmConstDef.EXECCLASS_DRAFT_SENDBOX) == i)
					Boxname = "����������";
             			else if(Integer.parseInt(GCmConstDef.EXECCLASS_DRAFT_ENDBOX) == i)
					Boxname = "�Ϸ������";
                  		else if(Integer.parseInt(GCmConstDef.EXECCLASS_DRAFT_REJECTBOX) == i)
					Boxname = "�ݷ�������";
                       		else if(Integer.parseInt(GCmConstDef.EXECCLASS_DRAFT_TEMPBOX) == i)
					Boxname = "�ӽú�����";

                                Boxno = getMaxBoxNo(COMCODE,strDbType);

			        SqlQuery = new StringBuffer()
		 		           .append(" INSERT INTO TB_"+COMCODE+"_M10 (BOXNO,ICONNO,PARENTNO,BOXCLASS,EXECCLASS,BOXTYPE,BOXNAME,BASEFLAG,PUBFLAG,EXECFLAG,USERID,REGUSER,REGDATE) ")
                                           .append(" VALUES("+genQuote(Boxno)+",'','000000000000',"+genQuote(GCmConstDef.BOXCLASS_DRAFT)+",")
                                           .append("        "+genQuote(gplus.commlib.util.GCmFcts.numToStr(i,1))+","+genQuote(GCmConstDef.BOXTYPE_PRIVATE)+","+genQuote(Boxname)+","+genQuote(GCmConstDef.BASEFLAG_OFF)+",")
                                           .append("        "+genQuote(GCmConstDef.PUBFLAG_OFF)+","+genQuote(GCmConstDef.EXECFLAG_ON)+","+genQuote(tbz20.getStrUserId())+","+genQuote(USERID)+","+genQuote(Regdate)+") ");
		                rv = stmt.executeUpdate(SqlQuery.toString());
                                if( rv <= 0 ) throw new Exception(" During processNewUserAdd error !!!");

			        SqlQuery = new StringBuffer()
				           .append(" INSERT INTO TB_"+COMCODE+"_M20 (BOXNO,USERID,DOCREAD,DOCWRITE,DOCDEL,DOCDELADM,FLDMAKE,FLDDEL) ")
				           .append(" VALUES ("+genQuote(Boxno)+","+genQuote(tbz20.getStrUserId())+",'0','0','0','0','0','0') ");
		                rv = stmt.executeUpdate(SqlQuery.toString());
                                if( rv <= 0 ) throw new Exception(" During processNewUserAdd error !!!");
			}

                        GCmResultSet rsCominfo = cominfo.getComInfo(cp, dmProp, msgInfo);

                        String Docread = "1";
                        String Docwrite = "1";
                        String Docdel = "1";
                        String Docdeladm = "1";
                        String Fldmake = "1";
                        String Flddel = "1";

                        if(rsCominfo.next())
                        {
                        	if(rsCominfo.getString("docread") != null && !rsCominfo.getString("docread").equals(""))
                        	     Docread = rsCominfo.getString("docread");
                        	if(rsCominfo.getString("docwrite") != null && !rsCominfo.getString("docwrite").equals(""))
                        	     Docwrite = rsCominfo.getString("docwrite");
                        	if(rsCominfo.getString("docdel") != null && !rsCominfo.getString("docdel").equals(""))
                        	{
                        	     Docdel = rsCominfo.getString("docdel");
                        	     Docdeladm = rsCominfo.getString("docdel");
                        	}
                        	if(rsCominfo.getString("fldmake") != null && !rsCominfo.getString("fldmake").equals(""))
                        	     Fldmake = rsCominfo.getString("fldmake");
                        	if(rsCominfo.getString("flddel") != null && !rsCominfo.getString("flddel").equals(""))
                        	     Flddel = rsCominfo.getString("flddel");
                        }

                        rsCominfo = boxinfo.getPubBoxList(cp, dmProp, msgInfo);

    			while(rsCominfo.next())
    			{
    				stmt.close();
				stmt = conn.createStatement();
			        SqlQuery = new StringBuffer()
  					   .append(" INSERT INTO TB_"+COMCODE+"_M20 (BOXNO,USERID,DOCREAD,DOCWRITE,DOCDEL,DOCDELADM,FLDMAKE,FLDDEL) ")
					   .append(" VALUES ("+genQuote(rsCominfo.getString("BOXNO"))+","+genQuote(tbz20.getStrUserId())+","+genQuote(Docread)+","+genQuote(Docwrite)+","+genQuote(Docdel)+",")
                                           .append("         "+genQuote(Docdeladm)+","+genQuote(Fldmake)+","+genQuote(Flddel)+") ");
		                rv = stmt.executeUpdate(SqlQuery.toString());
                                if( rv <= 0 ) throw new Exception(" During processNewUserAdd error !!!");
    			}

		        SqlQuery = new StringBuffer()
				   .append(" INSERT INTO TB_").append(COMCODE).append("_N11 (ORGNO,USERID,DEFLT) ")
				   .append(" VALUES ("+genQuote(tbz20.getStrOrgNo())+","+genQuote(tbz20.getStrUserId())+",'0') ");
	                rv = stmt.executeUpdate(SqlQuery.toString());
                        if( rv <= 0 ) throw new Exception(" During processNewUserAdd error !!!");


		        SqlQuery = new StringBuffer()
				   .append(" INSERT INTO TB_COMM_Z20 ")
				   .append(" ( USERID,PASSWD,ORGNO,POSCODE,USERNAME,SECLVL,ALARMFLAG,ALARMTIME,ALARMREPEAT,ALARMTYPE,ALARMMAILON, ALARMDRFTON, ")
                                   .append("   LOGINFLAG,LOGINDATE,BOXNO,SIGNDOCNO,COMCODE,TEL1,TEL2,TEL3,ZIPCODE,ADDR,INDATE,BIRTHDAY,LUNARFLAG) ")
                                   .append("   VALUES("+genQuote(tbz20.getStrUserId())+","+genQuote(tbz20.getStrPassWd())+","+genQuote(tbz20.getStrOrgNo())+",")
                                   .append("          "+genQuote(tbz20.getStrPosCode())+","+genQuote(tbz20.getStrUserName())+","+genQuote(tbz20.getStrSecLvl())+",")
                                   .append("          "+genQuote(tbz20.getStrAlarmFlag())+","+tbz20.getStrAlarmTime()+","+tbz20.getStrAlarmRepeat()+",")
                                   .append("          "+genQuote(tbz20.getStrAlarmType())+","+genQuote(tbz20.getStrAlarmMailOn())+","+genQuote(tbz20.getStrAlarmDrftOn())+",")
                                   .append("          "+genQuote(tbz20.getStrLogInFlag())+","+genQuote(tbz20.getStrLogInDate())+","+genQuote(tbz20.getStrBoxNo())+",")
                                   .append("          "+genQuote(tbz20.getStrSignDocNo())+","+genQuote(COMCODE)+","+genQuote(tbz20.getStrTel1())+",")
                                   .append("          "+genQuote(tbz20.getStrTel2())+","+genQuote(tbz20.getStrTel3())+","+genQuote(tbz20.getStrZipCode())+",")
                                   .append("          "+genQuote(tbz20.getStrAddr())+","+genQuote(tbz20.getStrInDate())+","+genQuote(tbz20.getStrBirthDay())+",")
                                   .append("          "+genQuote(tbz20.getStrLunarFlag())+")");
	                rv = stmt.executeUpdate(SqlQuery.toString());
                        if( rv <= 0 ) throw new Exception(" During processNewUserAdd error !!!");

			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::processNewUserAdd : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::processNewUserAdd : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::processNewUserAdd : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ������� ������ �����Ѵ�. ������� �̹���ȭ���� �ٽ� �����ϰ�,updateUserInfo���� �����ȯ�������� �����Ѵ�.
        * updateUserOrgNo���� ������� ���� ������ ������ �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> EntityModel tbz20 : �����ȯ������ ������ ��
        *                      <LI> object smtUpload : �̹��� ȭ���� ������ �ִ� ���� smtUpload ��ü
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int processUserModify(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		GEmTB_Z20 tbz20 = (GEmTB_Z20)dmProp.getObject("tbz20");
                SmartUpload smtUpload = (SmartUpload)dmProp.getObject("smtUpload");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;
                StringBuffer SqlQuery = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			stmt = conn.createStatement();
			conn.setAutoCommit(false);

   			int fileCnt = smtUpload.getFiles().getCount();
    			String filename = tbz20.getStrUserId();
    			String strDocroot = cp.getProperty("gplus.system.docroot");
    			String imgpath = "/DATA/" + COMCODE + "/IMAGE/";
    			gplus.commlib.util.GCmFcts.folderMake(strDocroot,"/DATA/"+COMCODE+"/IMAGE/");

    			for (int i=0;i<fileCnt;i++)
    			{
	        		com.jspsmart.upload.File upFile = smtUpload.getFiles().getFile(i);

	        		if (!upFile.isMissing())
	        		{
			            filename = tbz20.getStrUserId() + "." + upFile.getFileExt();
			            upFile.saveAs(imgpath + filename,upFile.SAVEAS_VIRTUAL);
        			}
    			}

		        SqlQuery = new StringBuffer()
				   .append(" UPDATE TB_COMM_Z20 ")
                                   .append(" SET USERNAME="+genQuote(tbz20.getStrUserName())+", ALARMFLAG="+genQuote(tbz20.getStrAlarmFlag())+", ALARMTIME="+tbz20.getStrAlarmTime()+",")
                                   .append("     ALARMREPEAT="+tbz20.getStrAlarmRepeat()+", ALARMTYPE="+genQuote(tbz20.getStrAlarmType())+", ALARMMAILON="+genQuote(tbz20.getStrAlarmMailOn())+", ALARMDRFTON="+genQuote(tbz20.getStrAlarmDrftOn())+",")
                                   .append("     TEL1="+genQuote(tbz20.getStrTel1())+", TEL2="+genQuote(tbz20.getStrTel2())+", TEL3="+genQuote(tbz20.getStrTel3())+" , ZIPCODE="+genQuote(tbz20.getStrZipCode())+", PASSWD="+genQuote(tbz20.getStrPassWd())+", SECLVL="+genQuote(tbz20.getStrSecLvl())+",")
                                   .append("     ADDR="+genQuote(tbz20.getStrAddr())+", INDATE="+genQuote(tbz20.getStrInDate())+", BIRTHDAY="+genQuote(tbz20.getStrBirthDay())+", LUNARFLAG="+genQuote(tbz20.getStrLunarFlag())+", ORGNO = "+genQuote(tbz20.getStrOrgNo())+" , POSCODE = "+genQuote(tbz20.getStrPosCode())+", BOXNO = "+genQuote(tbz20.getStrBoxNo()))
				   .append(" WHERE USERID = "+genQuote(tbz20.getStrUserId()));
	                rv = stmt.executeUpdate(SqlQuery.toString());
                        if( rv <= 0 ) throw new Exception(" During processUserModify error !!!");

		        SqlQuery = new StringBuffer()
					.append(" UPDATE TB_").append(COMCODE).append("_N11 ")
					.append(" SET ORGNO = "+genQuote(tbz20.getStrOrgNo()))
					.append(" WHERE USERID = "+genQuote(tbz20.getStrUserId()));
	                rv = stmt.executeUpdate(SqlQuery.toString());
                        if( rv <= 0 ) throw new Exception(" During processUserModify error !!!");

			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::processUserModify : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::processUserModify : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::processUserModify : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ����ڸ� �����Ѵ�. deleteUserDocMaster,deleteUserDocDetail,deleteUserFolder,deleteUserMailBox,deleteUserMailAccount,
        * deleteUserMainDraft,deleteUserSubDraft,deleteUserSubDraftLine,deleteUserSchdule,deleteUserSchduleGroup,deleteUserCard,
        * deleteUserCardHistory,deleteUserCardGroup,deleteUserCardBookDetail,deleteUserCardBook,deleteUserBox,deleteUserBoxRight,
        * deleteUser�� ���������� �����Ͽ� ����ڿ� ������ ���̺� ������ �����ϰ� /DATA/../BOX/������ ���������� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Userno : ������ (ex)�ټ��� �����ڴ� aa,bb,cc���·� ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int processUserDelete(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
       		String COMCODE = dmProp.getString("COMCODE");
		    String Userno = dmProp.getString("Userno");
            String strDocroot = cp.getProperty("gplus.system.docroot");
            String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		    int rv;

		    GCmConnection conn = null;
		    Statement stmt = null;
            StringBuffer SqlQuery = null;

            GCoOrOrgInfo orginfo = new GCoOrOrgInfo();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			stmt = conn.createStatement();

                        if ("oracle".equals(strDbType))
                        {
			      conn.setAutoCommit(false);
                        }

		        SqlQuery = new StringBuffer()
			           .append(" DELETE FROM TB_").append(COMCODE).append("_L10 ")
			           .append(" WHERE DOCNO IN (SELECT DOCNO ")
			           .append("                 FROM TB_").append(COMCODE).append("_B10 ")
			           .append("                 WHERE DOCNO > '1' AND BOXNO IN (SELECT BOXNO ")
			           .append("                                                 FROM TB_").append(COMCODE).append("_M10 ")
			           .append("                                                 WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') AND BOXCLASS = '2' AND EXECCLASS = '2') ) ");
	                rv = stmt.executeUpdate(SqlQuery.toString());

		        SqlQuery = new StringBuffer()
   			           .append(" DELETE FROM TB_").append(COMCODE).append("_L11 ")
			           .append(" WHERE DOCNO IN (SELECT DOCNO ")
			           .append("                 FROM TB_").append(COMCODE).append("_B10 ")
			           .append("                 WHERE DOCNO > '1' AND BOXNO IN (SELECT BOXNO ")
			           .append("                                                 FROM TB_").append(COMCODE).append("_M10 ")
			           .append("                                                 WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') AND BOXCLASS = '2' AND EXECCLASS = '2') ) ");
	                rv = stmt.executeUpdate(SqlQuery.toString());

		        SqlQuery = new StringBuffer()
			           .append(" DELETE FROM TB_").append(COMCODE).append("_B10 ")
                                   .append(" WHERE BOXNO IN  (SELECT BOXNO ")
			           .append("                  FROM TB_").append(COMCODE).append("_M10 ")
			           .append("                  WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') AND BOXCLASS = '2' AND EXECCLASS = '2') ");
	                rv = stmt.executeUpdate(SqlQuery.toString());

		        SqlQuery = new StringBuffer()
   			           .append(" DELETE FROM TB_").append(COMCODE).append("_C20 ")
                                   .append(" WHERE BOXNO IN ( SELECT BOXNO ")
			           .append("                  FROM TB_").append(COMCODE).append("_M10 ")
			           .append("                  WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') AND BOXCLASS = '3' AND EXECCLASS = '2') ");
	                rv = stmt.executeUpdate(SqlQuery.toString());

		        SqlQuery = new StringBuffer()
			    .append(" DELETE FROM TB_").append(COMCODE).append("_C30 ")
			    .append(" WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ");
	                rv = stmt.executeUpdate(SqlQuery.toString());

                        if ("oracle".equals(strDbType))
                        {
                             SqlQuery = new StringBuffer()
			                .append(" DELETE FROM TB_").append(COMCODE).append("_D11 ")
  			                .append(" WHERE (DRFTNO,SEQ) IN (SELECT A.DRFTNO,A.SEQ ")
			                .append("                        FROM TB_").append(COMCODE).append("_D11 A, TB_").append(COMCODE).append("_D10 B ")
			                .append("                        WHERE A.SEQ < '08' AND A.APPRID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ")
                                        .append("                              AND A.DRFTNO = B.DRFTNO AND A.REFTYPE = '1') ");
                        }
                        else if ("mssql".equals(strDbType))
                             {
                                   SqlQuery = new StringBuffer()
		                              .append(" DELETE FROM TB_").append(COMCODE).append("_D11 ")
  			                      .append(" WHERE (DRFTNO) IN (SELECT A.DRFTNO ")
			                      .append("                        FROM TB_").append(COMCODE).append("_D11 A, TB_").append(COMCODE).append("_D10 B ")
			                      .append("                        WHERE A.SEQ < '08' AND A.APPRID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ")
                                              .append("                              AND A.DRFTNO = B.DRFTNO AND A.REFTYPE = '1') AND ")
  			                      .append("        (SEQ) IN (SELECT A.SEQ ")
			                      .append("                        FROM TB_").append(COMCODE).append("_D11 A, TB_").append(COMCODE).append("_D10 B ")
			                      .append("                        WHERE A.SEQ < '08' AND A.APPRID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ")
                                              .append("                              AND A.DRFTNO = B.DRFTNO AND A.REFTYPE = '1') ");
                             }
	                rv = stmt.executeUpdate(SqlQuery.toString());

		        SqlQuery = new StringBuffer()
  			           .append(" DELETE FROM TB_").append(COMCODE).append("_D11 ")
			           .append(" WHERE APPRID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ")
                                   .append("       AND (REFTYPE = '2' OR REFTYPE = '3') ");
	                rv = stmt.executeUpdate(SqlQuery.toString());

		        SqlQuery = new StringBuffer()
 			           .append(" DELETE FROM TB_").append(COMCODE).append("_D31 ")
			           .append(" WHERE LINENUM IN ( SELECT LINENUM ")
			           .append("                   FROM TB_").append(COMCODE).append("_D30 ")
			           .append("                   WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"')) ");
	                rv = stmt.executeUpdate(SqlQuery.toString());

		        SqlQuery = new StringBuffer()
			           .append(" DELETE FROM TB_").append(COMCODE).append("_D30 ")
			           .append(" WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ");
	                rv = stmt.executeUpdate(SqlQuery.toString());

		        SqlQuery = new StringBuffer()
			           .append(" DELETE FROM TB_").append(COMCODE).append("_E10 ")
			           .append(" WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ");
	                rv = stmt.executeUpdate(SqlQuery.toString());

		        SqlQuery = new StringBuffer()
			           .append(" DELETE FROM TB_").append(COMCODE).append("_G10 ")
			           .append(" WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ");
	                rv = stmt.executeUpdate(SqlQuery.toString());

		        SqlQuery = new StringBuffer()
			           .append(" DELETE FROM TB_").append(COMCODE).append("_F10 ")
			           .append(" WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ");
	                rv = stmt.executeUpdate(SqlQuery.toString());

		        SqlQuery = new StringBuffer()
			           .append(" DELETE FROM TB_").append(COMCODE).append("_F11 ")
			           .append(" WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ");
	                rv = stmt.executeUpdate(SqlQuery.toString());

		        SqlQuery = new StringBuffer()
			           .append(" DELETE FROM TB_").append(COMCODE).append("_F31 ")
			           .append(" WHERE BROADCASTNO IN ( SELECT BROADCASTNO ")
                                   .append("                       FROM TB_").append(COMCODE).append("_F30 ")
                                   .append("                       WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"')) ");
	                rv = stmt.executeUpdate(SqlQuery.toString());

		        SqlQuery = new StringBuffer()
			           .append(" DELETE FROM TB_").append(COMCODE).append("_F30 ")
                                   .append(" WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ");
	                rv = stmt.executeUpdate(SqlQuery.toString());

		        SqlQuery = new StringBuffer()
			           .append(" DELETE FROM TB_").append(COMCODE).append("_M10 ")
                                   .append(" WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ");
	                rv = stmt.executeUpdate(SqlQuery.toString());

		        SqlQuery = new StringBuffer()
			           .append(" DELETE FROM TB_").append(COMCODE).append("_M20 ")
                                   .append(" WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ");
	                rv = stmt.executeUpdate(SqlQuery.toString());

		        SqlQuery = new StringBuffer()
			           .append(" DELETE FROM TB_").append(COMCODE).append("_N11 ")
                                   .append(" WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ");
	                rv = stmt.executeUpdate(SqlQuery.toString());

		        SqlQuery = new StringBuffer()
			           .append(" DELETE FROM TB_COMM_Z20 ")
                                   .append(" WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userno,",","','")+"') ");
	                rv = stmt.executeUpdate(SqlQuery.toString());

                        GCmResultSet rs = orginfo.getDeleteBoxList(cp, dmProp, msgInfo);

                        while(rs.next())
                        {
                              gplus.commlib.util.GCmFcts.setDelete(strDocroot+"/DATA/" + COMCODE + "/BOX/" + rs.getString("BOXNO") + "/");
                        }

            gplus.commlib.util.GCmFcts.setDelete(strDocroot+"/DATA/" + COMCODE + "/IMAGE/" + Userno + ".gif");
            gplus.commlib.util.GCmFcts.setDelete(strDocroot+"/DATA/" + COMCODE + "/IMAGE/" + Userno + "sign.gif");

			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoOrOrgInfoTran::processUserDelete : " + ignored.getMessage());
			}

	 		System.out.println(" GCoOrOrgInfoTran::processUserDelete : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoOrOrgInfoTran::processUserDelete : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * �����Կ� ��ϵǴ� �ű� �������� ��Ͻ� �ʿ��� �ű� ������ȣ�� �����ϴ� �����Լ��̸�,
        * �����Ǵ� ������ȣ�� �ش���+�Ϸù�ȣ������ �����ȴ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String strDbType : gplus db type
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return String : �ű� �����Թ�ȣ
        */
    	private String getFolderNo(String comcode,String strDbType) {

	    GCmConnection conn = null;

	    try
	    {
		    conn = GCmDbManager.getInstance().getConnection();

		    StringBuffer sqlQuery = new StringBuffer();

                    if ("oracle".equals(strDbType))
                    {
		    	sqlQuery
		           .append(" SELECT DECODE(SUBSTR(MAX(FLDNO),1,8),TO_CHAR(sysdate,'YYYYMMDD'),TO_CHAR(TO_NUMBER(MAX(FLDNO))+1),null,TO_CHAR(sysdate,'YYYYMMDD')||'0001') as NO ")
                           .append(" FROM TB_").append(comcode).append("_B10 ")
                           .append(" WHERE FLDNO LIKE TO_CHAR(sysdate,'YYYYMMDD')||'%'");
                    }
                    else if ("mssql".equals(strDbType))
                         {
                                sqlQuery
                                   .append(" SELECT (CASE SUBSTRING(MAX(FLDNO),1,8) WHEN convert(char(08),getdate(),112) THEN CAST(SUBSTRING(MAX(FLDNO),1,8) AS varchar(8)) + RIGHT('0000'+CAST(SUBSTRING(MAX(FLDNO),9,4)+1 AS varchar(4)),4) ELSE convert(char(08),getdate(),112)+'0001' END) as NO ")
                                   .append(" FROM TB_").append(comcode).append("_B10 ")
                                   .append(" WHERE FLDNO LIKE convert(char(08),getdate(),112)+'%' ");
                         }

    		    GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
                    rs.next();

		    return rs.getString("NO");

            }
            catch (Exception e)
            {
 		  System.out.println(" GCoOrOrgInfoTran::getFolderNo " + e.getMessage());
	 	  return null;
            }
            finally
            {
		  conn.close();
            }
      }

}