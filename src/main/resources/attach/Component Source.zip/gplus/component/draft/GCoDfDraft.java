package gplus.component.draft;


import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

/**
 * <PRE>
 * Filename	: GCoDfDraft.java
 * Class		    : gplus.component.draft.GCoDfDraft
 * Fuction	    :
 * Comment	:
 * History       : 1/6/2002, ������, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCoDfDraft extends GCmTopComponent
{




	/**
	 * <PRE>
	 * ����ī��Ʈ
	 * </PRE>
	 *
	 * @param prop	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�	<BR>
	 *				<LI> String USERID         : �����ID  <BR>
	 *				<LI> String timelogin        : �α��νð�  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  GCmResultSet ���� ��
	 */
	public GCmResultSet getDraftAlarmCountApprtypeNo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID  = dmProp.getString("USERID");
                String timelogin = dmProp.getString("timelogin");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                          .append(" select xx.boxno ")
                          .append(" from tb_").append(COMCODE).append("_d10 cc, ")
                          .append(" ( select yy.boxno, yy.drftno,yy.regdrftno, yy.regdate, yy.execclass, yy.reftype ,yy.readflag   ")
			  .append("   from ( select aa.boxno, aa.drftno, aa.regdrftno,aa.REFTYPE, bb.regdate, bb.execclass,aa.readflag ")
                          .append("           from tb_").append(COMCODE).append("_d20 aa, tb_").append(COMCODE).append("_m10 bb	")
                          .append("           where aa.boxno = bb.boxno ")
			  .append("	      and boxclass='4' ")
                          .append("           and execclass="+genQuote( gplus.commlib.comm.GCmConstDef.EXECCLASS_DRAFT_INBOX) )
                          .append(" 	      and userid =  "+genQuote(USERID))
                          .append("	    ) yy ")
                          .append("    	) xx	  ")
                          .append("  where xx.drftno = cc.drftno ")
                          .append(" and cc.apprtype !='3' ")
                          .append(" and cc.credate >"+genQuote(timelogin));


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println("GCoDfDraft::getDraftAlarmCountApprtypeNo::" + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}

	}


	public GCmResultSet getDraftStatus(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strDrftNo = dmProp.getString("DRFTNO");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();
			StringBuffer sqlQuery = new StringBuffer()
							.append("SELECT A.*, B.SIGNDOCNO ")
							.append(" FROM TB_").append(strComCode).append("_D11 A, TB_COMM_Z20 B ")
							.append(" WHERE A.DRFTNO = " + genQuote(strDrftNo)).append(" AND A.REFTYPE != '3' AND A.APPRID = B.USERID ")
							.append(" ORDER BY A.SEQ ASC ");
			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
		    return rs;
		}
		catch (Exception e)
		{
	 		System.out.println("GCoDfDraft :: getDraftStatus " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}



	/**
	 * <PRE>
	 * ����ī��Ʈ
	 * </PRE>
	 *
	 * @param prop	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�	<BR>
	 *				<LI> String USERID         : �����ID  <BR>
	 *				<LI> String timelogin        : �α��νð�  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  GCmResultSet ���� ��
	 */
	public GCmResultSet getDraftAlarmCountApprtypeYes(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID  = dmProp.getString("USERID");
                String timelogin = dmProp.getString("timelogin");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()

                  .append(" select xx.boxno ")
                          .append(" from tb_").append(COMCODE).append("_d10 cc, ")
                          .append(" ( select yy.boxno, yy.drftno,yy.regdrftno, yy.regdate, yy.execclass, yy.reftype ,yy.readflag   ")
	                  .append("   from ( select aa.boxno, aa.drftno, aa.regdrftno,aa.REFTYPE, bb.regdate, bb.execclass,aa.readflag ")
                          .append("           from tb_").append(COMCODE).append("_d20 aa, tb_").append(COMCODE).append("_m10 bb	")
                          .append("           where aa.boxno = bb.boxno ")
	                  .append("	      and boxclass='4' ")
                          .append("           and execclass="+genQuote( gplus.commlib.comm.GCmConstDef.EXECCLASS_DRAFT_INBOX) )
                          .append(" 	      and userid =  "+genQuote(USERID))
                          .append("	    ) yy ")
                          .append("    	) xx	  ")
                          .append("  where xx.drftno = cc.drftno ")
                          .append(" and cc.apprtype ='3' ")
                          .append("  and xx.readflag ='1' ")
                          .append(" and cc.credate >"+genQuote(timelogin));



			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.err.println("GCoDfDraft::getDraftAlarmCountApprtypeYes::" + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}

	}




	/**
	 * <PRE>
	 * ���縮��Ʈ(����ȭ��)
	 * </PRE>
	 *
	 * @param prop	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�	<BR>
	 *				<LI> String USERID         : �����ID  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return  GCmResultSet ���縮��Ʈ
	 */
	public GCmResultSet getDraftScreenList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID  = dmProp.getString("USERID");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

  	        StringBuffer sqlQuery = new StringBuffer();

            if ("oracle".equals(strDbType))
            {
               sqlQuery
    		  .append(" select xx.boxno,xx.drftno,xx.regdrftno,xx.execclass, ")
		  .append(" cc.title,cc.drftdept,cc.drftpos,cc.drftname,cc.regdate,xx.num,xx.reftype,cc.docno,cc.apprtype ")
                  .append(" from tb_").append(COMCODE).append("_d10 cc, ")
		  .append("    (select rownum num, yy.boxno, yy.drftno,yy.regdrftno, yy.regdate, yy.execclass, yy.reftype ,yy.readflag ")
		  .append("     from (select aa.boxno, aa.drftno, aa.regdrftno,aa.REFTYPE, bb.regdate, bb.execclass,aa.readflag ")
		  .append("           from tb_").append(COMCODE).append("_d20 aa, tb_").append(COMCODE).append("_m10 bb	")
		  .append("  	        where aa.boxno = bb.boxno ")
		  .append("			and boxclass='4' ")
		  .append("			and execclass="+genQuote(gplus.commlib.comm.GCmConstDef.EXECCLASS_DRAFT_INBOX) )
		  .append("			and userid =  "+genQuote(USERID) )
		  .append("	        order by drftno desc) yy ")
  		  .append("    	) xx	  ")
		  .append(" where xx.drftno = cc.drftno ")
    		  .append(" and cc.apprtype !='3' ")
		  .append(" and cc.apprtype !='4' ")         // �ݷ��� �׸�.
		  .append(" union  ")
    		  .append(" select xx.boxno,xx.drftno,xx.regdrftno,xx.execclass, ")
		  .append(" cc.title,cc.drftdept,cc.drftpos,cc.drftname,cc.regdate,xx.num,xx.reftype,cc.docno,cc.apprtype  ")
    		  .append(" from tb_").append(COMCODE).append("_d10 cc,  ")
		  .append("	    (select rownum num, yy.boxno, yy.drftno,yy.regdrftno, yy.regdate, yy.execclass, yy.reftype ,yy.readflag   ")
		  .append("	     from ( select aa.boxno, aa.drftno, aa.regdrftno,aa.REFTYPE, bb.regdate, bb.execclass,aa.readflag  ")
		  .append("                from tb_").append(COMCODE).append("_d20 aa, tb_").append(COMCODE).append("_m10 bb	")
		  .append("   	   	        where aa.boxno = bb.boxno ")
		  .append("				and boxclass='4'  ")
		  .append("				and execclass="+genQuote(gplus.commlib.comm.GCmConstDef.EXECCLASS_DRAFT_INBOX) )
		  .append("				and userid =  "+genQuote(USERID) )
		  .append("		        order by drftno desc) yy ")
  		  .append("    	) xx	  ")
		  .append(" where xx.drftno = cc.drftno ")
        	  .append(" and cc.apprtype ='3' ")
		  .append(" and xx.readflag ='1' ");
            }
            else if ("mssql".equals(strDbType))
            {
               sqlQuery
    		  .append(" select xx.boxno,xx.drftno,xx.regdrftno,xx.execclass, ")
		  .append(" cc.title,cc.drftdept,cc.drftpos,cc.drftname,cc.regdate,xx.reftype,cc.docno,cc.apprtype ")
                  .append(" from tb_").append(COMCODE).append("_d10 cc, ")
		  .append("    (select yy.boxno, yy.drftno,yy.regdrftno, yy.regdate, yy.execclass, yy.reftype ,yy.readflag ")
		  .append("     from (select TOP 4 aa.boxno, aa.drftno, aa.regdrftno,aa.REFTYPE, bb.regdate, bb.execclass,aa.readflag ")
		  .append("           from tb_").append(COMCODE).append("_d20 aa, tb_").append(COMCODE).append("_m10 bb	")
		  .append("  	        where aa.boxno = bb.boxno ")
		  .append("			and boxclass='4' ")
		  .append("			and execclass="+genQuote(gplus.commlib.comm.GCmConstDef.EXECCLASS_DRAFT_INBOX) )
		  .append("			and userid =  "+genQuote(USERID) )
		  .append("	        order by drftno desc) yy ")
  		  .append("    	) xx	  ")
		  .append(" where xx.drftno = cc.drftno ")
    		  .append(" and cc.apprtype !='3' ")
		  .append(" and cc.apprtype !='4' ")         // �ݷ��� �׸�.
		  .append(" union  ")
    		  .append(" select xx.boxno,xx.drftno,xx.regdrftno,xx.execclass, ")
		  .append(" cc.title,cc.drftdept,cc.drftpos,cc.drftname,cc.regdate,xx.reftype,cc.docno,cc.apprtype  ")
    		  .append(" from tb_").append(COMCODE).append("_d10 cc,  ")
		  .append("	    (select yy.boxno, yy.drftno,yy.regdrftno, yy.regdate, yy.execclass, yy.reftype ,yy.readflag   ")
		  .append("	     from ( select TOP 4 aa.boxno, aa.drftno, aa.regdrftno,aa.REFTYPE, bb.regdate, bb.execclass,aa.readflag  ")
		  .append("                from tb_").append(COMCODE).append("_d20 aa, tb_").append(COMCODE).append("_m10 bb	")
		  .append("   	   	        where aa.boxno = bb.boxno ")
		  .append("				and boxclass='4'  ")
		  .append("				and execclass="+genQuote(gplus.commlib.comm.GCmConstDef.EXECCLASS_DRAFT_INBOX) )
		  .append("				and userid =  "+genQuote(USERID) )
		  .append("		        order by drftno desc) yy ")
  		  .append("    	) xx	  ")
		  .append(" where xx.drftno = cc.drftno ")
        	  .append(" and cc.apprtype ='3' ")
		  .append(" and xx.readflag ='1' ");
            }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;

		}
		catch (Exception e)
		{
	 		System.err.println("GCoDfDraft::getDraftScreenList" + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}




	/**
	 * <PRE>
	 *  ���缱 ��ȣ�� ���缱 ������ �˻��Ͽ� ����� Resultset���� �����ϴ� ���
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�		<BR>
	 *				<LI> String LINENO       : ���缱��ȣ  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return �˻������ �ش��ϴ� ���缱������ ���� GCmResultSet
	 */

	public GCmResultSet getDraftLineInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strLineNo     = dmProp.getString("LINENO");


		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
							.append(" SELECT LINENUM,USERID,LINENAME,LINENOTE ")
							.append("	FROM TB_").append(strComCode).append("_D30 WHERE ")
							.append("	LINENUM = " + genQuote(strLineNo));


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{


	 		System.out.println("GCoDfDraft :: getDraftLineInfo " + e.getMessage());

		 	return null;
		}
		finally
		{
			conn.close();
		}
	}




	/**
	 * <PRE>
	 *  ���缱 ��ȣ�� ����,���� ������ �˻��Ͽ� ����� Resultset���� �����ϴ� ���
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�		<BR>
	 *				<LI> String LINENO	        : ���缱��ȣ  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return �˻������ �ش��ϴ� ���缱������ ���� GCmResultSet
	 */

	public GCmResultSet getDraftSubLineInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strLineNo     = dmProp.getString("LINENO");


		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
							.append("SELECT SEQ, SUBTYPE, SUBAPPRID, STEPNUM, SUBAPPRNAME ")
							.append("	FROM TB_").append(strComCode).append("_D31 WHERE ")
							.append("	LINENUM = " + genQuote(strLineNo));


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{

	 		System.out.println("GCoDfDraft :: getDraftSubLineInfo" + e.getMessage());

		 	return null;
		}
		finally
		{
			conn.close();
		}
	}




	/**
	 * <PRE>
	 *  ���缱��ȣ�� ����(���ó�¥ + Max��(4�ڸ�)) �Ͽ� String ��ü�� ����
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�		<BR>
	 *				<LI> String strRegDate     : ���ó�¥ + %  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return ���缱��ȣ�� ���� String
	 */
	public String getMaxLineNo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;

		String strRet = null;



		String strComCode = dmProp.getString("COMCODE");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

	        String strRegDate = GCmFcts.dateToStr(new java.util.Date(),1) + "%";

			StringBuffer sqlQuery = new StringBuffer()
							.append("SELECT MAX(LINENUM) AS MAXNO ")
							.append("	FROM TB_").append(strComCode).append("_D30 WHERE ")
							.append("	LINENUM LIKE " + genQuote(strRegDate));



			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());



			while (rs.next()) {
			    strRet = rs.getString("MAXNO");
				if (strRet.equals(null)) {
					strRet = strRegDate + "0001";
	            }
		        else {
			        strRet = String.valueOf(Integer.parseInt(strRet.substring(8,12)) + 1);
				    strRet = GCmFcts.numToStr(strRet,4);
					strRet = strRegDate + strRet;
	            }
			}


		    return strRet;


		}
		catch (Exception e)
		{

	 		System.out.println("GCoDfDraft :: getMaxLineNo" + e.getMessage());

		 	return null;
		}
		finally
		{
			conn.close();
		}
	}



	/**
	 * <PRE>
	 *  ����ں� ���缱��ȣ�� �̸��� ResultSet���� �����ϴ� ���
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�		<BR>
	 *				<LI> String USERID         : �����ID  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return ���缱��ȣ,�̸��� ���� ResultSet
	 */
	public GCmResultSet getDraftLineList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;


		String strComCode = dmProp.getString("COMCODE");
		String strUserId = dmProp.getString("USERID");


		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
							.append("SELECT LINENUM, LINENAME ")
							.append("	FROM TB_").append(strComCode).append("_D30 WHERE ")
							.append("	USERID = " + genQuote(strUserId))
							.append(" ORDER BY LINENAME");


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());


		    return rs;


		}
		catch (Exception e)
		{

	 		System.out.println("GCoDfDraft :: getDraftLineList" + e.getMessage());

		 	return null;
		}
		finally
		{
			conn.close();
		}
	}




	/**
	 * <PRE>
	 *  �ش� �����Կ� ����� ���簡 �ִ��� ResultSet���� �����ϴ� ���
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�		<BR>
	 *				<LI> String BOXNO         : �Թ�ȣ  <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return ������ ���� ResultSet
	 */
	public GCmResultSet getBoxnoApplyCnt(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;


		String strComCode = dmProp.getString("COMCODE");
		String strBoxNo = dmProp.getString("BOXNO");


		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
							.append("SELECT COUNT(*) AS CNT ")
							.append("	FROM TB_").append(strComCode).append("_D20 WHERE ")
							.append("	BOXNO = " + genQuote(strBoxNo));


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());


		    return rs;


		}
		catch (Exception e)
		{


	 		System.out.println("GCoDfDraft :: getBoxnoApplyCnt" + e.getMessage());

		 	return null;
		}
		finally
		{
			conn.close();
		}
	}




	/**
	 * <PRE>
	 *  �ش� �������� ���� ����Ʈ�� ResultSet���� �����ϴ� ���
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						      <BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�    <BR>
	 *				<LI> String USERID         : �����ID    <BR>
	 *				<LI> String BOXNO         : �Թ�ȣ       <BR>
	 *				<LI> String TRASH          : ������       <BR>
	 *				<LI> String SORTID         : �����ʵ�    <BR>
	 *				<LI> String SORTOPT      : ��������,��������  <BR>
	 *				<LI> String OPT              : �����ʵ�   <BR>
	 *				<LI> String Q				    :                 <BR>
	 *				<LI> String SDATE          : ��������    <BR>
	 *				<LI> String LDATE          : ��������    <BR>
	 *				<LI> String CURPAGE     : ���������� <BR>
	 *				<LI> String PAGESIZE     : ������ũ�� <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return ���縮��Ʈ�� ���� ResultSet
	 */
	public GCmResultSet getDraftList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

        String strOptSql = "";
        String strSortSql = "";

		String strComCode = dmProp.getString("COMCODE");
		String strUserId = dmProp.getString("USERID");
		String strBoxNo = dmProp.getString("BOXNO");
		String strTrash = dmProp.getString("TRASH");
		String strSortId = dmProp.getString("SORTID");
		String strSortOpt = dmProp.getString("SORTOPT");
		String strOpt = dmProp.getString("OPT");
		String strQ = dmProp.getString("Q");
		String strSDate = dmProp.getString("SDATE");
		String strLDate = dmProp.getString("LDATE");
		int intCurPage = dmProp.getInt("CURPAGE");
		int intPageSize = dmProp.getInt("PAGESIZE");
        String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			if (!strOpt.equals("") && (!strQ.equals("") || !strSDate.equals(""))) {
				strSDate = GCmFcts.replace(strSDate,"/","");
			    strLDate = GCmFcts.replace(strLDate,"/","");
	        }

			strOptSql = GCmUtil.getOptSQL(strOpt, strQ, strSDate, strLDate);               //GCmUtil.class
	        strSortSql = GCmUtil.getSortSQL(strSortId, strSortOpt);								//GCmUtil.class

			StringBuffer sqlQuery = new StringBuffer();

            if ("oracle".equals(strDbType))
            {
	  	         sqlQuery.append("SELECT D.* ")
						 .append(" FROM (SELECT C.*, ROWNUM AS RN ")
						 .append(" FROM (SELECT A.DRFTNO,A.DOCNO,B.REFTYPE,B.REGDRFTNO,B.READFLAG,A.ATTNUM,A.DRFTNAME,A.TITLE,A.APPRTYPE,A.CREDATE ")
						 .append(" FROM TB_").append(strComCode).append("_D10 A, TB_").append(strComCode).append("_D20 B ")
						 .append(" WHERE B.BOXNO = " + genQuote(strBoxNo) + " AND A.DRFTNO = B.DRFTNO ")
						 .append(" AND B.TRASHFLAG = " + genQuote(strTrash))
						 .append(strOptSql)
						 .append("	ORDER BY ")
						 .append(strSortSql)
						 .append("	) C ")
						 .append(" WHERE ROWNUM <=  " ).append(intCurPage * intPageSize).append(") D ")
						 .append(" WHERE D.RN BETWEEN ").append(intCurPage * intPageSize - intPageSize + 1).append(" AND ").append(intCurPage * intPageSize);
            }
            else if ("mssql".equals(strDbType))
            {
	  	         sqlQuery.append(" SELECT TOP ").append(intCurPage * intPageSize).append(" SELECT A.DRFTNO,A.DOCNO,B.REFTYPE,B.REGDRFTNO,B.READFLAG,A.ATTNUM,A.DRFTNAME,A.TITLE,A.APPRTYPE,A.CREDATE ")
						 .append(" FROM TB_").append(strComCode).append("_D10 A, TB_").append(strComCode).append("_D20 B ")
						 .append(" WHERE B.BOXNO = " + genQuote(strBoxNo) + " AND A.DRFTNO = B.DRFTNO ")
						 .append(" AND B.TRASHFLAG = " + genQuote(strTrash))
						 .append(strOptSql)
						 .append("	ORDER BY ")
						 .append(strSortSql);
            }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

            if ("mssql".equals(strDbType))
            {
                rs.moveRecordPos((intCurPage-1)*intPageSize);
            }

		    return rs;
		}
		catch (Exception e)
		{

	 		System.out.println("GCoDfDraft :: getDraftList" + e.getMessage());

		 	return null;
		}
		finally
		{
			conn.close();
		}
	}


	public GCmProperties getDraftApprStatusList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;
        GCmProperties strRetProp = new GCmProperties();

        String strOptSql = "";
        String strSortSql = "";

		String strComCode = dmProp.getString("COMCODE");
		String strUserId = dmProp.getString("USERID");
		String strBoxNo = dmProp.getString("BOXNO");
		String strTrash = dmProp.getString("TRASH");
		String strSortId = dmProp.getString("SORTID");
		String strSortOpt = dmProp.getString("SORTOPT");
		String strOpt = dmProp.getString("OPT");
		String strQ = dmProp.getString("Q");
		String strSDate = dmProp.getString("SDATE");
		String strLDate = dmProp.getString("LDATE");
		int intCurPage = dmProp.getInt("CURPAGE");
		int intPageSize = dmProp.getInt("PAGESIZE");
        String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			if (!strOpt.equals("") && (!strQ.equals("") || !strSDate.equals(""))) {
				strSDate = GCmFcts.replace(strSDate,"/","");
			    strLDate = GCmFcts.replace(strLDate,"/","");
	        }

			strOptSql = GCmUtil.getOptSQL(strOpt, strQ, strSDate, strLDate);               //GCmUtil.class
	        strSortSql = GCmUtil.getSortSQL(strSortId, strSortOpt);								//GCmUtil.class

			StringBuffer sqlQuery = new StringBuffer();

            if ("oracle".equals(strDbType))
            {
	  	         sqlQuery.append(" SELECT DRFTNO,APPRID,APPRNAME,APPRPOSNAME,READFLAG,REALVIEWDATE,APPRTYPE,APPRDATE,REFTYPE,SEQ ")
                         .append(" FROM TB_").append(strComCode).append("_D11 ")
                         .append(" WHERE  REFTYPE != '3' AND ")
                         .append("    DRFTNO IN ( SELECT D.DRFTNO ")
						 .append("                FROM (SELECT C.DRFTNO, ROWNUM AS RN ")
						 .append("                      FROM (SELECT A.DRFTNO ")
						 .append("                            FROM TB_").append(strComCode).append("_D10 A, TB_").append(strComCode).append("_D20 B ")
						 .append("                            WHERE B.BOXNO = " + genQuote(strBoxNo) + " AND A.DRFTNO = B.DRFTNO ")
						 .append("                            AND B.TRASHFLAG = " + genQuote(strTrash))
						 .append(                             strOptSql)
						 .append("	                          ORDER BY ")
						 .append(                             strSortSql)
						 .append("	                          ) C ")
						 .append("                      WHERE ROWNUM <=  " ).append(intCurPage * intPageSize).append(") D ")
						 .append("                 WHERE D.RN BETWEEN ").append(intCurPage * intPageSize - intPageSize + 1).append(" AND ").append(intCurPage * intPageSize)
						 .append("	             ) ")
						 .append("	ORDER BY DRFTNO ,SEQ ");
            }
            else if ("mssql".equals(strDbType))
            {
	  	         sqlQuery.append(" SELECT DRFTNO,APPRID,APPRNAME,APPRPOSNAME,READFLAG,REALVIEWDATE,APPRTYPE,APPRDATE,REFTYPE,SEQ ")
                                 .append(" FROM TB_").append(strComCode).append("_D11 ")
                                 .append(" WHERE  REFTYPE != '3' AND ")
                                 .append("    DRFTNO IN ( SELECT TOP ").append(intCurPage * intPageSize).append(" A.DRFTNO ")
				 .append("                FROM TB_").append(strComCode).append("_D10 A, TB_").append(strComCode).append("_D20 B ")
				 .append("                WHERE B.BOXNO = " + genQuote(strBoxNo) + " AND A.DRFTNO = B.DRFTNO ")
				 .append("                AND B.TRASHFLAG = " + genQuote(strTrash))
				                         .append(strOptSql)
				 .append("	         ORDER BY ")
                                 .append(strSortSql)
				 .append("               ) ")
				 .append(" ORDER BY DRFTNO ,SEQ ");
            }

			ResultSet rs = conn.executeSqlQuery(sqlQuery.toString());
			ResultSet rsnext = conn.executeSqlQuery(sqlQuery.toString());
            String tempretstr = "";

            rsnext.next();

            while(rs.next())
            {
                String nowdocno = rs.getString("DRFTNO");

                String APPRID = rs.getString("APPRID");
                String APPRNAME = rs.getString("APPRNAME");
                String APPRPOSNAME = rs.getString("APPRPOSNAME");
                String READFLAG = rs.getString("READFLAG");
                String REALVIEWDATE = rs.getString("REALVIEWDATE");
                String APPRTYPE = rs.getString("APPRTYPE");
                String APPRDATE = rs.getString("APPRDATE");
                String REFTYPE = rs.getString("REFTYPE");
                String SEQ = rs.getString("SEQ");

                if(APPRPOSNAME == null || APPRPOSNAME.trim().length() <= 0 )
                {
                   APPRPOSNAME = "`";
                }

                if(REALVIEWDATE == null || REALVIEWDATE.trim().length() <= 0)
                {
                   REALVIEWDATE = "`";
                }

                if(APPRDATE == null || APPRDATE.trim().length() <= 0)
                {
                   APPRDATE = "`";
                }

                String retstr = APPRID+"||"+APPRNAME+"||"+APPRPOSNAME+"||"+READFLAG+"||"+
                                REALVIEWDATE+"||"+APPRTYPE+"||"+APPRDATE+"||"+REFTYPE+"||"+SEQ;

                String nextdocno = "";

                if(rsnext.next())
                {
                   nextdocno = rsnext.getString("DRFTNO");
                }
                else
                {
                   if(tempretstr.equals(""))
                   {
                      strRetProp.setProperty(nowdocno,retstr);
                   }
                   else
                   {
                      strRetProp.setProperty(nowdocno, tempretstr +","+retstr);
                   }

                   tempretstr = "";
                   break;
                }

                if(nowdocno.equals(nextdocno))
                {
                   if(tempretstr.equals(""))
                   {
                        tempretstr = retstr;
                   }
                   else
                   {
                        tempretstr = tempretstr +","+retstr;
                   }
                }
                else
                {
                   if(tempretstr.equals(""))
                   {
                        strRetProp.setProperty(nowdocno,retstr);
                   }
                   else
                   {
                        strRetProp.setProperty(nowdocno, tempretstr +","+retstr);
                   }

                   tempretstr = "";
                }
            }

            rs.close();
            rsnext.close();
	    return strRetProp;

        }
		catch (Exception e)
		{
	 		System.out.println("GCoDfDraft :: getDraftStatus " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.closeGlobalStmt();
		}
	}



	/**
	 * <PRE>
	 *  �ش� �������� ������� ����
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�    <BR>
	 *				<LI> String BOXNO         : �Թ�ȣ       <BR>
	 *				<LI> String TRASH          : ������       <BR>
	 *				<LI> String OPT              : �����ʵ�   <BR>
	 *				<LI> String Q				    :                 <BR>
	 *				<LI> String SDATE          : ��������    <BR>
	 *				<LI> String LDATE          : ��������    <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return �����Ժ� ��ȸ�� ����
	 */
	public int getRecordCount(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;

        String strOptSql = "";


		String strComCode = dmProp.getString("COMCODE");
		String strBoxNo = dmProp.getString("BOXNO");
		String strTrash = dmProp.getString("TRASH");
		String strOpt = dmProp.getString("OPT");
		String strQ = dmProp.getString("Q");
		String strSDate = dmProp.getString("SDATE");
		String strLDate = dmProp.getString("LDATE");



		try
		{
			conn = GCmDbManager.getInstance().getConnection();


			if (!strOpt.equals("") && (!strQ.equals("") || !strSDate.equals(""))) {

				strSDate = GCmFcts.replace(strSDate,"/","");
			    strLDate = GCmFcts.replace(strLDate,"/","");

				strOptSql = GCmUtil.getOptSQL(strOpt, strQ, strSDate, strLDate);               //GCmUtil.class

	        }



			StringBuffer sqlQuery = new StringBuffer()
							.append("SELECT COUNT(B.REGDRFTNO) AS CNT ")
							.append(" FROM TB_").append(strComCode).append("_D10 A, TB_").append(strComCode).append("_D20 B ")
							.append(" WHERE B.BOXNO = " + genQuote(strBoxNo) + " AND A.DRFTNO = B.DRFTNO ")
                            .append(" AND TRASHFLAG = " + genQuote(strTrash) +  strOptSql ) ;


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			rs.next();

		    return rs.getInt("CNT");


		}
		catch (Exception e)
		{

	 		System.out.println("GCoDfDraft :: getRecordCnt" + e.getMessage());

		 	return -1;
		}
		finally
		{
			conn.close();
		}
	}


	/**
	 * <PRE>
	 *  ���� ��ȣ ����
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�    <BR>
	 *				<LI> String REGDATE      : ��������    <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return �����ȣ
	 */
	public String getMaxDrftNo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;


		String strComCode = dmProp.getString("COMCODE");
		String strRet = "";

		try
		{


			conn = GCmDbManager.getInstance().getConnection();

			String strRegDate =   GCmFcts.dateToStr(new java.util.Date(),1) ;

			StringBuffer sqlQuery = new StringBuffer()
							.append("SELECT MAX(DRFTNO) AS MAXNO ")
							.append(" FROM TB_").append(strComCode).append("_D10 ")
							.append(" WHERE DRFTNO LIKE " + genQuote(strRegDate + "%"));



			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());


			while (rs.next()) {

				strRet = rs.getString("MAXNO");

	            if (strRet.equals(null) || strRet.equals("")) {

		            strRet = strRegDate + "0001";

	            }
		        else {

			        strRet = String.valueOf(Integer.parseInt(strRet.substring(8, 12)) + 1);
				    strRet = GCmFcts.numToStr(strRet, 4);
					strRet = strRegDate + strRet;

	            }
		    }



		    return strRet;


		}
		catch (Exception e)
		{

			System.out.println("GCoDfDraft :: getMaxDrftNo" + e.getMessage());

		 	return null;
		}
		finally
		{
			conn.close();
		}
	}




	/**
	 * <PRE>
	 *  �����Ժ� ��ȹ�ȣ ����
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�    <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return �����Ժ� �����ȣ
	 */
	public String getMaxRegDrftNo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;


		String strRegDate = "";
		String strRet = "";

		try
		{


			String strComCode = dmProp.getString("COMCODE");

			conn = GCmDbManager.getInstance().getConnection();

			strRegDate =   GCmFcts.dateToStr(new java.util.Date(),1);

			StringBuffer sqlQuery = new StringBuffer()
							.append("SELECT MAX(REGDRFTNO) AS MAXNO ")
							.append(" FROM TB_").append(strComCode).append("_D20 ")
							.append(" WHERE REGDRFTNO LIKE ")
							.append( genQuote(strRegDate+ "%"));



			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			while (rs.next()) {

				strRet = rs.getString("MAXNO");

	            if (strRet.equals(null) || strRet.equals("")) {

		            strRet = strRegDate + "0001";

	            }
		        else {

			        strRet = String.valueOf(Integer.parseInt(strRet.substring(8, 12)) + 1);
				    strRet = GCmFcts.numToStr(strRet, 4);
					strRet = strRegDate + strRet;

	            }
		    }

		    return strRet;


		}
		catch (Exception e)
		{

	 		System.out.println("GCoDfDraft :: getMaxRegDrftNo" + e.getMessage());

		 	return null;
		}
		finally
		{
			conn.close();
		}
	}




	/**
	 * <PRE>
	 *  �бⰡ��üũ (�����ܰ� ���簡 �̷�������� �˻�)
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�    <BR>
	 *				<LI> String DRFTNO        : �����ȣ    <BR>
	 *				<LI> String SEQ              : ����    <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return Boolean
	 */
	public GCmResultSet isCheckRead(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strDrftNo = dmProp.getString("DRFTNO");
		String strSeq = dmProp.getString("SEQ");

		try
		{


			conn = GCmDbManager.getInstance().getConnection();



			StringBuffer sqlQuery = new StringBuffer()
							.append("SELECT APPRTYPE ")
							.append(" FROM TB_").append(strComCode).append("_D11 ")
							.append(" WHERE DRFTNO = " + genQuote(strDrftNo) + "AND SEQ = " + genQuote(strSeq));


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

		    return rs;


		}
		catch (Exception e)
		{

	 		System.out.println("GCoDfDraft  :: isCheckRead" + e.getMessage());

		 	return null;
		}
		finally
		{
			conn.close();
		}
	}



/**
	 * <PRE>
	 *  �������� ��ȸ
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�    <BR>
	 *				<LI> String REGDRFTNO  : �����Ժ���ȹ�ȣ    <BR>
	 *				<LI> String SEQ              : ����("01")    <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return ���������� ���� ResultSet
	 */
	public GCmResultSet getDraftInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;


		String strComCode = dmProp.getString("COMCODE");
		String strRegDrftNo = dmProp.getString("REGDRFTNO");

		try
		{

			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
							.append("SELECT A.*, B.*, C.* ")
							.append(" FROM TB_").append(strComCode).append("_D10 A, TB_").append(strComCode).append("_D20 B, TB_").append(strComCode).append("_L11 C ")
							.append(" WHERE A.DRFTNO = B.DRFTNO AND B.REGDRFTNO = " + genQuote(strRegDrftNo))
							.append(" AND A.DOCNO = C.DOCNO AND SEQ = " + genQuote("01"));



			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

		    return rs;


		}
		catch (Exception e)
		{

	 		System.out.println("GCoDfDraft :: getDraftInfo" + e.getMessage());

		 	return null;
		}
		finally
		{
			conn.close();
		}
	}




	/**
	 * <PRE>
	 *   ���缱����(�����Ȳ���)
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�    <BR>
	 *				<LI> String REGDRFTNO  : �����Ժ���ȹ�ȣ    <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return ���缱������ ���� ResultSet
	 */
	public GCmResultSet getDraftProcList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{


		GCmConnection conn = null;


		String strComCode = dmProp.getString("COMCODE");
		String strDrftNo = dmProp.getString("DRFTNO");


		try
		{


			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
							.append("SELECT A.*, B.SIGNDOCNO ")
							.append(" FROM TB_").append(strComCode).append("_D11 A, TB_COMM_Z20 B ")
							.append(" WHERE A.DRFTNO = " + genQuote(strDrftNo)).append(" AND A.APPRID = B.USERID ")
							.append(" ORDER BY A.SEQ ASC ");


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());


		    return rs;

		}
		catch (Exception e)
		{


	 		System.out.println("GCoDfDraft :: getDraftInfo" + e.getMessage());

		 	return null;
		}
		finally
		{
			conn.close();
		}
	}


	public GCmResultSet getPApprUserList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;
		String strComCode = dmProp.getString("COMCODE");
		String strUSERID = dmProp.getString("USERID");
               String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();
                        StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                            sqlQuery
			       .append(" SELECT A.USERID, A.USERNAME, A.POSCODE, A.ORGNO, B.ORGNAME, C.POSNAME, D.DEFLT ")
			       .append(" FROM TB_COMM_Z20 A, TB_").append(strComCode).append("_N10 B, TB_").append(strComCode).append("_N20 C, TB_").append(strComCode).append("_N11 D ")
			       .append(" WHERE A.USERID = D.USERID ")
			       .append(" AND A.POSCODE = C.POSCODE(+) ")
			       .append(" AND B.ORGNO = D.ORGNO AND A.COMCODE = " + genQuote(strComCode))
			       .append(" AND A.USERID = "+genQuote(strUSERID)+" ORDER BY A.USERNAME ");
                        }
                        else if ("mssql".equals(strDbType))
                        {
                            sqlQuery
			       .append(" SELECT A.USERID, A.USERNAME, A.POSCODE, A.ORGNO, B.ORGNAME, C.POSNAME, D.DEFLT ")
			       .append(" FROM TB_COMM_Z20 A, TB_").append(strComCode).append("_N10 B, TB_").append(strComCode).append("_N20 C, TB_").append(strComCode).append("_N11 D ")
			       .append(" WHERE A.USERID = D.USERID ")
			       .append(" AND A.POSCODE *= C.POSCODE ")
			       .append(" AND B.ORGNO = D.ORGNO AND A.COMCODE = " + genQuote(strComCode))
			       .append(" AND A.USERID = "+genQuote(strUSERID)+" ORDER BY A.USERNAME ");
                        }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
		        return rs;
		}
		catch (Exception e)
		{

	 		System.out.println( "GCoDfDraft   :: getPApprUserList" + e.getMessage());

		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

	/**
	 * <PRE>
	 *   �μ��� ã��
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�    <BR>
	 *				<LI> String OPT  : ����                      <BR>
	 *				<LI> String Q      : �˻���                   <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return ResultSet
	 */
	public GCmResultSet getOrgUserList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;
		String strComCode = dmProp.getString("COMCODE");
		String strOpt = dmProp.getString("OPT");
		String strQ = dmProp.getString("Q").trim();
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
		     conn = GCmDbManager.getInstance().getConnection();

	             if (strOpt.toUpperCase().equals("USERID"))
		        strOpt = " A.USERID LIKE '%" + strQ + "%'";
		     else
			strOpt = " A.USERNAME LIKE '%" + strQ + "%'";

  	             StringBuffer sqlQuery = new StringBuffer();

                     if ("oracle".equals(strDbType))
                     {
                         sqlQuery
                           .append(" SELECT A.USERID, A.USERNAME, A.POSCODE, A.ORGNO, B.ORGNAME, C.POSNAME, D.DEFLT ")
                           .append(" FROM TB_COMM_Z20 A, TB_").append(strComCode).append("_N10 B, TB_").append(strComCode).append("_N20 C, TB_").append(strComCode).append("_N11 D ")
                           .append(" WHERE A.USERID = D.USERID AND A.POSCODE = C.POSCODE(+) ")
                           .append("       AND B.ORGNO = D.ORGNO AND A.COMCODE = " + genQuote(strComCode))
                           .append("       AND ").append(strOpt).append(" ORDER BY A.USERNAME ");
                     }
                     else if ("mssql".equals(strDbType))
                     {
                         sqlQuery
                           .append(" SELECT A.USERID, A.USERNAME, A.POSCODE, A.ORGNO, B.ORGNAME, C.POSNAME, D.DEFLT ")
                           .append(" FROM TB_COMM_Z20 A, TB_").append(strComCode).append("_N10 B, TB_").append(strComCode).append("_N20 C, TB_").append(strComCode).append("_N11 D ")
                           .append(" WHERE A.USERID = D.USERID AND A.POSCODE *= C.POSCODE ")
                           .append("       AND B.ORGNO = D.ORGNO AND A.COMCODE = " + genQuote(strComCode))
                           .append("       AND ").append(strOpt).append(" ORDER BY A.USERNAME ");
                     }

	             GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
		     return rs;

		}
		catch (Exception e)
		{
	 		System.out.println( "GCoDfDraft   :: getOrgUserList" + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

	/**
	 * <PRE>
	 *   �����ǰ� ��ȸ
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�    <BR>
	 *				<LI> String DRFTNO        : �����ȣ      <BR>
	 *				<LI> String USERID         : �����ID       <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return ResultSet
	 */
	public GCmResultSet getDraftHelpComment(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strDraftNo = dmProp.getString("DRFTNO");
		String strUserId = dmProp.getString("USERID");
		String strRefType = dmProp.getString("REFTYPE");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();
			StringBuffer sqlQuery = new StringBuffer()
							.append("SELECT * FROM TB_").append(strComCode).append("_D11 ")
							.append(" WHERE DRFTNO = " + genQuote(strDraftNo))
							.append("       AND APPRID = " + genQuote(strUserId))
							.append("       AND APPRTYPE != '2' AND REFTYPE = " + genQuote(strRefType));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
		    return rs;


		}
		catch (Exception e)
		{

	 		System.out.println( "GCoDfDraft   :: getDraftHelpComment" + e.getMessage());

		 	return null;
		}
		finally
		{
			conn.close();
		}
	}


}
