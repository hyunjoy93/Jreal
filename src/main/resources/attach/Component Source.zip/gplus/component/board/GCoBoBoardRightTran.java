package gplus.component.board;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

/**
 * <PRE>
 * Filename		: GCoBoBoardRightTran.java
 * Class		: gplus.component.pos.GCoBoBoardRightTran
 * Fuction		:
 * Comment		:
 * History      : 03/19/2002, ������, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCoBoBoardRightTran extends GCmTopComponent
{
   /**
    * <PRE>
    *    ������ �������� ���޵� �Ķ���͸� ���Ͽ� �ű� ����Ѵ�.
    * </PRE>
    *
	* @author          03/19/2002, ������
	*
    * @param cp        a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE   : current user companycode at seeeion
    *                      <LI> String Boxno     : �Թ�ȣ
    *                      <LI> String Userno    : ����ڹ�ȣ
    *                      <LI> String Docread   : �����б����
    *                      <LI> String Docwrite  : �����������
    *                      <LI> String Docdel    : ������������
    *                      <LI> String Docdeladm : Ÿ������������
    *                      <LI> String Fldmake   : �����ۼ�����
    *                      <LI> String Flddel    : ������������
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return N/A
    */
	public int insertBoxRight(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE   = dmProp.getString("COMCODE");
		String Boxno     = dmProp.getString("Boxno");
		String Userno    = dmProp.getString("Userno");
		String Docread   = dmProp.getString("Docread");
		String Docwrite  = dmProp.getString("Docwrite");
		String Docdel    = dmProp.getString("Docdel");
		String Docdeladm = dmProp.getString("Docdeladm");
		String Fldmake   = dmProp.getString("Fldmake");
		String Flddel    = dmProp.getString("Flddel");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" INSERT INTO TB_"+COMCODE+"_M20 (BOXNO,USERID,DOCREAD,DOCWRITE,DOCDEL,DOCDELADM,FLDMAKE,FLDDEL) ")
					.append(" VALUES ("+genQuote(Boxno)+","+genQuote(Userno)+","+genQuote(Docread)+","+genQuote(Docwrite)+","+genQuote(Docdel)+",")
                                        .append("         "+genQuote(Docdeladm)+","+genQuote(Fldmake)+","+genQuote(Flddel)+") ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			  rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoBoBoardRightTran::insertBoxRight : " + ignored.getMessage());
			}

	 		System.out.println(" GCoBoBoardRightTran::insertBoxRight : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoBoBoardRightTran::insertBoxRight : " + e.getMessage());
			}
			conn.close();
		}
	}

   /**
    * <PRE>
    *    ������ �������� ���޵� ����ڹ�ȣ�� �Թ�ȣ�� ���Ͽ� ������
    * </PRE>
    *
	* @author          03/19/2002, ������
	*
    * @param cp        a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at seeeion
    *                      <LI> String Boxno   : �Թ�ȣ
    *                      <LI> String Userid  : ����ڹ�ȣ (ex)�ټ��� ID�� aa,bb,cc���·� ����
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return N/A
    */
	public int deleteBoxRight(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Boxno = dmProp.getString("Boxno");
		String Userid = dmProp.getString("Userid");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" DELETE FROM TB_"+COMCODE+"_M20 ")
					.append(" WHERE BOXNO = "+genQuote(Boxno)+" AND USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userid,",","','")+"') ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			  rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoBoBoardRightTran::deleteBoxRight : " + ignored.getMessage());
			}

	 		System.out.println(" GCoBoBoardRightTran::deleteBoxRight : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoBoBoardRightTran::deleteBoxRight : " + e.getMessage());
			}
			conn.close();
		}
	}

   /**
    * <PRE>
    *    ���޵� �ټ��� ����� ID�� ����ڵ��� ����� ������ �ϰ� ����ϸ� ��� ����ڴ� ���޵� ���� ������
    *    ������ �������� ��� ��
    * </PRE>
    *
	* @author          03/19/2002, ������
	*
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE   : current user companycode at seeeion
    *                      <LI> String Boxno     : �Թ�ȣ
    *                      <LI> String Userno    : ����ڹ�ȣ  (ex)�ټ��� ID�� aa,bb,cc���·� ����
    *                      <LI> String Docread   : �����б����
    *                      <LI> String Docwrite  : �����������
    *                      <LI> String Docdel    : ������������
    *                      <LI> String Docdeladm : Ÿ������������
    *                      <LI> String Fldmake   : �����ۼ�����
    *                      <LI> String Flddel    : ������������
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return N/A
    */
	public int insertMultyBoxRight(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE   = dmProp.getString("COMCODE");
		String Boxno     = dmProp.getString("Boxno");
		String Userid    = dmProp.getString("Userid");
		String Docread   = dmProp.getString("Docread");
		String Docwrite  = dmProp.getString("Docwrite");
		String Docdel    = dmProp.getString("Docdel");
		String Docdeladm = dmProp.getString("Docdeladm");
		String Fldmake   = dmProp.getString("Fldmake");
		String Flddel    = dmProp.getString("Flddel");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" INSERT INTO TB_"+COMCODE+"_M20 (BOXNO,USERID,DOCREAD,DOCWRITE,DOCDEL,DOCDELADM,FLDMAKE,FLDDEL) ")
					.append("          SELECT "+genQuote(Boxno)+",USERID,"+genQuote(Docread)+","+genQuote(Docwrite)+","+genQuote(Docdel)+",")
                    .append("                 "+genQuote(Docdeladm)+","+genQuote(Fldmake)+","+genQuote(Flddel))
                    .append("          FROM TB_COMM_Z20 ")
                    .append("          WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userid,",","','")+"') ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			  rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoBoBoardRightTran::insertMultyBoxRight : " + ignored.getMessage());
			}

	 		System.out.println(" GCoBoBoardRightTran::insertMultyBoxRight : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoBoBoardRightTran::insertMultyBoxRight : " + e.getMessage());
			}
			conn.close();
		}
	}

   /**
    * <PRE>
    *    �ű� ������ ������ �����Կ� ���� ȸ�� ��ü ������ ���� ������ �������� �⺻������ �ϰ� �����
    *    ���޵� ȸ���ڵ�� ȸ���ڵ忡 �ش��ϴ� ����ڵ��� ����� ������ �ϰ� ����ϸ� ��� ����ڴ�
    *    ��� �����Ա����� ���� �������� Setting ��
    * </PRE>
    *
	* @author          03/19/2002, ������
	*
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at seeeion
    *                      <LI> String Boxno   : �Թ�ȣ
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return N/A
    */
	public int insertNewDocBoxRight(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Boxno = dmProp.getString("Boxno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" INSERT INTO TB_"+COMCODE+"_M20 (BOXNO,USERID,DOCREAD,DOCWRITE,DOCDEL,DOCDELADM,FLDMAKE,FLDDEL) ")
					.append("          SELECT "+genQuote(Boxno)+",USERID,'1','1','1','1','1','1' ")
                                        .append("          FROM TB_COMM_Z20 ")
                                        .append("          WHERE COMCODE = "+genQuote(COMCODE));

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			  rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoBoBoardRightTran::insertNewDocBoxRight : " + ignored.getMessage());
			}

	 		System.out.println(" GCoBoBoardRightTran::insertNewDocBoxRight : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoBoBoardRightTran::insertNewDocBoxRight : " + e.getMessage());
			}
			conn.close();
		}
	}


}