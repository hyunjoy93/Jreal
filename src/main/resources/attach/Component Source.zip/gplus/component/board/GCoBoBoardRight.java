package gplus.component.board;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

/**
 * <PRE>
 * Filename		: GCoBoBoardRight.java
 * Class		: gplus.component.pos.GCoBoBoardRight
 * Fuction		:
 * Comment		:
 * History      : 03/19/2002, ������, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCoBoBoardRight extends GCmTopComponent
{
    /**
     * <PRE>
     *    ȸ���ȣ, �����Թ�ȣ, ����� ID�� ���޹޾� ����ں� ������ ��뿡 ���� ������ �����ش�.
     * </PRE>
     *
	 * @author          03/19/2002, ������
	 *
     * @param cp        a GCmProperties holding gplus groupware properties.
     * @param dmProp    GCmProperties
     *                  <UL>relevant fields.
     *                      <LI> String COMCODE : current user companycode at session
     *                      <LI> String Boxno   : �Թ�ȣ
	 *                      <LI> String USERID  : current user ID at session
     *                  </UL>
     * @param msgInfo   a GCmMsgInfo holding error codes.
     * @return          GCmResultSet : �����Ա������� list (BOXNO,USERID,DOCREAD,DOCWRITE,DOCDEL,DOCDELADM,FLDMAKE,FLDDEL)
     */

	 public GCmResultSet getBoxRight(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String BOXNO   = dmProp.getString("BOXNO");
		String USERID  = dmProp.getString("USERID");


		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT BOXNO,USERID,DOCREAD,DOCWRITE,DOCDEL,DOCDELADM,FLDMAKE,FLDDEL ")
                           .append(" FROM TB_").append(COMCODE).append("_M20 ")
                           .append(" WHERE BOXNO = "+genQuote(BOXNO))
                           .append(" AND USERID = "+genQuote(USERID));

                	GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoBoBoardRight::getBoxRight " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	 }

     /**
     * <PRE>
     *    ȸ���ȣ, �����Թ�ȣ�� ���޹޾� �������� ���� ����ڵ��� ���� ����Ʈ�� �����´�.
     * </PRE>
     *
	 * @author          03/19/2002, ������
	 *
     * @param cp        a GCmProperties holding gplus groupware properties.
     * @param dmProp    GCmProperties
     *                  <UL>relevant fields.
     *                      <LI> String COMCODE : current user companycode at session
     *                      <LI> String Boxno   : �Թ�ȣ
     *                  </UL>
     * @param msgInfo   a GCmMsgInfo holding error codes.
     * @return          GCmResultSet : ������ ����ں� �������� list
	 *                                 (BOXNO,USERID,DOCREAD,DOCWRITE,DOCDEL,DOCDELADM,FLDMAKE,FLDDEL,USERNAME,POSNAME,ORGNAME)
     */
	 public GCmResultSet getBoxRightUserList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String Boxno   = dmProp.getString("Boxno");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT A.BOXNO,A.USERID,A.DOCREAD,A.DOCWRITE,A.DOCDEL,A.DOCDELADM,A.FLDMAKE,A.FLDDEL, B.USERNAME, C.POSNAME, D.ORGNAME ")
                           .append(" FROM TB_").append(COMCODE).append("_M20 A, TB_COMM_Z20 B, TB_").append(COMCODE).append("_N20 C, TB_").append(COMCODE).append("_N10 D ")
                           .append(" WHERE A.USERID = B.USERID AND B.POSCODE = C.POSCODE AND B.ORGNO = D.ORGNO AND A.BOXNO = "+genQuote(Boxno))
                           .append(" ORDER BY D.ORGNAME ");

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoBoBoardRight::getBoxRightUserList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	 }

     /**
     * <PRE>
     *    ȸ���ȣ, �����Թ�ȣ, ����� ID�� ���޹޾� ����ں� ������ ��뿡 ���� ������ �����ش�.
     * </PRE>
     *
	 * @author          03/19/2002, ������
	 *
     * @param cp        a GCmProperties holding gplus groupware properties.
     * @param dmProp    GCmProperties
     *                  <UL>relevant fields.
     *                      <LI> String COMCODE : current user companycode at session
     *                      <LI> String Boxno   : �Թ�ȣ
	 *                      <LI> String Userid  : current user ID at session
     *                  </UL>
     * @param msgInfo   a GCmMsgInfo holding error codes.
     * @return          GCmResultSet : ����ں� �������� list 
	 *                                 (BOXNO,USERID,DOCREAD,DOCWRITE,DOCDEL,DOCDELADM,FLDMAKE,FLDDEL,USERNAME,POSNAME,ORGNAME)
     */
	 public GCmResultSet getBoxRightUsers(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String Boxno   = dmProp.getString("Boxno");
		String Userid  = dmProp.getString("Userid");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT A.BOXNO,A.USERID,A.DOCREAD,A.DOCWRITE,A.DOCDEL,A.DOCDELADM,A.FLDMAKE,A.FLDDEL, B.USERNAME, C.POSNAME, D.ORGNAME ")
                           .append(" FROM TB_").append(COMCODE).append("_M20 A, TB_COMM_Z20 B, TB_").append(COMCODE).append("_N20 C, TB_").append(COMCODE).append("_N10 D ")
                           .append(" WHERE A.USERID = B.USERID AND B.POSCODE = C.POSCODE AND B.ORGNO = D.ORGNO AND A.BOXNO = "+genQuote(Boxno)+" AND ")
                           .append("       A.USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Userid,",","','")+"')");

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoBoBoardRight::getBoxRightUserList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

}