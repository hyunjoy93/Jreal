package gplus.component.research;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

/**
 * <PRE>
 * Filename		: GCoBoBoard.java
 * Class		: gplus.component.pos.GCoBoBoard
 * Fuction		:
 * Comment		:
 * History      : 03/19/2002, ������, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GCoReResearch extends GCmTopComponent
{
        public GCmResultSet getRecordCount(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

                String COMCODE  = dmProp.getString("COMCODE");
                String PARENTNO = dmProp.getString("BOXNO");
                String OPT      = dmProp.getString("OPT");
                String Q	    = dmProp.getString("Q");
		String SDATE    = dmProp.getString("SDATE");
                String LDATE    = dmProp.getString("LDATE");


               	try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT COUNT(*) AS CNT ")
                           .append(" FROM TB_").append(COMCODE).append("_Q10 A");

                           if(OPT.equals("USERNAME")){
                                 sqlQuery
                                     .append(", TB_COMM_Z20 B ");
                           }
                           sqlQuery
                              .append(" WHERE A.BOXNO = ")
                              .append(genQuote(PARENTNO));

                       if(!OPT.equals("") && (!Q.equals("") || !SDATE.equals("")))
                       {
                            String s4 = GCmFcts.replace(SDATE, "/", "");
                            String s5 = GCmFcts.replace(LDATE, "/", "");


                            if(OPT.toUpperCase().equals("DATE"))
                            {

                                          sqlQuery
                                             .append(" AND ( (A.S").append(OPT)
                                             .append(" BETWEEN "+genQuote(s4))
                                             .append(" AND "+genQuote(s5))
                                             .append(" ) OR (A.L").append(OPT)
                                             .append(" BETWEEN "+genQuote(s4))
                                             .append(" AND "+genQuote(s5))
                                             .append(" ) OR (A.S").append(OPT).append(" <= " + s4)
                                             .append(" AND A.L").append(OPT).append(" >= "+ s5+"))");

                            } else if(OPT.toUpperCase().equals("USERNAME")){
                               sqlQuery
                                  .append(" AND LOWER(B.").append(OPT).append(") LIKE ")
                                  .append("'%").append(Q.toLowerCase()).append("%'")
                                  .append(" AND A.REGUSER = B.USERID");
                            }else{

                            sqlQuery
                                  .append(" AND LOWER(A.").append(OPT).append(") LIKE ")
                                  .append("'%").append(Q.toLowerCase()).append("%'");

                              }
                        }

                        GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;
		}
		catch (Exception e)
		{
	 		System.out.println(" GCoRdResearch ::getRecordCount " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

        public GCmResultSet getResearchList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
                  GCmConnection conn = null;
                  String COMCODE = dmProp.getString("COMCODE");
                  String BOXNO   = dmProp.getString("BOXNO");
                  String SORTID  = dmProp.getString("SORTID");
                  String SORTOPT = dmProp.getString("SORTOPT");
                  String OPT     = dmProp.getString("OPT");
                  String Q       = dmProp.getString("Q");
                  String SDATE   = dmProp.getString("SDATE");
                  String LDATE   = dmProp.getString("LDATE");
	          int  CURPAGE   = dmProp.getInt("CURPAGE");
		  int  PAGESIZE  = dmProp.getInt("PAGESIZE");
                  String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		  try
      		  {
			conn = GCmDbManager.getInstance().getConnection();

                        StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                              sqlQuery
                        	  .append(" SELECT C.QUESTIONNO,C.BOXNO,C.SDATE,C.LDATE,C.STATUS,C.REGUSER,C.TITLE,C.COMMENTS, C.RN")
                  		  .append(" FROM (SELECT B.QUESTIONNO,B.BOXNO,B.SDATE,B.LDATE,B.STATUS,B.REGUSER,B.TITLE,B.COMMENTS,ROWNUM AS RN  ")
                                  .append("       FROM (SELECT A.QUESTIONNO,A.BOXNO,A.SDATE,A.LDATE,A.STATUS,A.REGUSER,A.TITLE,A.COMMENTS ")
                        	  .append("             FROM TB_").append(COMCODE).append("_Q10 A ");

                              if(OPT.equals("USERNAME")){
                                    sqlQuery
                                          .append(" , tb_comm_z20 Z ");
                              }
                              sqlQuery
                                  .append(" WHERE A.BOXNO = ").append(genQuote(BOXNO));
                        }
                        else if ("mssql".equals(strDbType))
                        {
                               sqlQuery
                  		  .append(" SELECT TOP ").append(CURPAGE * PAGESIZE).append(" A.QUESTIONNO,A.BOXNO,A.SDATE,A.LDATE,A.STATUS,A.REGUSER,A.TITLE,A.COMMENTS ")
                  		  .append(" FROM TB_").append(COMCODE).append("_Q10 A ,tb_comm_z20 Z WHERE A.BOXNO = ").append(genQuote(BOXNO));
                        }

                        if(!OPT.equals("") && (!Q.equals("") || !SDATE.equals("")))
                        {

                                  String s4 = GCmFcts.replace(SDATE, "/", "");
                                  String s5 = GCmFcts.replace(LDATE, "/", "");

                                  if(OPT.toUpperCase().equals("DATE"))
                                  {
                                          sqlQuery
                                             .append(" AND ( (A.S").append(OPT)
                                             .append(" BETWEEN "+genQuote(s4))
                                             .append(" AND "+genQuote(s5))
                                             .append(" ) OR (A.L").append(OPT)
                                             .append(" BETWEEN "+genQuote(s4))
                                             .append(" AND "+genQuote(s5))
                                             .append(" ) OR (A.S").append(OPT).append(" <= " + s4)
                                             .append(" AND A.L").append(OPT).append(" >= "+ s5+"))");



                                   } else if(OPT.toUpperCase().equals("USERNAME")){
                                          sqlQuery
                                                .append(" AND LOWER(Z.").append(OPT).append(") LIKE ")
                                                .append("'%").append(Q.toLowerCase()).append("%'")
                                                .append(" AND A.REGUSER = Z.USERID");
                                  }else{

                                          sqlQuery
                                                .append(" AND LOWER(A.").append(OPT).append(") LIKE ")
                                                .append("'%").append(Q.toLowerCase()).append("%'");

                                    }

                           }

                           if ("oracle".equals(strDbType))
                          {
                                sqlQuery
                                    .append(" order by questionno DESC) B WHERE rownum <=  " ).append(CURPAGE * PAGESIZE).append(") C ")
  			            .append(" WHERE C.RN BETWEEN ").append(CURPAGE * PAGESIZE - PAGESIZE + 1)
                                    .append(" AND ").append(CURPAGE * PAGESIZE)
                                    .append(" ORDER BY C.QUESTIONNO DESC" );
                          }

                          GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

                          if ("mssql".equals(strDbType))
                          {
                                  rs.moveRecordPos((CURPAGE-1)*PAGESIZE);
                          }

                          return rs;

                  }
		  catch (Exception e)
                  {
	 		System.out.println(" GCoReResearch::getResearchList : " + e.getMessage());
		 	return null;
		  }
		  finally
		  {
			conn.close();
		  }
	   }

           public GCmResultSet getResearchInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
          {
		  GCmConnection conn = null;

		  String strComCode = dmProp.getString("COMCODE");
		  String strQuestionNo  = dmProp.getString("questionno");
                  String strBoxNo = dmProp.getString("boxno");

		  try
		  {
			conn = GCmDbManager.getInstance().getConnection();
			StringBuffer sqlQuery = new StringBuffer()
				.append(" SELECT QUESTIONNO, BOXNO, SDATE, LDATE, REGUSER, TITLE, COMMENTS ")
                                .append(" FROM TB_").append(strComCode).append("_Q10 ")
                                .append(" where QUESTIONNO = " + genQuote(strQuestionNo))
                                .append(" and BOXNO = " + genQuote(strBoxNo))
                                .append(" ORDER BY QUESTIONNO ");

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		  }
		  catch (Exception e)
		  {
	 		System.out.println("  GCoReResearch::getResearchInfo" + e.getMessage());
		 	return null;
		  }
		  finally
		  {
			conn.close();
		  }
	    }

             public GCmResultSet getUserList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
            {
		  GCmConnection conn = null;

		  String strComCode = dmProp.getString("COMCODE");
		  String strQuestionNo  = dmProp.getString("questionno");

		  try
		  {
			conn = GCmDbManager.getInstance().getConnection();
			StringBuffer sqlQuery = new StringBuffer()
				.append(" SELECT t2.orgname, n2.posname, t2.username, t2.userid ")
                                .append(" from (select t1.poscode, t1.username, n1.orgname, t1.userid ")
                                .append(" from (select z2.orgno, z2.poscode, z2.username, q2.userid ")
                                .append(" FROM TB_").append(strComCode).append("_Q20 q2,tb_comm_z20 z2 ")
                                .append(" where q2.userid = z2.userid ")
                                .append(" AND q2.QUESTIONNO = "+ genQuote(strQuestionNo))
                                .append(" ) t1, tb_gplus_n10 n1 where t1.orgno = n1.orgno) t2,")
                                .append(" tb_gplus_n20 n2 where t2.poscode = n2.poscode");

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		  }
		  catch (Exception e)
		  {
	 		System.out.println("  GCoReResearch::getUserList" + e.getMessage());
		 	return null;
		  }
		  finally
		  {
			conn.close();
		  }
	    }

             public GCmResultSet getUserFlag(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
            {
		  GCmConnection conn = null;

		  String strComCode = dmProp.getString("COMCODE");
                  String strUserId  = dmProp.getString("USERID");
		  String strQuestionNo  = dmProp.getString("questionno");

		  try
		  {
			conn = GCmDbManager.getInstance().getConnection();
			StringBuffer sqlQuery = new StringBuffer()
				.append(" SELECT REQFLAG ")
                                .append(" FROM TB_").append(strComCode).append("_Q20")
                                .append(" WHERE QUESTIONNO = " + genQuote(strQuestionNo))
                                .append(" AND USERID = "+ genQuote(strUserId));


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		  }
		  catch (Exception e)
		  {
	 		System.out.println("  GCoReResearch::getUserFlag" + e.getMessage());
		 	return null;
		  }
		  finally
		  {
			conn.close();
		  }
	    }


            //�����׸�
            public GCmResultSet getResearchObject(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
            {
		  GCmConnection conn = null;

		  String strComCode = dmProp.getString("COMCODE");
		  String strQuestionNo  = dmProp.getString("questionno");

		  try
		  {
			conn = GCmDbManager.getInstance().getConnection();
			StringBuffer sqlQuery = new StringBuffer()
				.append(" SELECT ITEMNO, QUESTIONNO, SEQ, ITEMTITLE, ITEMTYPE, SUBITEMCNT ")
                                .append(" FROM TB_").append(strComCode).append("_Q11 ")
                                .append(" WHERE QUESTIONNO =" + genQuote(strQuestionNo))
                                .append(" ORDER BY ITEMNO ");

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		  }
		  catch (Exception e)
		  {
	 		System.out.println("  GCoReResearch::getResearchObject" + e.getMessage());
		 	return null;
		  }
		  finally
		  {
			conn.close();
		  }
	    }

            //���� �� �׸�
            public GCmResultSet getResearchObjectDetail(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
            {
		  GCmConnection conn = null;

		  String strComCode = dmProp.getString("COMCODE");
		  String strItemNo  = dmProp.getString("itemno");

		  try
		  {
			conn = GCmDbManager.getInstance().getConnection();
			StringBuffer sqlQuery = new StringBuffer()
				.append(" SELECT SUBITEMNO, ITEMNO, SEQ, SUBITEMTITLE ")
                                .append(" FROM TB_").append(strComCode).append("_Q12 ")
                                .append(" WHERE ITEMNO =" + genQuote(strItemNo))
                                .append(" ORDER BY SUBITEMNO ");

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		  }
		  catch (Exception e)
		  {
	 		System.out.println("  GCoReResearch::getResearchObjectDetail" + e.getMessage());
		 	return null;
		  }
		  finally
		  {
			conn.close();
		  }
	    }

            public GCmResultSet getResultCount(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
            {
		  GCmConnection conn = null;

		  String strComCode    = dmProp.getString("COMCODE");
                  String strQuestionNo  = dmProp.getString("questionno");
		  String strSubItemNo  = dmProp.getString("subitemno");


		  try
		  {
			conn = GCmDbManager.getInstance().getConnection();
			StringBuffer sqlQuery = new StringBuffer()
				.append(" SELECT * ")
                                .append(" FROM TB_").append(strComCode).append("_Q30 ")
                                .append(" WHERE subitemno =" + genQuote(strSubItemNo))
                                .append(" AND QUESTIONNO = "+ genQuote(strQuestionNo));


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		  }
		  catch (Exception e)
		  {
	 		System.out.println("  GCoReResearch::getResearchObjectDetail" + e.getMessage());
		 	return null;
		  }
		  finally
		  {
			conn.close();
		  }
	    }

            public GCmResultSet getUserCount(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
            {
		  GCmConnection conn = null;

		  String strComCode    = dmProp.getString("COMCODE");
                  String strQuestionNo  = dmProp.getString("questionno");
		  String strUserId  = dmProp.getString("USERID");

		  try
		  {
			conn = GCmDbManager.getInstance().getConnection();
			StringBuffer sqlQuery = new StringBuffer()
				.append(" SELECT * ")
                                .append(" FROM TB_").append(strComCode).append("_Q20 ")
                                .append(" WHERE USERID =" + genQuote(strUserId))
                                .append(" AND QUESTIONNO = "+ genQuote(strQuestionNo));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		  }
		  catch (Exception e)
		  {
	 		System.out.println("  GCoReResearch::getUserCount" + e.getMessage());
		 	return null;
		  }
		  finally
		  {
			conn.close();
		  }
	    }

            public GCmResultSet getUserName(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
            {
		  GCmConnection conn = null;

		  String strComCode    = dmProp.getString("COMCODE");
                  String strUserId     = dmProp.getString("userid");

		  try
		  {
			conn = GCmDbManager.getInstance().getConnection();
			StringBuffer sqlQuery = new StringBuffer()
				.append(" SELECT B.USERNAME ")
                                .append(" FROM TB_").append(strComCode).append("_Q10 A, TB_COMM_Z20 B ")
                                .append(" WHERE A.REGUSER = "+ genQuote(strUserId))
                                .append(" AND A.REGUSER = B.USERID");

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		  }
		  catch (Exception e)
		  {
	 		System.out.println("  GCoReResearch::getUserName" + e.getMessage());
		 	return null;
		  }
		  finally
		  {
			conn.close();
		  }
	    }

            public GCmResultSet getDelList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
            {
		  GCmConnection conn = null;

		  String strComCode    = dmProp.getString("COMCODE");
                  String strQuestionNo  = dmProp.getString("questionno");
		  //String strSubItemNo  = dmProp.getString("subitemno");

		  try
		  {
			conn = GCmDbManager.getInstance().getConnection();
			StringBuffer sqlQuery = new StringBuffer()
				.append(" SELECT ITEMNO ")
                                .append(" FROM TB_").append(strComCode).append("_Q11 ")
                                .append(" WHERE QUESTIONNO = "+ genQuote(strQuestionNo));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		  }
		  catch (Exception e)
		  {
	 		System.out.println("  GCoReResearch::getDelList" + e.getMessage());
		 	return null;
		  }
		  finally
		  {
			conn.close();
		  }
	    }


            public GCmResultSet getSuggestion(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
            {
		  GCmConnection conn = null;

		  String strComCode    = dmProp.getString("COMCODE");
                  String strQuestionNo  = dmProp.getString("questionno");
		  String strSubItemNo  = dmProp.getString("subitemno");

		  try
		  {
			conn = GCmDbManager.getInstance().getConnection();
			StringBuffer sqlQuery = new StringBuffer()
				.append(" SELECT SUGGESTION ")
                                .append(" FROM TB_").append(strComCode).append("_Q30 ")
                                .append(" WHERE QUESTIONNO = "+ genQuote(strQuestionNo))
                                .append(" AND SUBITEMNO = "+ genQuote(strSubItemNo));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		  }
		  catch (Exception e)
		  {
	 		System.out.println("  GCoReResearch::getSuggestion" + e.getMessage());
		 	return null;
		  }
		  finally
		  {
			conn.close();
		  }
	    }

            public GCmResultSet getDelSubList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
            {
		  GCmConnection conn = null;

		  String strComCode    = dmProp.getString("COMCODE");
                  String strItemNo  = dmProp.getString("itemno");
		  //String strSubItemNo  = dmProp.getString("subitemno");

		  try
		  {
			conn = GCmDbManager.getInstance().getConnection();
			StringBuffer sqlQuery = new StringBuffer()
				.append(" SELECT SUBITEMNO ")
                                .append(" FROM TB_").append(strComCode).append("_Q12 ")
                                .append(" WHERE ITEMNO = "+ genQuote(strItemNo));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		  }
		  catch (Exception e)
		  {
	 		System.out.println("  GCoReResearch::getDelSubList" + e.getMessage());
		 	return null;
		  }
		  finally
		  {
			conn.close();
		  }
	    }

            public GCmResultSet getDelUser(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
            {
		  GCmConnection conn = null;

		  String strComCode    = dmProp.getString("COMCODE");
                  String strQuestionNo  = dmProp.getString("questionno");
		  //String strSubItemNo  = dmProp.getString("subitemno");

		  try
		  {
			conn = GCmDbManager.getInstance().getConnection();
			StringBuffer sqlQuery = new StringBuffer()
				.append(" SELECT USERID ")
                                .append(" FROM TB_").append(strComCode).append("_Q20 ")
                                .append(" WHERE QUESTIONNO = "+ genQuote(strQuestionNo));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		  }
		  catch (Exception e)
		  {
	 		System.out.println("  GCoReResearch::getDelUser" + e.getMessage());
		 	return null;
		  }
		  finally
		  {
			conn.close();
		  }
	    }

            public GCmResultSet getUserConfirm(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
            {
		  GCmConnection conn = null;

		  String strComCode    = dmProp.getString("COMCODE");
                  String strQuestionNo  = dmProp.getString("questionno");

		  try
		  {
			conn = GCmDbManager.getInstance().getConnection();
			StringBuffer sqlQuery = new StringBuffer()
				.append(" SELECT ITEMNO ")
                                .append(" FROM TB_").append(strComCode).append("_Q20 ")
                                .append(" WHERE QUESTIONNO = "+ genQuote(strQuestionNo));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		  }
		  catch (Exception e)
		  {
	 		System.out.println("  GCoReResearch::getUserConfirm" + e.getMessage());
		 	return null;
		  }
		  finally
		  {
			conn.close();
		  }
	    }





}