package gplus.component.common;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;


/**
 * <PRE>
 * Filename		: GCoCnZipCode.java
 * Class		: gplus.component.common.GCoCnZipCode
 * Fuction		: ������ȣ ����Ÿ�� �����Ѵ�.
 * Comment		:
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCoCnZipCode extends GCmTopComponent
{
       /**
        * <PRE>
        * ���޵� ���̸��� ���Ͽ� �ش��ϴ� ���̸��� �����ϰ� �ִ� �����ּҸ� �˻��Ͽ� �����ش�. 
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String addrname : ���̸�
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet ������ȣ list (zipcode,si_do,gu_gun,dong,bunji_range)
        */	 	 
	public GCmResultSet getAddressList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;
		String addrname = dmProp.getString("addrname");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();
			StringBuffer sqlQuery = new StringBuffer()
				   .append(" SELECT zipcode,si_do,gu_gun,dong,bunji_range ")
				   .append(" FROM TB_COMM_ZIPCODE ")
				   .append(" WHERE dong like "+genQuote("%"+addrname+"%"))
				   .append(" order by zipcode ");
			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		}
		catch (Exception e)
		{
	 		System.out.println(" GCoCnZipCode::getAddressList : " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

}