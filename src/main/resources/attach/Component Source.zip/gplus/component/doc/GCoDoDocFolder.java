package gplus.component.doc;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

/**
 * <PRE>
 * Filename		: GCoDoDocFolder.java
 * Class		: gplus.component.doc.GCoDoDocFolder
 * Fuction		: ���� ������ ��ȸ��
 * Comment		:
 * History  : 12/10/2001, ������ , �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GCoDoDocFolder extends GCmTopComponent
{

       /**
        * <PRE>
        * ������ ������ ���޹޾� ������ �����ϱ� ������ �����ؾ� ��  ������  ������.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID :  ����� ���̵�
        * 		       <LI> String BOXNO :  �� ��ȣ
        *		       <LI> String FLDNO :  ����  ��ȣ
        *  		       <LI> String TARGET :  �̵��� ���� ��ȣ
        *  		       <LI> String PPATH :  ���α׷� ��ġ�Ȱ��
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        *
        */
    public int getFldCopy(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
    {

        GCmConnection conn = null;
        Statement stmt = null;

        String COMCODE = dmProp.getString("COMCODE");
        String USERID = dmProp.getString("USERID");
        String BOXNO = dmProp.getString("BOXNO");
        String FLDNO = dmProp.getString("FLDNO");
        String TARGET = dmProp.getString("TARGET");
        String PPATH = dmProp.getString("PPATH");
        String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

        int rv = 0;
        String docno = "";
        String newfldno = "";
        String filename = "";
        boolean flag = true;

        StringBuffer SqlQuery = null;

        GCoDoDocFolder docfolder = new GCoDoDocFolder();
        GCoDoDocFolderTran docfoldertran = new GCoDoDocFolderTran();
        GCoDoDoc doc = new GCoDoDoc();
        GCoDoDocTran docTran = new GCoDoDocTran();


	try {

   	   conn = GCmDbManager.getInstance().getConnection();
           stmt = conn.createStatement();
           conn.setAutoCommit(false);

           String regdate = gplus.commlib.util.GCmDateFcts.dateToStr(new java.util.Date(),2);

           // ���� �������� ����.
           dmProp.setProperty("BOXNO",FLDNO);
           GCmResultSet rsFldInfo = docfolder.getFldInfo(cp,dmProp,msgInfo);

           // ������ �ۼ�.
           for(int i=0;i<rsFldInfo.getRowCount() && rsFldInfo.next();i++) {
    	   	dmProp.setProperty("Docno","");
             	dmProp.setProperty("Boxname",rsFldInfo.getString("FLDNAME") );
             	dmProp.setProperty("Userno",USERID);
             	dmProp.setProperty("Regdate",regdate);
             	dmProp.setProperty("Comments","");
             	dmProp.setProperty("Refno","");
             	dmProp.setProperty("Parentno",TARGET);
             	dmProp.setProperty("Boxno",BOXNO);

             	rv = docfoldertran.insertFolder( cp, dmProp, msgInfo );



               if(flag) {  // ������ ������ ��ȣ..
            	   newfldno =  dmProp.getString("Folderno1");
               	   flag = false;
               }

           }// for



             	// ���繮������ ��������(���� & ����)
             	dmProp.setProperty("BOXNO",BOXNO);
             	dmProp.setProperty("PARENTNO",FLDNO);
             	GCmResultSet rsFldListAll =  getFldListAll(cp, dmProp, msgInfo);

            for(int i=0;i<rsFldListAll.getRowCount() && rsFldListAll.next();i++) {

                  if( rsFldListAll.getString("DOCNO") == null || rsFldListAll.getString("DOCNO").equals("") ) {
                        dmProp.setProperty("FLDNO",rsFldListAll.getString("FLDNO") );
                        dmProp.setProperty("TARGET",newfldno);

                        int rv1 =   getFldCopy( cp, dmProp,  msgInfo);

                     } else {

		       	   String Docno = dmProp.getString("Docno");

		       	   dmProp.setProperty("Docno",rsFldListAll.getString("DOCNO") );
		       	   GCmResultSet rsDocInfo = doc.getDocInfo(cp,dmProp,msgInfo);


		       for(int m=0;m<rsDocInfo.getRowCount() && rsDocInfo.next();m++) {

		       	   dmProp.setProperty("Doctype",rsDocInfo.getString("DOCTYPE") );
		       	   dmProp.setProperty("Title",rsDocInfo.getString("TITLE") );
		       	   dmProp.setProperty("Attnum",rsDocInfo.getString("FILENUM") );
		       	   dmProp.setProperty("Reguser",rsDocInfo.getString("REGUSER") );
		       	   dmProp.setProperty("Regdate",rsDocInfo.getString("REGDATE") );
		       	   dmProp.setProperty("Moduser", USERID );
		           dmProp.setProperty("Moddate", regdate );

		           int rv3 =  docTran.insertDoc(cp, dmProp, msgInfo);

		           docno = (String)dmProp.getProperty("Docno");
		           dmProp.setProperty("Docno",dmProp.getString("Docno") );
		           dmProp.setProperty("Boxname",rsFldListAll.getString("FLDNAME") );
		           dmProp.setProperty("Userno",USERID);
		           dmProp.setProperty("Regdate",regdate);
		           dmProp.setProperty("Comments",rsFldListAll.getString("COMMENTS") );
		           dmProp.setProperty("Refno",rsFldListAll.getString("REFNO") );
		           dmProp.setProperty("Parentno", newfldno );
		           dmProp.setProperty("Boxno",BOXNO);

		           int rv4 = docfoldertran.insertFolder(cp, dmProp, msgInfo);

		         } // for..

		            dmProp.setProperty("Fldno", newfldno );
		            dmProp.setProperty("Boxno", BOXNO );

		            dmProp.setProperty("Boxname", "");
		            String fldnopath = getFldnoPath(cp, dmProp, msgInfo);

		            String fldpath = "/DATA/" + COMCODE + "/BOX/" + BOXNO + "/" + fldnopath; // �����

		            GCmFcts fcts = new GCmFcts();
		            fcts.setMakeFldPath(fldpath, PPATH); // ��������� �����

		            dmProp.setProperty("Docno", rsFldListAll.getString("DOCNO") );
		            dmProp.setProperty("Seq","00");

		            GCmResultSet rsdocdtllist =  doc.getDocDtlList(cp, dmProp, msgInfo);

		            for(int k=0;k<rsdocdtllist.getRowCount() && rsdocdtllist.next();k++)  {


		                 dmProp.setProperty("Docno", docno );
		                 dmProp.setProperty("Seq",rsdocdtllist.getString("SEQ") );
		                 dmProp.setProperty("Conttype",rsdocdtllist.getString("CONTTYPE") );
		                 dmProp.setProperty("Title",rsdocdtllist.getString("TITLE") );
		                 dmProp.setProperty("Fileext",rsdocdtllist.getString("FILEEXT") );

		                 dmProp.setProperty("Vpath",fldpath  );
		                 dmProp.setProperty("Orgname",rsdocdtllist.getString("ORGNAME") );
		                 dmProp.setProperty("Orgpath",rsdocdtllist.getString("ORGPATH") );
		                 dmProp.setProperty("Reguser",rsdocdtllist.getString("REGUSER") );
		                 dmProp.setProperty("Regdate",rsdocdtllist.getString("REGDATE") );
		                 dmProp.setProperty("Moduser",USERID );
		                 dmProp.setProperty("Moddate",regdate );

		                 filename = docno +"_"+rsdocdtllist.getString("SEQ")+rsdocdtllist.getString("FILEEXT");

		                 dmProp.setProperty("Filename",filename );

		                 java.io.File srcFile = new java.io.File(PPATH+rsdocdtllist.getString("VPATH"),rsdocdtllist.getString("FILENAME"));
		                 java.io.File desFile = new java.io.File(PPATH+fldpath,filename);

		                 if (srcFile.isFile()) {

		                      gplus.commlib.util.GCmFcts.copyFile(srcFile,desFile);


		                  }

		                      int rv1 = docTran.insertAttDoc(cp,dmProp,msgInfo);



		                 }// for
                            }//if
                       } // for
		}
		catch (Exception e)
		{
	 		System.out.println(" GCoMeBoxs::getFldCopy " + e.getMessage());
		 	return -1;
		}
		finally
		{
			conn.close();
		}
                return rv;

   }

       /**
        * <PRE>
        * ������ �̵��� ������ ���޹޾� ������ �̵���ŰŴ.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : ����ھ��̵�
        *                      <LI> String BOXNO : �Թ�ȣ
        *                      <LI> String FLDNO : ������ȣ
        *                      <LI> String PPATH : ���α׷� ��ġ�Ȱ��
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        *
        */

     public void getFldMoveFile(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
      {

        GCmConnection conn = null;
        Statement stmt = null;

        GCoDoDoc doc = new GCoDoDoc();
        GCoDoDocTran doctran = new GCoDoDocTran();

        String COMCODE = dmProp.getString("COMCODE");
        String USERID = dmProp.getString("USERID");
        String BOXNO = dmProp.getString("BOXNO");
        String FLDNO = dmProp.getString("FLDNO");
        String PPATH = dmProp.getString("PPATH");

        String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

        int rv = 0;
        String docno = "";
        String subfldno = "";

        dmProp.setProperty("Boxno", BOXNO );
        dmProp.setProperty("Fldno", FLDNO );

        dmProp.setProperty("Boxname", "");
        String fldnopath = getFldnoPath(cp, dmProp, msgInfo);

        String fldpath = "/DATA/" + COMCODE + "/BOX/" + BOXNO + "/" + fldnopath; // �����

	try {

           GCmFcts fcts = new GCmFcts();
           fcts.setMakeFldPath(fldpath, PPATH); // ��������� �����

           String regdate = gplus.commlib.util.GCmDateFcts.dateToStr(new java.util.Date(),2);
	   StringBuffer SqlQuery = null;

	   conn = GCmDbManager.getInstance().getConnection();
   	   stmt = conn.createStatement();
	   conn.setAutoCommit(false);

           GCmResultSet rsFldListAll =  getFldListAll(cp, dmProp, msgInfo);

           for(int i=0;i<rsFldListAll.getRowCount() && rsFldListAll.next();i++) {

               docno = rsFldListAll.getString("DOCNO");
               subfldno = rsFldListAll.getString("FLDNO");

             if (docno == null || docno.equals("")) {    // folder

                dmProp.setProperty("FLDNO", subfldno);
                getFldMoveFile(cp, dmProp, msgInfo);

                } else {

                 GCmResultSet rsDocDtlList = doc.getDocDtlList(cp, dmProp, msgInfo);

                 for(int k=0;i<rsDocDtlList.getRowCount() && rsDocDtlList.next();k++) {

                      java.io.File srcFile = new java.io.File(PPATH+rsDocDtlList.getString("VPATH"),rsDocDtlList.getString("FILENAME"));
                      java.io.File desFile = new java.io.File(PPATH+"/DATA/"+COMCODE+"/TEMP/"+USERID,rsDocDtlList.getString("FILENAME") );

                    if (srcFile.isFile()) {
                        gplus.commlib.util.GCmFcts.copyFile(srcFile,desFile);
                        srcFile.delete();
                        }
 					 // �����󼼸�� ������ ������Ʈ ġ��
	 	     dmProp.setProperty("Conttype", rsDocDtlList.getString("CONTTYPE") );
	 	     dmProp.setProperty("Title", rsDocDtlList.getString("TITLE") );
	 	     dmProp.setProperty("Fileext", rsDocDtlList.getString("FILEEXT") );
	 	     dmProp.setProperty("Filename", rsDocDtlList.getString("FILENAME") );
	 	     dmProp.setProperty("Vpath", rsDocDtlList.getString("VPATH") );
	 	     dmProp.setProperty("Mimetype", rsDocDtlList.getString("MIMETYPE") );
	 	     dmProp.setProperty("Filesize", rsDocDtlList.getString("FILESIZE") );
	 	     dmProp.setProperty("Orgname", rsDocDtlList.getString("ORGNAME") );
	 	     dmProp.setProperty("Orgpath", rsDocDtlList.getString("ORGPATH") );
	 	     dmProp.setProperty("Reguser", rsDocDtlList.getString("REGUSER") );
	 	     dmProp.setProperty("Regdate", rsDocDtlList.getString("REGDATE") );
	 	     dmProp.setProperty("Moduser", rsDocDtlList.getString("MODUSER") );
	 	     dmProp.setProperty("Moddate", rsDocDtlList.getString("MODDATE") );
	 	     dmProp.setProperty("Docno", rsDocDtlList.getString("DOCNO") );
                     dmProp.setProperty("Seq", rsDocDtlList.getString("SEQ") );

                     int rv2 = doctran.updateDocDtl( cp, dmProp, msgInfo );

                     }

                 }
            }// for

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoDoDocFolder :: setFldMoveFile " + e.getMessage());
		}
		finally
		{
			conn.close();
		}

          }

       /**
        * <PRE>
        * ������ �̵��� ������ ���޹޾� ������ �̵���Ŵ.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : ����� ���̵�
        *                      <LI> String BOXNO : �� ��ȣ
        *                      <LI> String FLDNO : ����  ��ȣ
        *                      <LI> String TARGET : �̵��� ���� ��ȣ
        *                      <LI> String PPATH : ���α׷� ��ġ�Ȱ��
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        */

   public int getFldMove(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

        GCmConnection conn = null;
        Statement stmt = null;

        String COMCODE = dmProp.getString("COMCODE");
        String USERID = dmProp.getString("USERID");
        String BOXNO = dmProp.getString("BOXNO");
        String FLDNO = dmProp.getString("FLDNO");
        String TARGET = dmProp.getString("TARGET");
       	String PPATH = dmProp.getString("PPATH");
        String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

        int rv = 0;

        StringBuffer SqlQuery = null;
        dmProp.setProperty("Boxno", BOXNO );
        dmProp.setProperty("Fldno", FLDNO );


        dmProp.setProperty("Boxname", "");
        String fldnopath = getFldnoPath(cp, dmProp, msgInfo);
        String fldpath = "/DATA/" + COMCODE + "/BOX/" + BOXNO + "/" + fldnopath; // �����
        GCoDoDocFolder docfolder = new GCoDoDocFolder();
        GCoDoDoc doc = new GCoDoDoc();

	try
	 {

    		conn = GCmDbManager.getInstance().getConnection();
    		stmt = conn.createStatement();
    		conn.setAutoCommit(false);

    		SqlQuery = new StringBuffer()
    			.append(" UPDATE  TB_").append(COMCODE).append("_B10 ")
    			.append(" SET PARENTNO = "+genQuote(TARGET) )
    			.append(" WHERE FLDNO = "+genQuote(FLDNO) );

    		rv = stmt.executeUpdate(SqlQuery.toString());

    		dmProp.setProperty("COMCODE", COMCODE );
    		dmProp.setProperty("USERID", USERID );
    		dmProp.setProperty("BOXNO", BOXNO );
    		dmProp.setProperty("FLDNO", FLDNO );
    		dmProp.setProperty("PPATH", PPATH );
    		getFldMoveFile(cp, dmProp, msgInfo);

    		conn.commit();
			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoDoDocFolder::getFldMove : " + ignored.getMessage());
			}

	 		System.out.println(" GCoDoDocFolder::getFldMove : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoDoDocFolder::getFldMove : " + e.getMessage());
			}
			conn.close();
		}
	}



       /**
        * <PRE>
        * �Թ�ȣ�� ������ ��ȣ�� ���޹޾� ���� ���� ��Ͽ� ���� ������ ������.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String BOXNO :  �� ��ȣ
        *                      <LI> String PARENTNO : ������ ��ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : FLDNO,BOXNO,DOCNO,PARENTNO,FLDNAME,REGUSER,REGDATE,
		*                                 TRASHFLAG,COMMENTS,REFNO
        */

   public GCmResultSet getFldListAll(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String BOXNO = dmProp.getString("BOXNO");
                String PARENTNO = dmProp.getString("PARENTNO");

		try
		{

			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT FLDNO,BOXNO,DOCNO,PARENTNO,FLDNAME,REGUSER,REGDATE,TRASHFLAG,COMMENTS,REFNO ")
                           .append(" FROM TB_").append(COMCODE).append("_B10 ")
                           .append(" WHERE PARENTNO = "+genQuote(PARENTNO))
                           .append(" AND BOXNO = "+genQuote(BOXNO))
                           .append(" ORDER BY DOCNO");


			   GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoDoDocFolder::getFldListAll" + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}



       /**
        * <PRE>
        * �Թ�ȣ�� ������ ��ȣ�� ���޹޾� ���� ������ ������ȣ�� �����̸��� ������.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String BOXNO :  �� ��ȣ
        *                      <LI> String ROOTNO : ������ ��ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : FLDNO,FLDNAME
        */

   public GCmResultSet getFindFldno(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String BOXNO = dmProp.getString("BOXNO");
		String PARENTNO = dmProp.getString("ROOTNO");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{

			conn = GCmDbManager.getInstance().getConnection();

	        	StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
	  	      	     sqlQuery
                                .append(" SELECT FLDNO,FLDNAME FROM TB_").append(COMCODE).append("_B10 ")
                                .append(" WHERE BOXNO = "+genQuote(BOXNO))
                                .append(" AND PARENTNO = "+genQuote(PARENTNO))
                                .append(" AND (DOCNO IS NULL OR DOCNO = '`') ");
                        }
                        else if("mssql".equals(strDbType))
                        {
	  	       	         sqlQuery
                                   .append(" SELECT FLDNO,FLDNAME FROM TB_").append(COMCODE).append("_B10 ")
                                   .append(" WHERE BOXNO = "+genQuote(BOXNO))
                                   .append(" AND PARENTNO = "+genQuote(PARENTNO))
                                   .append(" AND (DOCNO = '' OR DOCNO = '`') ");
                        }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoDoDocFolder::getFindFldno" + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}


       /**
        * <PRE>
        * �Թ�ȣ�� ������ ��ȣ�� ���޹޾� �� ���Ͽ��� �Թ�ȣ�� ���̸��� ������.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String BOXNO : �� ��ȣ
        *                      <LI> String ROOTNO : ������ ��ȣ
        *                      <LI> String BOXCLASS : �� ����
        *                      <LI> String BOXTYPE : �� ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : BOXNO, BOXNAME
        *
        */

   public GCmResultSet getFindBoxno(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String ROOTNO = dmProp.getString("ROOTNO");
		String BOXCLASS = dmProp.getString("BOXCLASS");
		String BOXTYPE = dmProp.getString("BOXTYPE");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT BOXNO, BOXNAME ")
                           .append(" FROM TB_").append(COMCODE).append("_M10 ")
                           .append(" WHERE PARENTNO = "+genQuote(ROOTNO))
                           .append(" AND BOXCLASS = "+genQuote(BOXCLASS))
                           .append(" AND BOXTYPE = "+genQuote(BOXTYPE));


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoDoDoc::getFindBoxno " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}


       /**
        * <PRE>
        *  ���޵� �Թ�ȣ�� ���õ� ������ Ʈ���������� �׷� ��.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Boxno : �� ��ȣ
        *                      <LI> String rootno : ����������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet :  Tree
        */

       public GCmResultSet getDrawDocFolderTree(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String rootno = dmProp.getString("rootno");
		String Boxno = dmProp.getString("Boxno");

                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                           sqlQuery
                             .append(" SELECT FLDNO,BOXNO,DOCNO,PARENTNO,FLDNAME,REGUSER,REGDATE,TRASHFLAG,COMMENTS,REFNO ")
                             .append(" FROM TB_").append(COMCODE).append("_B10 ")
                             .append(" WHERE PARENTNO = "+genQuote(rootno)+" AND BOXNO = "+genQuote(Boxno)+" AND (DOCNO IS NULL OR DOCNO = '`') ");
                        }
                        else if ("mssql".equals(strDbType))
                             {
                           sqlQuery
                            .append(" SELECT FLDNO,BOXNO,DOCNO,PARENTNO,FLDNAME,REGUSER,REGDATE,TRASHFLAG,COMMENTS,REFNO ")
                            .append(" FROM TB_").append(COMCODE).append("_B10 ")
                            .append(" WHERE PARENTNO = "+genQuote(rootno)+" AND BOXNO = "+genQuote(Boxno)+" AND (DOCNO = '' OR DOCNO = '`') ");
                             }



			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoMeBoxs::getDrawDocFolderTree " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}


       /**
        * <PRE>
        *  ���޵� ���ǿ� ���� �Ǽ��� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String PARENTNO : ������ ��ȣ
        *                      <LI> String OPT :  �˻� ����
        *                      <LI> String Q :  �˻���
        *                      <LI> String SDATE : �˻���������
        *                      <LI> String LDATE : �˻���������
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet :  Tree
        */

   public GCmResultSet getRecordCount(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
                GCmConnection conn = null;

                String COMCODE  = dmProp.getString("COMCODE");
                String PARENTNO = dmProp.getString("PAREMTNO");
                String OPT      = dmProp.getString("OPT");
                String Q	= dmProp.getString("Q");
                String SDATE    = dmProp.getString("SDATE");
                String LDATE    = dmProp.getString("LDATE");

                Q = Q.toLowerCase();

        try
		{
			conn = GCmDbManager.getInstance().getConnection();

		  	StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT PARENTNO ")
                           .append(" FROM TB_").append(COMCODE).append("_B10 A")
                           .append(" WHERE A.DOCNO > '0' AND A.PARENTNO = " + genQuote(PARENTNO));


                       if(!OPT.equals("") && (!Q.equals("") || !SDATE.equals("")))
                       {
                            String s4 = GCmFcts.replace(SDATE, "/", "");
                            String s5 = GCmFcts.replace(LDATE, "/", "");

                            s4 = s4.concat("000000");
                            s5 = s5.concat("240000");

                            if(OPT.toUpperCase().equals("REGDATE"))
                            {
                                if(!s5.equals(""))
                                {
                                     sqlQuery
                                        .append(" AND A.").append(OPT)
                                        .append(" BETWEEN "+genQuote(s4))
                                        .append(" AND "+genQuote(s5));

                                } else {
                                    sqlQuery
                                        .append(" AND A.").append(OPT)
                                        .append(" BETWEEN '%")
                                        .append(s4).append("%'");
                                }
                            } else {
                               sqlQuery
                                  .append(" AND LOWER(A.").append(OPT).append(") LIKE ")
                                  .append("'%").append(Q).append("%'");
                            }
                        }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;
		}
		catch (Exception e)
		{
	 		System.out.println(" GCoDoDoc::getRecordCount " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}


       /**
        * <PRE>
        *  ���޵� ���ǿ� ���� ���� ����� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String PARENTNO : ���� ������ȣ
        *                      <LI> String SORTID : ������ �ʵ�
        *                      <LI> String SORTOPT : �����ɼ�
        *                      <LI> String OPT : �˻� ����
        *                      <LI> String Q : �˻���
        *                      <LI> String SDATE : �˻���������
        *                      <LI> String LDATE : �˻���������
        *                      <LI> String CURPAGE : ���� ������
        *                      <LI> String PAGESIZE : �� ������
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet :
        */

   public GCmResultSet getFldDocList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

                String COMCODE = dmProp.getString("COMCODE");
                String PARENTNO = dmProp.getString("PARENTNO");
                String SORTID = dmProp.getString("SORTID");
                String SORTOPT = dmProp.getString("SORTOPT");
                String OPT = dmProp.getString("OPT");
                String Q = dmProp.getString("Q");
                String SDATE = dmProp.getString("SDATE");
                String LDATE = dmProp.getString("LDATE");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

                int  CURPAGE = dmProp.getInt("CURPAGE");
                int  PAGESIZE = dmProp.getInt("PAGESIZE");

                Q = Q.toLowerCase();

		try
		{
 		        conn = GCmDbManager.getInstance().getConnection();

  	             StringBuffer sqlQuery = new StringBuffer();

                     if ("oracle".equals(strDbType))
                     {
                         sqlQuery
                            .append(" SELECT C.FLDNO,C.DOCNO,C.PARENTNO,C.FLDNAME,C.USERNAME,C.REGUSER,C.REGDATE, C.TRASHFLAG,C.REFNO,C.FILENUM, C.RN ")
                            .append(" FROM (SELECT B.FLDNO,B.DOCNO,B.PARENTNO,B.FLDNAME,B.USERNAME,B.REGUSER,B.REGDATE,B.TRASHFLAG,B.REFNO,B.FILENUM, ROWNUM AS RN ")
                            .append("       FROM (SELECT A.FLDNO,A.DOCNO,A.PARENTNO,A.FLDNAME,(select username from tb_comm_z20 where userid = a.reguser and comcode="+genQuote(COMCODE)+") username,A.REGUSER,A.REGDATE,A.TRASHFLAG,A.REFNO,D.FILENUM ")
                            .append("             FROM TB_").append(COMCODE).append("_B10 A, TB_").append(COMCODE).append("_L10 D")
                            .append("             WHERE A.DOCNO = D.DOCNO AND A.PARENTNO = " + genQuote(PARENTNO));
                     }
                     else if ("mssql".equals(strDbType))
                     {
                         sqlQuery
                            .append(" SELECT TOP ").append(CURPAGE * PAGESIZE).append(" A.FLDNO,A.DOCNO,A.PARENTNO,A.FLDNAME,A.REGUSER,A.REGDATE,A.TRASHFLAG,A.REFNO,D.FILENUM ")
                            .append(" FROM TB_").append(COMCODE).append("_B10 A, TB_").append(COMCODE).append("_L10 D")
                            .append(" WHERE A.DOCNO = D.DOCNO AND A.PARENTNO = " + genQuote(PARENTNO));
                     }

                            if(!OPT.equals("") && (!Q.equals("") || !SDATE.equals("")))
                            {
                                 String s4 = GCmFcts.replace(SDATE, "/", "");
                                 String s5 = GCmFcts.replace(LDATE, "/", "");

                                 s4 = s4.concat("000000");
                                 s5 = s5.concat("240000");

                                 if(OPT.toUpperCase().equals("REGDATE"))
                                 {
                                      if(!s5.equals(""))
                                      {
                                           sqlQuery
                                             .append(" AND A.").append(OPT)
                                             .append(" BETWEEN "+genQuote(s4))
                                             .append(" AND "+genQuote(s5));

                                       } else {
                                         sqlQuery
                                            .append(" AND A.").append(OPT)
                                            .append(" BETWEEN '%")
                                            .append(s4).append("%'");

                                       }
                                   } else {
                                       sqlQuery
                                          .append(" AND LOWER(A.").append(OPT).append(") LIKE ")
                                          .append("'%").append(Q).append("%'");

                                    }
                            }

                        if(!SORTID.equals("") && !SORTOPT.equals("")){
                          if(SORTID.equals("username")){
                              sqlQuery
                                .append(" ORDER BY ")
                                .append(SORTID).append(" ").append(SORTOPT);
                          }else{
                              sqlQuery
                                .append(" ORDER BY ")
                                .append(" A.").append(SORTID).append(" ").append(SORTOPT);
                          }
                        }else{
                            sqlQuery
                              .append(" ORDER BY A.FLDNO DESC");
                        }

                    if ("oracle".equals(strDbType))
                    {
                        sqlQuery
                            .append(" ) B WHERE rownum <=  " ).append(CURPAGE * PAGESIZE).append(") C ")
  			                .append(" WHERE C.RN BETWEEN ").append(CURPAGE * PAGESIZE - PAGESIZE + 1)
                            .append(" AND ").append(CURPAGE * PAGESIZE);
                    }
                    GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

                    if ("mssql".equals(strDbType))
                    {
                         rs.moveRecordPos((CURPAGE-1)*PAGESIZE);
                    }

                    return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoDoDoc::getFldDocList : " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}



       /**
        * <PRE>
        *  ���޵� �Թ�ȣ�� ���� �������� ����� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String BOXNO : �� ��ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : FLDNO,BOXNO,DOCNO,PARENTNO,FLDNAME,REGUSER,REGDATE,
        *                                 TRASHFLAG,COMMENTS,REFNO
        */

   public GCmResultSet getFldInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String BOXNO = dmProp.getString("BOXNO");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT FLDNO,BOXNO,DOCNO,PARENTNO,FLDNAME,REGUSER,REGDATE,TRASHFLAG,COMMENTS,REFNO ")
                           .append(" FROM TB_").append(COMCODE).append("_B10 ")
                           .append(" WHERE FLDNO = "+genQuote(BOXNO));


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoDoDoc::getFldInfo " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

       /**
        * <PRE>
        *  ���޵� ������ȣ�� ����������ȣ�� ���� ����Ʈ���� ���� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String BOXNO : �� ��ȣ
        *                      <LI> String ROOTFLDNO : ���� ������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : Tree
        */

	public GCmResultSet getDrawTree(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String BOXNO = dmProp.getString("BOXNO");
		String ROOTFLDNO = dmProp.getString("ROOTFLDNO");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();
	        	StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
	  	      	     sqlQuery
                               .append(" SELECT FLDNO,BOXNO,DOCNO,PARENTNO,FLDNAME,REGUSER,REGDATE,TRASHFLAG,COMMENTS,REFNO ")
                               .append(" FROM TB_").append(COMCODE).append("_B10 ")
                               .append(" WHERE PARENTNO = "+genQuote(ROOTFLDNO)+" AND BOXNO = "+genQuote(BOXNO)+" AND (DOCNO IS NULL OR DOCNO = '`') ");
                        }
                        else if("mssql".equals(strDbType))
                        {
 	                     sqlQuery
                               .append(" SELECT FLDNO,BOXNO,DOCNO,PARENTNO,FLDNAME,REGUSER,REGDATE,TRASHFLAG,COMMENTS,REFNO ")
                               .append(" FROM TB_").append(COMCODE).append("_B10 ")
                               .append(" WHERE PARENTNO = "+genQuote(ROOTFLDNO)+" AND BOXNO = "+genQuote(BOXNO)+" AND (DOCNO = '' OR DOCNO = '`') ");
                        }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoMeBoxs::getDrawTree : " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}	// end component call



       /**
        * <PRE>
        *  ���޵� �������� ���� �Թ�ȣ�� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String ROOTNO : �����Թ�ȣ
        *                      <LI> String BOXCLASS : �� ����
        *                      <LI> String BOXTYPE : �� ����
        *                      <LI> String USERID : ����� ���̵�

        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : BOXNO
        *
        */


	public GCmResultSet getFindUserBoxno(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String ROOTNO = dmProp.getString("ROOTNO");
		String BOXCLASS = dmProp.getString("BOXCLASS");
		String BOXTYPE = dmProp.getString("BOXTYPE");
		String USERID = dmProp.getString("USERID");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();
			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT BOXNO ")
                           .append(" FROM TB_"+COMCODE+"_M10 ")
                           .append(" WHERE PARENTNO = "+genQuote(ROOTNO)+" AND BOXCLASS = "+genQuote(BOXCLASS))
                           .append(" AND BOXTYPE ="+genQuote(BOXTYPE)+" AND USERID = "+genQuote(USERID));


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoMeBoxs::getFindUserBoxno : " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}	// end component call



       /**
        * <PRE>
        *  ���޵� ����ڿ� ����  ���õ� �������� ����Ʈ �Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : ����� ���̵�
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : A.BOXNO,A.BOXNAME,A.BOXTYPE,B.DOCREAD,B.DOCWRITE,C.FLDNAME,C.FLDNO
        *
        */


	public GCmResultSet getFldBoxList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
	 	GCmConnection conn = null;

                String COMCODE = dmProp.getString("COMCODE");
                String USERID = dmProp.getString("USERID");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();
			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT A.BOXNO,A.BOXNAME,A.BOXTYPE,B.DOCREAD,B.DOCWRITE,C.FLDNAME,C.FLDNO ")
                           .append(" FROM TB_"+COMCODE+"_M10 A, TB_"+COMCODE+"_M20 B, TB_"+COMCODE+"_B10 C")
                           .append(" WHERE A.BOXNO = B.BOXNO AND A.BOXNO = C.BOXNO AND B.USERID = "+genQuote(USERID))
                           .append(" AND A.BOXCLASS = '2' AND C.PARENTNO = '000000000000'  ORDER BY A.BOXTYPE DESC, A.BOXNO");

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoMeBoxs::getFldBoxList : " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}


       /**
        * <PRE>
        *  ���޵� ������ ���� ���õ� ������ ���丮 ������ �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : ����� ���̵�
        *                      <LI> String Boxno : �� ��ȣ
        *                      <LI> String Fldno :  ���� ��ȣ
        *                      <LI> String Boxname : �� �̸�
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : A.BOXNO,A.BOXNAME,A.BOXTYPE,B.DOCREAD,B.DOCWRITE,C.FLDNAME,C.FLDNO
        *
        */

       public  String getFldnoPath(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
        {

            String COMCODE = dmProp.getString("COMCODE");
            String USERID = dmProp.getString("USERID");
            String BOXNO = dmProp.getString("Boxno");
            String FLDNO = dmProp.getString("Fldno");
            String BOXNAME = dmProp.getString("Boxname");
            String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

            GCmConnection conn = null;
            String sRet = BOXNAME;

	    try
	    {
	        conn = GCmDbManager.getInstance().getConnection();

	        	StringBuffer sqlQuery = new StringBuffer();

                 if ("oracle".equals(strDbType))
                 {
	      	     sqlQuery
                        .append(" SELECT FLDNO,BOXNO,DOCNO,PARENTNO,FLDNAME,REGUSER,REGDATE,TRASHFLAG,COMMENTS,REFNO ")
                        .append(" FROM TB_").append(COMCODE).append("_B10 ")
                        .append(" WHERE BOXNO = "+genQuote(BOXNO)+" AND FLDNO = "+genQuote(FLDNO))
                        .append("       AND ( DOCNO IS NULL OR DOCNO = '`' )");
                 }
                 else if("mssql".equals(strDbType))
                 {
                     sqlQuery
                        .append(" SELECT FLDNO,BOXNO,DOCNO,PARENTNO,FLDNAME,REGUSER,REGDATE,TRASHFLAG,COMMENTS,REFNO ")
                        .append(" FROM TB_").append(COMCODE).append("_B10 ")
                        .append(" WHERE BOXNO = "+genQuote(BOXNO)+" AND FLDNO = "+genQuote(FLDNO))
                        .append("       AND ( DOCNO = '' OR DOCNO = '`' )");
                 }

    	        GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

                while(rs.next())
               {

                    dmProp.setProperty("Fldno",rs.getString("PARENTNO"));
                    dmProp.setProperty("Boxname",sRet);


                    if( !( BOXNO.equals(FLDNO)) ){
                    sRet = getFldnoPath(cp, dmProp, msgInfo);
                    }


                   // sRet +=  rs.getString("FLDNO") + "/";
                   //sRet +=  "/";
                }

               return sRet;

            }
            catch (Exception e)
            {
 		  System.out.println(" GCoDoDocFolder::getFldnoPath " + e.getMessage());
	 	  return null;
            }
            finally
            {
		  conn.close();
            }
      }
}