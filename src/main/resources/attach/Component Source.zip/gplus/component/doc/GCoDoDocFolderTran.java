package gplus.component.doc;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;
import gplus.template.*;
import gplus.component.board.*;
import gplus.component.doc.*;


/**
 * <PRE>
 * Filename		: GCoDoDocFolderTran.java
 * Class		: gplus.component.pos.GCoDoDocFolderTran
 * Fuction		:
 * Comment		:
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GCoDoDocFolderTran extends GCmTopComponent
{

       /**
        * <PRE>
        *  ���� ���� ������ �̵��� ���� ���θ� ���޹޾� ���� ������ ������ �̵���.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID :  ����� ���̵�
        *                      <LI> String BOXNO :  �� ��ȣ
        *                      <LI> String FLDNO :  ���� ��ȣ
        *                      <LI> String PARENTNO :  ������ ��ȣ
        *                      <LI> String TARGET :  �̵��� ���� ��ȣ
        *                      <LI> String PPATH :  ���α׷� ��Ʈ ���丮
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        */

	public int getFldDocMove(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
            String COMCODE = dmProp.getString("COMCODE");
            String USERID = dmProp.getString("USERID");
            String BOXNO = dmProp.getString("BOXNO");
            String FLDNO = dmProp.getString("FLDNO");
            String PARENTNO = dmProp.getString("PARENTNO");
            String TARGET = dmProp.getString("TARGET");
            String PPATH = dmProp.getString("PPATH");
            String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

            int rv = 0;
            GCmConnection conn = null;
            Statement stmt = null;

            GCoDoDocFolder docfolder = new GCoDoDocFolder();
            GCoDoDocTran docTran = new GCoDoDocTran();
            GCoDoDoc doc = new GCoDoDoc();
            GCmFcts fcts = new GCmFcts();

            String docno = "";
            String filename = "";

	   try {

            String regdate = gplus.commlib.util.GCmDateFcts.dateToStr(new java.util.Date(),2);
            StringBuffer SqlQuery = null;

            conn = GCmDbManager.getInstance().getConnection();
            stmt = conn.createStatement();
            conn.setAutoCommit(false);

            // ������������ ��ȸ.
            dmProp.setProperty("BOXNO",FLDNO);
            GCmResultSet rsFldInfo = docfolder.getFldInfo(cp,dmProp,msgInfo);

            if( rsFldInfo.getRowCount() > 0)  {
                 rsFldInfo.next();
                 docno = rsFldInfo.getString("DOCNO");
                 // �������� ���� ����.
                 dmProp.setProperty("BOXNO", rsFldInfo.getString("BOXNO") );
                 dmProp.setProperty("DOCNO", docno );
                 dmProp.setProperty("PARENTNO", TARGET );
                 dmProp.setProperty("REGUSER",rsFldInfo.getString("REGUSER") );
                 dmProp.setProperty("REGDATE",rsFldInfo.getString("REGDATE") );
                 dmProp.setProperty("TRASHFLAG","1");
                 dmProp.setProperty("COMMENTS",rsFldInfo.getString("COMMENTS") );
                 dmProp.setProperty("FLDNAME",rsFldInfo.getString("FLDNAME") );
                 dmProp.setProperty("FLDNO", FLDNO );
                 int rv1  = updateFolderEdit(cp, dmProp, msgInfo);

            }

            dmProp.setProperty("Docno", docno );
            GCmResultSet rsDocInfo = doc.getDocInfo(cp, dmProp, msgInfo);

            if( rsDocInfo.getRowCount() > 0)  {
            	rsDocInfo.next();

                dmProp.setProperty("COMCODE",COMCODE );
            	dmProp.setProperty("Title", rsDocInfo.getString("TITLE") );
            	dmProp.setProperty("DOCTYPE", rsDocInfo.getString("DOCTYPE") );
            	dmProp.setProperty("Filenum", rsDocInfo.getString("FILENUM") );
            	dmProp.setProperty("REGUSER", rsDocInfo.getString("REGUSER") );
            	dmProp.setProperty("REGDATE", rsDocInfo.getString("REGDATE") );
            	dmProp.setProperty("MODUSER", USERID );
            	dmProp.setProperty("MODDATE", regdate );
            	dmProp.setProperty("Docno",docno );

                //----------------------5.08�� �߰�
                dmProp.setProperty("Totfilesize",rsDocInfo.getString("TOTFILESIZE"));
                dmProp.setProperty("Conts",rsDocInfo.getString("MSTDOC"));
                //---------------------
            	rv += docTran.updateDocEdit(cp, dmProp, msgInfo );
            }

            dmProp.setProperty("Boxno", BOXNO );
            dmProp.setProperty("Fldno", TARGET );
            dmProp.setProperty("Boxname", "");
            String fldnopath = docfolder.getFldnoPath(cp, dmProp, msgInfo);

            //String fldpath = "/DATA/" + COMCODE + "/BOX/" + BOXNO + "/" + fldnopath; // �����
            //fcts.setMakeFldPath(fldpath, PPATH ); // ��������� �����

            String fldpath = "/DATA/" + COMCODE + "/BOX/" + regdate.substring(0,6)+"/"+regdate.substring(6,8) + "/"; // �����
            gplus.commlib.util.GCmFcts.folderMake(PPATH,fldpath);

            dmProp.setProperty("Seq","00");
            //dmProp.setProperty("Seq","01");
            GCmResultSet rsdocdtllist = doc.getDocDtlList(cp, dmProp, msgInfo);
            for(int i=0;i<rsdocdtllist.getRowCount() && rsdocdtllist.next();i++)
            {
            	java.io.File srcFile = new java.io.File(PPATH+rsdocdtllist.getString("VPATH"),rsdocdtllist.getString("FILENAME"));
            	java.io.File desFile = new java.io.File(PPATH+fldpath,rsdocdtllist.getString("FILENAME") );


                if (srcFile.isFile()) {
                   // gplus.commlib.util.GCmFcts.copyFile(srcFile,desFile);
                   //srcFile.delete();
                }

            	dmProp.setProperty("Docno", docno);
            	dmProp.setProperty("Seq", rsdocdtllist.getString("SEQ") );
            	dmProp.setProperty("Conttype",rsdocdtllist.getString("CONTTYPE") );
            	dmProp.setProperty("Title",rsdocdtllist.getString("TITLE") );
            	dmProp.setProperty("Fileext",rsdocdtllist.getString("FILEEXT") );
            	dmProp.setProperty("Filename",rsdocdtllist.getString("FILENAME") );
            	dmProp.setProperty("Filesize",rsdocdtllist.getString("FILESIZE") );
            	dmProp.setProperty("Vpath",fldpath);
            	dmProp.setProperty("Orgname",rsdocdtllist.getString("ORGNAME") );
            	dmProp.setProperty("Orgpath",rsdocdtllist.getString("ORGPATH") );
            	dmProp.setProperty("Mimetype",rsdocdtllist.getString("MIMETYPE") );
            	dmProp.setProperty("Reguser",rsdocdtllist.getString("REGUSER") );
            	dmProp.setProperty("Regdate",rsdocdtllist.getString("REGDATE") );
            	dmProp.setProperty("Moduser",USERID );
            	dmProp.setProperty("Moddate",regdate );


            	int rv1 = docTran.updateDocDtl(cp,dmProp,msgInfo);
            	}


            	if( rv <= 0 ) throw new Exception(" getFldDocMove:: During processUserModify error !!!");

			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoDoDocFolderTran::getFldDocMove --: " + ignored.getMessage());
			}

	 		System.out.println(" GCoDoDocFolderTran::getFldDocMove~~~~ : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoDoDocFolderTran::getFldDocMove=== : " + e.getMessage());
			}
			conn.close();
		}
	}


       /**
        * <PRE>
        *  ���� ���� ������ �̵��� ���� ���θ� ���޹޾� ���� ������ ������ ������.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : ����� ���̵�
        *                      <LI> String BOXNO : �� ��ȣ
        *                      <LI> String FLDNO : ���� ��ȣ
        *                      <LI> String PARENTNO: ������ ��ȣ
        *                      <LI> String TARGET : �̵��� ���� ��ȣ
        *                      <LI> String PPATH : ���α׷� ��Ʈ ���丮
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        */


	public int getFldDocCopy(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
                String COMCODE = dmProp.getString("COMCODE");
                String USERID = dmProp.getString("USERID");
                String FLDNO = dmProp.getString("FLDNO");
                String BOXNO = dmProp.getString("BOXNO");
                String PARENTNO = dmProp.getString("PARENTNO");
                String TARGET = dmProp.getString("TARGET");
                String PPATH = dmProp.getString("PPATH");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

                int rv = 0;
                GCmConnection conn = null;
                Statement stmt = null;
                GCoDoDocFolder docfolder = new GCoDoDocFolder();
                GCoDoDocTran docTran = new GCoDoDocTran();
                GCoDoDoc doc = new GCoDoDoc();
                GCmFcts fcts = new GCmFcts();

                String docno = "";
                String docno2 ="";
                String filename = "";

		try
		{

                String regdate = gplus.commlib.util.GCmDateFcts.dateToStr(new java.util.Date(),2);
               	StringBuffer SqlQuery = null;

               	conn = GCmDbManager.getInstance().getConnection();
               	stmt = conn.createStatement();
               	conn.setAutoCommit(false);

                // ������������ ��ȸ
               	dmProp.setProperty("BOXNO",FLDNO);
               	GCmResultSet rsFldInfo = docfolder.getFldInfo(cp,dmProp,msgInfo);


                if( rsFldInfo.getRowCount() > 0)  {
                    rsFldInfo.next();

                    // ���� ������� ��ȸ
                    dmProp.setProperty("Docno", rsFldInfo.getString("DOCNO") );
                    GCmResultSet rsDocInfo = doc.getDocInfo(cp, dmProp, msgInfo);

                    if( rsDocInfo.getRowCount() > 0)  {
                         rsDocInfo.next();

                         dmProp.setProperty("Title",rsDocInfo.getString("TITLE") );
                         dmProp.setProperty("Doctype",rsDocInfo.getString("DOCTYPE") );
                         dmProp.setProperty("Attnum",rsDocInfo.getString("FILENUM") );
                         dmProp.setProperty("Reguser",rsDocInfo.getString("REGUSER") );
                         dmProp.setProperty("Regdate",rsDocInfo.getString("REGDATE") );
                         dmProp.setProperty("Moduser",USERID );
                         dmProp.setProperty("Moddate",regdate );

                         //----------------------5.08�� �߰�
                         dmProp.setProperty("Totfilesize",rsDocInfo.getString("TOTFILESIZE"));
                         dmProp.setProperty("Conts",rsDocInfo.getString("MSTDOC"));
                          //---------------------

                          // �����������
                          rv += docTran.insertDoc(cp, dmProp, msgInfo );
                        }

                    docno = (String)dmProp.getProperty("Docno");

                    dmProp.setProperty("Docno",docno );
                    dmProp.setProperty("Boxno", BOXNO );
                    dmProp.setProperty("Parentno", TARGET ); //parentno
                    dmProp.setProperty("Boxname", rsFldInfo.getString("FLDNAME") );
                    dmProp.setProperty("Userno", USERID);
                    dmProp.setProperty("Regdate", regdate );
                    dmProp.setProperty("Comments", rsFldInfo.getString("COMMENTS") );
                    dmProp.setProperty("Refno", rsFldInfo.getString("REFNO") );

                    docno2 = rsFldInfo.getString("DOCNO");
                    // �ű� �������� ����
                    rv += insertFolder(cp, dmProp, msgInfo );
                    }

                    dmProp.setProperty("Boxno", BOXNO );
                    dmProp.setProperty("Fldno", TARGET );
                    dmProp.setProperty("Boxname", "");
                    String fldnopath = docfolder.getFldnoPath(cp, dmProp, msgInfo);
                    //String fldpath = "/DATA/" + COMCODE + "/BOX/" + BOXNO + "/" + fldnopath; // �����
                    String fldpath = "/DATA/" + COMCODE + "/BOX/" + regdate.substring(0,6) + "/" + regdate.substring(6,8) + "/"; // �����

                    //fcts.setMakeFldPath(fldpath, PPATH ); // ��������� �����
                    fcts.folderMake(PPATH,fldpath);

                    dmProp.setProperty("Seq","00");
                    dmProp.setProperty("Docno",docno2);
                    GCmResultSet rsdocdtllist = doc.getDocDtlList(cp,dmProp,msgInfo);

                    for(int i=0;i<rsdocdtllist.getRowCount() && rsdocdtllist.next();i++)
                       {
                         filename = docno +"_"+rsdocdtllist.getString("SEQ")+rsdocdtllist.getString("FILEEXT");
                         java.io.File srcFile = new java.io.File(PPATH+rsdocdtllist.getString("VPATH"),rsdocdtllist.getString("FILENAME"));
                         java.io.File desFile = new java.io.File(PPATH+fldpath,filename);
                         if (srcFile.isFile()) {
                              gplus.commlib.util.GCmFcts.copyFile(srcFile,desFile);
                         }

                         dmProp.setProperty("Docno", docno );
                         dmProp.setProperty("Seq",rsdocdtllist.getString("SEQ") );
                         dmProp.setProperty("Conttype",rsdocdtllist.getString("CONTTYPE") );
                         dmProp.setProperty("Title",rsdocdtllist.getString("TITLE") );
                         dmProp.setProperty("Fileext",rsdocdtllist.getString("FILEEXT") );
                         //dmProp.setProperty("Filename",rsdocdtllist.getString("FILENAME") ); // �����̸��� �����ϰ� �߰��ǹǷ� ������ ���� �߻�
                         dmProp.setProperty("Filename",filename );
                         dmProp.setProperty("Vpath",rsdocdtllist.getString("VPATH") );
                         dmProp.setProperty("Orgname",rsdocdtllist.getString("ORGNAME") );
                         dmProp.setProperty("Orgpath",rsdocdtllist.getString("ORGPATH") );
                         dmProp.setProperty("Reguser",rsdocdtllist.getString("REGUSER") );
                         dmProp.setProperty("Regdate",rsdocdtllist.getString("REGDATE") );
                         dmProp.setProperty("Moduser",USERID );
                         dmProp.setProperty("Moddate",regdate );

                         int rv1 = docTran.insertAttDoc(cp,dmProp,msgInfo);
                        }

                       if( rv <= 0 ) throw new Exception(" During processUserModify error !!!");

			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoDoDocFolderTran::getFldDocCopy : " + ignored.getMessage());
			}

	 		System.out.println(" GCoDoDocFolderTran::getFldDocCopy : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoDoDocFolderTran::getFldDocCopy : " + e.getMessage());
			}
			conn.close();
		}
	}


       /**
        * <PRE>
        *  ���� ������ ���޹޾� ���� ���� ��Ͽ� ���� ���� ������ ����.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE    : current user companycode at session
        *                      <LI> String BOXNO      :  �� ��ȣ
        *                      <LI> String FLDNO      :  ���� ��ȣ
        *                      <LI> String FLDNAME    :  ���� �̸�
        *                      <LI> String COMMENTS   :  ����
        *                      <LI> String REGDATE    :  �����
        *                      <LI> String PARENTNO   :  ������ ��ȣ
        *                      <LI> String DOCNO      :  ������ȣ
        *                      <LI> String REGUSER    :  �����
        *                      <LI> String TRASHFLAG  :  ������
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        */


	public int updateFolderEdit(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String FLDNAME = dmProp.getString("FLDNAME");
		String FLDNO = dmProp.getString("FLDNO");
		String COMCODE = dmProp.getString("COMCODE");
		String BOXNO = dmProp.getString("BOXNO");
		String COMMENTS = dmProp.getString("COMMENTS");
		String REGDATE = dmProp.getString("REGDATE");
		String PARENTNO = dmProp.getString("PARENTNO");
		String DOCNO = dmProp.getString("DOCNO");
		String REGUSER = dmProp.getString("REGUSER");
		String TRASHFLAG = dmProp.getString("TRASHFLAG");

		String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		int rv;
		GCmConnection conn = null;
		Statement stmt = null;
		GCoDoDocFolder docfolder = new GCoDoDocFolder();
		GCoDoDoc doc = new GCoDoDoc();

		try
		{

			conn = GCmDbManager.getInstance().getConnection();
			stmt = conn.createStatement();
			conn.setAutoCommit(false);

			StringBuffer SqlQuery = new StringBuffer()
                                  .append(" UPDATE  TB_").append(COMCODE).append("_B10 ")
                                  .append(" SET BOXNO = "+genQuote(BOXNO))
                                  .append(" , DOCNO = "+genQuote(DOCNO))
                                  .append(" , PARENTNO = "+genQuote(PARENTNO))
                                  .append(" , FLDNAME = "+genQuote(FLDNAME))
                                  .append(" , REGUSER = "+genQuote(REGUSER))
                                  .append(" , REGDATE = "+genQuote(REGDATE))
                                  .append(" , TRASHFLAG ="+genQuote(TRASHFLAG))
                                  .append(" , COMMENTS = "+genQuote(COMMENTS))
                                  .append(" WHERE FLDNO = "+genQuote(FLDNO));

			rv = stmt.executeUpdate(SqlQuery.toString());

			if( rv <= 0 ) throw new Exception(" During processUserModify error !!!");
				conn.commit();
				return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoDoDocFolderTran::updateFolderEdit : " + ignored.getMessage());
			}

	 		System.out.println(" GCoDoDocFolderTran::updateFolderEdit : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoDoDocFolderTran::updateFolderEdit : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        *  ���� ������ ���޹޾� ���� ���� ��Ͽ��� FLDNAME�� FLDNO ���� ���� ������ ����.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE    : current user companycode at session
        *                      <LI> String FLDNO      :  ���� ��ȣ
        *                      <LI> String FLDNAME    :  ���� �̸�
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        */


	public int updateFolder(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String FLDNAME = dmProp.getString("FLDNAME");
		String FLDNO = dmProp.getString("FLDNO");
		String COMCODE = dmProp.getString("COMCODE");
		String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		int rv;
		GCmConnection conn = null;
		Statement stmt = null;

		GCoDoDocFolder docfolder = new GCoDoDocFolder();
		GCoDoDoc doc = new GCoDoDoc();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();
			stmt = conn.createStatement();
			conn.setAutoCommit(false);

			StringBuffer SqlQuery = new StringBuffer()
                            .append(" UPDATE  TB_").append(COMCODE).append("_B10 ")
                            .append(" SET FLDNAME = "+genQuote(FLDNAME))
                            .append(" WHERE FLDNO = "+genQuote(FLDNO));

			rv = stmt.executeUpdate(SqlQuery.toString());

			conn.commit();
			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoDoDocFolderTran::updateFolder : " + ignored.getMessage());
			}

	 		System.out.println(" GCoDoDocFolderTran::updateFolder : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoDoDocFolderTran::updateFolder : " + e.getMessage());
			}
			conn.close();
		}
	}


       /**
        * <PRE>
        *  ���� ������ ���޹޾� ���� �� ���( L11 ) , �������( L10 ) , �����������( B10 )
		*  �� ���Ѱ� ����.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE :  current user companycode at session
        *                      <LI> String USERID :  ����� ���̵�
        *                      <LI> String BOXNO :  �� ��ȣ
        *                      <LI> String FLDNO :  ���� ��ȣ
        *                      <LI> String PPATH :  ���α׷� ��ġ���
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        */


	public int deleteFolder(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String BOXNO = dmProp.getString("BOXNO");
		String FLDNO = dmProp.getString("FLDNO");
		String PPATH = dmProp.getString("PPATH");

		String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		int rv = 0;
		GCmConnection conn = null;
		Statement stmt = null;

		GCoDoDocFolder docfolder = new GCoDoDocFolder();
		GCoDoDoc doc = new GCoDoDoc();

		try
		{

			StringBuffer SqlQuery = null;

			conn = GCmDbManager.getInstance().getConnection();
			stmt = conn.createStatement();
			conn.setAutoCommit(false);

                        dmProp.setProperty("PARENTNO",FLDNO);
                        GCmResultSet rsfldinfo = docfolder.getFldListAll(cp,dmProp,msgInfo);


                   for(int i=0;i<rsfldinfo.getRowCount() && rsfldinfo.next();i++) {

                      if (rsfldinfo.getString("DOCNO") == null || rsfldinfo.getString("DOCNO").equals("")) { // ���� ���ȣ��

                            dmProp.setProperty("FLDNO",rsfldinfo.getString("FLDNO"));
                            deleteFolder(cp, dmProp, msgInfo);
                                                                  // ������ ���� ����...
                      } else {

                            dmProp.setProperty("Docno",rsfldinfo.getString("DOCNO"));
                            dmProp.setProperty("Seq","00");
                            GCmResultSet rsdocdtllist = doc.getDocDtlList(cp,dmProp,msgInfo);

                           for(int j=0; j<rsdocdtllist.getRowCount() && rsdocdtllist.next();j++) {

                               //java.io.File srcFile = new java.io.File(PPATH+rsfldinfo.getString("VPATH"),rsdocdtllist.getString("FILENAME"));
                               java.io.File srcFile = new java.io.File(PPATH+rsdocdtllist.getString("VPATH"),rsdocdtllist.getString("FILENAME"));
                               java.io.File desFile = new java.io.File(PPATH+"/DATA/"+COMCODE+"/TEMP/"+USERID,rsdocdtllist.getString("FILENAME"));


                              if (srcFile.isFile()) {
                                    gplus.commlib.util.GCmFcts.copyFile(srcFile,desFile);
                                     srcFile.delete();
                                    }

			             SqlQuery = new StringBuffer()
                                   .append(" DELETE FROM TB_").append(COMCODE).append("_L11 ")
                                   .append(" WHERE DOCNO = "+genQuote(rsfldinfo.getString("DOCNO"))+" AND SEQ = "+genQuote(rsdocdtllist.getString("SEQ")));
   		                   rv = stmt.executeUpdate(SqlQuery.toString());
                          } // for End

		                  SqlQuery = new StringBuffer()
                                  .append(" DELETE FROM TB_").append(COMCODE).append("_L10 ")
                                  .append(" WHERE DOCNO = "+genQuote(rsfldinfo.getString("DOCNO")));
   	                          rv = stmt.executeUpdate(SqlQuery.toString());

                    }// if end

		             SqlQuery = new StringBuffer()
                                  .append(" DELETE FROM TB_").append(COMCODE).append("_B10 ")
                                  .append(" WHERE FLDNO = "+genQuote(FLDNO));

   	                          rv = stmt.executeUpdate(SqlQuery.toString());

				  conn.commit();


             } // for end

		       SqlQuery = new StringBuffer()
                                  .append(" DELETE FROM TB_").append(COMCODE).append("_B10 ")
                                  .append(" WHERE FLDNO = "+genQuote(FLDNO));

   	               rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();
			return rv;

		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoDoDocFolderTran::deleteFolder : " + ignored.getMessage());
			}

	 		System.out.println(" GCoDoDocFolderTran::deleteFolder : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoDoDocFolderTran::deleteFolder : " + e.getMessage());
			}
			conn.close();
		}
	}



       /**
        * <PRE>
        *  ���� ������ ���޹޾� ���� �� ���( L11 ) , �������( L10 ) , �����������( B10 )
        *  �� ���Ѱ��� ���� �Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE    : current user companycode at session
        *                      <LI> String USERID     :  ����� ���̵�
        *                      <LI> String FLDNO      :  ���� ��ȣ
        *                      <LI> String PPATH      :  ���α׷� ��ġ ���
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        */


	public int deleteList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String FLDNO = dmProp.getString("FLDNO");
		String PPATH = dmProp.getString("PPATH");

		String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		int rv;
		GCmConnection conn = null;
		Statement stmt = null;

		GCoDoDocFolder docfolder = new GCoDoDocFolder();
		GCoDoDoc doc = new GCoDoDoc();

	     try
		{
           	 StringBuffer SqlQuery = null;

           	 conn = GCmDbManager.getInstance().getConnection();
           	 stmt = conn.createStatement();
           	 conn.setAutoCommit(false);

           	 dmProp.setProperty("BOXNO",FLDNO);
           	 GCmResultSet rsfldinfo = docfolder.getFldInfo(cp,dmProp,msgInfo);
			rsfldinfo.next();
           	 dmProp.setProperty("Docno",rsfldinfo.getString("DOCNO"));
           	 dmProp.setProperty("Seq","00");
           	 GCmResultSet rsdocdtllist = doc.getDocDtlList(cp,dmProp,msgInfo);



           	 for(int i=0;i<rsdocdtllist.getRowCount() && rsdocdtllist.next();i++)
               	    {

                 	java.io.File srcFile = new java.io.File(PPATH+rsdocdtllist.getString("VPATH"),rsdocdtllist.getString("FILENAME"));
                 	//java.io.File desFile = new java.io.File(PPATH+"/DATA/"+COMCODE+"/TEMP/"+USERID,rsdocdtllist.getString("FILENAME"));
                        //if(srcFile.isFile()) {
                             srcFile.delete();
                      	//}


                 	SqlQuery = new StringBuffer()
                            .append(" DELETE FROM TB_").append(COMCODE).append("_L11 ")
                            .append(" WHERE DOCNO = "+genQuote(rsfldinfo.getString("DOCNO"))+" AND SEQ = "+genQuote(rsdocdtllist.getString("SEQ")));
                 	//System.out.println("delete---L11--->"+SqlQuery.toString());
                        rv = stmt.executeUpdate(SqlQuery.toString());
                     }

           	 SqlQuery = new StringBuffer()
                            .append(" DELETE FROM TB_").append(COMCODE).append("_L10 ")
                            .append(" WHERE DOCNO = "+genQuote(rsfldinfo.getString("DOCNO")));
                            //System.out.println("delete---L10--->"+SqlQuery.toString());
           	 rv = stmt.executeUpdate(SqlQuery.toString());


           	 SqlQuery = new StringBuffer()
                            .append(" DELETE FROM TB_").append(COMCODE).append("_B10 ")
                            .append(" WHERE FLDNO = "+genQuote(FLDNO));
                            //System.out.println("delete---b10--->"+SqlQuery.toString());
           	 rv = stmt.executeUpdate(SqlQuery.toString());

                 if( rv <= 0 ) throw new Exception(" During processUserModify error !!!");

			conn.commit();
			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoDoDocFolderTran::deleteList : " + ignored.getMessage());
			}

	 		System.out.println(" GCoDoDocFolderTran::deleteList : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoDoDocFolderTran::deleteList : " + e.getMessage());
			}
			conn.close();
		}
	}


       /**
        * <PRE>
        *  ���� ������ ���޹޾�  �����������( B10 )�� ���Ѱ��� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE    : current user companycode at session
        *                      <LI> String Userno     :  ����� ���̵�
        *                      <LI> String Boxno      :  �Թ�ȣ
        *                      <LI> String Docno      :  ������ȣ
        *                      <LI> String Parentno   :  ����������ȣ
        *                      <LI> String Boxname    :  ���̸�
        *                      <LI> String Regdate    :  �����
        *                      <LI> String Trashflag  :  ������
        *                      <LI> String Comments   :  ����
        *                      <LI> String Refno      :  ���ù�ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        */



	public int insertFolder(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

		String COMCODE = dmProp.getString("COMCODE");
		String Boxno = dmProp.getString("Boxno");
		String Docno = dmProp.getString("Docno");
		String Parentno = dmProp.getString("Parentno");
		String Boxname = dmProp.getString("Boxname");
		String Userno = dmProp.getString("Userno");
		String Regdate = dmProp.getString("Regdate");
		String Trashflag = "1";
		String Comments = dmProp.getString("Comments");
		String Refno = dmProp.getString("Refno");
		String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;
		String Folderno = getMaxNo(COMCODE,strDbType);

		dmProp.setProperty("Folderno1",Folderno);

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" INSERT INTO TB_"+COMCODE+"_B10 (FLDNO,BOXNO,DOCNO,PARENTNO,FLDNAME,REGUSER,REGDATE,TRASHFLAG,COMMENTS,REFNO) ")
					.append(" VALUES ("+genQuote(Folderno)+","+genQuote(Boxno)+","+genQuote(Docno)+","+genQuote(Parentno)+","+genQuote(Boxname)+","+genQuote(Userno)+",")
					.append("         "+genQuote(Regdate)+","+genQuote(Trashflag)+","+genQuote(Comments)+","+genQuote(Refno)+")");
                  //System.out.println("gcododocfoldertran�� insertDoc������---->"+SqlQuery.toString());
			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoDoDocFolderTran::insertFolder : " + ignored.getMessage());
			}

	 		System.out.println(" GCoDoDocFolderTran::insertFolder : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoDoDocFolderTran::insertFolder : " + e.getMessage());
			}
			conn.close();
		}
	}


       /**
        * <PRE>
        *  ����Ŭ�� ���� �ð����� ������ȣ�� �˻��� ���� �����ϰԵ� ���� ��ȣ �ο�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE    : current user companycode at session
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        */


   	private String getMaxNo(String comcode,String strDbType)
		{

			GCmConnection conn = null;

	    try
	    {
		    conn = GCmDbManager.getInstance().getConnection();

		    StringBuffer sqlQuery = new StringBuffer();

                    if ("oracle".equals(strDbType))
                    {
		    	sqlQuery
		           .append(" SELECT DECODE(SUBSTR(MAX(FLDNO),1,8),TO_CHAR(sysdate,'YYYYMMDD'),TO_CHAR(TO_NUMBER(MAX(FLDNO))+1),null,TO_CHAR(sysdate,'YYYYMMDD')||'0001') as NO ")
		           .append(" FROM TB_").append(comcode).append("_B10 ")
		           .append(" WHERE FLDNO LIKE TO_CHAR(sysdate,'YYYYMMDD')||'%'");
                    }
                    else if ("mssql".equals(strDbType))
                         {
		    	sqlQuery
		           .append(" SELECT (CASE SUBSTRING(MAX(FLDNO),1,8) WHEN convert(char(08),getdate(),112) THEN CAST(SUBSTRING(MAX(FLDNO),1,8) AS varchar(8)) + RIGHT('0000'+CAST(SUBSTRING(MAX(FLDNO),9,4)+1 AS varchar(4)),4) ELSE convert(char(08),getdate(),112)+'0001' END) as NO ")
		           .append(" FROM TB_").append(comcode).append("_B10 ")
		           .append(" WHERE FLDNO LIKE convert(char(08),getdate(),112)+'%' ");
                         }

    		    GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
                    rs.next();

		    return rs.getString("NO");

            }
            catch (Exception e)
            {
 		  System.out.println(" GCoDoDocFolderTran::getMaxNo " + e.getMessage());
	 	  return null;
            }
            finally
            {
		  conn.close();
            }
      }

}