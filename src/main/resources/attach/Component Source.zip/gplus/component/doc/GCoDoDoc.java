package gplus.component.doc;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

/**
 * <PRE>
 * Filename		: GCoDoDoc.java
 * Class		: gplus.component.doc.GCoDoDoc
 * Fuction		: �ڷḦ ��ȸ��
 * Comment		:
 * History  : 12/10/2001, ������ , �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCoDoDoc extends GCmTopComponent
{

       /**
        * <PRE>
        * ���޵� ȸ���ڵ�� �Թ�ȣ ������ �������̸�(BOXNAME) �� �����´�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String BOXNO : �� ��ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : �� �̸�
        */

	public GCmResultSet getMenuDoc(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String BOXNO = dmProp.getString("BOXNO");

		try
		{
                	conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT BOXNO, BOXNAME ")
                           .append(" FROM TB_").append(COMCODE).append("_M10 ")
                           .append(" WHERE BOXNO = "+genQuote(BOXNO));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoDoDoc::getMenuDoc " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� ������ȣ�� ������ �����  �����󼼸���� �����´�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Docno : ���� ��ȣ
        *                      <LI> String SEQ : ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : ���� ���� (DOCNO,SEQ,CONTTYPE,TITLE,FILEEXT,
        *                                 FILENAME,VPATH,MIMETYPE,FILESIZE,ORGNAME,
        *                                 ORGPATH,REGUSER,REGDATE,MODUSER,MODDATE)
        */

	public GCmResultSet getDocDtlInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String Docno = dmProp.getString("Docno");
		String Seq = dmProp.getString("Seq");


		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT DOCNO,SEQ,CONTTYPE,TITLE,FILEEXT,FILENAME,VPATH,MIMETYPE,FILESIZE,ORGNAME,ORGPATH,REGUSER,REGDATE,MODUSER,MODDATE ")
                           .append(" FROM TB_"+COMCODE+"_L11 ")
                           .append(" WHERE DOCNO = "+genQuote(Docno)+" AND SEQ = "+genQuote(Seq));
			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoDoDoc::getDocDtlInfo " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}


       /**
        * <PRE>
        * ���޵� ������ȣ�� ����� �����󼼸���� �����´�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Docno: ���� ��ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : ���� ���� (DOCNO,TITLE,DOCTYPE,FILENUM,REGUSER,REGDATE,
        *                                 MODUSER,MODDATE
        */


	public GCmResultSet getDocInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String Docno = dmProp.getString("Docno");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT DOCNO,TITLE,DOCTYPE,FILENUM,REGUSER,REGDATE,MODUSER,MODDATE,MSTDOC,TOTFILESIZE ")
                           .append(" FROM TB_"+COMCODE+"_L10 ")
                           .append(" WHERE DOCNO = "+genQuote(Docno));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoDoDoc::getDocInfo " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}


       /**
        * <PRE>
        * ���޵� ������ȣ�� ������ �����  �����󼼸���� �����´�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Docno : ���� ��ȣ
        *                      <LI> String Seq : ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : ���� ���� (DOCNO,SEQ,CONTTYPE,TITLE,FILEEXT,
        *                                 FILENAME,VPATH,MIMETYPE,FILESIZE,ORGNAME,
        *                                 ORGPATH,REGUSER,REGDATE,MODUSER,MODDATE)
        */
	public GCmResultSet getDocDtlList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String Docno = dmProp.getString("Docno");
		String Seq = dmProp.getString("Seq");


		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT DOCNO,SEQ,CONTTYPE,TITLE,FILEEXT,FILENAME,VPATH,MIMETYPE,FILESIZE,ORGNAME,ORGPATH,REGUSER,REGDATE,MODUSER,MODDATE ")
                           .append(" FROM TB_"+COMCODE+"_L11 ")
                           .append(" WHERE DOCNO = "+genQuote(Docno)+" AND SEQ > "+genQuote(Seq))
                           .append(" ORDER BY SEQ ");
			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoDoDoc::getDocDtlList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}


       /**
        * <PRE>
        *  ���޵� �Խù�ȣ�� ����� �Խù� ��� & ���� ��� & ������ ��Ͽ� ���� ������ �����´�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String NOTINO : �Խ� ��ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : �Խù���� ( NOTINO,BOXNO,DOCNO,PARENTNO,TITLE,
        *                                 ATTNUM,REFNUM,NOMNUM,CHILDNUM,REGUSER,REGDATE,REGNAME )
        */


   public GCmResultSet getNotiDtlInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

                String COMCODE = dmProp.getString("COMCODE");
                String NOTINO = dmProp.getString("NOTINO");


               	try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT A.NOTINO,A.BOXNO,A.DOCNO,A.PARENTNO,A.TITLE,A.ATTNUM,A.REFNUM,A.NOMNUM,A.CHILDNUM,A.REGUSER,A.REGDATE,A.REGNAME,")
                           .append(" A.REF,A.SORTSTEP,A.RELEVEL , B.DOCNO,B.DOCTYPE,B.FILENUM , C.SEQ,C.FILEEXT,C.FILENAME,C.VPATH,C.MIMETYPE,C.FILESIZE")
                           .append(" FROM TB_"+COMCODE+"_A01 A, TB_"+COMCODE+"_L10 B, TB_"+COMCODE+"_L11 C")
                           .append(" WHERE A.DOCNO = B.DOCNO AND B.DOCNO = C.DOCNO ")
                           .append(" AND A.NOTINO = " + genQuote(NOTINO) + " AND C.SEQ = '01'" );
			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;
		}
		catch (Exception e)
		{
	 		System.out.println(" GCoBoBoard::getNotiInfo " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

       /**
        * <PRE>
        *  ���޵� ������ȣ�� ����� ������ ��Ͽ� ���� ������ �����´�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String DOCNO : ������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : �Խù���� (DOCNO,SEQ,CONTTYPE,TITLE,FILEEXT,FILENAME,
	*                                 VPATH,MIMETYPE,FILESIZE,ORGNAME,ORGPATH,REGUSER,
	*		  		  REGDATE,MODUSER,MODDATE)
	*/

	public GCmResultSet getNotiDocList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String DOCNO = dmProp.getString("DOCNO");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT DOCNO,SEQ,CONTTYPE,TITLE,FILEEXT,FILENAME,VPATH,MIMETYPE,FILESIZE, ")
                           .append(" ORGNAME,ORGPATH,REGUSER,REGDATE,MODUSER,MODDATE ")
                           .append(" FROM TB_").append(COMCODE).append("_L11 ")
                           .append(" WHERE DOCNO = ").append(genQuote(DOCNO)).append(" AND SEQ > '01' " );

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.err.println(" GCoDoDoc::getNotiDocList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}


}