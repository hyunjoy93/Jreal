package gplus.component.doc;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;
import oracle.sql.*;
import oracle.jdbc.driver.*;

/**
 * <PRE>
 * Filename		: GCoDoDocTran.java
 * Class		: gplus.component.doc.GCoDoDocTran
 * Fuction		:
 * Comment		:
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GCoDoDocTran extends GCmTopComponent
{

       /**
        * <PRE>
        * ������� ������ ���޹޾� ���� ��Ͽ� ������
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Title :  ����
        *                      <LI> String Doctype :  ��������
        *                      <LI> String Attnum  :  ÷�μ�
        *                      <LI> String Reguser  :  �����
        *                      <LI> String Regdate  :  �����
        *                      <LI> String Moduser  :  ������
        *                      <LI> String Moddate  :  ������
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        */

	public int insertDoc(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Title = dmProp.getString("Title");
		String Doctype = dmProp.getString("Doctype");
		String Attnum = dmProp.getString("Attnum");
		String Reguser = dmProp.getString("Reguser");
		String Regdate = dmProp.getString("Regdate");
		String Moduser = dmProp.getString("Moduser");
		String Moddate = dmProp.getString("Moddate");
		String Conts = dmProp.getString("Conts");
		String strDbType = cp.getProperty("gplus.db.type").toLowerCase();
                String Totfilesize = dmProp.getString("Totfilesize");
                String fromEmail = dmProp.getString("fromEmail");

                if( Totfilesize == null)
                {
                     Totfilesize = "0";
                }

		int rv=0;

		GCmConnection conn = null;
		Statement stmt = null;

		String Docno = "";
		
		if(fromEmail != null && !fromEmail.equals(""))
		{
	           Docno = dmProp.getString("Docno");
	        }
	        else
	        {
		   Docno = getMaxNo(COMCODE,strDbType);
		}

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

            if ("oracle".equals(strDbType))
            {
                 StringBuffer SqlQuery = new StringBuffer()
                                 .append(" INSERT INTO TB_"+COMCODE+"_L10 (DOCNO,TITLE,DOCTYPE,FILENUM,REGUSER,REGDATE,MODUSER,MODDATE,MSTDOC,TOTFILESIZE) ")
                                 .append(" VALUES ("+genQuote(Docno)+","+genQuote(Title)+","+genQuote(Doctype)+","+Attnum+","+genQuote(Reguser)+","+genQuote(Regdate)+",")
                                 .append("         "+genQuote(Moduser)+","+genQuote(Moddate)+", EMPTY_CLOB() ,"+Totfilesize+")");

			      conn.setAutoCommit(false);
 			      stmt = conn.createStatement();
          //System.out.println("gcododoctran�� insertDoc������---->"+SqlQuery.toString());
                  rv = stmt.executeUpdate(SqlQuery.toString());

                  if(Conts != null && !Conts.equals(""))
                  {
                       stmt.close();

                       SqlQuery = new StringBuffer()
                          .append(" SELECT MSTDOC ")
                          .append(" FROM TB_"+COMCODE+"_L10 ")
                          .append(" WHERE DOCNO = "+genQuote(Docno)+" FOR UPDATE ");

 			           stmt = conn.createStatement();
                       ResultSet mRs = stmt.executeQuery(SqlQuery.toString());

		               if( mRs.next() )
		               {
			                CLOB rClob = ((OracleResultSet)mRs).getCLOB(1);
			                Writer oWr = rClob.getCharacterOutputStream();

 			                oWr.write(Conts);
			                oWr.flush();
			                oWr.close();
		               }

		               mRs.close();
                }

			    conn.commit();
            }
            else if ("mssql".equals(strDbType))
                 {
                        StringBuffer SqlQuery = new StringBuffer()
                                      .append(" INSERT INTO TB_"+COMCODE+"_L10 (DOCNO,TITLE,DOCTYPE,FILENUM,REGUSER,REGDATE,MODUSER,MODDATE,MSTDOC) ")
                                      .append(" VALUES ("+genQuote(Docno)+","+genQuote(Title)+","+genQuote(Doctype)+","+Attnum+","+genQuote(Reguser)+","+genQuote(Regdate)+",")
                                      .append("         "+genQuote(Moduser)+","+genQuote(Moddate)+","+genQuote(Conts)+" ) ");

			            stmt = conn.createStatement();
			            conn.setAutoCommit(false);
			                rv = stmt.executeUpdate(SqlQuery.toString());
                        conn.commit();
                 }

            dmProp.setProperty("Docno",Docno);
			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoDoDocTran::insertDoc : " + ignored.getMessage());
			}

	 		System.out.println(" GCoDoDocTran::insertDoc : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoDoDocTran::insertDoc : " + e.getMessage());
			}
			conn.close();
		}
	}



       /**
        * <PRE>
        * ������� ������ ���޹޾� ���� �󼼸�Ͽ� ������
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Title :  ����
        *                      <LI> String Docno :  ������ȣ
        *                      <LI> String Seq :  ����
        *                      <LI> String Fileext :  Ȯ����
        *                      <LI> String Filename :  �����̸�
        *                      <LI> String Vpath : ������
        *                      <LI> String Mimetype : ������
        *                      <LI> String Filesize : ������
        *                      <LI> String Orgname: ������
        *                      <LI> String Orgpath : ������
        *                      <LI> String Reguser : ������
        *                      <LI> String Regdate : ������
        *                      <LI> String Moduser : ������
        *                      <LI> String Moddate : ������
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        */


	public int insertAttDoc(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Docno = dmProp.getString("Docno");
		String Seq = dmProp.getString("Seq");
		String Conttype = dmProp.getString("Conttype");
		String Title = dmProp.getString("Title");
		String Fileext = dmProp.getString("Fileext");
		String Filename = dmProp.getString("Filename");
		String Vpath = dmProp.getString("Vpath");
		String Mimetype = dmProp.getString("Mimetype");
		String Filesize = dmProp.getString("Filesize");
		String Orgname = dmProp.getString("Orgname");
		String Orgpath = dmProp.getString("Orgpath");
		String Reguser = dmProp.getString("Reguser");
		String Regdate = dmProp.getString("Regdate");
		String Moduser = dmProp.getString("Moduser");
		String Moddate = dmProp.getString("Moddate");
                int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" INSERT INTO TB_"+COMCODE+"_L11 (DOCNO,SEQ,CONTTYPE,TITLE,FILEEXT,FILENAME, ")
					.append("             VPATH,MIMETYPE,FILESIZE,ORGNAME,ORGPATH,REGUSER,REGDATE,MODUSER,MODDATE) ")
					.append(" VALUES ("+genQuote(Docno)+","+genQuote(Seq)+","+genQuote(Conttype)+","+genQuote(Title)+","+genQuote(Fileext)+","+genQuote(Filename)+",")
					.append("         "+genQuote(Vpath)+","+genQuote(Mimetype)+","+Filesize+","+genQuote(Orgname)+","+genQuote(Orgpath)+","+genQuote(Reguser)+",")
					.append("         "+genQuote(Regdate)+","+genQuote(Moduser)+","+genQuote(Moddate)+")");
                        //System.out.println("insertAttDoc----------->"+SqlQuery.toString());
			stmt = conn.createStatement();
			conn.setAutoCommit(false);
		        rv = stmt.executeUpdate(SqlQuery.toString());

			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoDoDocTran::insertAttDoc : " + ignored.getMessage());
			}

	 		System.out.println(" GCoDoDocTran::insertAttDoc : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoDoDocTran::insertAttDoc : " + e.getMessage());
			}
			conn.close();
		}
	}


       /**
        * <PRE>
        * ������ȣ�� ���޹޾� ������ �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Docno :  ������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        */

	public int deleteDoc(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Docno = dmProp.getString("Docno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" DELETE FROM TB_"+COMCODE+"_L10 ")
					.append(" WHERE DOCNO = "+genQuote(Docno));

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoDoDocTran::deleteDoc : " + ignored.getMessage());
			}

	 		System.out.println(" GCoDoDocTran::deleteDoc : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoDoDocTran::deleteDoc : " + e.getMessage());
			}
			conn.close();
		}
	}


       /**
        * <PRE>
        * ������ȣ�� ������ ���޹޾� ���������  ������.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Docno :  ������ȣ
        *                      <LI> String Seq" :  ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        */

	public int deleteFile(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Docno = dmProp.getString("Docno");
		String Seq = dmProp.getString("Seq");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" DELETE FROM TB_"+COMCODE+"_L11 ")
					.append(" WHERE DOCNO = "+genQuote(Docno)+" AND SEQ = "+genQuote(Seq));

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
		        rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoDoDocTran::deleteFile : " + ignored.getMessage());
			}

	 		System.out.println(" GCoDoDocTran::deleteFile : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoDoDocTran::deleteFile : " + e.getMessage());
			}
			conn.close();
		}
	}


       /**
        * <PRE>
        * ������ȣ�� ������ ���޹޾� ������ ����� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Docno :  ������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        */


	public int deleteFileAll(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Docno = dmProp.getString("Docno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" DELETE FROM TB_"+COMCODE+"_L11 ")
					.append(" WHERE DOCNO = "+genQuote(Docno));
//System.out.println("gcododoctran�� delectFileAll--->"+SqlQuery.toString());
			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoDoDocTran::deleteFileAll : " + ignored.getMessage());
			}

	 		System.out.println(" GCoDoDocTran::deleteFileAll : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoDoDocTran::deleteFileAll : " + e.getMessage());
			}
			conn.close();
		}
	}


       /**
        * <PRE>
        * ������ ���� ������ ���޹޾� ������Ͽ� ������.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Title   :  ����
        *                      <LI> String Filenum :  ���ϼ�
        *                      <LI> String Docno   :  ������ȣ
        *                      <LI> String DOCTYPE :  ��������
        *                      <LI> String REGUSER :  �����
        *                      <LI> String REGDATE :  �����
        *                      <LI> String MODUSER :  ������
        *                      <LI> String MODDATE :  ������
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        */


	public int updateDocEdit(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Title = dmProp.getString("Title");
		String Filenum = dmProp.getString("Filenum");
		String Docno = dmProp.getString("Docno");
		String DOCTYPE = dmProp.getString("DOCTYPE");
		String REGUSER = dmProp.getString("REGUSER");
		String REGDATE = dmProp.getString("REGDATE");
		String MODUSER = dmProp.getString("MODUSER");
		String MODDATE = dmProp.getString("MODDATE");
		String Conts = dmProp.getString("Conts");
                int Totfilesize = dmProp.getInt("Totfilesize");
		String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		int rv=0;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

            if ("oracle".equals(strDbType))
            {
			    StringBuffer SqlQuery = new StringBuffer()
					            .append(" UPDATE TB_"+COMCODE+"_L10 ")
                                .append(" SET TITLE = "+genQuote(Title))
                                .append(", FILENUM = "+Filenum)
                                .append(", DOCTYPE = "+genQuote(DOCTYPE))
                                .append(", REGUSER = "+genQuote(REGUSER))
                                .append(", REGDATE = "+genQuote(REGDATE))
                                .append(", MODUSER = "+genQuote(MODUSER))
                                .append(", MODDATE = "+genQuote(MODDATE))
                                .append(" , TOTFILESIZE = "+Totfilesize)
				.append(" WHERE DOCNO = "+genQuote(Docno));
                              //System.out.println("updateDocEdit---->"+SqlQuery.toString());

			      conn.setAutoCommit(false);
 			      stmt = conn.createStatement();
                  rv = stmt.executeUpdate(SqlQuery.toString());
                  stmt.close();

                  SqlQuery = new StringBuffer()
                                 .append(" SELECT MSTDOC ")
                                 .append(" FROM TB_"+COMCODE+"_L10 ")
                                 .append(" WHERE DOCNO = "+genQuote(Docno)+" FOR UPDATE ");

 			      stmt = conn.createStatement();
                  ResultSet mRs = stmt.executeQuery(SqlQuery.toString());

		          if(mRs.next())
		          {
			           CLOB rClob = ((OracleResultSet)mRs).getCLOB(1);
			           Writer oWr = rClob.getCharacterOutputStream();

 			           oWr.write(Conts);
			           oWr.flush();
			           oWr.close();
		          }

			      conn.commit();
		          mRs.close();
            }
            else if ("mssql".equals(strDbType))
                 {
 			         StringBuffer SqlQuery = new StringBuffer()
					            .append(" UPDATE TB_"+COMCODE+"_L10 ")
                                .append(" SET TITLE = "+genQuote(Title))
                                .append(", FILENUM = "+Filenum)
                                .append(", DOCTYPE = "+genQuote(DOCTYPE))
                                .append(", REGUSER = "+genQuote(REGUSER))
                                .append(", REGDATE = "+genQuote(REGDATE))
                                .append(", MODUSER = "+genQuote(MODUSER))
                                .append(", MODDATE = "+genQuote(MODDATE))
                                .append(", MSTDOC = "+genQuote(Conts))
					            .append(" WHERE DOCNO = "+genQuote(Docno));

			            stmt = conn.createStatement();
			            conn.setAutoCommit(false);
			                rv = stmt.executeUpdate(SqlQuery.toString());
                        conn.commit();

                 }

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoDoDocTran::updateDocEdit : " + ignored.getMessage());
			}

	 		System.out.println(" GCoDoDocTran::updateDocEdit : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoDoDocTran::updateDocEdit : " + e.getMessage());
			}
			conn.close();
		}
	}




       /**
        * <PRE>
        * ������ ���� ������ ���޹޾� ������Ͽ� ������.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Title   :  ����
        *                      <LI> String Filenum :  ���ϼ�
        *                      <LI> String Docno   :  ������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        */


	public int updateDoc(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Title = dmProp.getString("Title");
		String Filenum = dmProp.getString("Filenum");
		String Docno = dmProp.getString("Docno");
                int Totfilesize = dmProp.getInt("Totfilesize");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
				.append(" UPDATE TB_"+COMCODE+"_L10 ")
                                .append(" SET TITLE = "+genQuote(Title)+", FILENUM = "+genQuote(Filenum))
                                .append(" , TOTFILESIZE = "+Totfilesize)
				.append(" WHERE DOCNO = "+genQuote(Docno));


			stmt = conn.createStatement();
			conn.setAutoCommit(false);

			rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoDoDocTran::updateDoc : " + ignored.getMessage());
			}

	 		System.out.println(" GCoDoDocTran::updateDoc : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoDoDocTran::updateDoc : " + e.getMessage());
			}
			conn.close();
		}
	}


       /**
        * <PRE>
        * ���ϰ����� ���޹޾� ������Ͽ� ������.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String Filenum :  ���ϼ�
        *                      <LI> String Docno   :  ������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        */


	public int updateFileNum(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Filenum = dmProp.getString("Filenum");
		String Docno = dmProp.getString("Docno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" UPDATE TB_"+COMCODE+"_L10 ")
                                        .append(" SET FILENUM = "+Filenum)
					.append(" WHERE DOCNO = "+genQuote(Docno));

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoDoDocTran::updateFileNum : " + ignored.getMessage());
			}

	 		System.out.println(" GCoDoDocTran::updateFileNum : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoDoDocTran::updateFileNum : " + e.getMessage());
			}
			conn.close();
		}
	}


       /**
        * <PRE>
        * ���� ��Ͽ� ���� ������ ���޹޾� ������( ���� ).
        * </PRE>
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE   : current user companycode at session
        *                      <LI> String Conttype  :  ��������
        *                      <LI> String Title     :  ����
        *                      <LI> String Fileext   :  Ȯ����
        *                      <LI> String Filename  :  �����̸�
        *                      <LI> String Vpath     :  ������
        *                      <LI> String Mimetype  :  ��������
        *                      <LI> String Filesize  :  ����ũ��
        *                      <LI> String Orgname   :  �������̸�
        *                      <LI> String Orgpath   :  �����ϰ��
        *                      <LI> String Reguser   :  �����
        *                      <LI> String Regdate   :  �����
        *                      <LI> String Moduser   :  ������
        *                      <LI> String Moddate   :  ������
        *                      <LI> String Seq       :  ����
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        *
        */

	public int updateDocDtl(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Conttype = dmProp.getString("Conttype");
		String Title = dmProp.getString("Title");
		String Fileext = dmProp.getString("Fileext");
		String Filename = dmProp.getString("Filename");
		String Vpath = dmProp.getString("Vpath");
		String Mimetype = dmProp.getString("Mimetype");
		String Filesize = dmProp.getString("Filesize");
		String Orgname = dmProp.getString("Orgname");
		String Orgpath = dmProp.getString("Orgpath");
		String Reguser = dmProp.getString("Reguser");
		String Regdate = dmProp.getString("Regdate");
		String Moduser = dmProp.getString("Moduser");
		String Moddate = dmProp.getString("Moddate");
		String Docno = dmProp.getString("Docno");
		String Seq = dmProp.getString("Seq");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" UPDATE TB_"+COMCODE+"_L11 ")
                                        .append(" SET CONTTYPE = "+genQuote(Conttype)+",TITLE = "+genQuote(Title)+",FILEEXT = "+genQuote(Fileext)+",FILENAME = "+genQuote(Filename)+",VPATH = "+genQuote(Vpath)+",")
                                        .append("     MIMETYPE = "+genQuote(Mimetype)+",FILESIZE = "+Filesize+",ORGNAME = "+genQuote(Orgname)+",ORGPATH = "+genQuote(Orgpath)+",REGUSER = "+genQuote(Reguser)+",")
                                        .append("     REGDATE = "+genQuote(Regdate)+",MODUSER = "+genQuote(Moduser)+",MODDATE = "+genQuote(Moddate))
					.append(" WHERE DOCNO = "+genQuote(Docno)+" AND SEQ = "+genQuote(Seq));
              //System.out.println("updateDocDtl---------->"+SqlQuery.toString());
			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoDoDocTran::updateDocDtl : " + ignored.getMessage());
			}

	 		System.out.println(" GCoDoDocTran::updateDocDtl : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoDoDocTran::updateDocDtl : " + e.getMessage());
			}
			conn.close();
		}
	}


       /**
        * <PRE>
        *  ����Ŭ�� ���� �ð����� ������ȣ�� �˻��� ���� �����ϰԵ� ���� ��ȣ �ο�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE   : current user companycode at session
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        */

    private String getMaxNo(String comcode,String strDbType) {

	    GCmConnection conn = null;

	    try
	    {
		    conn = GCmDbManager.getInstance().getConnection();

		    StringBuffer sqlQuery = new StringBuffer();

                    if ("oracle".equals(strDbType))
                    {
		    	sqlQuery
		           .append(" SELECT DECODE(SUBSTR(MAX(DOCNO),1,8),TO_CHAR(sysdate,'YYYYMMDD'),TO_CHAR(TO_NUMBER(MAX(DOCNO))+1),null,TO_CHAR(sysdate,'YYYYMMDD')||'0001') as NO ")
                           .append(" FROM TB_").append(comcode).append("_L10 ")
                           .append(" WHERE DOCNO LIKE TO_CHAR(sysdate,'YYYYMMDD')||'%'");
                    }
                    else if ("mssql".equals(strDbType))
                         {
                                sqlQuery
                                   .append(" SELECT (CASE SUBSTRING(MAX(DOCNO),1,8) WHEN convert(char(08),getdate(),112) THEN CAST(SUBSTRING(MAX(DOCNO),1,8) AS varchar(8)) + RIGHT('0000'+CAST(SUBSTRING(MAX(DOCNO),9,4)+1 AS varchar(4)),4) ELSE convert(char(08),getdate(),112)+'0001' END) as NO ")
                                   .append(" FROM TB_").append(comcode).append("_L10 ")
                                   .append(" WHERE DOCNO LIKE convert(char(08),getdate(),112)+'%' ");
                         }

    		    GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
                    rs.next();

		    return rs.getString("NO");

            }
            catch (Exception e)
            {
 		  System.err.println(" GCoDoDocTran::getMaxNo " + e.getMessage());
	 	  return null;
            }
            finally
            {
		  conn.close();
            }
      }



      public int updateContsDoc(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Docno = dmProp.getString("Docno");
                String MODUSER = dmProp.getString("Moduser");
		String MODDATE = dmProp.getString("Moddate");
                String Conts = dmProp.getString("Conts");
		String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		int rv=0;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

            if ("oracle".equals(strDbType))
            {

			    StringBuffer SqlQuery = new StringBuffer()

					            .append(" UPDATE TB_"+COMCODE+"_L10 ")
                                .append(" SET MODUSER = "+genQuote(MODUSER))
                                .append(", MODDATE = "+genQuote(MODDATE))
					            .append(" WHERE DOCNO = "+genQuote(Docno));

			      conn.setAutoCommit(false);
 			      stmt = conn.createStatement();
 //System.out.println("updateContsDoc   = " + SqlQuery.toString());
                  rv = stmt.executeUpdate(SqlQuery.toString());
                  stmt.close();

                  SqlQuery = new StringBuffer()
                                 .append(" SELECT MSTDOC ")
                                 .append(" FROM TB_"+COMCODE+"_L10 ")
                                 .append(" WHERE DOCNO = "+genQuote(Docno)+" FOR UPDATE ");

 			      stmt = conn.createStatement();
                  ResultSet mRs = stmt.executeQuery(SqlQuery.toString());

		          if(mRs.next())
		          {
			           CLOB rClob = ((OracleResultSet)mRs).getCLOB(1);
			           Writer oWr = rClob.getCharacterOutputStream();

                           // System.out.println("Conts = " + Conts);

 			           oWr.write(Conts);
			           oWr.flush();
			           oWr.close();
		          }
                    //System.out.println("updateContsDoc select = " + SqlQuery.toString());
			      conn.commit();
		          mRs.close();
            }
            else if ("mssql".equals(strDbType))
                 {
 			         StringBuffer SqlQuery = new StringBuffer()
					            .append(" UPDATE TB_"+COMCODE+"_L10 ")
                                .append(" SET MSTDOC = "+genQuote(Conts))
					            .append(" WHERE DOCNO = "+genQuote(Docno));

			            stmt = conn.createStatement();
			            conn.setAutoCommit(false);
			                rv = stmt.executeUpdate(SqlQuery.toString());
                        conn.commit();

                 }

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoDoDocTran::updateContsDoc : " + ignored.getMessage());
			}

	 		System.out.println(" GCoDoDocTran::updateContsDoc : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoDoDocTran::updateContsDoc : " + e.getMessage());
			}
			conn.close();
		}
	}



}