package gplus.component.card;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

/**
 * <PRE>
 * Filename		: GCoCaCard.java
 * Class		: gplus.component.card.GCoCaCard
 * Fuction		:
 * Comment		:
 * History      : 01/10/2002, ���߱� , �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GCoCaCard extends GCmTopComponent
{
   /**
    * <PRE>
    * ���޵� ���Թ�ȣ�� ������ ���Ը�ϰ� ���Ա׷� ����� �ǵ��� �ش�.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String USERID : current user id at session
    *                      <LI> String CardNo : ���Թ�ȣ
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : �������� (F10.*,GRPNAME,ORGNAME )
    */
	public GCmResultSet getCardInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

            GCmConnection conn = null;
	    String COMCODE = dmProp.getString("COMCODE");
            String USERID = dmProp.getString("USERID");
            String pCardNo = dmProp.getString("CardNo");
            String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

            try
            {
         	conn = GCmDbManager.getInstance().getConnection();
	        StringBuffer sqlQuery = new StringBuffer();

                if ("oracle".equals(strDbType))
                {
	  	    sqlQuery
                        .append(" SELECT A.*, B.GRPNAME, C.ORGNAME ")
                        .append(" FROM TB_").append(COMCODE).append("_F10 A, TB_").append(COMCODE).append("_G10 B, TB_").append(COMCODE).append("_N10 C")
                        .append(" WHERE A.GRPNO = B.GRPNO(+) AND A.CARDNO="+genQuote(pCardNo));
                }
                else if ("mssql".equals(strDbType))
                {
	  	    sqlQuery
                        .append(" SELECT A.*, B.GRPNAME, C.ORGNAME ")
                        .append(" FROM TB_").append(COMCODE).append("_F10 A, TB_").append(COMCODE).append("_G10 B, TB_").append(COMCODE).append("_N10 C")
                        .append(" WHERE A.GRPNO *= B.GRPNO AND A.CARDNO="+genQuote(pCardNo));
                }

		GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
		return rs;

            }
            catch (Exception e)
            {
	 	System.out.println(" GCoCaCard::getCardInfo " + e.getMessage());
	 	return null;
	    }
            finally
	    {
		conn.close();
	    }
	}
    /**
    * <PRE>
    * ������ �� ����� �̸��� �����´�.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String USERID : tb_f10�� copierid
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : �������� (USERNAME)
    */

        public GCmResultSet getCardCopyInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

            GCmConnection conn = null;
	    String COMCODE = dmProp.getString("COMCODE");
            String USERID = dmProp.getString("USERID");
            String pCardNo = dmProp.getString("CardNo");
            String strDbType = cp.getProperty("gplus.db.type").toLowerCase();
            GCmResultSet rs = null;
            StringBuffer sqlQuery = null;

            try
            {
         	conn = GCmDbManager.getInstance().getConnection();

                if ("oracle".equals(strDbType))
                {
	  	    sqlQuery = new StringBuffer()
                        .append(" SELECT COPIERID ")
                        .append(" FROM TB_").append(COMCODE).append("_F10 A, TB_").append(COMCODE).append("_G10 B, TB_").append(COMCODE).append("_N10 C")
                        .append(" WHERE A.GRPNO = B.GRPNO(+) AND A.CARDNO="+genQuote(pCardNo));

                    rs = conn.executeQuery(sqlQuery.toString());
                    rs.next();
                    sqlQuery = new StringBuffer()
                        .append("select username ")
                        .append("from tb_comm_z20 ")
                        .append("where comcode="+genQuote(COMCODE)+ "and userid="+genQuote(rs.getString("COPIERID")));

                }
                else if ("mssql".equals(strDbType))
                {
	  	    sqlQuery = new StringBuffer()
                        .append(" SELECT COPIERID ")
                        .append(" FROM TB_").append(COMCODE).append("_F10 A, TB_").append(COMCODE).append("_G10 B, TB_").append(COMCODE).append("_N10 C")
                        .append(" WHERE A.GRPNO *= B.GRPNO AND A.CARDNO="+genQuote(pCardNo));

                    rs = conn.executeQuery(sqlQuery.toString());
                    rs.next();
                    sqlQuery = new StringBuffer()
                        .append("select username ")
                        .append("from tb_comm_z20 ")
                        .append("where comcode="+genQuote(COMCODE)+ "and userid="+genQuote(rs.getString("COPIERID")));
                }

		rs = conn.executeQuery(sqlQuery.toString());
		return rs;

            }
            catch (Exception e)
            {
	 	System.out.println(" GCoCaCard::getCardCopyInfo " + e.getMessage());
	 	return null;
	    }
            finally
	    {
		conn.close();
	    }
	}


       /**
        * <PRE>
        * ���޵� ���Թ�ȣ�� USERID ������ ���� �μ�� �ʿ��� �ּ�, �̸�, ������ȣ�� �ǵ����ش�
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : current user id at session
        *                      <LI> String CardNo : ���Թ�ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : �������� (ADDR,NAMEK,ZIPCODE )
        */
	public GCmResultSet getCardDmInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

            GCmConnection conn = null;
	    String COMCODE = dmProp.getString("COMCODE");
            String USERID = dmProp.getString("USERID");
            String LIST = dmProp.getString("LIST");
            String strDbType = cp.getProperty("gplus.db.type").toLowerCase();
            GCmResultSet rs = null;

            try
            {
         	conn = GCmDbManager.getInstance().getConnection();
	        StringBuffer sqlQuery = null;

                sqlQuery = new StringBuffer()
                        .append(" SELECT ADDR,NAMEK,ZIPCODE ")
                        .append(" FROM TB_").append(COMCODE).append("_F10 ")
                        .append(" WHERE CARDNO IN ('"+gplus.commlib.util.GCmFcts.replace(LIST,",","','")+"') AND USERID = "+genQuote(USERID));

                rs = conn.executeQuery(sqlQuery.toString());
                return rs;
            }
            catch (Exception e)
            {
	 	System.out.println(" GCoCaCard::getCardDmInfo " + e.getMessage());
	 	return null;
	    }
            finally
	    {
		conn.close();
	    }
	}

   /**
    * <PRE>
    * ���޵� ������ ������ �˻��Ͽ� ���� ���� ����Ʈ�� �ǵ��� �ش�.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String USERID : current user id at session
    *                      <LI> String SortId : ������ �ʵ�
    *                      <LI> String SortOpt : �����ɼ�
    *                      <LI> String GrpNo : ���Ա׷��ȣ
    *                      <LI> String Opt : �˻�����
    *                      <LI> String Q : �˻���
    *                      <LI> String Sdate : �˻���������
    *                      <LI> String Ldate : �˻���������
    *                      <LI> String curPage : ���� page
    *                      <LI> String pageSize : ǥ���� page�� row ��
    *                      <LI> String orgcode : ���� ���� �ڵ�
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : ������������ (F10.*,GRPNAME,ORGNAME )
    */
	public GCmResultSet getCardPublicList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

       	    GCmConnection conn = null;
            String COMCODE = dmProp.getString("COMCODE");
            String USERID = dmProp.getString("USERID");
            String pSortId = dmProp.getString("SortId");
            String pSortOpt = dmProp.getString("SortOpt");
            String pGrpNo = dmProp.getString("GrpNo");
            String pOpt = dmProp.getString("Opt");
            String pQ = dmProp.getString("Q");
            String sdate = dmProp.getString("Sdate");
            String ldate = dmProp.getString("Ldate");
            String curPage = dmProp.getString("curPage");
            String pageSize = dmProp.getString("pageSize");
            String orgcode = dmProp.getString("orgcode");
            String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

            int ipageSize = Integer.parseInt ( pageSize );
            int icurPage  = Integer.parseInt ( curPage );
            int nCnt = 1;

            String opt="";
            String sqlstmt="";
            String sortList ="";

            if(pSortId.equals("USERNAME")){
              sortList = pSortId + " "+ pSortOpt ;
            }else{
              sortList = "A."+ pSortId + " "+ pSortOpt ;
            }


            try
            {
	       conn = GCmDbManager.getInstance().getConnection();

               if (!pOpt.equals("") && (!pQ.equals("") || !sdate.equals("")))
               {
                        sdate = gplus.commlib.util.GCmFcts.replace(sdate,"/","");
                        ldate = gplus.commlib.util.GCmFcts.replace(ldate,"/","");
                        if (pOpt.toUpperCase().equals("REGDATE"))
                        {
                            if (!ldate.equals(""))
                            {
                                opt = " AND A." +pOpt+" BETWEEN '"+sdate+"000000' AND '"+ldate+"240000' ";
                            }
                            else
                                opt = " AND LOWER(A."+pOpt+") LIKE '"+sdate+"%' ";
                        }
                        else
                            opt = " AND LOWER(A."+pOpt+") LIKE '%" + pQ.toLowerCase() + "%' ";
               }

   	  	       StringBuffer sqlQuery = new StringBuffer();

               if ("oracle".equals(strDbType))
               {
                     sqlQuery
                           .append(" SELECT D.* ")
                           .append(" FROM (SELECT C.*, ROWNUM AS RN ")
                           .append("       FROM (SELECT a.cardno, namek, comname, addr, mobile, email, a.userid, (select username from tb_comm_z20 z where z.userid=a.userid) username ")
                           .append("             from tb_"+COMCODE+"_f10 a, tb_"+COMCODE+"_f50 b ")
                           .append("             where a.cardno=b.cardno ")
                           .append("             and b.userid="+genQuote(USERID)+" "+opt)
                           .append("             ORDER BY "+sortList+" ) C ")
                           .append("	   WHERE ROWNUM <= "+String.valueOf(icurPage * ipageSize)+") D ")
                           .append(" WHERE D.RN BETWEEN "+String.valueOf(icurPage * ipageSize - ipageSize + 1)+" AND "+String.valueOf(icurPage * ipageSize));
                }
                else if ("mssql".equals(strDbType))
                {
  	      	           sqlQuery
                           .append(" SELECT TOP ").append(icurPage * ipageSize).append(" a.cardno, namek, comname, addr, mobile, email, a.userid, (select username from tb_comm_z20 z where z.userid=a.userid) username ")
                           .append(" from tb_"+COMCODE+"_f10 a, tb_"+COMCODE+"_f50 b ")
                           .append(" where a.cardno=b.cardno and b.userid="+genQuote(USERID)+" "+opt)
                           .append(" ORDER BY "+sortList);
                }

		GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

                if ("mssql".equals(strDbType))
                {
                    rs.moveRecordPos((icurPage-1)*ipageSize);
                }

                return rs;

            }
	    catch (Exception e)
	    {
	        System.out.println(" GCoCaCard::getCardPublicList " + e.getMessage());
		return null;
            }
	    finally
	    {
		conn.close();
	    }
	}
   /**
    * <PRE>
    * ���޵� ������ ������ �˻��Ͽ� ���� ���� ����Ʈ�� ������ ��������.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String USERID : current user id at session
    *                      <LI> String SortId : ������ �ʵ�
    *                      <LI> String SortOpt : �����ɼ�
    *                      <LI> String GrpNo : ���Ա׷��ȣ
    *                      <LI> String Opt : �˻�����
    *                      <LI> String Q : �˻���
    *                      <LI> String Sdate : �˻���������
    *                      <LI> String Ldate : �˻���������
    *                      <LI> String curPage : ���� page
    *                      <LI> String pageSize : ǥ���� page�� row ��
    *                      <LI> String orgcode : ���� ���� �ڵ�
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : �������� (N10.ORGNAME)
    */
	public GCmResultSet getPublicRecordCount(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

       	    GCmConnection conn = null;
            String COMCODE = dmProp.getString("COMCODE");
	    String USERID = dmProp.getString("USERID");
	    String pSortId = dmProp.getString("SortId");
	    String pSortOpt = dmProp.getString("SortOpt");
	    String pGrpNo = dmProp.getString("GrpNo");
	    String pOpt = dmProp.getString("Opt");
	    String pQ = dmProp.getString("Q");
	    String sdate = dmProp.getString("Sdate");
            String ldate = dmProp.getString("Ldate");
            String orgcode = dmProp.getString("orgcode");
            String pCardNo = dmProp.getString("CARDNO");
            String opt="";
            String sqlstmt="";
            String sortList = "A."+ pSortId + " "+ pSortOpt ;

            try
            {
                conn = GCmDbManager.getInstance().getConnection();

                if (!pOpt.equals("") && (!pQ.equals("") || !sdate.equals("")))
                {
                    sdate = gplus.commlib.util.GCmFcts.replace(sdate,"/","");
                    ldate = gplus.commlib.util.GCmFcts.replace(ldate,"/","");
                    if (pOpt.toUpperCase().equals("REGDATE"))
                    {
                        if (!ldate.equals(""))
                        {
                            opt = " AND A." +pOpt+" BETWEEN '"+sdate+"000000' AND '"+ldate+"240000' ";
                        }
                        else
                            opt = " AND LOWER(A."+pOpt+") LIKE '"+sdate+"%' ";
                    }
                    else
                        opt = " AND LOWER(A."+pOpt+") LIKE '%" + pQ.toLowerCase() + "%' ";
                 }


   		 StringBuffer sqlQuery = new StringBuffer()
                            .append("SELECT a.cardno, comname, namek, regdate ")
                            .append("from tb_"+COMCODE+"_f10 a, tb_"+COMCODE+"_f50 b ")
                            .append("where a.cardno=b.cardno ")
                            .append("and b.userid="+genQuote(USERID))
                            .append(" ORDER BY A.NAMEK ASC ");
                  /*
                           .append(" SELECT B.ORGNAME ")
                           .append(" FROM TB_"+COMCODE+"_F10 A, TB_"+COMCODE+"_N10 B, TB_COMM_Z20 E ")
                           .append(" WHERE A.ORGNO = B.ORGNO AND A.USERID = E.USERID AND A.ORGNO='"+orgcode+"' AND A.PUBFLAG='0' "+opt)
                           .append(" ORDER BY "+sortList);
                  */

                 GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
                 return rs;
            }
            catch (Exception e)
            {
	 	System.out.println(" GCoCaCard::getPublicRecordCount " + e.getMessage());
		return null;
            }
            finally
            {
		conn.close();
            }
	}

   /**
    * <PRE>
    * ���޵� ������ ������ �˻��Ͽ� ���θ��� ����Ʈ�� �ǵ��� �ش�.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String USERID : current user id at session
    *                      <LI> String SortId : ������ �ʵ�
    *                      <LI> String SortOpt : �����ɼ�
    *                      <LI> String GrpNo : ���Ա׷��ȣ
    *                      <LI> String Opt : �˻�����
    *                      <LI> String Q : �˻���
    *                      <LI> String Sdate : �˻���������
    *                      <LI> String Ldate : �˻���������
    *                      <LI> String curPage : ���� page
    *                      <LI> String pageSize : ǥ���� page�� row ��
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : ���θ�������(F10.*,GRPNAME)
    */
	public GCmResultSet getCardPrivateList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
                GCmConnection conn = null;
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String pSortId = dmProp.getString("SortId");
		String pSortOpt = dmProp.getString("SortOpt");
		String pGrpNo = dmProp.getString("GrpNo");
		String pOpt = dmProp.getString("Opt");
		String pQ = dmProp.getString("Q");
		String sdate = dmProp.getString("Sdate");
		String ldate = dmProp.getString("Ldate");
                String curPage = dmProp.getString("curPage");
		String pageSize = dmProp.getString("pageSize");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

                int nCnt = 1;
                String opt="";
                String grpSql="";
                String sqlstmt="";
                String sortList = "A."+ pSortId + " "+ pSortOpt ;
                int ipageSize = Integer.parseInt ( pageSize );
                int icurPage  = Integer.parseInt ( curPage );

		try
		{
	                conn = GCmDbManager.getInstance().getConnection();

                    if (!pOpt.equals("") && (!pQ.equals("") || !sdate.equals("")))
                    {
                        sdate = gplus.commlib.util.GCmFcts.replace(sdate,"/","");
                        ldate = gplus.commlib.util.GCmFcts.replace(ldate,"/","");
                        if (pOpt.toUpperCase().equals("REGDATE"))
                        {
                            if (!ldate.equals(""))
                            {
                                opt = " AND A." +pOpt+" BETWEEN '"+sdate+"000000' AND '"+ldate+"240000' ";
                            }
                            else
                                opt = " AND LOWER(A."+pOpt+") LIKE '"+sdate+"%' ";
                        }
                        else
                            opt = " AND LOWER(A."+pOpt+") LIKE '%" + pQ.toLowerCase() + "%' ";
                    }

                    if(!pGrpNo.equals(""))
                    {
                          grpSql= " AND A.GRPNO = '"+pGrpNo+"' ";
                    }

   		            StringBuffer sqlQuery = new StringBuffer();

                    if ("oracle".equals(strDbType))
                    {
                         sqlQuery
                           .append(" SELECT D.* ")
                           .append(" FROM (SELECT C.*, ROWNUM AS RN ")
                           .append("       FROM (SELECT A.*, B.GRPNAME ")
                           .append("             FROM TB_"+COMCODE+"_F10 A, TB_"+COMCODE+"_G10 B ")
                           .append("	         WHERE A.GRPNO = B.GRPNO(+) AND A.USERID="+genQuote(USERID)+" "+opt+" "+grpSql)
                           .append("	         ORDER BY "+sortList+" ) C ")
                           .append("	   WHERE ROWNUM <= "+String.valueOf(icurPage * ipageSize)+") D ")
                           .append(" WHERE D.RN BETWEEN "+String.valueOf(icurPage * ipageSize - ipageSize + 1)+" AND "+String.valueOf(icurPage * ipageSize));
                    }
                    else if ("mssql".equals(strDbType))
                         {
  	      	              sqlQuery
                                 .append(" SELECT TOP ").append(icurPage * ipageSize).append(" A.*, B.GRPNAME ")
                                 .append(" FROM TB_"+COMCODE+"_F10 A, TB_"+COMCODE+"_G10 B ")
                                 .append(" WHERE A.GRPNO *= B.GRPNO AND A.USERID="+genQuote(USERID)+" "+opt+" "+grpSql)
                                 .append(" ORDER BY "+sortList);
                         }

	               GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

                   if ("mssql".equals(strDbType))
                   {
                        rs.moveRecordPos((icurPage-1)*ipageSize);
                   }

                   return rs;
		}
		catch (Exception e)
		{
	 		System.out.println(" GCoCaCard::getCardPrivateList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

   /**
    * <PRE>
    * ���޵� ������ ������ �˻��Ͽ� ���θ��� ����Ʈ�� ������ ��������.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String USERID : current user id at session
    *                      <LI> String SortId : ������ �ʵ�
    *                      <LI> String SortOpt : �����ɼ�
    *                      <LI> String GrpNo : ���Ա׷��ȣ
    *                      <LI> String Opt : �˻�����
    *                      <LI> String Q : �˻���
    *                      <LI> String Sdate : �˻���������
    *                      <LI> String Ldate : �˻���������
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : �������� (N10.ORGNAME)
    */
	public GCmResultSet getRecordCount(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

       	    GCmConnection conn = null;
            String COMCODE = dmProp.getString("COMCODE");
            String USERID = dmProp.getString("USERID");
            String pCardNo = dmProp.getString("CARDNO");
            String pSortId = dmProp.getString("SortId");
	    String pSortOpt = dmProp.getString("SortOpt");
	    String pGrpNo = dmProp.getString("GrpNo");
	    String pOpt = dmProp.getString("Opt");
	    String pQ = dmProp.getString("Q");
	    String sdate = dmProp.getString("Sdate");
	    String ldate = dmProp.getString("Ldate");
            String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

            int nCnt = 1;
            String opt="";
            String grpSql="";
            String sqlstmt="";
            String sortList = "A."+ pSortId + " "+ pSortOpt ;

            try
	    {
	        conn = GCmDbManager.getInstance().getConnection();

                if (!pOpt.equals("") && (!pQ.equals("") || !sdate.equals("")))
                {
                    sdate = gplus.commlib.util.GCmFcts.replace(sdate,"/","");
                    ldate = gplus.commlib.util.GCmFcts.replace(ldate,"/","");
                    if (pOpt.toUpperCase().equals("REGDATE"))
                    {
                         if (!ldate.equals(""))
                         {
                             opt = " AND A." +pOpt+" BETWEEN '"+sdate+"000000' AND '"+ldate+"240000' ";
                         }
                         else
                             opt = " AND LOWER(A."+pOpt+") LIKE '"+sdate+"%' ";
                    }
                    else
                         opt = " AND LOWER(A."+pOpt+") LIKE '%" + pQ.toLowerCase() + "%' ";
                }

                if(!pGrpNo.equals(""))
                {
                    grpSql= " AND A.GRPNO = '"+pGrpNo+"' ";
                }

   		        StringBuffer sqlQuery = new StringBuffer();

                if ("oracle".equals(strDbType))
                {
                      sqlQuery
                        .append(" SELECT B.GRPNAME ")
                        .append(" FROM TB_"+COMCODE+"_F10 A, TB_"+COMCODE+"_G10 B ")
                        .append(" WHERE A.GRPNO = B.GRPNO(+) AND A.USERID="+genQuote(USERID)+" "+opt+" "+grpSql)
                        .append(" ORDER BY "+sortList);
                }
                else if ("mssql".equals(strDbType))
                {
                      sqlQuery
                        .append(" SELECT B.GRPNAME ")
                        .append(" FROM TB_"+COMCODE+"_F10 A, TB_"+COMCODE+"_G10 B ")
                        .append(" WHERE A.GRPNO *= B.GRPNO AND A.USERID="+genQuote(USERID)+" "+opt+" "+grpSql)
                        .append(" ORDER BY "+sortList);
                }

                GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
                      return rs;
            }
	    catch (Exception e)
	    {
                  System.out.println(" GCoCaCard::getRecordCount " + e.getMessage());
                  return null;
            }
	    finally
	    {
                  conn.close();
	    }
	}

	/**
	 * <PRE>
	 *  �����ּҷ� �̸�����Ʈ
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�    <BR>
	 *				<LI> String ADDRBOOKNO : �ּҷϹ�ȣ    <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return �˻������ �ش��ϴ� �����ּҷ� �̸��� ���� GCmResultSet
	 */

	public GCmResultSet getAddrBookUser(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strAddrBookNo = dmProp.getString("ADDRBOOKNO");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
							.append(" SELECT A.USERID, B.USERNAME FROM TB_").append(strComCode).append("_F31 A, TB_COMM_Z20 B ")
							.append(" WHERE A.ADDRBOOKNO = " + genQuote(strAddrBookNo))
							.append(" AND A.USERID = B.USERID ");

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		}
		catch (Exception e)
		{
	 		System.out.println("GCoCaCard  :: getAddrBookUser " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

	/**
	 * <PRE>
	 *  �����ּҷϸ���Ʈ
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�    <BR>
	 *				<LI> String USERID         : ����ڹ�ȣ    <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return �˻������ �ش��ϴ� �����ּҷ��� ���� GCmResultSet
	 */
 	 public GCmResultSet getAddrBookList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	 {
		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strUserId = dmProp.getString("USERID");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
							.append(" SELECT GRPNO, GRPNAME FROM TB_").append(strComCode).append("_G10 ")
							.append(" WHERE  GRPTYPE = '2' AND USERID = " + genQuote(strUserId));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		}
		catch (Exception e)
		{
		 	System.out.println("GCoCaCard :: getAddrBookList error" + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

	/**
	 * <PRE>
	 *  �ּҷϿ��� �����ּ� ����
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�    <BR>
	 *				<LI> String USERID     : ����ڹ�ȣ    <BR>
	 *				<LI> String NameK   : ������̸�     <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return �˻������ �ش��ϴ� �����ּҸ� ���� GCmResultSet
	 */
	public GCmResultSet getMailAddrDB(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strUserId = dmProp.getString("USERID");
		String strNameK = dmProp.getString("NameK");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
							.append(" SELECT NAMEK,EMAIL,EMAIL1,EMAIL2 FROM TB_").append(strComCode).append("_F10 ")
							.append(" WHERE USERID = " + genQuote(strUserId))
							.append(" AND NAMEK = " + genQuote(strNameK));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		}
		catch (Exception e)
		{
	 		System.out.println("GCoCaCard  :: getMailAddrDB error" + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

	/**
	 * <PRE>
	 *  �̸�<�����ּ�>���� �����ּ� ����
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String EMAIL    : ȸ���ڵ�    <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @String
	 */

	public String getMailAddr(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

		String strEmail = dmProp.getString("EMAIL");

		String sRet = "";
        int nLtPos = 0;
        int nGtPos = 0;
        sRet = strEmail;

		try
		{
	        nLtPos = sRet.indexOf("<");
		    if (nLtPos > 0)
			{
			    sRet = sRet.substring(nLtPos+1);
				nGtPos = sRet.indexOf(">");
	            if (nGtPos>0)
		            sRet = sRet.substring(0,nGtPos);
			}

            return sRet;
		}
		catch (Exception e)
		{
	 		System.out.println("GCoCaCard :: getMailAddr error" + e.getMessage());
		 	return null;
		}
	}

	/**
	 * <PRE>
	 *  �����׷쿡�� �����ּ� ����
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�    <BR>
	 *				<LI> String USERID     : ����ڹ�ȣ    <BR>
	 *				<LI> String GRPNAME    : �׷��̸�     <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return �˻������ �ش��ϴ� �����ּҸ� ���� GCmResultSet
	 */

	public GCmResultSet getGrpMail(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strUserId = dmProp.getString("USERID");
		String strGrpName = dmProp.getString("GRPNAME");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
							.append(" SELECT A.EMAIL,A.EMAIL1,A.EMAIL2 FROM TB_").append(strComCode).append("_F10 A ")
							.append(" WHERE A.USERID = " + genQuote(strUserId))
							.append(" AND A.GRPNO = (SELECT GRPNO FROM TB_").append(strComCode).append("_G10 ")
							.append(" WHERE GRPTYPE = '2' AND USERID = " + genQuote(strUserId)).append(" AND GRPNAME = " + genQuote(strGrpName));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		}
		catch (Exception e)
		{
	 		System.out.println("GCoCaCard  : getGrpMail error" + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

	/**
	 * <PRE>
	 *  ���� �ּҷ� ����Ʈ
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE    : ȸ���ڵ�    <BR>
	 *				<LI> String USERID         : ����ڹ�ȣ    <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return �˻������ �ش��ϴ� �����ּҷ��� ���� GCmResultSet
	 */
	public GCmResultSet getCardList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strUserId = dmProp.getString("USERID");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
							.append(" SELECT CARDNO,NAMEK,EMAIL,EMAIL1,EMAIL2 FROM TB_")
                                                        .append(strComCode)
                                                        .append("_F10 ")
							.append(" WHERE USERID = " + genQuote(strUserId));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		}
		catch (Exception e)
		{
	 		System.out.println("GCoCaCard :: getCardList error" + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

        /**
	 * <PRE>
	 *  ���� ������ ȸ���� ����Ʈ
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String CARDNO    : ���Թ�ȣ    <BR>
	 *				<LI> String USERID         : ����ڹ�ȣ    <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @return �˻������ �ش��ϴ� ���԰�������Ʈ�� ���� GCmResultSet
	 */

        public GCmResultSet getCardPublicNameList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
        {
              GCmConnection conn = null;
              String comcode = dmProp.getString("COMCODE");
              String strCardNo = dmProp.getString("CardNo");
              String strUserId = dmProp.getString("USERID");

              try
              {
                  conn = GCmDbManager.getInstance().getConnection();
                  /*
                  StringBuffer sqlQuery = new StringBuffer()
                                    .append("select username, userid ")
                                    .append("from tb_comm_z20 a, (select userid ")
                                    .append("from tb_"+comcode+"_f50 ")
                                    .append("where cardno = "+genQuote(strCardNo)+") b ")
                                    .append("where comcode = "+genQuote(comcode)+ " and a.userid = b.userid ");
                  */
                   StringBuffer sqlQuery = new StringBuffer()
                                        .append("select userid, username ")
                                        .append("from tb_comm_z20 ")
                                        .append("where userid in (select userid from tb_"+comcode+"_f50 ")
                                        .append("                 where cardno="+genQuote(strCardNo)+")")
                                        .append("and comcode="+genQuote(comcode));

                  GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

                  return rs;
              }
              catch(Exception e)
              {
                  System.out.println("GCoCaCard :: getCatdPublicNameList error:=" + e.getMessage());
                  return null;
              }
              finally
              {
                  conn.close();
              }
          }
	/**
	 * <PRE>
	 *  ���� ������Ȯ��(�����׷�����)
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE	: ȸ���ڵ�    <BR>
	 *				<LI> String USEID			: �����ID    <BR>
	 *				<LI> String GRPNAME    : �׷��    <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @GCmResultSet
	 */
	public GCmResultSet getCountGrpName(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strUserId = dmProp.getString("USERID");
		String strGrpName = dmProp.getString("GRPNAME");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
							.append(" SELECT COUNT(*) AS CNT FROM TB_").append(strComCode).append("_G10 ")
							.append(" WHERE GRPTYPE = '2' AND USERID = " + genQuote(strUserId))
							.append(" AND GRPNAME = " + genQuote(strGrpName));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		}
		catch (Exception e)
		{
	 		System.out.println("GCoCaCard  :: getCountGrpName error" + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}

	}

	/**
	 * <PRE>
	 *  �ּҷϿ� �ִ� �̸����� Ȯ��
	 * </PRE>
	 *
	 * @param cp	GCmProperties ��ü�� GPlus property�� ��� �ִ�.
	 * @param dmProp	GCmProperties ��ü
	 *				<�����׸� ����Ʈ>						<BR>
	 *				<TT><UL>
	 *				<LI> String COMCODE	: ȸ���ڵ�    <BR>
	 *				<LI> String USEID			: �����ID    <BR>
	 *				<LI> String NAMEK         :  �����ѱ��̸�   <BR>
	 *				</UL></TT>
	 * @param msgInfo 	Message�� �����ϴ� GCmMsgInfo ��ü�̴�.
	 * @GCmResultSet
	 */
	public GCmResultSet getCardDupName(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String strComCode = dmProp.getString("COMCODE");
		String strUserId = dmProp.getString("USERID");
		String strNameK = dmProp.getString("NAMEK");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
							.append(" SELECT CARDNO, NAMEK, EMAIL, EMAIL1, EMAIL2 FROM TB_").append(strComCode).append("_F10 ")
							.append(" WHERE USERID = " + genQuote(strUserId))
							.append(" AND NAMEK = " + genQuote(strNameK));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		}
		catch (Exception e)
		{
	 		System.out.println("GCoCaCard  : (getCardDupName error)" + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}

	}

}