package gplus.component.card;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;


/**
 * <PRE>
 * Filename		: GCoCaCardGroupTran.java
 * Class		: gplus.component.card.GCoCaCardGroup
 * Fuction		:
 * Comment		:
 * History      : 01/10/2002, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GCoCaCardGroupTran extends GCmTopComponent{

   /**
    * <PRE>
    *  ���޵� ����� �׷��� ����. 
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String USERID : current user id at session
    *                      <LI> String GRPNO : �׷��ڵ�
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : 
    */

	public int deleteCardGroup(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String GRPNO = dmProp.getString("GRPNO");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection(); 

			StringBuffer sqlQuery = new StringBuffer()
                            .append(" DELETE FROM TB_"+COMCODE+"_G10 WHERE GRPTYPE = '2' AND GRPNO="+GRPNO+" AND USERID="+genQuote(USERID));

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			  rv = stmt.executeUpdate(sqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoCaCardGroupTran::deleteCardGroup : " + ignored.getMessage());
			}

	 		System.out.println(" GCoCaCardGroupTran::deleteCardGroup : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoCaCardGroupTran::deleteCardGroup : " + e.getMessage());
			}
			conn.close();
		}
	}

   /**
    * <PRE>
    *  ���޵� ����� �׷��� ����
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String USERID : current user id at session
    *                      <LI> String GRPNAME : �׷��̸�
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : �׷� ����
    */

    public int insertCardGroup(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String GRPNAME = dmProp.getString("GRPNAME");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
                      String grpNo = getMaxNo(COMCODE,cp.getProperty("gplus.db.type"));
		      conn = GCmDbManager.getInstance().getConnection();

                      StringBuffer sqlQuery = new StringBuffer()
                                     .append(" INSERT INTO TB_"+COMCODE+"_G10 (GRPNO,GRPNAME,USERID,GRPTYPE) ")
                                     .append(" VALUES("+genQuote(grpNo)+","+genQuote(GRPNAME)+","+genQuote(USERID)+",'2')");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			  rv = stmt.executeUpdate(sqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoCaCardGroupTran::insertCardGroup : " + ignored.getMessage());
			}

	 		System.out.println(" GCoCaCardGroupTran::insertCardGroup : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoCaCardGroupTran::insertCardGroup : " + e.getMessage());
			}
			conn.close();
		}
	}

   /**
    * <PRE>
    *  �׷��ڵ� ��ȣ ����.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE   : current user companycode at session
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : MEETNO
    */
    	private String getMaxNo(String comcode,String strDbType)
    	{

		GCmConnection conn = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

            if ("oracle".equals(strDbType))
            {
                   sqlQuery
	          	      .append(" SELECT DECODE(SUBSTR(MAX(GRPNO),1,8),TO_CHAR(sysdate,'YYYYMMDD'),TO_CHAR(TO_NUMBER(MAX(GRPNO))+1),null,TO_CHAR(sysdate,'YYYYMMDD')||'0001') as NO ")
                      .append(" FROM TB_").append(comcode).append("_G10 ")
                      .append(" WHERE GRPNO LIKE TO_CHAR(sysdate,'YYYYMMDD')||'%'");
            }
            else if ("mssql".equals(strDbType))
                 {
                         sqlQuery
                            .append(" SELECT (CASE SUBSTRING(MAX(GRPNO),1,8) WHEN convert(char(08),getdate(),112) THEN CAST(SUBSTRING(MAX(GRPNO),1,8) AS varchar(8)) + RIGHT('0000'+CAST(SUBSTRING(MAX(GRPNO),9,4)+1 AS varchar(4)),4) ELSE convert(char(08),getdate(),112)+'0001' END) as NO ")
                            .append(" FROM TB_").append(comcode).append("_G10 ")
                            .append(" WHERE GRPNO LIKE convert(char(08),getdate(),112)+'%' ");
                 }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
            rs.next();

			return rs.getString("NO");

      		}
      		catch (Exception e)
      		{
 			System.out.println(" GCoCaCardGroupTran::getMaxNo " + e.getMessage());
	 		return null;
      		}
      		finally
      		{
			conn.close();
      		}
    	}

}

