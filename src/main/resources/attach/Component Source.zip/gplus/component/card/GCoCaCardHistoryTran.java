package gplus.component.card;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

/**
 * <PRE>
 * Filename		: GCoCaCardGroupHistoryTran.java
 * Class		: gplus.component.card.GCoCaCardGroup
 * Fuction		:
 * Comment		:
 * History      : 01/10/2002, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GCoCaCardHistoryTran extends GCmTopComponent {

   /**
    * <PRE>
    * ���� ���� ��ȣ�� ���� ���� ����.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String MeetNo : �׷��ڵ�
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : DELETE
    */

	public int deleteCardHistory(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String MeetNo = dmProp.getString("MeetNo");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
                                        .append(" DELETE FROM TB_").append(COMCODE).append("_F11 ")
                                        .append(" WHERE MEETNO IN ('"+gplus.commlib.util.GCmFcts.replace(MeetNo,",","','")+"') ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			  rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoCaCardHistory::deleteCardHistory : " + ignored.getMessage());
			}

	 		System.out.println(" GCoCaCardHistory::deleteCardHistory : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoCaCardHistory::deleteDraftLine : " + e.getMessage());
			}
			conn.close();
		}
	}

   /**
    * <PRE>
    * ���� ������  ���� ��� ���� ����.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String CardNo : �׷��ڵ�
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : ALL DELETE
    */


	public int deleteCardHistoryAll(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String CardNo = dmProp.getString("CardNo");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
                                        .append(" DELETE FROM TB_").append(COMCODE).append("_F11 ")
                                        .append(" WHERE CARDNO IN ('"+gplus.commlib.util.GCmFcts.replace(CardNo,",","','")+"') ");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			  rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoCaCardHistory::deleteCardHistoryAll : " + ignored.getMessage());
			}

	 		System.out.println(" GCoCaCardHistory::deleteCardHistoryAll : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoCaCardHistory::deleteCardHistoryAll : " + e.getMessage());
			}
			conn.close();
		}
	}



   /**
    * <PRE>
    * ���޵� ���� ������ ���� ���� ����.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE   : current user companycode at session
    *                      <LI> String USERID    : ����� ���̵�
    *                      <LI> String pCardNo   : �׷��ڵ�
    *                      <LI> String pComments : �޸�
    *                      <LI> String pRegdate  : ����� 
    *                      <LI> String pHH   : �ð�
    *                      <LI> String pMI   : ��
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : ALL DELETE
    */


	public int insertCardHistory(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String CardNo = dmProp.getString("pCardNo");
		String Comments = dmProp.getString("pComments");
		String Regdate =  dmProp.getString("pRegdate");
		String HH =  dmProp.getString("pHH");
		String MI =  dmProp.getString("pMI");
		String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

  	  try
   	   {

  	      conn = GCmDbManager.getInstance().getConnection();

              String meetNo = getMaxNo(COMCODE,strDbType);

              String meetDate = Regdate + HH + MI + "00";

              StringBuffer SqlQuery = new StringBuffer()
              .append(" INSERT INTO TB_").append(COMCODE).append("_F11 (MEETNO,CARDNO,USERID,MEETDATE,COMMENTS) ")
              .append(" VALUES( "+genQuote(meetNo)+","+genQuote(CardNo)+","+genQuote(USERID)+","+genQuote(meetDate)+","+genQuote(Comments)+")");

 	      stmt = conn.createStatement();
	      conn.setAutoCommit(false);

	      rv = stmt.executeUpdate(SqlQuery.toString());
	      conn.commit();

 	      return rv;

	      }	catch (Exception e) {

			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoCaCardHistoryTran::insertCardHistory : " + ignored.getMessage());
			}

	 		System.out.println(" GCoCaCardHistoryTran::insertCardHistory : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoCaCardHistoryTran::insertCardHistory : " + e.getMessage());
			}
			conn.close();
		}
	}

   /**
    * <PRE>
    * ���޵� ���� ������ ���� ���� ����.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE   : current user companycode at session
    *                      <LI> String USERID    : ����� ���̵�
    *                      <LI> String pCardNo   : �׷��ڵ�
    *                      <LI> String pComments : �޸�
    *                      <LI> String pRegdate  : ����� 
    *                      <LI> String pHH   : �ð�
    *                      <LI> String pMI   : ��
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : ALL DELETE
    */

	public int updateCardHistory(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
                String USERID = dmProp.getString("USERID");
                String CardNo = dmProp.getString("pCardNo");
                String Comments = dmProp.getString("pComments");
                String Regdate =  dmProp.getString("pRegdate");
                String HH =  dmProp.getString("pHH");
                String MI =  dmProp.getString("pMI");
                String MeetNo =  dmProp.getString("pMeetNo");

                String meetDate = Regdate + HH + MI + "00";

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
		            .append(" UPDATE TB_"+COMCODE+"_F11 ")
                            .append(" SET USERID="+genQuote(USERID)+",MEETDATE="+genQuote(meetDate)+",COMMENTS="+genQuote(Comments))
                            .append(" WHERE CARDNO="+genQuote(CardNo)+" AND MEETNO="+genQuote(MeetNo));

			stmt = conn.createStatement();
 			conn.setAutoCommit(false);
 		           rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println("GCoCaCardHistoryTran ::updateCardHistory : " + ignored.getMessage());
			}

	 		System.out.println(" GCoCaCardHistoryTran::updateCardHistory : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoCaCardHistoryTran::updatePosCode : " + e.getMessage());
			}
			conn.close();
		}
    	}


   /**
    * <PRE>
    *  ���� ���� ��ȣ ����.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE   : current user companycode at session
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : MEETNO
    */
    	private String getMaxNo(String comcode,String strDbType)
    	{

		GCmConnection conn = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                           sqlQuery
			        	      .append(" SELECT DECODE(SUBSTR(MAX(MEETNO),1,8),TO_CHAR(sysdate,'YYYYMMDD'),TO_CHAR(TO_NUMBER(MAX(MEETNO))+1),null,TO_CHAR(sysdate,'YYYYMMDD')||'0001') as NO ")
                              .append(" FROM TB_").append(comcode).append("_F11 ")
                              .append(" WHERE MEETNO LIKE TO_CHAR(sysdate,'YYYYMMDD')||'%'");
                        }
                        else if ("mssql".equals(strDbType))
                             {
                                     sqlQuery
                                        .append(" SELECT (CASE SUBSTRING(MAX(MEETNO),1,8) WHEN convert(char(08),getdate(),112) THEN CAST(SUBSTRING(MAX(MEETNO),1,8) AS varchar(8)) + RIGHT('0000'+CAST(SUBSTRING(MAX(MEETNO),9,4)+1 AS varchar(4)),4) ELSE convert(char(08),getdate(),112)+'0001' END) as NO ")
                                        .append(" FROM TB_").append(comcode).append("_F11 ")
                                        .append(" WHERE MEETNO LIKE convert(char(08),getdate(),112)+'%' ");
                             }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
                	rs.next();

			return rs.getString("NO");

      		}
      		catch (Exception e)
      		{
 			System.out.println(" GCoCaCardHistoryTran::getMaxNo " + e.getMessage());
	 		return null;
      		}
      		finally
      		{
			conn.close();
      		}
    	}

}