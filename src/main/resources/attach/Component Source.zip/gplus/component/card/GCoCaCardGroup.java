package gplus.component.card;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.entitymodel.*;

/**
 * <PRE>
 * Filename		: GCoCaCardGroup.java
 * Class		: gplus.component.pos.GCoCaCardGroup
 * Fuction		:
 * Comment		:
 * History      : 01/10/2002, rjman, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCoCaCardGroup  extends GCmTopComponent {

   /**
    * <PRE>
    * ���޵� ���Թ�ȣ�� ������ ���Ը�ϰ� ���Ա׷����� �ǵ��� �ش�.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String USERID : current user id at session
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : �������� (GRPNO, GRPNAME, ORGNAME )
    */

	public GCmResultSet getCardGrpList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT GRPNO, GRPNAME, USERID ")
                           .append(" FROM TB_"+COMCODE+"_G10 ")
                           .append(" WHERE GRPTYPE = '2' AND USERID="+genQuote(USERID))
                           .append(" ORDER BY GRPNAME");

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		}
		catch (Exception e)
		{
	 		System.out.println(" GCoCaCardGroup::getCardGrpList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}


   /**
    * <PRE>
    * ���޵� ���Թ�ȣ�� ������ ���Ը�ϰ� ���Ա׷����� �ǵ��� �ش�.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String USERID : current user id at session
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : �������� (GRPNO, GRPNAME, ORGNAME )
    */

	public GCmResultSet getMailCardGrpList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT T1.GRPNO, T1.GRPNAME, T2.USERID ")
                           .append(" FROM TB_"+COMCODE+"_G10 T1, TB_"+COMCODE+"_F10 T2 ")
                           .append(" WHERE T1.GRPNO = T2.GRPNO AND T1.GRPTYPE = '2' AND T2.USERID = "+genQuote(USERID))
                           .append(" ORDER BY T1.GRPNAME ");

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		}
		catch (Exception e)
		{
	 		System.out.println(" GCoCaCardGroup::getCardGrpList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}


   /**
    * <PRE>
    * ���޵� �׷��� ����� �� ���.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String USERID : current user id at session
    *                      <LI> String GRPNO : �׷��ڵ� 
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet :  �׷��� ����� �� ��� 
    */

	public GCmResultSet getGrpUsed(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{

		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String GRPNO = dmProp.getString("GRPNO");

    		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()

                           .append(" SELECT GRPNO ")
                           .append(" FROM TB_"+COMCODE+"_F10 ")
                           .append(" WHERE USERID="+genQuote(USERID)+" AND GRPNO="+genQuote(GRPNO));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
			return rs;
		}
		catch (Exception e)
		{
	 		System.out.println(" GCoCaCardGroup::getGrpUsed " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}


   /**
    * <PRE>
    * �ߺ��� �׷���� üũ.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String USERID : current user id at session
    *                      <LI> String GRPNAME : �׷��̸�
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet :  �ߺ��� �׷���� �ִ��� Ȯ��.
    */

	public GCmResultSet getGrpNameDup(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String GRPNAME = dmProp.getString("GRPNAME");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                         .append(" SELECT GRPNAME ")
                         .append(" FROM TB_"+COMCODE+"_G10 ")
                         .append(" WHERE GRPTYPE = '2' AND GRPNAME="+genQuote(GRPNAME)+" AND USERID="+genQuote(USERID));
 
                        GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoCaCardGroup::getGrpNameDup " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}


} // class end