package gplus.component.card;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;
import gplus.commlib.util.GCmFcts;

/**
 * <PRE>
 * Filename		: GCoCaCardGroupTran.java
 * Class		: gplus.component.card.GCoCaCardGroup
 * Fuction		:
 * Comment		:
 * History      : 01/10/2002, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCoCaCardTran extends GCmTopComponent{

   /**
    * <PRE>
    * ���޵� ������ ���Ͽ� ���� ����� ������.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : ���� ��� ����
    */

    public int insertCard(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
                String USERID = dmProp.getString("USERID");
                String LIST = dmProp.getString("LIST");
                GEmTB_F10 tbf10 = (GEmTB_F10)dmProp.getObject("tbf10");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;
                java.util.Vector vList = new java.util.Vector();

		try
		{
                      String cardNo = getMaxCardNo(COMCODE,cp.getProperty("gplus.db.type"));
                      conn = GCmDbManager.getInstance().getConnection();

                      StringBuffer sqlQuery = new StringBuffer()
                              .append(" INSERT INTO TB_"+COMCODE+"_F10 (CARDNO, USERID, GRPNO, NAMEK, NAMEE, NAMEC,SEX, COMNAME, DEPTNAME,BIRTHDAY,ZIPCODE,ADDR,POSNAME, LUNARFLAG,TELHOME,TELOFFICE,TELWORK,MOBILE,PAGER,HOMEPAGE,TELFAX, ")
                              .append("         EMAIL, COMMENTS, EMAIL1, EMAIL2,  PUBFLAG, REGDATE ) ")
                              .append(" VALUES("+genQuote(cardNo)+","+genQuote(USERID)+","+genQuote(tbf10.getStrGrpNo())+","+genQuote(tbf10.getStrNameK())+","+genQuote(tbf10.getStrNameE())+","+genQuote(tbf10.getStrNameC())+",")
                              .append("        "+genQuote(tbf10.getStrSex())+","+genQuote(tbf10.getStrComName())+","+genQuote(tbf10.getStrDeptName())+","+genQuote(tbf10.getStrBirthDay())+","+genQuote(tbf10.getStrZipCode())+","+genQuote(tbf10.getStrAddr())+",")
                              .append("        "+genQuote(tbf10.getStrPosName())+","+genQuote(tbf10.getStrLunarFlag())+","+genQuote(tbf10.getStrTelHome())+","+genQuote(tbf10.getStrTelOffice())+","+genQuote(tbf10.getStrTelWork())+","+genQuote(tbf10.getStrMobile())+",")
                              .append("        "+genQuote(tbf10.getStrPager())+","+genQuote(tbf10.getStrHomePage())+","+genQuote(tbf10.getStrTelFax())+","+genQuote(tbf10.getStrEmail())+","+genQuote(tbf10.getStrComments())+","+genQuote(tbf10.getStrEmail1())+",")
                              .append("        "+genQuote(tbf10.getStrEmail2())+","+genQuote(tbf10.getStrPubFlag())+","+genQuote(tbf10.getStrRegDate())+" )");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			rv = stmt.executeUpdate(sqlQuery.toString());



                        try
                        {
                            vList = gplus.commlib.util.GCmFcts.getSplit(LIST,",");
                            StringBuffer sqlQuery1 = null;

                            for(int i=0; i<vList.size(); i++)
                            {
                                String sList = (String)vList.elementAt(i);
                                sqlQuery1 = new StringBuffer()
                                         .append("insert into tb_"+COMCODE+"_f50 (CARDNO, USERID) ")
                                         .append(" VALUES("+genQuote(cardNo)+","+genQuote(sList)+")");
                                stmt = conn.createStatement();
                                conn.setAutoCommit(false);
                                rv = stmt.executeUpdate(sqlQuery1.toString());

                            }
                        }
                        catch (SQLException e)
                        {
                            System.out.println("insertCard public list : " + e.getMessage());
                        }


			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoCaCardTran::insertCard : " + ignored.getMessage());
			}

	 		System.out.println(" GCoCaCardTran::insertCard : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoCaCardTran::insertCard : " + e.getMessage());
			}
			conn.close();
		}
	}




/**
    * <PRE>
    * ���޵� ������ ���Ͽ� ���� ����� ������.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : ���� ��� ����
    */

    public int insertCopyCard(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
    {
            String COMCODE = dmProp.getString("COMCODE");
            String USERID = dmProp.getString("USERID");
            GEmTB_F10 tbf10 = (GEmTB_F10)dmProp.getObject("tbf10");
            String NameList = dmProp.getString("NameList");
            String CardList = dmProp.getString("CardList");

            int rv = 0;

	    GCmConnection conn = null;
	    Statement stmt = null;
            GCmResultSet rs = null;

            java.util.Vector vCardList = new java.util.Vector();
            java.util.Vector vNameList = new java.util.Vector();

            try
            {
  	        conn = GCmDbManager.getInstance().getConnection();
                conn.setAutoCommit(true);

                stmt = conn.createStatement();

                vCardList = gplus.commlib.util.GCmFcts.getSplit(CardList,",");
                vNameList = gplus.commlib.util.GCmFcts.getSplit(NameList,",");
                StringBuffer sqlQuery = null;
                int count=0;
                for(int i=0; i<vCardList.size(); i++)
                {
                    String sCardList = (String)vCardList.elementAt(i);

                    //for���� ���鼭 tb_f10���̺��κ��� ������ ������ ������ select�Ѵ�.
                    sqlQuery = new StringBuffer()
                            .append("SELECT GRPNO, NAMEK, NAMEE, NAMEC, COMNAME, DEPTNAME, POSNAME, SEX, BIRTHDAY, LUNARFLAG, ZIPCODE, ADDR, MOBILE, PAGER, TELOFFICE, TELWORK, TELHOME, TELFAX, HOMEPAGE, EMAIL, EMAIL1, EMAIL2, COMMENTS, PUBFLAG, REGDATE ")
                            .append("FROM TB_"+COMCODE+"_F10 ")
                            .append("WHERE CARDNO ="+genQuote(sCardList));

                    rs = conn.executeQuery(sqlQuery.toString());

                    rs.next();

                    //entitybean�� �� ����
                    tbf10.setStrGrpNo(rs.getString("GRPNO"));
                    tbf10.setStrNameK(rs.getString("NAMEK"));
                    tbf10.setStrNameE(rs.getString("NAMEE"));
                    tbf10.setStrNameC(rs.getString("NAMEC"));
                    tbf10.setStrComName(rs.getString("COMNAME"));
                    tbf10.setStrDeptName(rs.getString("DEPTNAME"));
                    tbf10.setStrPosName(rs.getString("POSNAME"));
                    tbf10.setStrSex(rs.getString("SEX"));
                    tbf10.setStrBirthDay(rs.getString("BIRTHDAY"));
                    tbf10.setStrLunarFlag(rs.getString("LUNARFLAG"));
                    tbf10.setStrZipCode(rs.getString("ZIPCODE"));
                    tbf10.setStrAddr(rs.getString("ADDR"));
                    tbf10.setStrMobile(rs.getString("MOBILE"));
                    tbf10.setStrPager(rs.getString("PAGER"));
                    tbf10.setStrTelOffice(rs.getString("TELOFFICE"));
                    tbf10.setStrTelWork(rs.getString("TELWORK"));
                    tbf10.setStrTelHome(rs.getString("TELHOME"));
                    tbf10.setStrTelFax(rs.getString("TELFAX"));
                    tbf10.setStrHomePage(rs.getString("HOMEPAGE"));
                    tbf10.setStrEmail(rs.getString("EMAIL"));
                    tbf10.setStrEmail1(rs.getString("EMAIL1"));
                    tbf10.setStrEmail2(rs.getString("EMAIL2"));
                    tbf10.setStrComments(rs.getString("COMMENTS"));
                    tbf10.setStrPubFlag(rs.getString("PUBFLAG"));
                    tbf10.setStrRegDate(rs.getString("REGDATE"));


                    for(int k=0; k<vNameList.size(); k++){
                        String cardNo = getMaxCardNo(COMCODE,cp.getProperty("gplus.db.type"));
                        String sNameList = (String)vNameList.elementAt(k);

                        //������ ī�带 �����ϴ� insert(���� ��Ͽ� copierid�� �����ϴ� ����� ����, copydate�� �߰��Ǿ� insert��)
                        sqlQuery = new StringBuffer()
                                .append(" INSERT INTO TB_"+COMCODE+"_F10 (CARDNO, USERID, GRPNO, NAMEK, NAMEE, NAMEC, COMNAME, DEPTNAME, POSNAME, SEX, BIRTHDAY, LUNARFLAG, ZIPCODE, ADDR, MOBILE, PAGER, TELOFFICE, TELWORK, TELHOME, TELFAX, HOMEPAGE, ")
                                .append("         EMAIL, EMAIL1, EMAIL2, COMMENTS, PUBFLAG, REGDATE, COPIERID, COPYDATE ) ")
                                .append(" VALUES("+genQuote(cardNo)+","+genQuote(sNameList)+","+genQuote(tbf10.getStrGrpNo())+","+genQuote(tbf10.getStrNameK())+","+genQuote(tbf10.getStrNameE())+","+genQuote(tbf10.getStrNameC())+",")
                                .append("        "+genQuote(tbf10.getStrComName())+","+genQuote(tbf10.getStrDeptName())+","+genQuote(tbf10.getStrPosName())+","+genQuote(tbf10.getStrSex())+","+genQuote(tbf10.getStrBirthDay())+","+genQuote(tbf10.getStrLunarFlag())+",")
                                .append("        "+genQuote(tbf10.getStrZipCode())+","+genQuote(tbf10.getStrAddr())+","+genQuote(tbf10.getStrMobile())+","+genQuote(tbf10.getStrPager())+","+genQuote(tbf10.getStrTelOffice())+","+genQuote(tbf10.getStrTelWork())+",")
                                .append("        "+genQuote(tbf10.getStrTelHome())+","+genQuote(tbf10.getStrTelFax())+","+genQuote(tbf10.getStrHomePage())+","+genQuote(tbf10.getStrEmail())+","+genQuote(tbf10.getStrEmail1())+","+genQuote(tbf10.getStrEmail2())+",")
                                .append("        "+genQuote(tbf10.getStrComments())+","+genQuote(tbf10.getStrPubFlag())+","+genQuote(tbf10.getStrRegDate())+","+genQuote(USERID)+","+genQuote(tbf10.getStrRegDate())+" )");

                        rv = stmt.executeUpdate(sqlQuery.toString());

                        //�����Ϸ��� ���Կ� �������� select�ϱ�
                        sqlQuery = new StringBuffer()
                                .append("select a.cardno, meetno, meetdate, comments ")
                                .append("from tb_"+COMCODE+"_f11 a, (select userid, cardno ")
                                .append("                      from tb_"+COMCODE+"_f10 ")
                                .append("                      where cardno = "+genQuote(sCardList))
                                .append("                      and userid="+genQuote(USERID)+") b ")
                                .append("where a.userid = b.userid ")
                                .append("and a.cardno = b.cardno");
                        rs = conn.executeQuery(sqlQuery.toString());

                        while(rs.next())
                        {
                        /*
                            ���Կ����� ���� ���
                            select���� ī��Ʈ�Ѵ�.getRowCount()�޼ҵ带 ����Ͽ�...
                            for���� ����Ͽ� ī��Ʈ��ŭ �μ�Ʈ�Ѵ�.(meetno�� primary key�̰� ī���ȣ�� �״�� ����ϰ�
                            ����� ���̵� �����Ϸ��� ��������Ͽ� �ִ´�.)
                        */

                            String maxMeetNo =getMaxMeetNo(COMCODE,cp.getProperty("gplus.db.type"));

                            sqlQuery = new StringBuffer()
                                        .append("INSERT INTO TB_"+COMCODE+"_F11 (MEETNO, CARDNO, USERID, MEETDATE, COMMENTS) ")
                                        .append("VALUES("+genQuote(maxMeetNo)+","+genQuote(cardNo)+","+genQuote(sNameList)+",")
                                        .append("       "+genQuote(rs.getString("MEETDATE"))+","+genQuote(rs.getString("COMMENTS"))+")");

                            rv = stmt.executeUpdate(sqlQuery.toString());
                        }//while end
                    }//for end
                }//for end
                return rv;

            }
	    catch (Exception e)
	    {
	    	try
		{
	            conn.rollback();
		}
		catch (SQLException ignored)
		{
                    System.out.println(" GCoCaCardTran::insertCopyCard ::: " + ignored.getMessage());
                }

	 	System.out.println(" GCoCaCardTran::insertCopyCard : " + e.getMessage());

		return -1;
            }
            finally
	    {
		try
		{
	            stmt.close();
		}
		catch (SQLException e)
		{
		    System.out.println(" GCoCaCardTran::insertCopyCard : " + e.getMessage());
		}

                conn.close();
            }
    }



   /**
    * <PRE>
    * ���޵� ������ ���Ͽ� ���� ����� ������.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : ���� ��� ����
    */

	public int updateCard(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
                String COMCODE = dmProp.getString("COMCODE");
                String USERID = dmProp.getString("USERID");
		GEmTB_F10 tbf10 = (GEmTB_F10)dmProp.getObject("tbf10");
		String LIST = dmProp.getString("LIST");
                int rv;
          	GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			String cardNo = getMaxCardNo(COMCODE,cp.getProperty("gplus.db.type"));
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                                     .append(" UPDATE TB_"+COMCODE+"_F10 ")
                                     .append(" SET GRPNO="+genQuote(tbf10.getStrGrpNo())+", NAMEK="+genQuote(tbf10.getStrNameK())+",NAMEE="+genQuote(tbf10.getStrNameE())+", ")
                                     .append("     NAMEC="+genQuote(tbf10.getStrNameC())+",SEX="+genQuote(tbf10.getStrSex())+",COMNAME="+genQuote(tbf10.getStrComName())+", ")
                                     .append("     DEPTNAME="+genQuote(tbf10.getStrDeptName())+",BIRTHDAY="+genQuote(tbf10.getStrBirthDay())+",ZIPCODE="+genQuote(tbf10.getStrZipCode())+", ")
                                     .append("     ADDR="+genQuote(tbf10.getStrAddr())+",POSNAME="+genQuote(tbf10.getStrPosName())+",LUNARFLAG="+genQuote(tbf10.getStrLunarFlag())+", ")
                                     .append("     TELHOME="+genQuote(tbf10.getStrTelHome())+",TELOFFICE="+genQuote(tbf10.getStrTelOffice())+",TELWORK="+genQuote(tbf10.getStrTelWork())+", ")
                                     .append("     MOBILE="+genQuote(tbf10.getStrMobile())+",PAGER="+genQuote(tbf10.getStrPager())+",HOMEPAGE="+genQuote(tbf10.getStrHomePage())+", ")
                                     .append("     TELFAX="+genQuote(tbf10.getStrTelFax())+",EMAIL="+genQuote(tbf10.getStrEmail())+",COMMENTS="+genQuote(tbf10.getStrComments())+", ")
                                     .append("     EMAIL1="+genQuote(tbf10.getStrEmail1())+",EMAIL2="+genQuote(tbf10.getStrEmail2())+",PUBFLAG="+genQuote(tbf10.getStrPubFlag())+", ")
                                     .append("     REGDATE="+genQuote(tbf10.getStrRegDate()))
                                     .append(" WHERE CARDNO = "+genQuote(tbf10.getStrCardNo()));

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
                 	rv = stmt.executeUpdate(sqlQuery.toString());

                        java.util.Vector v1= new java.util.Vector();
                        v1 = gplus.commlib.util.GCmFcts.getSplit(LIST,",");
                        try
                        {
                            StringBuffer sqlQuery1 = new StringBuffer()
                                  .append("delete from tb_"+COMCODE+"_f50 where cardno = "+genQuote(tbf10.getStrCardNo()));

                            stmt = conn.createStatement();
                            conn.setAutoCommit(false);
                            rv=stmt.executeUpdate(sqlQuery1.toString());

                        }
                        catch(SQLException e)
                        {
                            System.out.println(e.getMessage());
                        }

                        for(int i=0; i<v1.size(); i++)
                        {
                            String sV = (String)v1.elementAt(i);
                            dmProp.setProperty("USERId",sV);
                            dmProp.setProperty("CardNo",tbf10.getStrCardNo());

                            sqlQuery = new StringBuffer()
                                    .append(" insert into TB_"+COMCODE+"_F50 (CardNo,UserId) values( "+genQuote(tbf10.getStrCardNo())+","+genQuote(sV)+")" );

                            rv = stmt.executeUpdate(sqlQuery.toString());

                        }

                        conn.commit();
                        return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoCaCardTran::updateCard : " + ignored.getMessage());
			}

	 		System.out.println(" GCoCaCardTran::updateCard : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoCaCardTran::updateCard : " + e.getMessage());
			}
			conn.close();
		}
	}

   /**
    * <PRE>
    * ���޵� ������ ���Ͽ� ���� ����� ������.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE : current user companycode at session
    *                      <LI> String USERID  : ����� ���̵�
    *                      <LI> String CardNo  : ���Թ�ȣ
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : ���� ��� ����
    */

	public int deleteCard(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String CardNo = dmProp.getString("CardNo");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
                                        .append(" DELETE FROM TB_").append(COMCODE).append("_F10 ")
                                        .append(" WHERE CARDNO IN ('"+gplus.commlib.util.GCmFcts.replace(CardNo,",","','")+"') AND USERID="+genQuote(USERID));

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			  rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoCaCard::deleteCard : " + ignored.getMessage());
			}

	 		System.out.println(" GCoCaCard::deleteCard : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (SQLException e)
			{
		 		System.out.println(" GCoCaCard::deleteCard : " + e.getMessage());
			}
			conn.close();
		}
	}

   /**
    * <PRE>
    *  ���� ��ȣ ����.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE   : current user companycode at session
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : MEETNO
    */
    	private String getMaxCardNo(String comcode,String strDbType)
    	{

		GCmConnection conn = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                           sqlQuery
	          	              .append(" SELECT DECODE(SUBSTR(MAX(CARDNO),1,8),TO_CHAR(sysdate,'YYYYMMDD'),TO_CHAR(TO_NUMBER(MAX(CARDNO))+1),null,TO_CHAR(sysdate,'YYYYMMDD')||'0001') as NO ")
                              .append(" FROM TB_").append(comcode).append("_F10 ")
                              .append(" WHERE CARDNO LIKE TO_CHAR(sysdate,'YYYYMMDD')||'%'");
                        }
                        else if ("mssql".equals(strDbType))
                             {
                                     sqlQuery
                                        .append(" SELECT (CASE SUBSTRING(MAX(CARDNO),1,8) WHEN convert(char(08),getdate(),112) THEN CAST(SUBSTRING(MAX(CARDNO),1,8) AS varchar(8)) + RIGHT('0000'+CAST(SUBSTRING(MAX(CARDNO),9,4)+1 AS varchar(4)),4) ELSE convert(char(08),getdate(),112)+'0001' END) as NO ")
                                        .append(" FROM TB_").append(comcode).append("_F10 ")
                                        .append(" WHERE CARDNO LIKE convert(char(08),getdate(),112)+'%' ");
                             }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
                	rs.next();

			return rs.getString("NO");

      		}
      		catch (Exception e)
      		{
 			System.out.println(" GCoCaCardTran::getMaxCardNo " + e.getMessage());
	 		return null;
      		}
      		finally
      		{
			conn.close();
      		}
    	}

/**
    * <PRE>
    *  ���� ���� ��ȣ ����.
    * </PRE>
    *
    * @param cp      a GCmProperties holding gplus groupware properties.
    * @param dmProp    GCmProperties
    *                  <UL>relevant fields.
    *                      <LI> String COMCODE   : current user companycode at session
    *                  </UL>
    * @param msgInfo   a GCmMsgInfo holding error codes.
    * @return          GCmResultSet : MEETNO
    */
    	private String getMaxMeetNo(String comcode,String strDbType)
    	{

		GCmConnection conn = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                           sqlQuery
			      .append(" SELECT DECODE(SUBSTR(MAX(MEETNO),1,8),TO_CHAR(sysdate,'YYYYMMDD'),TO_CHAR(TO_NUMBER(MAX(MEETNO))+1),null,TO_CHAR(sysdate,'YYYYMMDD')||'0001') as NO ")
                              .append(" FROM TB_").append(comcode).append("_F11 ")
                              .append(" WHERE MEETNO LIKE TO_CHAR(sysdate,'YYYYMMDD')||'%'");
                        }
                        else if ("mssql".equals(strDbType))
                             {
                                     sqlQuery
                                        .append(" SELECT (CASE SUBSTRING(MAX(MEETNO),1,8) WHEN convert(char(08),getdate(),112) THEN CAST(SUBSTRING(MAX(MEETNO),1,8) AS varchar(8)) + RIGHT('0000'+CAST(SUBSTRING(MAX(MEETNO),9,4)+1 AS varchar(4)),4) ELSE convert(char(08),getdate(),112)+'0001' END) as NO ")
                                        .append(" FROM TB_").append(comcode).append("_F11 ")
                                        .append(" WHERE MEETNO LIKE convert(char(08),getdate(),112)+'%' ");
                             }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
                	rs.next();

			return rs.getString("NO");

      		}
      		catch (Exception e)
      		{
 			System.out.println(" GCoCaCardHistoryTran::getMaxMeetNo " + e.getMessage());
	 		return null;
      		}
      		finally
      		{
			conn.close();
      		}
    	}


}

