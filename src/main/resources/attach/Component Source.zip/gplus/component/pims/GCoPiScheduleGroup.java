package gplus.component.pims;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;


/**
 * <PRE>
 * Filename		: CCoPimsSchdl.java
 * Class		: gplus.component.pims.CCoPimsSchdl
 * Fuction		: ����� ������������ ��ȸ�Ѵ�.
 * Comment		:
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCoPiScheduleGroup extends GCmTopComponent
{

       /**
        * <PRE>
        * ����ڿ� ���� �׷����� ����Ʈ.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : ����� ���̵�        
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */	

   	public GCmResultSet getScheduleGroupList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT GRPNO,GRPNAME,USERID,GRPCOLOR  ")
                           .append(" FROM TB_").append(COMCODE).append("_G10 ")
                           .append(" WHERE  GRPTYPE = '1' AND USERID = "+genQuote(USERID))
                           .append(" ORDER BY GRPNAME ");

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoPiScheduleGroup::getScheduleGroupList " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}


       /**
        * <PRE>
        * ����ڿ� ���� �׷�����.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : ����� ���̵�        
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
        
   	public GCmResultSet getScheduleGroupInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String Grpno = dmProp.getString("Grpno");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();
 
			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT GRPNO,GRPNAME,USERID,GRPCOLOR ")
                           .append(" FROM TB_").append(COMCODE).append("_G10 ")
                           .append(" WHERE GRPTYPE = '1' AND GRPNO = "+genQuote(Grpno)+" AND USERID = "+genQuote(USERID))
                           .append(" ORDER BY GRPNAME ");

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoPiScheduleGroup::getScheduleGroupInfo " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}



}