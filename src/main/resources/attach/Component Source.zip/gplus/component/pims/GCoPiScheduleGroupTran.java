
package gplus.component.pims;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

/**
 * <PRE>
 * Filename		: CCoPimsSchdlTran.java
 * Class		: gplus.component.common.CCoPimsSchdlTran
 * Fuction		: ���� ���������� ��ȸ �� ���� �Ѵ�.
 * Comment		:
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCoPiScheduleGroupTran extends GCmTopComponent
{
       /**
        * <PRE>
        * ���������� ��Ͽ� �ش� ������� ������ȣ�� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : current user id at session : �����
        *                      <LI> EntityModel tbz20 : getStrOrgNo ������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int insertScheduleGroup(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String Grpname = dmProp.getString("Grpname");
		String Grpcolor = dmProp.getString("Grpcolor");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
                        String grpno = getMaxNo(COMCODE,strDbType);

			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" INSERT INTO TB_").append(COMCODE).append("_G10 (GRPNO,GRPNAME,GRPCOLOR,USERID,GRPTYPE) ")
                                        .append(" VALUES("+genQuote(grpno)+","+genQuote(Grpname)+","+genQuote(Grpcolor)+","+genQuote(USERID)+",'1')");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			   rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoPiScheduleGroupTran::insertScheduleGroup " + ignored.getMessage());
			}

	 		System.out.println(" GCoPiScheduleGroupTran::insertScheduleGroup " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoPiScheduleGroupTran::insertScheduleGroup " + e.getMessage());
			}
			conn.close();
		}
	}


       /**
        * <PRE>
        * ���������� ��Ͽ� �ش� ������� ������ȣ�� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : current user id at session : �����
        *                      <LI> EntityModel tbz20 : getStrOrgNo ������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteScheduleGroup(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String Grpno = dmProp.getString("Grpno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" DELETE FROM TB_").append(COMCODE).append("_G10 ")
                                        .append(" WHERE GRPNO = "+genQuote(Grpno)+"  AND GRPTYPE = '1' AND USERID= "+genQuote(USERID));

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
                        rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoPiScheduleGroupTran::deleteScheduleGroup " + ignored.getMessage());
			}

	 		System.out.println(" GCoPiScheduleGroupTran::deleteScheduleGroup " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoPiScheduleGroupTran::deleteScheduleGroup " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���������� ��Ͽ� �ش� ������� ������ȣ�� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : current user id at session : �����
        *                      <LI> EntityModel tbz20 : getStrOrgNo ������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int updateScheduleGroup(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String Grpname = dmProp.getString("Grpname");
		String Grpcolor = dmProp.getString("Grpcolor");
		String Grpno = dmProp.getString("Grpno");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" UPDATE TB_").append(COMCODE).append("_G10 ")
                                        .append(" SET GRPNAME = "+genQuote(Grpname)+",GRPCOLOR = "+genQuote(Grpcolor))
                                        .append(" WHERE GRPTYPE = '1' AND GRPNO = "+genQuote(Grpno));

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoPiScheduleGroupTran::updateScheduleGroup " + ignored.getMessage());
			}

	 		System.out.println(" GCoPiScheduleGroupTran::updateScheduleGroup " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoPiScheduleGroupTran::updateScheduleGroup " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        *  �׷��ڵ� ��ȣ.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */

     private String getMaxNo(String comcode,String strDbType)
     {
	GCmConnection conn = null;

	try
	{
		conn = GCmDbManager.getInstance().getConnection();

		StringBuffer sqlQuery = new StringBuffer();

                if ("oracle".equals(strDbType))
                {
                      sqlQuery
	                     .append(" SELECT DECODE(SUBSTR(MAX(GRPNO),1,8),TO_CHAR(sysdate,'YYYYMMDD'),TO_CHAR(TO_NUMBER(MAX(GRPNO))+1),null,TO_CHAR(sysdate,'YYYYMMDD')||'0001') as NO ")
                             .append(" FROM TB_").append(comcode).append("_G10 ")
                             .append(" WHERE GRPNO LIKE TO_CHAR(sysdate,'YYYYMMDD')||'%'");
                }
                else if ("mssql".equals(strDbType))
                {
                      sqlQuery
                             .append(" SELECT (CASE SUBSTRING(MAX(GRPNO),1,8) WHEN convert(char(08),getdate(),112) THEN CAST(SUBSTRING(MAX(GRPNO),1,8) AS varchar(8)) + RIGHT('0000'+CAST(SUBSTRING(MAX(GRPNO),9,4)+1 AS varchar(4)),4) ELSE convert(char(08),getdate(),112)+'0001' END) as NO ")
                             .append(" FROM TB_").append(comcode).append("_G10 ")
                             .append(" WHERE GRPNO LIKE convert(char(08),getdate(),112)+'%' ");
                }

		GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
                rs.next();

		return rs.getString("NO");

      }
      catch (Exception e)
      {
 		System.out.println(" GCoPiScheduleGroupTran::getMaxNo " + e.getMessage());
	 	return null;
      }
      finally
      {
		conn.close();
      }
    }

}