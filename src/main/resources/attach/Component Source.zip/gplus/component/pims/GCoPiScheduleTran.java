
package gplus.component.pims;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

/**
 * <PRE>
 * Filename		: CCoPimsSchdlTran.java
 * Class		: gplus.component.common.CCoPimsSchdlTran
 * Fuction		: ���� ���������� ��ȸ �� ���� �Ѵ�.
 * Comment		:
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCoPiScheduleTran extends GCmTopComponent
{
       /**
        * <PRE>
        * ���������� ��Ͽ� �ش� ������� ������ȣ�� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : current user id at session : �����
        *                      <LI> EntityModel tbz20 : getStrOrgNo ������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int updateOtherNewSchedule(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String Sub2 = dmProp.getString("Sub2");
                String Sub4 = dmProp.getString("Sub4");
                GEmTB_E10 dm = (GEmTB_E10) dmProp.getObject("TB_E10");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		int rv=0;

		GCmConnection conn = null;
		Statement stmt = null;
		try
		{
		    conn = GCmDbManager.getInstance().getConnection();
  	            stmt = conn.createStatement();
		    conn.setAutoCommit(false);

                    StringBuffer SqlQuery = new StringBuffer()
			.append(" delete from TB_"+COMCODE+"_E10 ")
                        .append(" WHERE SCHDLNO = "+genQuote(dm.getStrSchdlNo())+" AND USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Sub4,",","','")+"') ");
		        rv = stmt.executeUpdate(SqlQuery.toString());

                    SqlQuery = new StringBuffer()
			.append(" INSERT INTO TB_"+COMCODE+"_E10 (SCHDLNO,USERID,GRPNO,TITLE,COMMENTS,SDATE,STIME,LDATE,LTIME,RELATMAN,RELATID,RELATAREA,REPEATFLAG,PARENTNO,ALARMFLAG,WRITERID) ")
			.append("          SELECT "+genQuote(dm.getStrSchdlNo())+",USERID,"+genQuote(dm.getStrGrpNo())+","+genQuote(dm.getStrTitle())+",")
                        .append("         "+genQuote(dm.getStrComments())+","+genQuote(dm.getStrSdate())+","+genQuote(dm.getStrStime())+","+genQuote(dm.getStrLdate())+","+genQuote(dm.getStrLtime())+",")
                        .append("         "+genQuote(dm.getStrRelatMan())+","+genQuote(dm.getStrRelatId())+","+genQuote(dm.getStrRelatArea())+","+genQuote(dm.getStrRepeatFlag())+","+genQuote(dm.getStrParentNo())+","+genQuote(dm.getStrAlarmFlag())+","+genQuote(USERID))
                        .append("          FROM TB_COMM_Z20 ")
                        .append("          WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Sub2,",","','")+"') ");

                    rv = stmt.executeUpdate(SqlQuery.toString());

		    conn.commit();

		    return rv;
		}
		catch (Exception e)
		{
                    try
		    {
		        conn.rollback();
                    }
		    catch (SQLException ignored)
		    {
		        System.out.println(" GCoPiScheduleTran::updateOtherNewSchedule " + ignored.getMessage());
                    }

	 	    System.out.println(" GCoPiScheduleTran::updateOtherNewSchedule " + e.getMessage());

                    return -1;
		}
		finally
		{
		    try
		    {
		        stmt.close();
                    }
		    catch (Exception e)
		    {
		        System.out.println(" GCoPiScheduleTran::updateOtherNewSchedule " + e.getMessage());
                    }
			conn.close();
		}
	}


       /**
        * <PRE>
        * ���������� ��Ͽ� �ش� ������� ������ȣ�� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : current user id at session : �����
        *                      <LI> EntityModel tbz20 : getStrOrgNo ������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int insertNewSchedule(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
                GEmTB_E10 dm = (GEmTB_E10) dmProp.getObject("TB_E10");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
                        String schdlno = getMaxNo(COMCODE,strDbType);

			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" INSERT INTO TB_").append(COMCODE).append("_E10(SCHDLNO,USERID,GRPNO,TITLE,COMMENTS,SDATE,STIME,LDATE,LTIME,RELATMAN,RELATAREA,REPEATFLAG,PARENTNO,ALARMFLAG) ")
                                        .append(" VALUES ("+genQuote(schdlno)+","+genQuote(dm.getStrUserId())+","+genQuote(dm.getStrGrpNo())+","+genQuote(dm.getStrTitle())+",")
                                        .append("         "+genQuote(dm.getStrComments())+","+genQuote(dm.getStrSdate())+","+genQuote(dm.getStrStime())+","+genQuote(dm.getStrLdate())+","+genQuote(dm.getStrLtime())+",")
                                        .append("         "+genQuote(dm.getStrRelatMan())+","+genQuote(dm.getStrRelatArea())+","+genQuote(dm.getStrRepeatFlag())+","+genQuote(dm.getStrParentNo())+","+genQuote(dm.getStrAlarmFlag())+")");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
                        rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();
                        dmProp.setProperty("Schdlno",schdlno);
			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoPiScheduleTran::insertNewSchedule " + ignored.getMessage());
			}

	 		System.out.println(" GCoPiScheduleTran::insertNewSchedule " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoPiScheduleTran::insertNewSchedule " + e.getMessage());
			}

			conn.close();
		}
	}


       /**
        * <PRE>
        * ���������� ��Ͽ� �ش� ������� ������ȣ�� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : current user id at session : �����
        *                      <LI> EntityModel tbz20 : getStrOrgNo ������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int updateSchedule(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
                GEmTB_E10 dm = (GEmTB_E10) dmProp.getObject("TB_E10");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" UPDATE TB_").append(COMCODE).append("_E10 ")
                                        .append(" SET GRPNO="+genQuote(dm.getStrGrpNo())+",TITLE="+genQuote(dm.getStrTitle())+",COMMENTS="+genQuote(dm.getStrComments())+",SDATE="+genQuote(dm.getStrSdate())+", ")
                                        .append("     STIME="+genQuote(dm.getStrStime())+",LDATE="+genQuote(dm.getStrLdate())+",LTIME="+genQuote(dm.getStrLtime())+",RELATMAN="+genQuote(dm.getStrRelatMan())+", ")
                                        .append("     RELATAREA="+genQuote(dm.getStrRelatArea())+",REPEATFLAG="+genQuote(dm.getStrRepeatFlag())+",PARENTNO="+genQuote(dm.getStrParentNo())+",ALARMFLAG="+genQuote(dm.getStrAlarmFlag()))
                                        .append(" WHERE SCHDLNO="+genQuote(dm.getStrSchdlNo())+" AND USERID="+genQuote(dm.getStrUserId()));

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
                        rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoPiScheduleTran::updateSchedule " + ignored.getMessage());
			}

	 		System.out.println(" GCoPiScheduleTran::updateSchedule " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoPiScheduleTran::updateSchedule " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���������� ��Ͽ� �ش� ������� ������ȣ�� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : current user id at session : �����
        *                      <LI> EntityModel tbz20 : getStrOrgNo ������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int deleteSchedule(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
                GEmTB_E10 dm = (GEmTB_E10) dmProp.getObject("TB_E10");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
                                        .append(" DELETE FROM TB_").append(COMCODE).append("_E10 ")
                                        .append(" WHERE SCHDLNO = "+genQuote(dm.getStrSchdlNo())+" AND USERID = "+genQuote(USERID));

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoPiScheduleTran::deleteSchedule " + ignored.getMessage());
			}

	 		System.out.println(" GCoPiScheduleTran::deleteSchedule " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoPiScheduleTran::deleteSchedule " + e.getMessage());
			}
			conn.close();
		}
	}


       /**
        * <PRE>
        * ���������� ��Ͽ� �ش� ������� ������ȣ�� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : current user id at session : �����
        *                      <LI> EntityModel tbz20 : getStrOrgNo ������ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int insertOtherNewSchedule(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String Sub2 = dmProp.getString("Sub2");
                GEmTB_E10 dm = (GEmTB_E10) dmProp.getObject("TB_E10");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();
                String Schdlno = dmProp.getString("Schdlno");

		int rv=0;

		GCmConnection conn = null;
		Statement stmt = null;
		try
		{
			conn = GCmDbManager.getInstance().getConnection();
                        StringBuffer SqlQuery = new StringBuffer()
					.append(" INSERT INTO TB_"+COMCODE+"_E10 (SCHDLNO,USERID,GRPNO,TITLE,COMMENTS,SDATE,STIME,LDATE,LTIME,RELATMAN,RELATID,RELATAREA,REPEATFLAG,PARENTNO,ALARMFLAG,WRITERID) ")
					.append("          SELECT "+genQuote(Schdlno)+",USERID,"+genQuote(dm.getStrGrpNo())+","+genQuote(dm.getStrTitle())+",")
                                        .append("         "+genQuote(dm.getStrComments())+","+genQuote(dm.getStrSdate())+","+genQuote(dm.getStrStime())+","+genQuote(dm.getStrLdate())+","+genQuote(dm.getStrLtime())+",")
                                        .append("         "+genQuote(dm.getStrRelatMan())+","+genQuote(dm.getStrRelatId())+","+genQuote(dm.getStrRelatArea())+","+genQuote(dm.getStrRepeatFlag())+","+genQuote(dm.getStrParentNo())+","+genQuote(dm.getStrAlarmFlag())+","+genQuote(USERID))
                                        .append("          FROM TB_COMM_Z20 ")
                                        .append("          WHERE USERID IN ('"+gplus.commlib.util.GCmFcts.replace(Sub2,",","','")+"') ");

  	                stmt = conn.createStatement();
			conn.setAutoCommit(false);
			rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();
			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoPiScheduleTran::insertOtherNewSchedule " + ignored.getMessage());
			}

	 		System.out.println(" GCoPiScheduleTran::insertOtherNewSchedule " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoPiScheduleTran::insertOtherNewSchedule " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        *  �׳������� ������ȣ
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */

   	private String getMaxNo(String comcode,String strDbType) {
		GCmConnection conn = null;

	try
	{
		conn = GCmDbManager.getInstance().getConnection();

		StringBuffer sqlQuery = new StringBuffer();

                if ("oracle".equals(strDbType))
                {
                      sqlQuery
                        .append(" SELECT DECODE(SUBSTR(MAX(SCHDLNO),1,8),TO_CHAR(sysdate,'YYYYMMDD'),TO_CHAR(TO_NUMBER(MAX(SCHDLNO))+1),null,TO_CHAR(sysdate,'YYYYMMDD')||'0001') as NO ")
                        .append(" FROM TB_").append(comcode).append("_E10 ")
                        .append(" WHERE SCHDLNO LIKE TO_CHAR(sysdate,'YYYYMMDD')||'%'");
                }
                else if ("mssql".equals(strDbType))
                     {
                      sqlQuery
                        .append(" SELECT (CASE SUBSTRING(MAX(SCHDLNO),1,8) WHEN convert(char(08),getdate(),112) THEN CAST(SUBSTRING(MAX(SCHDLNO),1,8) AS varchar(8)) + RIGHT('0000'+CAST(SUBSTRING(MAX(SCHDLNO),9,4)+1 AS varchar(4)),4) ELSE convert(char(08),getdate(),112)+'0001' END) as NO ")
                        .append(" FROM TB_").append(comcode).append("_E10 ")
                        .append(" WHERE SCHDLNO LIKE convert(char(08),getdate(),112)+'%' ");
                     }

		GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
                rs.next();

		return rs.getString("NO");

      }
      catch (Exception e)
      {
 		System.out.println(" GCoPiScheduleTran:getMaxNo " + e.getMessage());
	 	return null;
      }
      finally
      {
		conn.close();
      }
    }

       /**
        * <PRE>
        *  ����ڿ� ���� ������ȣ
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String userid : ����� ���̵�
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */

    private String getUserMaxNo(String comcode,String userid) {
	GCmConnection conn = null;

	try
	{
		conn = GCmDbManager.getInstance().getConnection();
		StringBuffer sqlQuery = new StringBuffer()
                                    .append(" SELECT MAX(SCHDLNO) AS NO ")
                                    .append(" FROM TB_").append(comcode).append("_E10 ")
                                    .append(" WHERE userid = "+genQuote(userid));

		GCmResultSet rs = conn.executeQuery(sqlQuery.toString());
                rs.next();

		return rs.getString("NO");
        }
        catch (Exception e)
        {
 		System.out.println(" GCoPiScheduleTran:getUserMaxNo " + e.getMessage());
	 	return null;
        }
        finally
        {
		conn.close();
        }
    }
}