package gplus.component.userinfo;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

/**
 * <PRE>
 * Filename		: GCoUiUserInfo.java
 * Class		: gplus.component.pos.GCoUiUserInfo
 * Fuction		: ���������� ������
 * Comment		:
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCoUiUserInfo extends GCmTopComponent
{
       /**
        * <PRE>
        * ���޵� ����ڹ�ȣ�� ������ �����ȯ�� �������� ������ ������ �˻��Ͽ� �ǵ��� �ָ�
        * ������� �����μ���, ���޸��� �Բ� �ǵ��� �ش�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : current user id at session
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : ����� ȯ������ (USERID,COMCODE,PASSWD,ORGNO,POSCODE,USERNAME,SECLVL,TEL1,TEL2,TEL3,
        *                                 ZIPCODE,ADDR,ALARMFLAG,ALARMTIME,ALARMREPEAT,ALARMTYPE,ALARMMAILON,ALARMDRFTON,
        *                                 LOGINFLAG,LOGINDATE,BOXNO,SIGNDOCNO,INDATE,BIRTHDAY,LUNARFLAG,ORGNAME,POSNAME)
        */
	public GCmResultSet getUserInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                           sqlQuery
                           .append(" SELECT TB_COMM_Z20.USERID,TB_COMM_Z20.COMCODE,TB_COMM_Z20.PASSWD,TB_COMM_Z20.ORGNO,TB_COMM_Z20.POSCODE, ")
                           .append("        TB_COMM_Z20.USERNAME,TB_COMM_Z20.SECLVL,TB_COMM_Z20.TEL1,TB_COMM_Z20.TEL2,TB_COMM_Z20.TEL3, ")
                           .append("        TB_COMM_Z20.ZIPCODE,TB_COMM_Z20.ADDR,TB_COMM_Z20.ALARMFLAG,TB_COMM_Z20.ALARMTIME,TB_COMM_Z20.ALARMREPEAT, ")
                           .append("        TB_COMM_Z20.ALARMTYPE,TB_COMM_Z20.ALARMMAILON,TB_COMM_Z20.ALARMDRFTON,TB_COMM_Z20.LOGINFLAG,TB_COMM_Z20.LOGINDATE, ")
                           .append("        TB_COMM_Z20.BOXNO,TB_COMM_Z20.SIGNDOCNO,TB_COMM_Z20.INDATE,TB_COMM_Z20.BIRTHDAY,TB_COMM_Z20.LUNARFLAG,TB_COMM_Z20.PAGESIZE, ")
                           .append("        TB_").append(COMCODE).append("_N10.ORGNAME, TB_").append(COMCODE).append("_N20.POSNAME  ")
                           .append(" FROM TB_COMM_Z20 TB_COMM_Z20, TB_").append(COMCODE).append("_N10 TB_").append(COMCODE).append("_N10, TB_").append(COMCODE).append("_N20 TB_").append(COMCODE).append("_N20 ")
                           .append(" WHERE TB_COMM_Z20.ORGNO = TB_").append(COMCODE).append("_N10.ORGNO (+) AND ")
                           .append("       TB_COMM_Z20.POSCODE = TB_").append(COMCODE).append("_N20.POSCODE (+) AND ")
                           .append("       TB_COMM_Z20.USERID = "+genQuote(USERID)+" AND TB_COMM_Z20.COMCODE = "+genQuote(COMCODE));
                        }
                        else if ("mssql".equals(strDbType))
                             {
                                   sqlQuery
                                   .append(" SELECT TB_COMM_Z20.USERID,TB_COMM_Z20.COMCODE,TB_COMM_Z20.PASSWD,TB_COMM_Z20.ORGNO,TB_COMM_Z20.POSCODE, ")
                                   .append("        TB_COMM_Z20.USERNAME,TB_COMM_Z20.SECLVL,TB_COMM_Z20.TEL1,TB_COMM_Z20.TEL2,TB_COMM_Z20.TEL3, ")
                                   .append("        TB_COMM_Z20.ZIPCODE,TB_COMM_Z20.ADDR,TB_COMM_Z20.ALARMFLAG,TB_COMM_Z20.ALARMTIME,TB_COMM_Z20.ALARMREPEAT, ")
                                   .append("        TB_COMM_Z20.ALARMTYPE,TB_COMM_Z20.ALARMMAILON,TB_COMM_Z20.ALARMDRFTON,TB_COMM_Z20.LOGINFLAG,TB_COMM_Z20.LOGINDATE, ")
                                   .append("        TB_COMM_Z20.BOXNO,TB_COMM_Z20.SIGNDOCNO,TB_COMM_Z20.INDATE,TB_COMM_Z20.BIRTHDAY,TB_COMM_Z20.LUNARFLAG,TB_COMM_Z20.PAGESIZE, ")
                                   .append("        TB_").append(COMCODE).append("_N10.ORGNAME, TB_").append(COMCODE).append("_N20.POSNAME  ")
                                   .append(" FROM TB_COMM_Z20 TB_COMM_Z20, TB_").append(COMCODE).append("_N10 TB_").append(COMCODE).append("_N10, TB_").append(COMCODE).append("_N20 TB_").append(COMCODE).append("_N20 ")
                                   .append(" WHERE TB_COMM_Z20.ORGNO *= TB_").append(COMCODE).append("_N10.ORGNO AND ")
                                   .append("       TB_COMM_Z20.POSCODE *= TB_").append(COMCODE).append("_N20.POSCODE AND ")
                                   .append("       TB_COMM_Z20.USERID = "+genQuote(USERID)+" AND TB_COMM_Z20.COMCODE = "+genQuote(COMCODE));
                             }

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoUiUserInfo::getUserInfo : " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� ȸ���ڵ带 ������ ��ü������ �����ȯ�� �������� ������ ������ �˻��Ͽ� �ǵ��� �ָ�
        * ������� �����μ���, ���޸��� �Բ� �ǵ��� �ش�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String SortOpt : �����ɼ�
        *                      <LI> String SortID : �����÷��̸�
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : ����� ȯ������ ��� (USERID,COMCODE,PASSWD,ORGNO,POSCODE,USERNAME,SECLVL,TEL1,TEL2,TEL3,
        *                                 ZIPCODE,ADDR,ALARMFLAG,ALARMTIME,ALARMREPEAT,ALARMTYPE,ALARMMAILON,ALARMDRFTON,
        *                                 LOGINFLAG,LOGINDATE,BOXNO,SIGNDOCNO,INDATE,BIRTHDAY,LUNARFLAG,ORGNAME,POSNAME)
        */
	public GCmResultSet getUserList(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String SortOpt = dmProp.getString("SortOpt");
		String SortID = dmProp.getString("SortID");
                String strDbType = cp.getProperty("gplus.db.type").toLowerCase();

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer();

                        if ("oracle".equals(strDbType))
                        {
                           sqlQuery
                             .append(" SELECT TB_COMM_Z20.USERID,TB_COMM_Z20.COMCODE,TB_COMM_Z20.PASSWD,TB_COMM_Z20.ORGNO,TB_COMM_Z20.POSCODE, ")
                             .append("        TB_COMM_Z20.USERNAME,TB_COMM_Z20.SECLVL,TB_COMM_Z20.TEL1,TB_COMM_Z20.TEL2,TB_COMM_Z20.TEL3, ")
                             .append("        TB_COMM_Z20.ZIPCODE,TB_COMM_Z20.ADDR,TB_COMM_Z20.ALARMFLAG,TB_COMM_Z20.ALARMTIME,TB_COMM_Z20.ALARMREPEAT, ")
                             .append("        TB_COMM_Z20.ALARMTYPE,TB_COMM_Z20.ALARMMAILON,TB_COMM_Z20.ALARMDRFTON,TB_COMM_Z20.LOGINFLAG,TB_COMM_Z20.LOGINDATE, ")
                             .append("        TB_COMM_Z20.BOXNO,TB_COMM_Z20.SIGNDOCNO,TB_COMM_Z20.INDATE,TB_COMM_Z20.BIRTHDAY,TB_COMM_Z20.LUNARFLAG, ")
                             .append("        TB_").append(COMCODE).append("_N10.ORGNAME, TB_").append(COMCODE).append("_N20.POSNAME  ")
                             .append(" FROM TB_COMM_Z20 TB_COMM_Z20, TB_").append(COMCODE).append("_N10 TB_").append(COMCODE).append("_N10, TB_").append(COMCODE).append("_N20 TB_").append(COMCODE).append("_N20 ")
                             .append(" WHERE TB_COMM_Z20.ORGNO = TB_").append(COMCODE).append("_N10.ORGNO (+) AND ")
                             .append("       TB_COMM_Z20.POSCODE = TB_").append(COMCODE).append("_N20.POSCODE (+) AND ")
                             .append("       TB_COMM_Z20.COMCODE = "+genQuote(COMCODE))
                             .append(SortOpt).append(SortID);
                        }
                        else if ("mssql".equals(strDbType))
                             {
                                   sqlQuery
                                     .append(" SELECT TB_COMM_Z20.USERID,TB_COMM_Z20.COMCODE,TB_COMM_Z20.PASSWD,TB_COMM_Z20.ORGNO,TB_COMM_Z20.POSCODE, ")
                                     .append("        TB_COMM_Z20.USERNAME,TB_COMM_Z20.SECLVL,TB_COMM_Z20.TEL1,TB_COMM_Z20.TEL2,TB_COMM_Z20.TEL3, ")
                                     .append("        TB_COMM_Z20.ZIPCODE,TB_COMM_Z20.ADDR,TB_COMM_Z20.ALARMFLAG,TB_COMM_Z20.ALARMTIME,TB_COMM_Z20.ALARMREPEAT, ")
                                     .append("        TB_COMM_Z20.ALARMTYPE,TB_COMM_Z20.ALARMMAILON,TB_COMM_Z20.ALARMDRFTON,TB_COMM_Z20.LOGINFLAG,TB_COMM_Z20.LOGINDATE, ")
                                     .append("        TB_COMM_Z20.BOXNO,TB_COMM_Z20.SIGNDOCNO,TB_COMM_Z20.INDATE,TB_COMM_Z20.BIRTHDAY,TB_COMM_Z20.LUNARFLAG, ")
                                     .append("        TB_").append(COMCODE).append("_N10.ORGNAME, TB_").append(COMCODE).append("_N20.POSNAME  ")
                                     .append(" FROM TB_COMM_Z20 TB_COMM_Z20, TB_").append(COMCODE).append("_N10 TB_").append(COMCODE).append("_N10, TB_").append(COMCODE).append("_N20 TB_").append(COMCODE).append("_N20 ")
                                     .append(" WHERE TB_COMM_Z20.ORGNO *= TB_").append(COMCODE).append("_N10.ORGNO AND ")
                                     .append("       TB_COMM_Z20.POSCODE *= TB_").append(COMCODE).append("_N20.POSCODE AND ")
                                     .append("       TB_COMM_Z20.COMCODE = "+genQuote(COMCODE))
                                     .append(SortOpt).append(SortID);

                             }


			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoUiUserInfo::getUserList : " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���� ����ڹ�ȣ�� ����������� ���θ� Ȯ���ϱ� ���� ����� �����ϸ�
        * ���޵� ����ڹ�ȣ ���Ͽ� �ش��ϴ� ����ڹ�ȣ�� �˻��Ͽ� �����ش�.
        * ���ϵ� ����� ��ȣ�� ���� ��쿡�� �ش� ����� ID�� ��밡���ϴ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String UserNo : ����ڹ�ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return          GCmResultSet : ����ڹ�ȣ (USERID)
        */
	public GCmResultSet getIdRegular(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		GCmConnection conn = null;

		String COMCODE = dmProp.getString("COMCODE");
		String UserNo = dmProp.getString("UserNo");

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer sqlQuery = new StringBuffer()
                           .append(" SELECT USERID ")
                           .append(" FROM TB_COMM_Z20 ")
                           .append(" WHERE USERID = "+genQuote(UserNo));

			GCmResultSet rs = conn.executeQuery(sqlQuery.toString());

			return rs;

		}
		catch (Exception e)
		{
	 		System.out.println(" GCoUiUserInfo::getIdRegular : " + e.getMessage());
		 	return null;
		}
		finally
		{
			conn.close();
		}
	}
}