package gplus.component.userinfo;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.exception.*;
import gplus.commlib.lib.*;
import gplus.commlib.log.*;
import gplus.commlib.util.*;
import gplus.entitymodel.*;

/**
 * <PRE>
 * Filename		: GCoUiUserInfoTran.java
 * Class		: gplus.component.pos.GCoUiUserInfoTran
 * Fuction		: ���������� ������
 * Comment		:
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCoUiUserInfoTran extends GCmTopComponent
{
       /**
        * <PRE>
        * ���޵� ȸ�����ڵ�� ����ڹ�ȣ�� ���Ͽ� �ش� �����ȯ�������� ����� ��ȣ�� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : current user id at session : ����ڹ�ȣ
        *                      <LI> String Oldpasswd : �����ȣ : �˻��� �������� Ȱ��
        *                      <LI> String Passwd : �����ȣ
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int updateUserPassword(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
		String Oldpasswd = dmProp.getString("Oldpasswd");
		String Passwd = dmProp.getString("Passwd");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" UPDATE TB_COMM_Z20 ")
					.append(" SET PASSWD = "+genQuote(Passwd))
					.append(" WHERE USERID = "+genQuote(USERID)+" AND PASSWD = "+genQuote(Oldpasswd));

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoUiUserInfoTran::updateUserPassword : " + ignored.getMessage());
			}

	 		System.out.println(" GCoUiUserInfoTran::updateUserPassword : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoUiUserInfoTran::updateUserPassword : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * ���޵� ����ڹ�ȣ�� ���Ͽ� ����� ȯ�������� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> String USERID : current user id at session : ����ڹ�ȣ
        *                      <LI> EntityModel tbz20 : �����ȯ������ ������ ��
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int updatePrivateUserInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
		String USERID = dmProp.getString("USERID");
                GEmTB_Z20 tbz20 = (GEmTB_Z20)dmProp.getObject("tbz20");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;
                StringBuffer SqlQuery = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();
			stmt = conn.createStatement();
			conn.setAutoCommit(false);

			SqlQuery = new StringBuffer()
				   .append(" UPDATE TB_COMM_Z20 ")
				   .append(" SET USERNAME="+genQuote(tbz20.getStrUserName())+", ALARMFLAG="+genQuote(tbz20.getStrAlarmFlag())+", ALARMTIME="+tbz20.getStrAlarmTime()+",")
                                   .append("     ALARMREPEAT="+tbz20.getStrAlarmRepeat()+", ALARMTYPE="+genQuote(tbz20.getStrAlarmType())+", ALARMMAILON="+genQuote(tbz20.getStrAlarmMailOn())+", ALARMDRFTON="+genQuote(tbz20.getStrAlarmDrftOn())+",")
                                   .append("     TEL1="+genQuote(tbz20.getStrTel1())+", TEL2="+genQuote(tbz20.getStrTel2())+", TEL3="+genQuote(tbz20.getStrTel3())+" , ZIPCODE="+genQuote(tbz20.getStrZipCode())+",")
                                   .append("     ADDR="+genQuote(tbz20.getStrAddr())+", INDATE="+genQuote(tbz20.getStrInDate())+", BIRTHDAY="+genQuote(tbz20.getStrBirthDay())+", LUNARFLAG="+genQuote(tbz20.getStrLunarFlag())+", ORGNO = "+genQuote(tbz20.getStrOrgNo())+" , POSCODE = "+genQuote(tbz20.getStrPosCode())+", BOXNO = "+genQuote(tbz20.getStrBoxNo())+", PAGESIZE = "+genQuote(tbz20.getStrPageSize()))
				   .append(" WHERE USERID = "+genQuote(USERID));

	                rv = stmt.executeUpdate(SqlQuery.toString());
                        if( rv <= 0 ) throw new Exception(" During updatePrivateUserInfo error !!!");

			SqlQuery = new StringBuffer()
					.append(" UPDATE TB_").append(COMCODE).append("_N11 ")
					.append(" SET ORGNO = "+genQuote(tbz20.getStrOrgNo()))
					.append(" WHERE USERID = "+genQuote(USERID));

	                rv = stmt.executeUpdate(SqlQuery.toString());
                        if( rv <= 0 ) throw new Exception(" During updatePrivateUserInfo error !!!");

			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoUiUserInfoTran::updatePrivateUserInfo : " + ignored.getMessage());
			}

	 		System.out.println(" GCoUiUserInfoTran::updatePrivateUserInfo : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoUiUserInfoTran::updatePrivateUserInfo : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * �ý��� �����ڸ� ���Ͽ� ����� ȯ�������� �����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> EntityModel tbz20 : �����ȯ������ ������ ��
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int updateUserInfo(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
                GEmTB_Z20 tbz20 = (GEmTB_Z20)dmProp.getObject("tbz20");

                System.out.println("pagesize = "+ tbz20.getStrPageSize());
		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" UPDATE TB_COMM_Z20 ")
                                        .append(" SET USERNAME="+genQuote(tbz20.getStrUserName())+", ALARMFLAG="+genQuote(tbz20.getStrAlarmFlag())+", ALARMTIME="+tbz20.getStrAlarmTime()+",")
                                        .append("     ALARMREPEAT="+tbz20.getStrAlarmRepeat()+", ALARMTYPE="+genQuote(tbz20.getStrAlarmType())+", ALARMMAILON="+genQuote(tbz20.getStrAlarmMailOn())+", ALARMDRFTON="+genQuote(tbz20.getStrAlarmDrftOn())+",")
                                        .append("     TEL1="+genQuote(tbz20.getStrTel1())+", TEL2="+genQuote(tbz20.getStrTel2())+", TEL3="+genQuote(tbz20.getStrTel3())+" , ZIPCODE="+genQuote(tbz20.getStrZipCode())+", PASSWD="+genQuote(tbz20.getStrPassWd())+", SECLVL="+genQuote(tbz20.getStrSecLvl())+",")
                                        .append("     ADDR="+genQuote(tbz20.getStrAddr())+", INDATE="+genQuote(tbz20.getStrInDate())+", BIRTHDAY="+genQuote(tbz20.getStrBirthDay())+", LUNARFLAG="+genQuote(tbz20.getStrLunarFlag())+", ORGNO = "+genQuote(tbz20.getStrOrgNo())+" , POSCODE = "+genQuote(tbz20.getStrPosCode())+", BOXNO = "+genQuote(tbz20.getStrBoxNo()) )
					.append(" WHERE USERID = "+genQuote(tbz20.getStrUserId()));

			stmt = conn.createStatement();
			conn.setAutoCommit(false);

			  rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoUiUserInfoTran::updateUserInfo : " + ignored.getMessage());
			}

	 		System.out.println(" GCoUiUserInfoTran::updateUserInfo : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoUiUserInfoTran::updateUserInfo : " + e.getMessage());
			}
			conn.close();
		}
	}

       /**
        * <PRE>
        * �ý��� �����ڸ� ���Ͽ� ����� ȯ�������� �űԻ���ڸ� ����Ѵ�.
        * </PRE>
        *
        * @param cp      a GCmProperties holding gplus groupware properties.
        * @param dmProp    GCmProperties
        *                  <UL>relevant fields.
        *                      <LI> String COMCODE : current user companycode at session
        *                      <LI> EntityModel tbz20 : �����ȯ������ ������ ��
        *                  </UL>
        * @param msgInfo   a GCmMsgInfo holding error codes.
        * @return N/A
        */
	public int insertNewUser(GCmProperties cp, GCmProperties dmProp, GCmMsgInfo msgInfo)
	{
		String COMCODE = dmProp.getString("COMCODE");
                GEmTB_Z20 tbz20 = (GEmTB_Z20)dmProp.getObject("tbz20");

		int rv;

		GCmConnection conn = null;
		Statement stmt = null;

		try
		{
			conn = GCmDbManager.getInstance().getConnection();

			StringBuffer SqlQuery = new StringBuffer()
					.append(" INSERT INTO TB_COMM_Z20 ")
					.append(" ( USERID,PASSWD,ORGNO,POSCODE,USERNAME,SECLVL,ALARMFLAG,ALARMTIME,ALARMREPEAT,ALARMTYPE,ALARMMAILON, ALARMDRFTON, ")
                                        .append("   LOGINFLAG,LOGINDATE,BOXNO,SIGNDOCNO,COMCODE,TEL1,TEL2,TEL3,ZIPCODE,ADDR,INDATE,BIRTHDAY,LUNARFLAG) ")
                                        .append("   VALUES("+genQuote(tbz20.getStrUserId())+","+genQuote(tbz20.getStrPassWd())+","+genQuote(tbz20.getStrOrgNo())+",")
                                        .append("          "+genQuote(tbz20.getStrPosCode())+","+genQuote(tbz20.getStrUserName())+","+genQuote(tbz20.getStrSecLvl())+",")
                                        .append("          "+genQuote(tbz20.getStrAlarmFlag())+","+tbz20.getStrAlarmTime()+","+tbz20.getStrAlarmRepeat()+",")
                                        .append("          "+genQuote(tbz20.getStrAlarmType())+","+genQuote(tbz20.getStrAlarmMailOn())+","+genQuote(tbz20.getStrAlarmDrftOn())+",")
                                        .append("          "+genQuote(tbz20.getStrLogInFlag())+","+genQuote(tbz20.getStrLogInDate())+","+genQuote(tbz20.getStrBoxNo())+",")
                                        .append("          "+genQuote(tbz20.getStrSignDocNo())+","+genQuote(COMCODE)+","+genQuote(tbz20.getStrTel1())+",")
                                        .append("          "+genQuote(tbz20.getStrTel2())+","+genQuote(tbz20.getStrTel3())+","+genQuote(tbz20.getStrZipCode())+",")
                                        .append("          "+genQuote(tbz20.getStrAddr())+","+genQuote(tbz20.getStrInDate())+","+genQuote(tbz20.getStrBirthDay())+",")
                                        .append("          "+genQuote(tbz20.getStrLunarFlag())+")");

			stmt = conn.createStatement();
			conn.setAutoCommit(false);
			  rv = stmt.executeUpdate(SqlQuery.toString());
			conn.commit();

			return rv;
		}
		catch (Exception e)
		{
			try
			{
				conn.rollback();
			}
			catch (SQLException ignored)
			{
		 		System.out.println(" GCoUiUserInfoTran::insertNewUser : " + ignored.getMessage());
			}

	 		System.out.println(" GCoUiUserInfoTran::insertNewUser : " + e.getMessage());

		 	return -1;
		}
		finally
		{
			try
			{
				stmt.close();
			}
			catch (Exception e)
			{
		 		System.out.println(" GCoUiUserInfoTran::insertNewUser : " + e.getMessage());
			}
			conn.close();
		}
	}

}