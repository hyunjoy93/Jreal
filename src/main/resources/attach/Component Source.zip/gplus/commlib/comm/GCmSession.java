package gplus.commlib.comm;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import com.objectspace.jgl.*;

/**
 * <PRE>
 * Filename : GCmSession.java
 * Class    : GCmSession
 * Function : initialize GPLUS system
 * Comment  :
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GCmSession extends HashMap
    implements Serializable, HttpSessionBindingListener
{
    protected static Array m_sessionPool = new Array();
    protected final String SESSION_KEY = "KEY";
    protected final String CUST_NODE = "CUST";

    private static final boolean VERBOSE = false;

    /**
     * add sessionId to m_sessionPool,
     * called when valueBound invoked
     */
    protected static void login(String key)
    {
        // m_sessionPool.add(key);

        // test lsk
        if (VERBOSE)
        	System.err.println("Session Key added.....");
    }

    /**
     * add sessionId to m_sessionPool,
     * called when valueUnbound invoked
     */
    protected static void logout(String key)
    {
        // m_sessionPool.remove(key);
        // test lsk
        if (VERBOSE)
        	System.err.println("Session Key removed.....");
    }

    /**
     * return m_sessionPool
     */
    public static Array getSessionIdArray()
    {
        return m_sessionPool;
    }

    /**
     * construct GCmSession with Session key
     *
     * @param key Session key
     */
    public GCmSession(String key)
    {
        add(SESSION_KEY, key);
    }

    public String getId()
    {
        return (String)get(SESSION_KEY);
    }

    /**
     * set contact cust info node
     *
     * @param cust CustNode
     */
    public void setContactCust(Object cust)
    {
        if (cust == null)
		{
            remove(CUST_NODE);
        }
        else
		{
            put(CUST_NODE, cust);
        }
    }

    /**
     * get contact cust info node
     *
     * @return CustNode contacting
     */
    public Object getContactCust()
    {
        return get(CUST_NODE);
    }

    public void valueBound(HttpSessionBindingEvent event)
    {
        login(event.getSession().getId());
    }

    public void valueUnbound(HttpSessionBindingEvent event)
    {
        logout(event.getSession().getId());
    }
}
