package gplus.commlib.comm;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import com.objectspace.jgl.*;

/**
 * <PRE>
 * Filename : GCmHttpSessionManager.java
 * Class    : GCmHttpSessionManager
 * Function : HttpSession ����
 * Comment  : Http Session�� �����Ѵ�.
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GCmHttpSessionManager
{
    static final String GPLUS_SESSION = "GPLUS_SESSION";

    static final boolean verbose = false;

    /**
     * <PRE>
     * session�� ���� �ϸ�, session�� ����� �����͵��� �����
     * ���ο� object�� session�� ����
     * </PRE>
     *
     * @param req HttpServletRequest
     * @pre (req!=null)
     * @return GPlusSession
     */
    public static GCmSession logon(HttpServletRequest req)
    {

        HttpSession ses = (HttpSession)req.getSession(false);

        if (ses != null)
	{
	    	if (verbose)
		{
            		System.err.println("OLD GPLUS SESSION : " + ses.getId());
        	}
		if (ses.getValue(GPLUS_SESSION) == null)
		{
            		ses.invalidate();
            	}
        }

        ses = req.getSession(true);

        if (verbose)
        {
        	System.err.println("NEW GPLUS SESSION : " + ses.getId());
        }

        StringBuffer msgbuf = new StringBuffer()
            .append("HttpSessionManager.logon: creating new seesion id=")
            .append(ses.getId());

        try
	{
            if (verbose)
            {
            	System.err.println(msgbuf.toString());
            }
        }
	catch (Exception e) {}

        GCmSession newone = new GCmSession(ses.getId());

        ses.putValue(GPLUS_SESSION,newone);

        return newone;
    }

    /**
     * <PRE>
     * GPLUS session logout
     * Session�� invalidate
     * </PRE>
     *
     * @param req HttpServletRequest
     * @return GPLUS Session
     */
    public static GCmSession logout(HttpServletRequest req)
    {
        HttpSession ses = req.getSession(false);

        if (ses != null)
	{
            GCmSession ises = (GCmSession)ses.getValue(GPLUS_SESSION);
            ses.invalidate();

            StringBuffer msgbuf = new StringBuffer()
                .append("GCmHttpSessionManager.logout: id=")
                .append(ses.getId())
                .append(" ofcid=")
                .append((String)ises.get("ofcid"));

            try
	    {
                // T3Services.getT3Services().log().info(msgbuf.toString());
            } catch (Exception e) {}

            return ises;
        }
        return null;
    }


    /**
     * get GCmSession thru HttpSession<br>
     * If failed to get HttpSession, call SessionExpired servlet
     *
     * @param req HttpServletRequest
     * @pre (req!=null)
     * @return GCmSession
     */
    public static GCmSession getGPlusSession(HttpServletRequest req)
    {
        HttpSession ses = (HttpSession)req.getSession(false);

        if (ses == null)
	{
            return null;
        }

	if (verbose)
        {
		System.err.println("PURE GPLUS SESSION : " + ses);
	}

        GCmSession cses = (GCmSession)ses.getValue(GPLUS_SESSION);

        return cses;
    }

}
