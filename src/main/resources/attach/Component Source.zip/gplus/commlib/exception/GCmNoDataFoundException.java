package  gplus.commlib.exception;

import gplus.commlib.lib.GCmMsgInfo;

/**
 * <PRE>
 * Filename	: GCmNoDataFoundException.java <BR>
 * Class	: GCmNoDataFoundException <BR>
 * Function	: <BR>
 * Comment	: 
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCmNoDataFoundException extends GCmGplusException 
{
	/**
	 * Catches exceptions without a specified string
	 *
	 */
	public GCmNoDataFoundException() {}
	
	/**
	 * Constructs the appropriate exception with the specified string
	 *
	 * @param message           Exception message
	 */
	public GCmNoDataFoundException(String message) {super(message);}

}
