package gplus.commlib.lib;

import java.io.*;
import java.util.*;
import java.sql.*;
import gplus.commlib.comm.*;
import gplus.commlib.db.*;
import gplus.commlib.lib.GCmUtil;
import gplus.commlib.log.GCmDebugLog;

/**
 * <PRE>
 * Filename : GCmCodeManager.java
 * Class    : GCmCodeManager
 * Function : Contains code table, and serves it.
 * Comment  : This class extends GCmProperties, and is singleton.
 *	      It contains code table in it's own property instance.
 * History      : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GCmCodeManager extends GCmProperties
{
	private	static GCmCodeManager 	m_instance;

	private static GCmDebugLog log = null;

	private boolean verbose = false;

	private final 	int		BYCODE = 0;
	private final	int 	BYNAME = 1;

	/**
	 * GCmCodeManager constructor<br>
	 * A private constructor since this is a Singleton
	 */
	protected GCmCodeManager()
	{
		m_instance = null;
	}


	/**
	 * This class is singleton, so Returns the single instance,
	 * creating one if it's the first time this mothod is called.
	 *
	 * @return GCmCodeManager The single instance of this class
	 */
	public static GCmCodeManager getInstance() throws Exception
	{
		if (m_instance == null)
		{
			throw new Exception("GCmCodeManager instance is null");
		}
		return m_instance;
	}


	/**
	 * Load properties and initializes the instance with these values
	 */
	public static void init() throws Exception
	{
		if (m_instance == null)
		{
			m_instance = new GCmCodeManager();

	    	try
	    	{
				String strLogPath = GCmPropertyManager.getInstance()
					.getPropertyInstance(GCmConstDef.GROUPWARE_ID)
					.getProperty("gplus.log.path");

				log = new GCmDebugLog(strLogPath + File.separator + "gplus.log");
			}
			catch (Exception e)
			{
				log = new GCmDebugLog(new PrintWriter(System.err));
			}

			try
			{
				m_instance.makeProperties();
			}
			catch (Exception e)
			{
				log.println("GCmCodeManager Initialize ERROR");
			}

		}
	}


	/**
	 * Make a properties which contains number of codes are read from
	 * DB or code.properties ( *NOW* : code.properties )
	 */
	private void makeProperties()
	{
/*		GCmConnection 	conn = null;
		GCmResultSet	rs 	 = null;

		try
		{
			GCmPropertyManager propMgr = GCmPropertyManager.getInstance();

			conn = GCmDbManager.getInstance().getConnection();

			if (verbose)
				System.err.println("GCmCodeManager: property : " + propMgr);

			StringBuffer strBuff = new StringBuffer()
					.append(" SELECT")
					.append("	TC.CD_NO,")
					.append("	TC.CD_NM,")
					.append("	TD.CD_DTL_NO,")
					.append("	TD.CD_DTL_NM")
					.append(" FROM TCODE TC, TCODEDTL TD")
					.append(" WHERE")
					.append("	TC.CD_NO = TD.CD_NO");

			rs = conn.executeQuery(strBuff.toString());

			while (rs.next())
			{
				String codeGrp 		= rs.getString("CD_NO");
				String codeGrpNm 	= rs.getString("CD_NM");
				String codeNo 		= rs.getString("CD_DTL_NO");
				String codeName		= rs.getString("CD_DTL_NM");

				String keyOfCode = codeGrp + "`" + codeNo;
				String strOfCode = codeGrpNm + "`" + codeName;

				put(keyOfCode, strOfCode);
			}

		}
		catch (Exception e)
		{
			log.println("GCmCodeManager: Can't load from file");

			if (verbose)
		 		System.err.println("CGdDisplay : " + e.getMessage());

		}
		finally
		{
			conn.close();
		}			*/

	}


    /**
     * Get name of code group
     *
     * @param groupId Identifier of group
     * @return groupName Name of code group
     */
    public String getGroupName(String groupId)
    {
		Vector values = new Vector();

		Enumeration enum = propertyNames();

		while (enum.hasMoreElements())
		{
			String keyToken = (String) enum.nextElement();
			StringTokenizer st = new StringTokenizer(keyToken, "`");

			String token = (String) st.nextToken();

			if (groupId.equals(token))
			{
				String fullName = getProperty(keyToken);
				StringTokenizer stn = new StringTokenizer(fullName, "`");

				String groupName = (String) stn.nextToken();
				String codeName = (String) stn.nextToken();

				return groupName;
			}
		}
		return null;
    }


    /**
     * Get code and code names which are resimented in group
     *
     * @param groupId Identifier of group
     * @return Values
     */
    public Vector getValues(String groupId)
    {
		Vector values = new Vector();
		values.clear();

		Enumeration enum = propertyNames();

		while (enum.hasMoreElements())
		{
			String keyToken = (String) enum.nextElement();

			StringTokenizer st = new StringTokenizer(keyToken, "`");
			String token = (String) st.nextToken();

			if (groupId.equals(token))
			{
				String[] aPair = new String[2];

				aPair[0] = (String) st.nextToken();
				aPair[1] = getProperty(keyToken);
				aPair[1] = aPair[1].substring(aPair[1].indexOf('`') + 1);

				values.insertElementAt(aPair, 0);
			}

		}
		return values;
    }


    /**
     * Get codes which are resimented in group
     *
     * @param groupId Identifier of group
     * @return codes
     */
    public Vector getCodes(String groupId)
    {
		Vector values = new Vector();

		Enumeration enum = propertyNames();

		while (enum.hasMoreElements())
		{
			String keyToken = (String) enum.nextElement();
			StringTokenizer st = new StringTokenizer(keyToken, "`");

			String token = (String) st.nextToken();

			if (groupId.equals(token))
			{
				values.insertElementAt((String) st.nextToken(), 0);
			}
		}
		return values;
    }


    /**
     * Get code names which are resimented in group
     *
     * @param groupId Identifier of group
     * @return codeNames
     */
    public Vector getCodeNames(String groupId)
    {
		Vector values = new Vector();

		Enumeration enum = propertyNames();

		while (enum.hasMoreElements())
		{
			String keyToken = (String) enum.nextElement();
			StringTokenizer st = new StringTokenizer(keyToken, "`");

			String token = (String) st.nextToken();

			if (groupId.equals(token))
			{
				String fullName = getProperty(keyToken);
				StringTokenizer stn = new StringTokenizer(fullName, "`");

				String groupName = (String) stn.nextToken();
				String codeName = (String) stn.nextToken();

				values.insertElementAt(codeName, 0);
			}
		}
		return values;
    }


    /**
     * Get a code name which are identifiered by given code
     *
     * @param groupId Identifier of group
     * @param code Identifier of code
     * @return codeString
     */
    public String getCodeString(String groupId, String code)
    {
		String key = groupId + "`" + code;

		try
		{
			String nameToken = getProperty(key);

			StringTokenizer st = new StringTokenizer(nameToken, "`");

			String groupName = (String) st.nextToken();
			String codeString = (String) st.nextToken();

			return codeString;
		}
		catch (Exception e)
		{
			return new String("");
		}
    }
}
