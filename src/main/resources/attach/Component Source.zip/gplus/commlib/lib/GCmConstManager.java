package gplus.commlib.lib;

import java.util.*;
import java.io.*;
import gplus.commlib.lib.*;
import gplus.commlib.comm.*;
import gplus.commlib.log.GCmDebugLog;

/**
 * 	<PRE>
 * 	Filename : GCmConstManager.java 
 * 	Class    : gplus.commlib.comm.GCmConstManager
 * 	Function : handling of defined constant value
 * 	Comment  : 
 *      History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 *      </PRE>
 *      @version   1.0 
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */

public class GCmConstManager extends GCmProperties
{
        private static 			GCmConstManager	m_instance;
	private static final String	GROUPWARE_ID = GCmConstDef.GROUPWARE_ID;
	private static final boolean 	verbose = false;
	private static GCmDebugLog	log = null;

 	protected GCmConstManager()
 	{
 		m_instance = null;
 	}    

	/**
	 * get singleton object<br>
	 * Must be called after init
	 *
	 * @return singleton GCmConstManager object
	 * @pre (m_instance != null), "GCmConstManager not yet initialized"
	 */
 	public static GCmConstManager getInstance() throws Exception
 	{
		if (m_instance == null) 
		{
			throw new Exception("System is not initialized properly: " +
								"GCmConstManager instance is null");
		}
		return m_instance;
 	}    

        /**
	* ������� ���� �ڵ鸵�ϱ� ����  GCmConstManager �ʱ�ȭ
	*
	* @param	N/A
	*/
	public static void init() throws Exception
	{
		if(m_instance == null)
		{
			if (verbose)
				System.err.println("GCmConstManager init ....");	
				
	    		try
	    		{
				String strLogPath = GCmPropertyManager.getInstance()
					.getPropertyInstance(GCmConstDef.GROUPWARE_ID)
					.getProperty("gplus.log.path");
							
				log = new GCmDebugLog(strLogPath + File.separator + "gplus.log");
			}
			catch (Exception e)
			{
				log = new GCmDebugLog(new PrintWriter(System.err));
			}
				
			m_instance = new GCmConstManager();
			
			try
			{
				m_instance.loadConstantFile();				
			}
			catch(Exception e)
			{
				log.println(e);
				throw new Exception("Class : GCmConstManager, Method : init ....error"); 
			}
		}
		
		if (verbose)
			System.err.println("constant property ==" + m_instance);
	}
	

   /**
	* ������������ config file������ GCmProperty�� �о���δ�. 
	*
	* @param		N/A
	* @return		N/A
	*/	
    private void loadConstantFile()
    {
		if (verbose)
			System.err.println("GCmConstManager : Constant defined file Loading.....");

		try
		{

			GCmProperties gplusProp = GCmPropertyManager.getInstance().getPropertyInstance(GROUPWARE_ID);

			Enumeration propName = gplusProp.propertyNames();

			for( ;propName.hasMoreElements(); ) 
			{
				boolean	validateToken = true;
				String keyToken = (String)propName.nextElement();

				StringTokenizer st = new StringTokenizer(keyToken, ".");

				while (st.hasMoreTokens() && validateToken) 
				{
					String token = (String)st.nextToken();

					if("gplus".compareToIgnoreCase(token) == 0)
					{
			   			while(st.hasMoreTokens())
						{
							token = (String)st.nextToken();	

					   		// ������� ������ ����ִ� ȭ���� ������ �д´�.			
					   		if("constant".compareToIgnoreCase(token) == 0)
					   		{
								loadConstant(gplusProp.getProperty(keyToken));
								validateToken = false;
							}
						}
					}
					else
					{
						validateToken = false;						
					}
				}
			}
		}
		catch(Exception e)
		{
			log.println(e);	
			System.err.println("GCmConstantManager : loadConstantFile error.");				
		}
    }
    
   /**
    * ������ǿ� ���� ������ ���� �ִ� ȭ�Ͽ���  
    * ������ �о� Property��ü loading
    *
	* @param	N/A
	* @return	N/A
	*/
    private void loadConstant(String constFile)
    {
		try
		{
			if (verbose)
				System.err.println("GCmConstManager : load Defined Constant  init");
						
			// load property information to the Dir
	    		loadFromFile(constFile);
		}
		catch(Exception e)
		{
			log.println(e);	
			System.err.println("GCmConstantManager : loadConstant error.");				
		}
	}
	
	
	/**
	 * ���ڿ��� �ش�Ǵ� �̹� ���ǵ� String�� ���
	 *
	 * @param	N/A
	 * @return	N/A
	 */
    public int getInt(String key)
    {
    	int constInt = 0;
    	
		try
		{
			constInt = super.getInt(key);
		}
		catch(Exception e)
		{
			log.println(e);	
		}
		
		return constInt;
	}
	

   /**
    * ���ڿ��� �ش�Ǵ� ���ǵ� ����� ���
    *
	* @param	N/A
	* @return	N/A
	*/
    public String getString(String key)
    {
    	String constString = null;
    	
		try
		{
			constString = super.getString(key);
		}
		catch(Exception e)
		{
			log.println(e);	
		}
		
		
		return constString;
	}

	public void saveToFile(String filePath)
	{
		super.saveToFile(filePath);		
	}

}
