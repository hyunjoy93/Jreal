package gplus.commlib;

import java.io.*;
import java.util.*;
import java.text.*;
import java.sql.*;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import gplus.commlib.comm.GCmConstDef;
import gplus.commlib.exception.GCmGplusException;
import gplus.commlib.log.GCmDebugLog;

/**
 * <PRE>
 * Filename : GCmLicenseManager.java
 * Class    : GCmLicenseManager
 * Function : ���� �ý����� ���̼��� üũ (�����, ��뷮)
 * Comment  :
 * History  : 12/10/2001, ���߱�, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */
public class GCmLicenseManager
{
	private static String SYS_PROPERTY_FILE = null;
	private static String GPLUSDIR = null;

	private static final boolean VERBOSE = false;					// used for debugging purpose
	private static final boolean DEBUG_1 = false;					// used for license constraints testing

	private static GCmLicenseManager m_instance;			// Singletone class
	private static int m_clients;

	private static Properties m_sysProp 	= new Properties();
	private static Properties m_licenseProp = new Properties();
	private static Properties m_currentProp = new Properties();


	/*
	 * Serial Number
	 */
	private static final String SERIAL_NUMBER 	= "G+20011202001";

	/*
	 * License Term
	 */
	private static final String SERIAL_NO			= "SN";		// Serial Number
	private static final String PRODUCT_TYPE		= "PT";		// ��ǰ ����
	private static final String EXPIRE_DATE			= "ED";	// Expiration Date
	private static final String USER_LIMIT			= "UL";	// user limit Date

	private static final String CODE_SEPARATOR              = "-";
	private static final String KEY_VALUE_SEPARATOR         = ":";
	private static final String SUB_VALUE_SEPARATOR	        = "`";

	private static final String GW_SINGLE_LIMIT_KEY         = "SINGLE_GW_LIMIT";
	private static final String GW_MULTY_LIMIT_KEY          = "MULTY_GW_LIMIT";
	private static final String UNLIMITED	                = "U";

	private static Vector vcNotStandardMenus = new Vector();

	/*
	 * RSA Encryption Terms
	 */
	private static long d = 50158807;
	private static long n = 54541453;

    /**
	 * GCmLicenseManager constructor<br>
     * A private constructor since this is a Singleton
     */
    protected GCmLicenseManager()
    {
		m_instance = null;
    }


	/**
	 * This class is singleton, so Returns the single instance,
	 * creating one if it's the first time this method is called.
     *
     * @return GCmLicenseManager The single instance.
     */
    public static synchronized GCmLicenseManager getInstance()
    {
        if (m_instance == null)
        {
            m_instance = new GCmLicenseManager();
        }
        m_clients++;
        return m_instance;
    }

    public static Properties getLicenseProp()
    {
        if (m_licenseProp == null)
        {
            try
            {
                m_instance.parseLicenseString();
            }
            catch(Exception e)
            {  }
        }
        return m_licenseProp;
    }


    /**
     * Loads properties and initializes the instance with its values.
     */
    public static void init(String gplusDir) throws GCmGplusException
	{
		if (m_instance == null)
		{
			if (VERBOSE)
			{
				System.err.println("GCmLicenseManager Initialized ...");
			}
                        GPLUSDIR = gplusDir;
			SYS_PROPERTY_FILE = gplusDir + File.separator + "gplus.properties";

			GCmDebugLog log = null;

			try
			{
	        		log = new GCmDebugLog(gplusDir + File.separator + "log" + File.separator + "gplus.log");
	                }
	        	catch (Exception e)
	        	{
	        		log = new GCmDebugLog(new PrintWriter(System.err));
	        	}

			log.println("SERIAL NO  : " + SERIAL_NUMBER);

			m_instance = new GCmLicenseManager();
			m_instance.loadSystemProperties();
			m_instance.loadCurrentStatusProperties();
			m_instance.parseLicenseString();
			m_instance.checkLegalUsing();

			if (VERBOSE)
			{
				System.err.println("CURRENT >>>>> " + m_instance.m_currentProp.toString());
				System.err.println("-----------------------------------------------------------------");
				System.err.println("LICENSE >>>>> " + m_instance.m_licenseProp.toString());
			}
		}
	}

	/**
	 * Load System Properties from file : gplus.properties
	 */
	private void loadSystemProperties()
	{
    	try
    	{
		    FileInputStream fin = new FileInputStream(SYS_PROPERTY_FILE);
		    m_sysProp.load(fin);
		    fin.close();

		    if (VERBOSE)
		    {
		    	System.err.println(m_sysProp);
		    }
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}


	/**
	 * Load properties which represents current status of installed gplus system
	 */
	private void loadCurrentStatusProperties() throws GCmGplusException
	{
		Connection conn = null;
		Statement  stmt = null;

		ResultSet userCnt = null;

		try
		{
			Class.forName(m_sysProp.getProperty("gplus.db.jdbcDriver"));

			String strUrl 		= m_sysProp.getProperty("gplus.db.jdbcUrl");
			String strUser 		= m_sysProp.getProperty("gplus.db.user");
			String strPasswd 	= m_sysProp.getProperty("gplus.db.password");

			conn = DriverManager.getConnection(strUrl, strUser, strPasswd);
			stmt = conn.createStatement();

			String strQuery = " select count(*) from tb_comm_z20 ";

			userCnt = stmt.executeQuery(strQuery);
                        if(userCnt.next()) {
 			    m_currentProp.put(USER_LIMIT, userCnt.getString(1));
			   // license�� üũ�ϱ� ���� ���� ����ڼ��� �ִ´�.
                        }
                        else {
 			    throw new GCmGplusException();
                        }

                        m_currentProp.put(EXPIRE_DATE, gplus.commlib.util.GCmDateFcts.dateToStr(new java.util.Date(),1));
                        // ����� ������ ����
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * Parse string which represents license features
	 */
	private void parseLicenseString() throws GCmGplusException
	{
		String strLicenseKey = getLicenseString();
		StringTokenizer st = new StringTokenizer(strLicenseKey, CODE_SEPARATOR);

		while (st.hasMoreTokens())
		{
			String strItem = st.nextToken();
			StringTokenizer stItem = new StringTokenizer(strItem, KEY_VALUE_SEPARATOR);

			String strKey = null;
			String strValue = null;

			if (stItem.countTokens() == 2)
			{
				strKey = (stItem.nextToken()).toUpperCase();
				strValue = stItem.nextToken().toUpperCase();

				m_licenseProp.put(strKey, strValue);
			}
			else
			{
				throw new GCmGplusException();
			}
		}

		if (VERBOSE)
		{
			System.err.println("PARSED : " + m_licenseProp.toString());
		}

	}


	/**
	 * Get license string from classes contains license key
	 *
	 * @return License Key String
	 */
	private String getLicenseString()
	{
		Properties licenseKeyProp = null;

		try
		{
			Class cLicense = Class.forName("GPlusLicense");

			Constructor ct = cLicense.getConstructor(null);
			Object objLicense = ct.newInstance(null);
			Method getLicenseKey = cLicense.getMethod("getLicenseKey", null);
			licenseKeyProp = (Properties) getLicenseKey.invoke(objLicense, null);

			if (VERBOSE)
			{
				System.err.println("KEY : " + decryptString(licenseKeyProp.getProperty("KEY")));
			}

			return decryptString(licenseKeyProp.getProperty("KEY"));
		}
		catch (ClassNotFoundException e)
		{
			System.err.println("License file does not exist or CLASSPATH is not correct");
			return null;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * Check GPlus user use package in legal.
	 *
	 * If user create lots of malls and shops without legal license,
	 * GPlus systems will be expired.
	 */
	private void checkLegalUsing() throws GCmGplusException
	{

		if ((m_licenseProp.getProperty(SERIAL_NO).toUpperCase().trim().equals(SERIAL_NUMBER)))
		{
			// If entered license was Evaluation version or Serial Number checking is success
		}
		else
		{
			throw new GCmGplusException();
		}

		if ((m_licenseProp.getProperty(EXPIRE_DATE).toUpperCase()).equals(UNLIMITED))
		{
		}
		else
		{
			int nCurrentDate = Integer.parseInt(m_currentProp.getProperty(EXPIRE_DATE));
			int nLicenseDate = Integer.parseInt(m_licenseProp.getProperty(EXPIRE_DATE));

			if (nCurrentDate > nLicenseDate)
			{
				throw new GCmGplusException();
			}
		}

		if ((m_licenseProp.getProperty(USER_LIMIT).toUpperCase()).equals(UNLIMITED))
		{
		}
		else
		{
			int nCurrentUser = Integer.parseInt(m_currentProp.getProperty(USER_LIMIT));
			int nLicenseUser = Integer.parseInt(m_licenseProp.getProperty(USER_LIMIT));

			if (nCurrentUser > nLicenseUser)
			{
				throw new GCmGplusException();
			}


		}

	}

	/**
	 * Check GPlus user use package in expiredate
	 * GPlus systems will be expired.
	 */
	public static void checkLegalDate() throws GCmGplusException
	{

		if ((m_licenseProp.getProperty(EXPIRE_DATE).toUpperCase()).equals(UNLIMITED))
		{
		}
		else
		{
		      GCmDebugLog log = null;
                      int nCurrentDate = 0;
                      int nLicenseDate = 0;

		      try {
 			    nCurrentDate = Integer.parseInt(gplus.commlib.util.GCmDateFcts.dateToStr(new java.util.Date(),1));
			    nLicenseDate = Integer.parseInt(m_licenseProp.getProperty(EXPIRE_DATE));
	        	    log = new GCmDebugLog(GPLUSDIR + File.separator + "log" + File.separator + "gplus.log");
	               }
	               catch (Exception e)
	               {
	        	   log = new GCmDebugLog(new PrintWriter(System.err));
	               }

			if (nCurrentDate > nLicenseDate)
			{
                             log.println("Your license Date is expired...");
        	             System.runFinalization();
                             System.exit(0);
                             throw new GCmGplusException();
			}
		}
	}


	public static Properties getlicenseprop()
	{
		return m_instance.m_licenseProp;
	}

	public static Properties getcurrentprop()
	{
		return m_instance.m_currentProp;
	}

	private static long computeModExp(long n, long e, long m)
	{
		long residue = 1;
		int i = 0;

		while (e > 0)
		{
			if (e % 2 == 1)
			{
				residue = (residue*n) % m;
			}

			if (residue < 0)
			{
				break;
			}

			n = (n * n) % m;

			e /= 2;

			i++;
		}
		return residue;
	}

	private static long computeEuclid(long a, long b)
	{
		long d 	= a;
		long d2 	= b;
		long u 	= 1;
		long u2 	= 0;
		long v 	= 0;
		long v2 	= 1;
		long q;


		while ( d2 != 0)
		{
			q = d / d2;

			long tmp;

			tmp = d;
			d = d2;
			d2 = tmp - d2 * q;

			tmp = u;
			u = u2;
			u2 = tmp - u2 * q;

			tmp = v;
			v = v2;
			v2 = tmp - v2 * q;
		}

		if (u < 0)
		{
			u = u + b;
		}

		return u;
	}



	private static String decryptString(String strEncrypted)
	{
		StringTokenizer st = new StringTokenizer(strEncrypted, "-");

		StringBuffer szBuff = new StringBuffer();

		for (int i = 0; st.hasMoreTokens(); i++)
		{
			String strCode = st.nextToken();
			szBuff.append((char) computeModExp(Long.parseLong(strCode), d, n));
		}

		return szBuff.toString();
	}

}