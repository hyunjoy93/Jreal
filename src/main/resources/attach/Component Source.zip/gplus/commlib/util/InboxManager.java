package gplus.commlib.util;



import java.io.*;
import javax.mail.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.mail.internet.*;

/**
 * <PRE>
 * Filename : InboxManager.java
 * Class    : InboxManager
 * Function : utility
 * Comment  :
 * History  : 2/16/2002, ������, �����ۼ� v1.0
 * </PRE>
 * @version   1.0
 * @author Copyright (c) 2001 by Korpa Corp. All Rights Reserved.
 */


public  class InboxManager implements HttpSessionBindingListener {
    
	
	static private Session session = Session.getDefaultInstance(System.getProperties(),null);
    private Store store;
    private Folder inbox;
    
	
	/**
     *<PRE>
     * ���������� ���� ������
	 * </PRE>
     * @param     url     URL
     */
    public  InboxManager(URLName url)
    throws NoSuchProviderException, MessagingException 
	{

        store = session.getStore(url);
        store.connect();
        inbox = store.getFolder("INBOX");

        try 
		{

            inbox.open(Folder.READ_WRITE);

        }
        catch (MessagingException e) 
		{

            //inbox.open(Folder.READ_ONLY);

        }
    
	}


	
	/**
	 * <PRE>
     * ����������
	 * </PRE>
     * @retrun Folder 
     */
    public Folder getInbox() 
	{
    
		return inbox;
    
	}
    
	
	
	/**
	 * <PRE>
     * ���������� ����
	 * </PRE>
     */
    public void setClose() 
	{
    
		try 
		{

            inbox.close(true);
            store.close();

        } 
		catch(MessagingException e) 
		{ 
		
		}
    
	}


	

	public void valueBound(HttpSessionBindingEvent event) 
	{

    }


	public void valueUnbound(HttpSessionBindingEvent event) 
	{
    
		try 
		{
            
			inbox.close(true);
            store.close();

        } 
		catch(MessagingException e) 
		{ 
		
		}

    }

}
